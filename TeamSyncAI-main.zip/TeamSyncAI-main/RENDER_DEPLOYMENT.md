# Render Deployment Guide for TeamSyncAI

## ✅ CRITICAL FIX APPLIED

**Login Issue Fixed:** The code has been updated with the following changes:
- Added `app.set('trust proxy', 1)` in production (server/routes.ts)
- Added `proxy: true` to session configuration (server/localAuth.ts)  
- Added `sameSite: 'lax'` to cookie settings

These changes allow Express to properly handle HTTPS connections when deployed behind Render's reverse proxy.

## Critical Environment Variables

Your login issue is likely caused by missing or incorrect environment variables on Render. Here are the **required** environment variables:

### 1. Session Configuration (CRITICAL for Login)
```
SESSION_SECRET=your-secure-random-string-here
```
**Important:** This MUST be set to a long, random, secure string. Generate one using:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### 2. Database Configuration
```
DATABASE_URL=your-postgresql-connection-string
PGHOST=your-db-host
PGPORT=5432
PGDATABASE=your-db-name
PGUSER=your-db-user
PGPASSWORD=your-db-password
```

### 3. Twilio SMS (Required for SMS features)
```
TWILIO_ACCOUNT_SID=your-twilio-account-sid
TWILIO_AUTH_TOKEN=your-twilio-auth-token
TWILIO_PHONE_NUMBER=your-twilio-phone-number
```

### 4. Google Gemini AI (Required for AI features)
```
GEMINI_API_KEY=your-gemini-api-key
```

### 5. Object Storage (Optional but recommended)
```
DEFAULT_OBJECT_STORAGE_BUCKET_ID=your-bucket-id
PUBLIC_OBJECT_SEARCH_PATHS=public
PRIVATE_OBJECT_DIR=.private
```

### 6. Node Environment
```
NODE_ENV=production
```

## Common Login Issues on Render

### Issue 1: SESSION_SECRET Not Set
**Symptom:** POST /api/login returns 500 error with "Login failed"
**Solution:** Set SESSION_SECRET environment variable in Render dashboard (generate with `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`)

### Issue 2: Database Connection Issues
**Symptom:** Login fails with 500 error, logs show session store errors
**Common Causes:**
- DATABASE_URL is incorrect or missing
- Database is not accessible from Render
- Session table doesn't exist (should auto-create with latest code)

**Solution:** 
1. Verify DATABASE_URL format in Render dashboard
2. Check Render logs for "Session store error" or database connection errors
3. Ensure database is running and network accessible from Render

### Issue 3: Cookie/CORS Issues
**Symptom:** Login appears to work but doesn't persist, redirects back to login
**Check:** Ensure your Render URL matches what users are accessing (http vs https)

The session cookie configuration requires HTTPS in production:
```javascript
cookie: {
  secure: process.env.NODE_ENV === 'production',  // Requires HTTPS
  httpOnly: true,
  sameSite: 'lax',  // Required for cross-site cookies
  maxAge: 7 * 24 * 60 * 60 * 1000  // 7 days
}
```

**Solution:** 
- Make sure you're accessing your app via HTTPS on Render (not HTTP)
- Render automatically provides HTTPS for `.onrender.com` domains
- Clear browser cookies and try again

### Issue 4: Build Configuration
Make sure your `render.yaml` or build settings include:
```yaml
buildCommand: npm install
startCommand: npm start
```

**⚠️ WARNING:** Do NOT include `db:push --force` in your build command! The `--force` flag can cause destructive database operations that delete your data. Only run schema migrations manually when you intentionally make schema changes.

## Debugging Steps (Read Render Logs!)

The application now includes detailed logging. After deploying, check your Render logs for:

### 1. Startup Logs (Should See):
```
Initializing session store with database: postgresql://***:***@your-host/dbname
[express] Checking for teams without default roles...
[express] Default roles initialization complete
[express] serving on port 5000
```

### 2. Login Attempt Logs (Should See):
```
Login attempt for email: user@example.com
Login successful for user@example.com
POST /api/login 200
```

### 3. Error Logs (If Something's Wrong):
```
Session store error: <database error details>
Passport authentication error: <auth error details>
Session login error: <login error details>
Login failed: Invalid credentials for user@example.com
```

### What to Check in Render Dashboard:

1. **Environment Tab:**
   - [ ] SESSION_SECRET is set (required!)
   - [ ] DATABASE_URL is set and correct
   - [ ] NODE_ENV=production is set

2. **Logs Tab:**
   - Try to login while watching logs in real-time
   - Look for "Session store error", "Passport authentication error", or "Session login error"
   - Check if you see "Login attempt for email: ..." (if not, request isn't reaching the server)

3. **Database:**
   - Verify your PostgreSQL database is running
   - Check that you can connect to it from outside Render (if external database)
   - Verify the `sessions` table exists (should auto-create)

4. **HTTPS Access:**
   - Ensure you're accessing `https://your-app.onrender.com` not `http://...`
   - Clear browser cookies before testing

## Quick Fix Checklist

- [ ] Set SESSION_SECRET in Render environment variables
- [ ] Verify DATABASE_URL is correct
- [ ] Confirm NODE_ENV=production is set
- [ ] Access app via HTTPS (https://your-app.onrender.com)
- [ ] Check Render logs for errors
- [ ] Verify database is running and accessible
- [ ] Ensure all Twilio and Gemini API keys are set if using those features

## Testing Login After Deployment

1. Clear browser cookies
2. Navigate to `https://your-app.onrender.com`
3. Try to login with existing credentials
4. Check browser developer console for errors
5. Check Render service logs for backend errors

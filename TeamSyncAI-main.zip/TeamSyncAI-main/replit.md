# TeamSyncAI

## Overview
TeamSyncAI is a Progressive Web App (PWA) that automates team management for amateur sports coaches. It acts as an "Assistant Manager" bot, using AI to communicate with players via SMS for availability confirmation, attendance tracking, and player reliability monitoring. The app reduces manual effort by automating customizable reminder campaigns based on player reliability scores. It is installable on mobile, works offline, and plans to monetize through a flexible membership system. The project aims to simplify coaching logistics and improve team communication.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### UI/UX Decisions
The frontend uses React, TypeScript, Vite, `shadcn/ui` (Radix UI), and Tailwind CSS. It features a design system combining Linear's typography with Material Design, supporting light/dark themes, responsive layouts, and mobile-first design with distinct navigation patterns for desktop and mobile. Fluid typography and responsive input/button components ensure a consistent user experience across devices.

### Technical Implementations
The backend is a Node.js Express.js server in TypeScript, using a RESTful API with shared TypeScript schemas. Authentication is handled via local username/password with Passport.js and bcrypt, using PostgreSQL for server-side session management. The system incorporates Role-Based Permissions (Coach, Assistant Coach, Player, Global Admin). Key features include:
- **Parent Profile System:** Allows parents to manage child player details and RSVP on their behalf.
- **Invitation Workflow:** Streamlined process for invited users to join teams directly.
- **Duplicate Player Prevention:** Canonical contact matching prevents duplicate player records during invitations.
- **Landing Page Management:** Global admins can edit landing page content via the Admin UI.
- **Test View Filtering:** Enables simulation of different user roles (coach/player/viewer) with appropriate data filtering.
- **Phone Number Formatting:** Automatic formatting and E.164 normalization for reliable SMS delivery and improved UX.
- **Mobile-First Responsive Design:** Comprehensive responsive design with fluid typography, responsive layouts, and persistent sidebar state.
- **Shared & Dedicated SMS Infrastructure (TCPA Compliance):** All teams start with a shared Twilio phone number (`+18556773180`) for immediate SMS capability. Teams can optionally provision dedicated Twilio phone numbers through the Phone Number Management UI for TCPA-compliant multi-tenant SMS. The system includes opt-out tracking and detailed message logging. The SMS webhook uses message logs to determine which team an incoming message belongs to when using the shared number.
- **Admin UI for Phone Number Management:** Team owners can provision, configure, and release dedicated Twilio numbers, view message statistics, and audit message logs. Until a dedicated number is provisioned, all teams use the shared number `+18556773180`.
- **Consolidated Roster & Invitations Interface:** Unifies all player import and invitation methods (individual, CSV, contacts, bulk send) into a single tabbed interface.
- **Pay-Per-Usage Billing System:** Tracks SMS usage and calculates costs with fixed-precision decimals, providing team usage dashboards and campaign cost estimations.
- **Campaign Template Management:** Global admins can create and manage reusable SMS campaign templates with customizable reminders, merge variables, and reliability-based targeting. Admin-created templates are globally available to all coaches, appearing alongside team-specific templates when creating campaigns.
- **Team Instance Branding:** Team owners can customize their instance name (e.g., "Hawks Manager", "Tigers Team Central") via Settings > Team Branding. The sidebar displays `team.instanceName` if set, otherwise falls back to the global `appName` (not the team name), ensuring new teams show the application name until explicitly customized.
- **Multi-Provider SMS Abstraction:** The system supports multiple SMS providers (Twilio, Plivo) through a clean abstraction layer. Providers can be switched via environment variable (SMS_PROVIDER) without code changes, enabling cost optimization before full launch. See SMS_PROVIDER_GUIDE.md for details.
- **Admin Notification System:** Global admins receive automatic notifications when new users sign up. The system tracks notification type, message content, read status, and timestamps. Admins can view all notifications at /admin/notifications, mark individual notifications as read, or mark all as read. The sidebar displays an unread count badge for quick visibility. MVP implementation suitable for single-admin environments; future enhancement planned for per-admin read tracking and pagination.
- **Admin User Management:** Global admins can promote or demote other users to/from global admin status via /admin/users. Security-hardened implementation prevents self-demotion and ensures at least one global admin always remains in the system. Automatic admin promotion on server startup allows designated emails (configured in server/index.ts) to be auto-promoted to global admin on first login, solving deployment scenarios where database shell access is restricted.
- **Public Marketing Pages:** Comprehensive public-facing website with five pages (/about, /features, /pricing, /contact, and enhanced landing page) for user acquisition. All pages use consistent navigation, SPA routing via Wouter, and comprehensive data-testid attributes for testing. The contact page includes a functional contact form with email/phone support information. All pages share the same design system with responsive layouts optimized for mobile and desktop. **Organization logo consistency**: All marketing pages display the same organization logo uploaded via the landing page editor. The logo is fetched from the landing page content and automatically appears in the header of all marketing pages (/landing, /about, /features, /pricing, /contact) through a shared useOrganizationLogo hook.
- **Editable Marketing Content:** Global admins can edit all public marketing page content through the Admin Center (/admin/marketing). Single-table architecture stores page-specific JSON content with specialized Zod schemas for type safety. Public pages fetch content via API (GET /api/marketing-pages/:page) with graceful fallback to defaults. Admin UI provides tabbed interface for editing About, Features, and Contact pages with real-time validation and preview capabilities.
- **Integrated Pricing Data:** The public pricing page (/pricing) is directly integrated with the membership tier system. Pricing information automatically displays active membership tiers with their configured prices, features, and limits from the admin-managed membership tiers (Admin Center → Settings → Membership Tiers). This eliminates duplicate data entry and ensures pricing consistency across the application. The public pricing page fetches data via GET /api/public/membership-tiers (no authentication required for marketing pages).
- **Google Maps Places Autocomplete:** Location fields use Google Maps Places API for address autocomplete. When creating events, coaches can search for venues and addresses with real-time suggestions. The component gracefully degrades to manual entry if the API is unavailable, and shows previously used locations for quick selection. API key stored in VITE_GOOGLE_MAPS_API_KEY.
- **Event Editing:** Coaches and team owners can edit existing events via the Edit Event button on the event detail page (/events/:id). The edit form pre-populates with existing event data including custom field values. The PATCH /api/events/:id endpoint uses Zod validation to ensure type safety and blocks modification of immutable fields (teamId, id, sequence, createdAt). Requires canManageEvents permission.
- **Centralized Sport Configuration:** Available sports are controlled globally via Admin Center → Settings. The `availableSports` field in `app_settings` table determines which sports appear in dropdowns app-wide (event creation, event editing, team creation, onboarding). The `useAvailableSports` hook fetches configured sports from `/api/app-settings` with fallback to full `AVAILABLE_SPORTS` constant. Global admins can add/remove sports from the admin settings page.
- **Privacy Policy Page:** Public privacy policy accessible at /privacy route with TCPA-compliant SMS/Mobile Privacy Clause. All marketing pages (landing, about, features, pricing, contact) include a footer link to the privacy policy.
- **Customizable Team Invitation Messages:** Team coaches can customize the SMS message sent when inviting players via Team Settings → Invitation Message. Templates support merge variables ({teamName}, {roleName}, {coachName}, {playerName}, {inviteUrl}). The {inviteUrl} variable is required for the invitation link. Custom templates are used across all invitation mechanisms (individual invitations, resend invitations, bulk send). UI provides variable insertion badges and live preview.

### Feature Specifications
The application includes iCalendar subscription, comprehensive team and event management (with attendance tracking, bulk CSV operations, and invitations), dual-level logo management, location autocomplete, and advanced reminder campaigns with reliability-based targeting. It supports event and campaign templates, custom event fields, and PWA offline capabilities. A message board, admin settings for global configuration, a membership tier system, and a unified tasks system are also included. Tier-gated AI-powered lineup management (for Baseball/Softball) uses Gemini AI, and a robust CSV roster management system facilitates player data import/export. A Helcim-powered payment system enables coaches to send payment requests and receive automated confirmations.

**Campaigns can be event-based or standalone**: Campaigns may optionally link to an event (for time-based reminders) or exist independently (for general team announcements). The scheduler handles both types, with standalone campaigns unable to send time-based reminders. The system supports 15+ merge variables including team-level variables ({teamName}, {coachName}) and event-specific variables.

### System Design Choices
A cron-based scheduler handles SMS reminders. Database operations are abstracted via an `IStorage` interface. API endpoints are secured with permission middleware (`requirePermission`, `requirePermissionForEvent`, `requireGlobalAdmin`). Security filters ensure users access only authorized data. The backend uses a RESTful API, with idempotent processing and race-condition protection for payment webhooks.

## External Dependencies

-   **Twilio:** SMS messaging.
-   **Helcim:** Payment processing (HelcimPay.js, webhooks).
-   **Google Gemini AI:** Natural language processing and AI lineup generation.
-   **Google Maps Places API:** Location autocomplete for event creation.
-   **UploadThing:** File uploads for logos and documents.
-   **PostgreSQL (Neon serverless):** Primary database.
-   **Drizzle ORM:** Database interactions.
-   **UI Component Libraries:** Radix UI, Lucide React, date-fns, React Hook Form with Zod.
-   **Papa Parse:** CSV parsing.
# Player Import Guide for TeamSyncAI

This guide explains all the different ways to add players to your team roster in TeamSyncAI. All import methods are consolidated in the **"Manage Roster & Invitations"** section on your team's detail page.

---

## Overview of Import Methods

TeamSyncAI provides **4 different ways** to add players to your roster:

1. **Individual Invitation** - Send a single invitation via SMS or email
2. **CSV Import** - Bulk import players from a spreadsheet file
3. **Import from Contacts** - Select players directly from your device contacts
4. **Bulk Send Invitations** - Send invitations to all existing roster players at once

Each method is designed for different scenarios. Choose the one that best fits your needs.

---

## Method 1: Individual Invitation

**Best for:** Adding one player at a time, sending personalized invitations

### Step-by-Step Instructions:

1. **Navigate to your team's page**
   - From the dashboard, click on your team name
   - Scroll to the "Manage Roster & Invitations" card

2. **Select the "Individual" tab**
   - This tab is selected by default
   - You'll see a form for sending individual invitations

3. **Choose your contact method**
   - Click the "Send Via" dropdown
   - Select either:
     - **SMS** - For phone number invitations (recommended for faster response)
     - **Email** - For email invitations

4. **Enter contact information**
   - **For SMS:** Enter the phone number in any format
     - Examples: (555) 123-4567, 555-123-4567, or +15551234567
     - The system automatically formats phone numbers
   - **For Email:** Enter a valid email address

5. **Assign a role**
   - Click the "Assign Role" dropdown
   - Select the appropriate role (e.g., Player, Coach, Assistant Coach)
   - The invitee will be assigned this role when they accept

6. **Send the invitation**
   - Click "Send Invitation" button
   - A confirmation message will appear
   - The invitation will appear in the "Pending Invitations" list below

### What happens next:
- The recipient receives an SMS or email with a link to accept the invitation
- When they click the link, they can sign up or log in
- After accepting, they'll appear in your team roster
- You'll see the status change from "Pending" to "Accepted" in the invitations list

---

## Method 2: CSV Import

**Best for:** Bulk importing many players at once, migrating from spreadsheets or other systems

### Step-by-Step Instructions:

1. **Navigate to the "CSV Import" tab**
   - Go to your team's page
   - Find the "Manage Roster & Invitations" card
   - Click the "CSV Import" tab

2. **Download the CSV template (first time only)**
   - Click "Download CSV Template" button
   - Save the file to your computer
   - Open it in Excel, Google Sheets, or any spreadsheet program

3. **Fill out the template**
   - **Required columns:**
     - `firstName` - Player's first name
     - `lastName` - Player's last name
     - `phone` - Phone number in any format
   
   - **Optional columns:**
     - `email` - Email address
     - `position` - Playing position (e.g., Forward, Goalie)
     - `jerseyNumber` - Jersey/uniform number
     - `dateOfBirth` - Date of birth (YYYY-MM-DD format)
   
   - **Example row:**
     ```
     firstName,lastName,phone,email,position,jerseyNumber,dateOfBirth
     John,Smith,(555) 123-4567,john@example.com,Forward,12,2005-03-15
     Jane,Doe,555-234-5678,jane@example.com,Defender,7,2006-07-22
     ```

4. **Save your CSV file**
   - Keep the first row as headers
   - Each subsequent row is one player
   - Save as CSV format (.csv file extension)

5. **Upload the file**
   - Click "Upload CSV File" button
   - Select your filled-out CSV file
   - Click "Open" or "Choose" (depending on your browser)

6. **Wait for import to complete**
   - You'll see "Importing..." on the button
   - A success message appears when complete
   - All players are added to your roster immediately

### CSV Format Tips:
- Phone numbers can be in any format - the system normalizes them automatically
- Leave optional fields blank if you don't have the information
- Date of birth must be in YYYY-MM-DD format (e.g., 2005-03-15)
- Don't include extra columns not in the template
- Maximum recommended: 200 players per file

### Troubleshooting CSV Import:
- **"Invalid file format"** - Make sure you saved as .csv, not .xlsx or .xls
- **"Missing required fields"** - Ensure firstName, lastName, and phone are filled for every row
- **"Invalid phone number"** - Check that phone numbers have at least 10 digits
- **"Import failed"** - Check that the first row contains the exact column names from the template

---

## Method 3: Import from Contacts

**Best for:** Quick imports on mobile devices, adding players whose contacts you already have

### Step-by-Step Instructions:

1. **Navigate to the "Contacts" tab**
   - Go to your team's page
   - Find the "Manage Roster & Invitations" card
   - Click the "Contacts" tab

2. **Click "Open Contact Picker"**
   - This opens your device's native contact picker
   - Note: This feature works best on mobile devices and modern browsers

3. **Select contacts**
   - Browse or search for the contacts you want to add
   - You can select multiple contacts at once
   - Tap/click each contact to select them

4. **Confirm your selection**
   - Click "Done" or "Select" (depending on your device)
   - The selected contacts are imported immediately

5. **Review imported players**
   - Players appear in your roster with their contact name and phone number
   - You can edit additional details (position, jersey number, etc.) later

### Browser Compatibility:
- **Works on:** iOS Safari, Android Chrome, Chrome on desktop (recent versions)
- **May not work on:** Older browsers, Firefox (depending on version)
- **Fallback:** If contact picker doesn't work, use CSV Import or Individual Invitation instead

### Privacy Note:
- TeamSyncAI never stores your full contact list
- Only the contacts you explicitly select are imported
- Contact access is granted temporarily and only when you click the button

---

## Method 4: Bulk Send Invitations

**Best for:** Sending invitations to an existing roster after CSV import, re-inviting players who haven't accepted

### Step-by-Step Instructions:

1. **Add players to your roster first**
   - Use CSV Import, Individual Invitation, or Import from Contacts
   - Make sure all players you want to invite are in your roster

2. **Navigate to the "Bulk Send" tab**
   - Go to your team's page
   - Find the "Manage Roster & Invitations" card
   - Click the "Bulk Send" tab

3. **Review who will receive invitations**
   - The tab shows how many players are in your roster
   - Invitations are sent to all players who:
     - Have a valid phone number or email
     - Haven't already accepted an invitation

4. **Click "Send Invitations to All"**
   - A single click sends invitations to all eligible players
   - You'll see "Sending..." while the system processes

5. **Wait for confirmation**
   - A success message appears when all invitations are sent
   - Check the "Pending Invitations" list to see who was invited

### Important Notes:
- Players with invalid or missing contact info are skipped
- Players who already accepted invitations won't receive duplicates
- Each player receives one invitation to the email or phone on file
- You can resend individual invitations from the "Pending Invitations" list

---

## Managing Pending Invitations

After sending invitations using any method, you can track and manage them in the **"Pending Invitations"** section at the bottom of the "Manage Roster & Invitations" card.

### Invitation Statuses:

- **Pending** (Orange badge) - Invitation sent, waiting for acceptance
- **Accepted** (Green badge) - Player accepted and joined the team
- **Expired** (Gray badge) - Invitation expired after 7 days

### Actions You Can Take:

**For Pending Invitations:**
- **Resend** (↻ icon) - Send the invitation again if player didn't receive it
- **Cancel** (✕ icon) - Cancel the invitation if it was sent by mistake

**For Accepted Invitations:**
- View when they accepted (shown as "Accepted [date]")
- These players are now active members in your roster

---

## Additional Methods: Manual Player Addition

You can also add players directly to your roster **without sending an invitation** using the traditional player form:

### When to use this method:
- You have all player details and want to add them directly
- You want to configure advanced settings (reliability score, batting/pitching order)
- You prefer not to send invitations

### How to add players manually:

1. **Scroll to the Roster section**
2. **Click "Add Player" button** (green button with + icon)
3. **Fill out the player form:**
   - Required: First name, last name, phone number
   - Optional: Email, date of birth, position, jersey number, reliability score, role
4. **Optional: Toggle "Send Invitation"** if you want them to accept and sign documents
5. **Click "Add Player"** to save

This method gives you full control over all player details from the start.

---

## Frequently Asked Questions

### Q: Which import method should I use?

**A:** It depends on your situation:
- **New team with a list of players?** → Use CSV Import
- **Adding one or two players?** → Use Individual Invitation
- **On your phone with contacts saved?** → Use Import from Contacts
- **Already have a roster, need invites?** → Use Bulk Send Invitations

### Q: Can I combine multiple import methods?

**A:** Yes! You can use CSV Import to add your roster, then use Individual Invitation to add new players later, and Bulk Send to invite everyone at once.

### Q: What's the difference between adding a player and sending an invitation?

**A:** 
- **Adding a player** puts them in your roster immediately (they can't log in or interact)
- **Sending an invitation** allows them to accept, create an account, sign documents, and RSVP to events

### Q: Can I edit player information after importing?

**A:** Yes! Click the "Edit" button next to any player in the roster to update their information.

### Q: What happens if I upload a CSV with duplicate players?

**A:** The system checks for duplicates by phone number. If a player already exists, they are skipped and not duplicated.

### Q: Can I delete players after importing them?

**A:** Yes, click the trash icon (🗑️) next to any player in the roster to remove them.

### Q: What if a player doesn't accept the invitation?

**A:** Invitations expire after 7 days. You can resend the invitation from the "Pending Invitations" list, or cancel it and send a new one.

### Q: Can I see which players have accepted invitations?

**A:** Yes, check the "Pending Invitations" section. Accepted invitations show a green "Accepted" badge with the date.

---

## Tips for Success

1. **Start with CSV Import for new teams** - It's the fastest way to add many players
2. **Use Individual Invitations for ongoing additions** - Perfect for new players joining mid-season
3. **Keep your CSV template** - Reuse it each season, just update the data
4. **Export your roster regularly** - Click "Export CSV" in the roster header to backup your data
5. **Send bulk invitations after CSV import** - Import first, then invite everyone at once
6. **Double-check phone numbers** - Valid phone numbers ensure SMS invitations work correctly
7. **Use the "Resend" button sparingly** - Wait at least 24 hours before resending to avoid spam

---

## Need Help?

If you encounter issues with any import method:

1. **Check the error message** - Most errors explain what went wrong
2. **Verify your data format** - Especially for CSV imports
3. **Try a different method** - If CSV doesn't work, try Individual Invitation
4. **Use manual player addition** - As a fallback, you can always add players one-by-one using the traditional form

---

**Last Updated:** November 2025  
**For:** TeamSyncAI v1.0

#!/usr/bin/env node

/**
 * One-time migration script to add api_key and webhook_secret columns
 * to payment_providers table in production database
 * 
 * Run this in Render Shell: node migrate-payment-columns.js
 */

import pg from 'pg';
const { Pool } = pg;

async function migrate() {
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
  });

  try {
    console.log('🔍 Checking current payment_providers schema...');
    
    // Check existing columns
    const columnsResult = await pool.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'payment_providers'
      ORDER BY ordinal_position;
    `);
    
    console.log('📋 Current columns:', columnsResult.rows.map(r => r.column_name).join(', '));
    
    const hasApiKey = columnsResult.rows.some(r => r.column_name === 'api_key');
    const hasWebhookSecret = columnsResult.rows.some(r => r.column_name === 'webhook_secret');
    
    if (hasApiKey && hasWebhookSecret) {
      console.log('✅ Columns already exist! No migration needed.');
      await pool.end();
      return;
    }
    
    console.log('🔨 Adding missing columns...');
    
    // Add columns safely (IF NOT EXISTS handles duplicate runs)
    await pool.query(`
      ALTER TABLE payment_providers 
      ADD COLUMN IF NOT EXISTS api_key TEXT,
      ADD COLUMN IF NOT EXISTS webhook_secret TEXT;
    `);
    
    console.log('✅ Migration complete!');
    
    // Verify the changes
    const verifyResult = await pool.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'payment_providers'
      ORDER BY ordinal_position;
    `);
    
    console.log('📋 Updated columns:', verifyResult.rows.map(r => r.column_name).join(', '));
    
    await pool.end();
    console.log('🎉 Done! You can now redeploy your service.');
    
  } catch (error) {
    console.error('❌ Migration failed:', error.message);
    await pool.end();
    process.exit(1);
  }
}

migrate();

# 🚀 DEPLOY TO RENDER - Quick Guide

## What I Just Fixed

I've added comprehensive logging to help diagnose your login issue on Render. The code will now tell us exactly what's failing.

## Steps to Deploy

### 1. Commit and Push Your Code
```bash
git add .
git commit -m "Add authentication debugging and fix session configuration"
git push origin main
```

### 2. Wait for Render to Deploy
- Go to your Render dashboard
- You should see "Deploying..." status
- Wait for it to show "Live" (usually 2-3 minutes)

### 3. Check the Logs (IMPORTANT!)

Once deployed, go to **Render Dashboard → Your Service → Logs** and look for these startup messages:

✅ **Good - You should see:**
```
[AUTH] Initializing session store with database: postgresql://***:***@...
[AUTH] Session configuration: production=true, proxy=true
[express] serving on port 5000
```

❌ **Bad - If you see:**
```
Error: SESSION_SECRET environment variable is required
```
→ You need to add SESSION_SECRET in Render's Environment tab

❌ **Bad - If you see:**
```
Error: DATABASE_URL environment variable is required
```
→ You need to add DATABASE_URL in Render's Environment tab

### 4. Try to Login

With the logs tab open, try to login. You should see:

✅ **Success:**
```
Login attempt for email: your@email.com
Login successful for your@email.com
POST /api/login 200
```

❌ **Wrong password:**
```
Login attempt for email: your@email.com
Login failed: Invalid credentials for your@email.com
POST /api/login 401
```

❌ **Session/database error:**
```
[AUTH] Session store error: <error details>
POST /api/login 500
```

## Required Environment Variables on Render

Make sure these are set in **Render Dashboard → Environment**:

### Critical (Required for Login):
```
SESSION_SECRET=<generate with: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))">
DATABASE_URL=<your-postgresql-connection-string>
NODE_ENV=production
```

### Optional (for full functionality):
```
TWILIO_ACCOUNT_SID=<your-twilio-sid>
TWILIO_AUTH_TOKEN=<your-twilio-token>
TWILIO_PHONE_NUMBER=<your-twilio-number>
GEMINI_API_KEY=<your-gemini-key>
```

## What to Tell Me

After deploying, tell me:
1. Did you see the `[AUTH] Initializing session store...` message in Render logs?
2. What happens when you try to login? (Copy the exact log messages)

## Common Issues

### "I don't see [AUTH] logs"
- Your deployment didn't include the latest code
- Try: `git status` to check if you have uncommitted changes
- Try: Force redeploy in Render dashboard

### "Login still returns 500 error"
- Check Render logs for the EXACT error message
- Most likely: SESSION_SECRET is missing or DATABASE_URL is wrong
- The new logs will tell us exactly what's failing

## Need Help?

Copy and paste the EXACT error messages from your Render logs and I can help diagnose the issue.

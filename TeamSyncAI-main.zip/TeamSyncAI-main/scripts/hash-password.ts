import bcrypt from "bcrypt";
import { db } from "../server/db";
import { users } from "../shared/schema";
import { eq } from "drizzle-orm";

async function hashAndUpdatePassword(email: string, newPassword: string) {
  try {
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    
    const result = await db
      .update(users)
      .set({ password: hashedPassword })
      .where(eq(users.email, email))
      .returning();

    if (result.length === 0) {
      console.error(`❌ User with email ${email} not found`);
      process.exit(1);
    }

    console.log(`✅ Password successfully updated for ${email}`);
    console.log(`Hashed password: ${hashedPassword}`);
    console.log(`\nYou can now log in with:`);
    console.log(`  Email: ${email}`);
    console.log(`  Password: ${newPassword}`);
    
    process.exit(0);
  } catch (error) {
    console.error("❌ Error updating password:", error);
    process.exit(1);
  }
}

const email = process.argv[2];
const password = process.argv[3];

if (!email || !password) {
  console.error("Usage: npm run hash-password <email> <password>");
  console.error("Example: npm run hash-password matt@gatewayap.com myNewPassword123");
  process.exit(1);
}

hashAndUpdatePassword(email, password);

import { Switch, Route, useLocation } from "wouter";
import { useEffect, useState } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { MobileNav } from "@/components/mobile-nav";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";
import { PWAInstallPrompt } from "@/components/pwa-install-prompt";
import { TestViewProvider } from "@/contexts/TestViewContext";
import { TestViewControls, TestViewBanner } from "@/components/TestViewControls";
import { useAuth } from "@/hooks/useAuth";
import Landing from "@/pages/landing";
import About from "@/pages/about";
import Features from "@/pages/features";
import Pricing from "@/pages/pricing";
import Contact from "@/pages/contact";
import Privacy from "@/pages/privacy";
import Login from "@/pages/login";
import Register from "@/pages/register";
import ForgotPassword from "@/pages/forgot-password";
import ResetPassword from "@/pages/reset-password";
import Onboarding from "@/pages/onboarding";
import Dashboard from "@/pages/dashboard";
import Teams from "@/pages/teams";
import TeamDetail from "@/pages/team-detail";
import TeamPayments from "@/pages/team-payments";
import Events from "@/pages/events";
import CreateEvent from "@/pages/create-event";
import EditEvent from "@/pages/edit-event";
import EventDetail from "@/pages/event-detail";
import PostGame from "@/pages/post-game";
import Campaigns from "@/pages/campaigns";
import MessageBoard from "@/pages/message-board";
import Tasks from "@/pages/tasks";
import Settings from "@/pages/settings";
import AdminSettings from "@/pages/admin-settings";
import AdminNotifications from "@/pages/admin-notifications";
import AdminUserManagement from "@/pages/admin-user-management";
import AdminMarketingContent from "@/pages/admin-marketing-content";
import Membership from "@/pages/membership";
import Notifications from "@/pages/notifications";
import InviteAccept from "@/pages/invite-accept";
import GuestPayment from "@/pages/guest-payment";
import ProfileEdit from "@/pages/profile-edit";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/onboarding" component={Onboarding} />
      <Route path="/invite/:token" component={InviteAccept} />
      <Route path="/profile" component={ProfileEdit} />
      <Route path="/tasks" component={Tasks} />
      <Route path="/notifications" component={Notifications} />
      <Route path="/teams" component={Teams} />
      <Route path="/teams/:id" component={TeamDetail} />
      <Route path="/teams/:teamId/payments" component={TeamPayments} />
      <Route path="/teams/:teamId/message-board" component={MessageBoard} />
      <Route path="/events" component={Events} />
      <Route path="/events/new" component={CreateEvent} />
      <Route path="/events/:id/edit" component={EditEvent} />
      <Route path="/events/:id/post-game" component={PostGame} />
      <Route path="/events/:id" component={EventDetail} />
      <Route path="/campaigns" component={Campaigns} />
      <Route path="/membership" component={Membership} />
      <Route path="/settings" component={Settings} />
      <Route path="/admin" component={AdminSettings} />
      <Route path="/admin/notifications" component={AdminNotifications} />
      <Route path="/admin/users" component={AdminUserManagement} />
      <Route path="/admin/marketing" component={AdminMarketingContent} />
      <Route component={NotFound} />
    </Switch>
  );
}

function PublicRouter() {
  return (
    <Switch>
      <Route path="/about" component={About} />
      <Route path="/features" component={Features} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/contact" component={Contact} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/forgot-password" component={ForgotPassword} />
      <Route path="/reset-password" component={ResetPassword} />
      <Route path="/invite/:token" component={InviteAccept} />
      <Route path="/pay/:token" component={GuestPayment} />
      <Route component={Landing} />
    </Switch>
  );
}

function AuthenticatedApp() {
  const [defaultOpen, setDefaultOpen] = useState(() => {
    const cookies = document.cookie.split('; ');
    const sidebarCookie = cookies.find(c => c.startsWith('sidebar_state='));
    
    if (sidebarCookie) {
      return sidebarCookie.split('=')[1] === 'true';
    }
    
    const isDesktop = window.matchMedia('(min-width: 768px)').matches;
    const maxAge = 60 * 60 * 24 * 7;
    document.cookie = `sidebar_state=${isDesktop}; path=/; max-age=${maxAge}`;
    return isDesktop;
  });
  
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as any} defaultOpen={defaultOpen}>
      <div className="flex h-screen w-full overflow-hidden">
        <AppSidebar />
        <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
          <TestViewBanner />
          <header className="flex items-center justify-between px-4 sm:px-6 py-3 border-b bg-background">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <ThemeToggle />
          </header>
          <main className="flex-1 overflow-auto px-4 py-4 sm:px-6 sm:py-6">
            <Router />
          </main>
        </div>
      </div>
      <MobileNav />
      <TestViewControls />
    </SidebarProvider>
  );
}

function AppContent() {
  const { isAuthenticated, isLoading, user } = useAuth();
  const [location, setLocation] = useLocation();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <PublicRouter />;
  }

  // Sport selection is optional - only team owners need it when creating teams
  // No mandatory redirect to onboarding

  return <AuthenticatedApp />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <TestViewProvider>
            <AppContent />
            <Toaster />
            <PWAInstallPrompt />
          </TestViewProvider>
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, MessageSquare, Calendar, TrendingUp, Bell, Zap, Shield, Database, Settings, CreditCard, BarChart, CheckCircle } from "lucide-react";
import { useAppName } from "@/hooks/useAppName";
import { useOrganizationLogo } from "@/hooks/useOrganizationLogo";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import type { FeaturesPageContent } from "@shared/schema";
import { MarketingFooter } from "@/components/marketing-footer";

const iconMap = {
  MessageSquare,
  Calendar,
  TrendingUp,
  Bell,
  Zap,
  Users,
  Database,
  CreditCard,
  BarChart,
  Shield,
  Settings,
  CheckCircle,
};

const defaultContent: FeaturesPageContent = {
  heroTitle: "Everything You Need to Manage Your Team",
  heroSubtitle: "From automated SMS reminders to payment processing, {appName} has all the tools coaches need to run their teams efficiently.",
  features: [
    {
      icon: "MessageSquare",
      title: "Smart SMS Reminders",
      description: "Automatically send customizable SMS reminders to your team. AI parses natural language responses to track who's coming."
    },
    {
      icon: "Calendar",
      title: "Event Management",
      description: "Create games and practices with all the details your team needs. Track attendance, location, opponent, and game-specific information."
    },
    {
      icon: "TrendingUp",
      title: "Player Reliability Scoring",
      description: "Automatically track which players show up consistently. Our intelligent scoring system adapts reminder frequency based on past behavior."
    },
    {
      icon: "Bell",
      title: "Automated Campaigns",
      description: "Schedule reminder campaigns that run automatically before events. Send multiple reminders at different intervals."
    },
    {
      icon: "Zap",
      title: "Reusable Templates",
      description: "Create campaign templates once and reuse them for every event. Save time by not rewriting the same messages over and over."
    },
    {
      icon: "Users",
      title: "Role-Based Permissions",
      description: "Control who can manage events, edit rosters, and view sensitive information. Create custom roles with specific permissions."
    },
    {
      icon: "Database",
      title: "Roster Management",
      description: "Import players via CSV, send individual invitations, or add them manually. Track contact information and custom player fields."
    },
    {
      icon: "CheckCircle",
      title: "Payment Integration",
      description: "Send payment requests for league fees, tournaments, or equipment. Receive automated confirmations when payments are completed."
    }
  ],
  ctaTitle: "Ready to experience all these features?",
  ctaSubtitle: "Start managing your team more efficiently today. All features included in every plan.",
  ctaPrimaryButton: "Get Started",
  ctaSecondaryButton: "View Pricing"
};

export default function Features() {
  const appName = useAppName();
  const logoUrl = useOrganizationLogo();
  
  const { data: content, isLoading, isError } = useQuery<FeaturesPageContent>({
    queryKey: ["/api/marketing-pages/features"],
  });

  const pageContent = content || defaultContent;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center" data-testid="loading-state">
          <div className="text-lg text-muted-foreground">Loading...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-3 md:py-4 flex justify-between items-center gap-2">
          <Link href="/" data-testid="link-home-logo">
            <div className="flex items-center gap-2 md:gap-3 cursor-pointer hover-elevate rounded-md p-2 -m-2 min-w-0">
              {logoUrl ? (
                <img 
                  src={logoUrl} 
                  alt="Logo" 
                  className="h-8 md:h-10 w-auto object-contain flex-shrink-0"
                  data-testid="img-header-logo"
                />
              ) : (
                <Users className="h-5 md:h-6 w-5 md:w-6 text-primary flex-shrink-0" />
              )}
              <span className="hidden sm:block text-lg md:text-xl font-bold truncate">{appName}</span>
            </div>
          </Link>
          <nav className="flex items-center gap-1 md:gap-4 flex-shrink-0">
            <Link 
              href="/about" 
              className="hidden md:inline-flex text-sm font-medium hover-elevate rounded-md px-3 py-2" 
              data-testid="link-about"
            >
              About
            </Link>
            <Link 
              href="/features" 
              className="hidden md:inline-flex text-sm font-medium hover-elevate rounded-md px-3 py-2" 
              data-testid="link-features"
            >
              Features
            </Link>
            <Link 
              href="/pricing" 
              className="text-xs md:text-sm font-medium hover-elevate rounded-md px-2 md:px-3 py-2" 
              data-testid="link-pricing"
            >
              Pricing
            </Link>
            <Link 
              href="/contact" 
              className="text-xs md:text-sm font-medium hover-elevate rounded-md px-2 md:px-3 py-2" 
              data-testid="link-contact"
            >
              Contact
            </Link>
            <Link href="/login">
              <Button size="sm" data-testid="button-login">Log In</Button>
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="container mx-auto px-4 py-8 md:py-16 landscape:py-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8 landscape:mb-6">
              <h1 className="text-3xl md:text-4xl lg:text-5xl landscape:text-3xl font-bold mb-4 landscape:mb-3" data-testid="text-heading">
                {pageContent.heroTitle}
              </h1>
              <p className="text-lg md:text-xl landscape:text-base text-muted-foreground max-w-3xl mx-auto" data-testid="text-subheading">
                {pageContent.heroSubtitle.replace('{appName}', appName)}
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8 landscape:mb-6">
              {pageContent.features.map((feature, index) => {
                const IconComponent = iconMap[feature.icon as keyof typeof iconMap];
                return (
                  <Card key={index} data-testid={`feature-card-${index}`}>
                    <CardHeader>
                      <IconComponent className="h-8 w-8 mb-2 text-primary" />
                      <CardTitle data-testid={`feature-title-${index}`}>{feature.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription data-testid={`feature-description-${index}`}>
                        {feature.description.replace('{appName}', appName)}
                      </CardDescription>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <div className="text-center bg-muted rounded-lg p-8 md:p-12">
              <h2 className="text-3xl font-bold mb-4" data-testid="text-cta-heading">
                {pageContent.ctaTitle}
              </h2>
              <p className="text-muted-foreground mb-8 max-w-2xl mx-auto" data-testid="text-cta-subheading">
                {pageContent.ctaSubtitle}
              </p>
              <div className="flex flex-wrap gap-4 justify-center">
                <Link href="/login">
                  <Button size="lg" data-testid="button-get-started">
                    {pageContent.ctaPrimaryButton}
                  </Button>
                </Link>
                <Link href="/pricing">
                  <Button size="lg" variant="outline" data-testid="button-view-pricing">
                    {pageContent.ctaSecondaryButton}
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <MarketingFooter />
    </div>
  );
}

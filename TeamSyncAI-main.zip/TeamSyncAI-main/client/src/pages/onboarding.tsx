import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useAvailableSports } from "@/hooks/useAvailableSports";
import { Trophy, CheckCircle } from "lucide-react";
import type { Team } from "@shared/schema";

export default function Onboarding() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const { availableSports } = useAvailableSports();
  const [selectedSports, setSelectedSports] = useState<string[]>([]);

  // Fetch user's teams to update the default team's sport
  const { data: teams } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  const updateSportsMutation = useMutation({
    mutationFn: async (sports: string[]) => {
      // Update user's sport preferences
      await apiRequest("PATCH", "/api/user/sports", { sports });
      
      // If user has a team, update the team's sport to the first selected sport
      if (teams && teams.length > 0 && sports.length > 0) {
        const firstTeam = teams[0];
        await apiRequest("PATCH", `/api/teams/${firstTeam.id}`, { 
          sport: sports[0] 
        });
      }
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      toast({
        title: "Welcome!",
        description: "Your sport preferences have been saved.",
      });
      setLocation("/");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save your sport preferences. Please try again.",
        variant: "destructive",
      });
    },
  });

  const toggleSport = (sport: string) => {
    setSelectedSports((prev) =>
      prev.includes(sport)
        ? prev.filter((s) => s !== sport)
        : [...prev, sport]
    );
  };

  const handleContinue = () => {
    if (selectedSports.length === 0) {
      toast({
        title: "Please select at least one sport",
        description: "You need to select at least one sport to continue.",
        variant: "destructive",
      });
      return;
    }
    updateSportsMutation.mutate(selectedSports);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
              <Trophy className="h-8 w-8 text-primary" />
            </div>
          </div>
          <CardTitle className="text-2xl md:text-3xl">
            Welcome{user?.firstName ? `, ${user.firstName}` : ""}!
          </CardTitle>
          <CardDescription className="text-base mt-2">
            Let's get started by selecting which sports you manage. Your first selection will be set as your team's primary sport. You can always change this later in settings.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {availableSports.map((sport) => {
              const isSelected = selectedSports.includes(sport);
              return (
                <div
                  key={sport}
                  className={`
                    flex items-center space-x-2 p-3 rounded-md border cursor-pointer transition-colors
                    ${isSelected ? "border-primary bg-primary/5" : "border-border hover-elevate"}
                  `}
                  onClick={() => toggleSport(sport)}
                  data-testid={`option-sport-${sport.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <Checkbox
                    id={`sport-${sport}`}
                    checked={isSelected}
                    onCheckedChange={() => toggleSport(sport)}
                    data-testid={`checkbox-sport-${sport.toLowerCase().replace(/\s+/g, '-')}`}
                  />
                  <label
                    htmlFor={`sport-${sport}`}
                    className="text-sm font-medium cursor-pointer flex-1"
                  >
                    {sport}
                  </label>
                  {isSelected && (
                    <CheckCircle className="h-4 w-4 text-primary" />
                  )}
                </div>
              );
            })}
          </div>

          {selectedSports.length > 0 && (
            <div className="bg-muted/50 p-3 rounded-md">
              <p className="text-sm text-muted-foreground">
                Selected {selectedSports.length} sport{selectedSports.length > 1 ? 's' : ''}: {selectedSports.join(", ")}
              </p>
            </div>
          )}

          <Button
            onClick={handleContinue}
            disabled={selectedSports.length === 0 || updateSportsMutation.isPending}
            className="w-full"
            data-testid="button-continue"
          >
            {updateSportsMutation.isPending ? "Saving..." : "Continue"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

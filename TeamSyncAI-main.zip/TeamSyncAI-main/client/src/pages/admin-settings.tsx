import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, ShieldOff, Save, Plus, Edit, Trash2, DollarSign, Crown, CheckCircle2, XCircle, HelpCircle, MessageSquare, Calendar, TrendingUp, Bell, Zap, Database, Settings, CheckCircle, Star, Target, Eye, Copy, X } from "lucide-react";
import { useQuery, useQueries, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User, AppSettings, MembershipTier, TierLimit, TierFeature, EventTemplate, InsertEventTemplate, CustomField, InsertCustomField, LandingPageContent, InsertLandingPageContent, LandingPageFeature, CampaignTemplate, InsertCampaignTemplate, TemplateReminder, InsertTemplateReminder } from "@shared/schema";
import { AVAILABLE_SPORTS } from "@shared/schema";
import { useState, useEffect, useMemo } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronRight, Users } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useTestView } from "@/contexts/TestViewContext";
import { UploadThingUploader } from "@/components/UploadThingUploader";

type TierWithDetails = MembershipTier & { limits: TierLimit[]; features: TierFeature[] };

const AVAILABLE_LIMITS = [
  { key: "max_teams", description: "Maximum number of teams a user can create" },
  { key: "max_players_per_team", description: "Maximum players allowed in a single team" },
  { key: "max_events_per_month", description: "Maximum events that can be created per month" },
  { key: "max_campaigns_per_month", description: "Maximum SMS campaigns per month" },
  { key: "max_sms_per_month", description: "Maximum SMS messages per month" },
  { key: "max_campaign_templates", description: "Maximum reusable campaign templates" },
  { key: "max_storage_mb", description: "Maximum storage for team logos and attachments (in MB)" },
];

const AVAILABLE_FEATURES = [
  { key: "sms_reminders", description: "Send automated SMS reminders to players" },
  { key: "ai_response_parsing", description: "Use AI to parse player responses" },
  { key: "reliability_tracking", description: "Track and score player reliability over time" },
  { key: "campaign_templates", description: "Create and reuse campaign templates" },
  { key: "calendar_subscriptions", description: "Generate calendar subscription links for teams" },
  { key: "message_board", description: "Enable team message board for communication" },
  { key: "csv_import", description: "Bulk import players via CSV upload" },
  { key: "role_management", description: "Create custom roles with granular permissions" },
  { key: "automated_updates", description: "Send automated SMS updates to specific roles" },
  { key: "priority_support", description: "Access to priority customer support" },
  { key: "custom_branding", description: "Customize app name and branding" },
];

export default function AdminSettings() {
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const { isTestViewActive } = useTestView();
  const [applicationName, setApplicationName] = useState("");
  const [availableSports, setAvailableSports] = useState<string[]>([]);
  const [newSport, setNewSport] = useState("");
  const [isTierDialogOpen, setIsTierDialogOpen] = useState(false);
  const [editingTier, setEditingTier] = useState<TierWithDetails | null>(null);
  const [tierForm, setTierForm] = useState({
    name: "",
    description: "",
    monthlyPrice: 0,
    annualPrice: 0,
    trialPeriodDays: 0,
    displayOrder: 0,
    helcimPaymentPlanId: "",
    helcimMonthlyCheckoutId: "",
    helcimAnnualCheckoutId: "",
    isContactForPricing: false,
    contactInfo: "",
    isDefault: false,
    isActive: true,
  });
  const [newLimit, setNewLimit] = useState({ key: "", value: 0 });
  const [newFeature, setNewFeature] = useState({ key: "", enabled: true });
  const [isLimitHelpOpen, setIsLimitHelpOpen] = useState(false);
  const [isFeatureHelpOpen, setIsFeatureHelpOpen] = useState(false);
  const [adminUsersOpen, setAdminUsersOpen] = useState(true);
  const [teamOwnersOpen, setTeamOwnersOpen] = useState(true);
  const [otherUsersOpen, setOtherUsersOpen] = useState(false);
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<EventTemplate | null>(null);
  const [templateForm, setTemplateForm] = useState({
    sport: "",
    name: "",
    type: "game",
    defaultTitle: "",
    durationMinutes: 0,
    defaultLocation: "",
    opponent: "",
    homeAway: "",
    fieldType: "",
    cleatsAllowed: "",
    jersey: "",
    arrivalTime: "",
    notes: "",
    customFieldIds: [] as string[],
  });
  const [enabledFields, setEnabledFields] = useState({
    opponent: true,
    homeAway: true,
    fieldType: true,
    cleatsAllowed: true,
    jersey: true,
    arrivalTime: true,
    notes: true,
  });
  const [isCustomFieldDialogOpen, setIsCustomFieldDialogOpen] = useState(false);
  const [editingCustomField, setEditingCustomField] = useState<CustomField | null>(null);
  const [customFieldForm, setCustomFieldForm] = useState({
    name: "",
    fieldType: "text",
    options: [] as string[],
    placeholder: "",
  });
  const [newOption, setNewOption] = useState("");
  const [isEditUserDialogOpen, setIsEditUserDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [userEditForm, setUserEditForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    sports: [] as string[],
  });
  const [landingPageForm, setLandingPageForm] = useState({
    heroTitle: "",
    heroSubtitle: "",
    heroCta: "",
    logoUrl: null as string | null,
    features: [] as LandingPageFeature[],
    ctaHeading: "",
    ctaDescription: "",
    ctaButton: "",
    footerText: "",
  });
  
  const [isCampaignTemplateDialogOpen, setIsCampaignTemplateDialogOpen] = useState(false);
  const [editingCampaignTemplate, setEditingCampaignTemplate] = useState<CampaignTemplate | null>(null);
  const [campaignTemplateForm, setCampaignTemplateForm] = useState({
    name: "",
    description: "",
  });
  const [expandedCampaignTemplate, setExpandedCampaignTemplate] = useState<string | null>(null);
  const [addingReminderTo, setAddingReminderTo] = useState<string | null>(null);
  const [editingReminder, setEditingReminder] = useState<TemplateReminder | null>(null);
  const [reminderForm, setReminderForm] = useState({
    intervalHours: 24,
    messageTemplate: "",
    minReliability: null as number | null,
    maxReliability: null as number | null,
  });
  
  const [usagePricingForm, setUsagePricingForm] = useState({
    smsBaseCost: 0,
    smsMarkupType: 'percentage' as 'percentage' | 'fixed',
    smsMarkupValue: 0,
    phoneNumberBaseCost: 0,
    phoneNumberMarkupType: 'percentage' as 'percentage' | 'fixed',
    phoneNumberMarkupValue: 0,
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
    enabled: !!currentUser?.isGlobalAdmin && !isTestViewActive,
  });

  const { data: appSettings } = useQuery<AppSettings>({
    queryKey: ["/api/app-settings"],
    enabled: !!currentUser?.isGlobalAdmin && !isTestViewActive,
  });

  const { data: membershipTiers = [] } = useQuery<TierWithDetails[]>({
    queryKey: ["/api/admin/membership-tiers"],
    enabled: !!currentUser?.isGlobalAdmin && !isTestViewActive,
  });

  const { data: eventTemplates = [] } = useQuery<EventTemplate[]>({
    queryKey: ["/api/admin/event-templates"],
    enabled: !!currentUser?.isGlobalAdmin && !isTestViewActive,
  });

  const { data: customFields = [] } = useQuery<CustomField[]>({
    queryKey: ["/api/admin/custom-fields"],
    enabled: !!currentUser?.isGlobalAdmin && !isTestViewActive,
  });

  const { data: campaignTemplates = [] } = useQuery<CampaignTemplate[]>({
    queryKey: ["/api/admin/campaign-templates"],
    enabled: !!currentUser?.isGlobalAdmin && !isTestViewActive,
  });

  const campaignTemplatesQuery = useQuery<CampaignTemplate[]>({
    queryKey: ["/api/admin/campaign-templates"],
    enabled: !!currentUser?.isGlobalAdmin && !isTestViewActive,
  });

  const templateRemindersQueries = useQueries({
    queries: campaignTemplates.map(template => ({
      queryKey: ["/api/admin/campaign-templates", template.id, "reminders"],
      queryFn: async () => {
        const response = await fetch(`/api/admin/campaign-templates/${template.id}/reminders`);
        if (!response.ok) throw new Error("Failed to fetch reminders");
        return response.json() as Promise<TemplateReminder[]>;
      },
      enabled: !!currentUser?.isGlobalAdmin && !isTestViewActive && !!template.id,
    })),
  });
  
  const templateReminders: Record<string, TemplateReminder[]> = {};
  campaignTemplates.forEach((template, index) => {
    templateReminders[template.id] = templateRemindersQueries[index]?.data || [];
  });

  const templateRemindersQuery = (templateId: string) => {
    const index = campaignTemplates.findIndex(t => t.id === templateId);
    return index >= 0 ? templateRemindersQueries[index] : { isLoading: false, data: [] };
  };

  const { data: paymentProviders = [] } = useQuery<any[]>({
    queryKey: ["/api/payment-providers"],
    enabled: !!currentUser?.isGlobalAdmin && !isTestViewActive,
  });

  const { data: landingPageContent } = useQuery<LandingPageContent>({
    queryKey: ["/api/landing-page"],
    enabled: !!currentUser?.isGlobalAdmin && !isTestViewActive,
  });

  const { data: usagePricing } = useQuery<any>({
    queryKey: ["/api/admin/usage-pricing"],
    enabled: !!currentUser?.isGlobalAdmin && !isTestViewActive,
  });

  const parsedUsagePricing = useMemo(() => {
    if (!usagePricing) return null;
    return {
      smsBaseCost: parseFloat(usagePricing.smsBaseCost as any) || 0,
      smsMarkupType: usagePricing.smsMarkupType || 'percentage',
      smsMarkupValue: parseFloat(usagePricing.smsMarkupValue as any) || 0,
      phoneNumberBaseCost: parseFloat(usagePricing.phoneNumberBaseCost as any) || 0,
      phoneNumberMarkupType: usagePricing.phoneNumberMarkupType || 'percentage',
      phoneNumberMarkupValue: parseFloat(usagePricing.phoneNumberMarkupValue as any) || 0,
    };
  }, [usagePricing]);

  useEffect(() => {
    if (appSettings) {
      setApplicationName(appSettings.applicationName);
      setAvailableSports(appSettings.availableSports || []);
    }
  }, [appSettings]);

  useEffect(() => {
    if (landingPageContent) {
      setLandingPageForm({
        heroTitle: landingPageContent.heroTitle,
        heroSubtitle: landingPageContent.heroSubtitle,
        heroCta: landingPageContent.heroCta,
        logoUrl: landingPageContent.logoUrl || null,
        features: (landingPageContent.features as LandingPageFeature[]) || [],
        ctaHeading: landingPageContent.ctaHeading,
        ctaDescription: landingPageContent.ctaDescription,
        ctaButton: landingPageContent.ctaButton,
        footerText: landingPageContent.footerText,
      });
    }
  }, [landingPageContent]);

  useEffect(() => {
    if (parsedUsagePricing) {
      setUsagePricingForm(parsedUsagePricing);
    }
  }, [parsedUsagePricing]);

  useEffect(() => {
    if (editingTier) {
      setTierForm({
        name: editingTier.name,
        description: editingTier.description || "",
        monthlyPrice: editingTier.monthlyPrice,
        annualPrice: (editingTier as any).annualPrice || 0,
        trialPeriodDays: editingTier.trialPeriodDays,
        displayOrder: editingTier.displayOrder,
        helcimPaymentPlanId: (editingTier as any).helcimPaymentPlanId || "",
        helcimMonthlyCheckoutId: (editingTier as any).helcimMonthlyCheckoutId || "",
        helcimAnnualCheckoutId: (editingTier as any).helcimAnnualCheckoutId || "",
        isContactForPricing: (editingTier as any).isContactForPricing || false,
        contactInfo: (editingTier as any).contactInfo || "",
        isDefault: editingTier.isDefault,
        isActive: editingTier.isActive,
      });
    }
  }, [editingTier]);

  useEffect(() => {
    if (editingCustomField) {
      setCustomFieldForm({
        name: editingCustomField.name,
        fieldType: editingCustomField.fieldType,
        options: editingCustomField.options || [],
        placeholder: editingCustomField.placeholder || "",
      });
    } else {
      // eslint-disable-next-line react-hooks/immutability
      resetCustomFieldForm();
    }
  }, [editingCustomField]);

  useEffect(() => {
    if (editingUser) {
      setUserEditForm({
        firstName: editingUser.firstName || "",
        lastName: editingUser.lastName || "",
        email: editingUser.email || "",
        sports: editingUser.sports || [],
      });
    } else {
      setUserEditForm({ firstName: "", lastName: "", email: "", sports: [] });
    }
  }, [editingUser]);

  useEffect(() => {
    if (editingTemplate) {
      setTemplateForm({
        sport: editingTemplate.sport,
        name: editingTemplate.name,
        type: editingTemplate.type,
        defaultTitle: editingTemplate.defaultTitle || "",
        durationMinutes: editingTemplate.durationMinutes || 0,
        defaultLocation: editingTemplate.defaultLocation || "",
        opponent: editingTemplate.opponent || "",
        homeAway: editingTemplate.homeAway || "",
        fieldType: editingTemplate.fieldType || "",
        cleatsAllowed: editingTemplate.cleatsAllowed || "",
        jersey: editingTemplate.jersey || "",
        arrivalTime: editingTemplate.arrivalTime || "",
        notes: editingTemplate.notes || "",
        customFieldIds: editingTemplate.customFieldIds || [],
      });
      setEnabledFields({
        opponent: !!editingTemplate.opponent,
        homeAway: !!editingTemplate.homeAway,
        fieldType: !!editingTemplate.fieldType,
        cleatsAllowed: !!editingTemplate.cleatsAllowed,
        jersey: !!editingTemplate.jersey,
        arrivalTime: !!editingTemplate.arrivalTime,
        notes: !!editingTemplate.notes,
      });
    } else {
      // eslint-disable-next-line react-hooks/immutability
      resetTemplateForm();
    }
  }, [editingTemplate]);

  const toggleAdminMutation = useMutation({
    mutationFn: async ({ userId, isGlobalAdmin }: { userId: string; isGlobalAdmin: boolean }) => {
      return apiRequest("POST", "/api/admin/set-global-admin", { userId, isGlobalAdmin });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Success",
        description: "Admin status updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update admin status. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: async ({ userId, userData }: { userId: string; userData: Partial<User> }) => {
      return apiRequest("PATCH", `/api/admin/users/${userId}`, userData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Success",
        description: "User updated successfully.",
      });
      setIsEditUserDialogOpen(false);
      setEditingUser(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update user. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return apiRequest("DELETE", `/api/admin/users/${userId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Success",
        description: "User deleted successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error?.message || "Failed to delete user. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateAppNameMutation = useMutation({
    mutationFn: async (newName: string) => {
      return apiRequest("PATCH", "/api/app-settings", { applicationName: newName });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/app-settings"] });
      toast({
        title: "Success",
        description: "Application name updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update application name. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateSportsMutation = useMutation({
    mutationFn: async (sports: string[]) => {
      return apiRequest("PATCH", "/api/app-settings", { availableSports: sports });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/app-settings"] });
      toast({
        title: "Success",
        description: "Sports list updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update sports list. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateLandingPageMutation = useMutation({
    mutationFn: async (data: InsertLandingPageContent) => {
      return apiRequest("PATCH", "/api/admin/landing-page", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/landing-page"] });
      toast({
        title: "Success",
        description: "Landing page content updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update landing page content. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateUsagePricingMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("PATCH", "/api/admin/usage-pricing", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/usage-pricing"] });
      toast({
        title: "Success",
        description: "Usage pricing updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update usage pricing. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createTierMutation = useMutation({
    mutationFn: async (data: typeof tierForm) => {
      return apiRequest("POST", "/api/admin/membership-tiers", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/membership-tiers"] });
      setIsTierDialogOpen(false);
      setTierForm({ name: "", description: "", monthlyPrice: 0, annualPrice: 0, trialPeriodDays: 0, displayOrder: 0, helcimPaymentPlanId: "", helcimMonthlyCheckoutId: "", helcimAnnualCheckoutId: "", isContactForPricing: false, contactInfo: "", isDefault: false, isActive: true });
      toast({ title: "Success", description: "Membership tier created successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create membership tier.", variant: "destructive" });
    },
  });

  const updateTierMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<typeof tierForm> }) => {
      return apiRequest("PATCH", `/api/admin/membership-tiers/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/membership-tiers"] });
      setEditingTier(null);
      setIsTierDialogOpen(false);
      toast({ title: "Success", description: "Membership tier updated successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update membership tier.", variant: "destructive" });
    },
  });

  const deleteTierMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/admin/membership-tiers/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/membership-tiers"] });
      toast({ title: "Success", description: "Membership tier deleted successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete membership tier.", variant: "destructive" });
    },
  });

  const createTemplateMutation = useMutation({
    mutationFn: async (data: InsertEventTemplate) => {
      return apiRequest("POST", "/api/admin/event-templates", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/event-templates"] });
      setIsTemplateDialogOpen(false);
      setEditingTemplate(null);
      resetTemplateForm();
      toast({ title: "Success", description: "Event template created successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create event template.", variant: "destructive" });
    },
  });

  const updateTemplateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertEventTemplate> }) => {
      return apiRequest("PATCH", `/api/admin/event-templates/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/event-templates"] });
      setIsTemplateDialogOpen(false);
      setEditingTemplate(null);
      resetTemplateForm();
      toast({ title: "Success", description: "Event template updated successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update event template.", variant: "destructive" });
    },
  });

  const deleteTemplateMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/admin/event-templates/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/event-templates"] });
      toast({ title: "Success", description: "Event template deleted successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete event template.", variant: "destructive" });
    },
  });

  const resetTemplateForm = () => {
    setTemplateForm({
      sport: "",
      name: "",
      type: "game",
      defaultTitle: "",
      durationMinutes: 0,
      defaultLocation: "",
      opponent: "",
      homeAway: "",
      fieldType: "",
      cleatsAllowed: "",
      jersey: "",
      arrivalTime: "",
      notes: "",
      customFieldIds: [],
    });
    setEnabledFields({
      opponent: true,
      homeAway: true,
      fieldType: true,
      cleatsAllowed: true,
      jersey: true,
      arrivalTime: true,
      notes: true,
    });
  };

  const createCustomFieldMutation = useMutation({
    mutationFn: async (data: InsertCustomField) => {
      return apiRequest("POST", "/api/admin/custom-fields", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/custom-fields"] });
      setIsCustomFieldDialogOpen(false);
      setEditingCustomField(null);
      resetCustomFieldForm();
      toast({ title: "Success", description: "Custom field created successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create custom field.", variant: "destructive" });
    },
  });

  const updateCustomFieldMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertCustomField> }) => {
      return apiRequest("PATCH", `/api/admin/custom-fields/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/custom-fields"] });
      setIsCustomFieldDialogOpen(false);
      setEditingCustomField(null);
      resetCustomFieldForm();
      toast({ title: "Success", description: "Custom field updated successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update custom field.", variant: "destructive" });
    },
  });

  const deleteCustomFieldMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/admin/custom-fields/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/custom-fields"] });
      toast({ title: "Success", description: "Custom field deleted successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete custom field.", variant: "destructive" });
    },
  });

  const createCampaignTemplateMutation = useMutation({
    mutationFn: async (data: InsertCampaignTemplate) => {
      return apiRequest("POST", "/api/admin/campaign-templates", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/campaign-templates"] });
      setIsCampaignTemplateDialogOpen(false);
      setCampaignTemplateForm({ name: "", description: "" });
      setEditingCampaignTemplate(null);
      toast({ title: "Success", description: "Campaign template created successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create campaign template.", variant: "destructive" });
    },
  });

  const updateCampaignTemplateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertCampaignTemplate> }) => {
      return apiRequest("PATCH", `/api/admin/campaign-templates/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/campaign-templates"] });
      setIsCampaignTemplateDialogOpen(false);
      setCampaignTemplateForm({ name: "", description: "" });
      setEditingCampaignTemplate(null);
      toast({ title: "Success", description: "Campaign template updated successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update campaign template.", variant: "destructive" });
    },
  });

  const deleteCampaignTemplateMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/admin/campaign-templates/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/campaign-templates"] });
      toast({ title: "Success", description: "Campaign template deleted successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete campaign template.", variant: "destructive" });
    },
  });

  const createTemplateReminderMutation = useMutation({
    mutationFn: async ({ templateId, data }: { templateId: string; data: InsertTemplateReminder }) => {
      return apiRequest("POST", `/api/admin/campaign-templates/${templateId}/reminders`, data);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/campaign-templates", variables.templateId, "reminders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/campaign-templates"] });
      setAddingReminderTo(null);
      setReminderForm({ intervalHours: 24, messageTemplate: "", minReliability: null, maxReliability: null });
      toast({ title: "Success", description: "Reminder added to template." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add reminder.", variant: "destructive" });
    },
  });

  const updateTemplateReminderMutation = useMutation({
    mutationFn: async ({ templateId, reminderId, data }: { templateId: string; reminderId: string; data: any }) => {
      return apiRequest("PATCH", `/api/admin/campaign-templates/${templateId}/reminders/${reminderId}`, data);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/campaign-templates", variables.templateId, "reminders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/campaign-templates"] });
      setEditingReminder(null);
      setReminderForm({ intervalHours: 24, messageTemplate: "", minReliability: null, maxReliability: null });
      toast({ title: "Success", description: "Reminder updated successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update reminder.", variant: "destructive" });
    },
  });

  const deleteTemplateReminderMutation = useMutation({
    mutationFn: async ({ templateId, reminderId }: { templateId: string; reminderId: string }) => {
      return apiRequest("DELETE", `/api/admin/campaign-templates/${templateId}/reminders/${reminderId}`);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/campaign-templates", variables.templateId, "reminders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/campaign-templates"] });
      toast({ title: "Success", description: "Reminder deleted successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete reminder.", variant: "destructive" });
    },
  });

  const resetCustomFieldForm = () => {
    setCustomFieldForm({
      name: "",
      fieldType: "text",
      options: [],
      placeholder: "",
    });
    setNewOption("");
  };

  const setLimitMutation = useMutation({
    mutationFn: async ({ tierId, limitKey, limitValue }: { tierId: string; limitKey: string; limitValue: number }) => {
      return apiRequest("POST", `/api/admin/membership-tiers/${tierId}/limits`, { limitKey, limitValue });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/membership-tiers"] });
      setNewLimit({ key: "", value: 0 });
      toast({ title: "Success", description: "Tier limit set successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to set tier limit.", variant: "destructive" });
    },
  });

  const deleteLimitMutation = useMutation({
    mutationFn: async ({ tierId, limitKey }: { tierId: string; limitKey: string }) => {
      return apiRequest("DELETE", `/api/admin/membership-tiers/${tierId}/limits/${limitKey}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/membership-tiers"] });
      toast({ title: "Success", description: "Tier limit deleted successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete tier limit.", variant: "destructive" });
    },
  });

  const setFeatureMutation = useMutation({
    mutationFn: async ({ tierId, featureKey, enabled }: { tierId: string; featureKey: string; enabled: boolean }) => {
      return apiRequest("POST", `/api/admin/membership-tiers/${tierId}/features`, { featureKey, enabled });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/membership-tiers"] });
      setNewFeature({ key: "", enabled: true });
      toast({ title: "Success", description: "Tier feature set successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to set tier feature.", variant: "destructive" });
    },
  });

  const deleteFeatureMutation = useMutation({
    mutationFn: async ({ tierId, featureKey }: { tierId: string; featureKey: string }) => {
      return apiRequest("DELETE", `/api/admin/membership-tiers/${tierId}/features/${featureKey}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/membership-tiers"] });
      toast({ title: "Success", description: "Tier feature deleted successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete tier feature.", variant: "destructive" });
    },
  });

  const assignTierMutation = useMutation({
    mutationFn: async ({ userId, tierId, startTrial }: { userId: string; tierId: string; startTrial: boolean }) => {
      return apiRequest("POST", `/api/admin/users/${userId}/assign-tier`, { tierId, startTrial });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "Success", description: "Membership tier assigned successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to assign membership tier.", variant: "destructive" });
    },
  });

  if (!currentUser?.isGlobalAdmin || isTestViewActive) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Access Restricted
            </CardTitle>
            <CardDescription>
              {isTestViewActive 
                ? "Admin settings are not available in test view mode. Disable test view to access this area."
                : "You don't have permission to access this area. Only global administrators can view admin settings."
              }
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">Admin Settings</h1>
        <p className="text-muted-foreground">
          Manage global administrators and application settings
        </p>
      </div>

      <Card className="border-primary/20">
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => scrollToSection('section-app-settings')}
              data-testid="button-nav-app-settings"
            >
              Application Settings
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => scrollToSection('section-landing-page')}
              data-testid="button-nav-landing-page"
            >
              Landing Page
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => scrollToSection('section-user-management')}
              data-testid="button-nav-user-management"
            >
              User Management
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => scrollToSection('section-membership-tiers')}
              data-testid="button-nav-membership-tiers"
            >
              Membership Tiers
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => scrollToSection('section-event-templates')}
              data-testid="button-nav-event-templates"
            >
              Event Templates
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => scrollToSection('section-campaign-templates')}
              data-testid="button-nav-campaign-templates"
            >
              Campaign Templates
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => scrollToSection('section-custom-fields')}
              data-testid="button-nav-custom-fields"
            >
              Custom Fields
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => scrollToSection('section-payment-providers')}
              data-testid="button-nav-payment-providers"
            >
              Payment Providers
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card id="section-app-settings">
        <CardHeader>
          <CardTitle>Application Settings</CardTitle>
          <CardDescription>
            Customize the application name
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="app-name">Application Name</Label>
            <div className="flex gap-2">
              <Input
                id="app-name"
                data-testid="input-app-name"
                value={applicationName}
                onChange={(e) => setApplicationName(e.target.value)}
                placeholder="TeamSyncAI"
                className="flex-1"
              />
              <Button
                onClick={() => updateAppNameMutation.mutate(applicationName)}
                disabled={updateAppNameMutation.isPending || !applicationName.trim()}
                data-testid="button-save-app-name"
              >
                <Save className="h-4 w-4 mr-2" />
                Save
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">
              This name will appear throughout the application
            </p>
          </div>
        </CardContent>
      </Card>

      <Card id="section-sports-management">
        <CardHeader>
          <CardTitle>Sports Management</CardTitle>
          <CardDescription>
            Manage the list of available sports for teams and events
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Current Sports</Label>
            <div className="flex flex-wrap gap-2 p-3 border rounded-md min-h-[100px]">
              {availableSports.length > 0 ? (
                availableSports.map((sport, index) => (
                  <Badge key={index} variant="secondary" className="gap-1 pr-1">
                    <span>{sport}</span>
                    <button
                      type="button"
                      className="ml-1 rounded-sm hover:bg-muted p-0.5"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        const updated = availableSports.filter((_, i) => i !== index);
                        setAvailableSports(updated);
                      }}
                      data-testid={`button-remove-sport-${index}`}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">No sports configured</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="new-sport">Add New Sport</Label>
            <div className="flex gap-2">
              <Input
                id="new-sport"
                data-testid="input-new-sport"
                value={newSport}
                onChange={(e) => setNewSport(e.target.value)}
                placeholder="e.g., Baseball, Soccer"
                className="flex-1"
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && newSport.trim() && !availableSports.includes(newSport.trim())) {
                    setAvailableSports([...availableSports, newSport.trim()]);
                    setNewSport("");
                  }
                }}
              />
              <Button
                onClick={() => {
                  if (newSport.trim() && !availableSports.includes(newSport.trim())) {
                    setAvailableSports([...availableSports, newSport.trim()]);
                    setNewSport("");
                  }
                }}
                disabled={!newSport.trim() || availableSports.includes(newSport.trim())}
                data-testid="button-add-sport"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">
              Add sports one at a time. Press Enter or click Add.
            </p>
          </div>

          <div className="flex justify-end pt-4">
            <Button
              onClick={() => updateSportsMutation.mutate(availableSports)}
              disabled={updateSportsMutation.isPending || availableSports.length === 0}
              data-testid="button-save-sports"
            >
              <Save className="h-4 w-4 mr-2" />
              Save Sports List
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card id="section-landing-page">
        <CardHeader>
          <CardTitle>Landing Page Content</CardTitle>
          <CardDescription>
            Customize the public landing page for non-logged-in visitors
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Hero Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Hero Section</h3>
            <div className="space-y-4 pl-4 border-l-2">
              <div className="space-y-2">
                <Label htmlFor="hero-title" data-testid="label-hero-title">Hero Title</Label>
                <Input
                  id="hero-title"
                  data-testid="input-hero-title"
                  value={landingPageForm.heroTitle}
                  onChange={(e) => setLandingPageForm({ ...landingPageForm, heroTitle: e.target.value })}
                  placeholder="Your AI-Powered Assistant Manager"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hero-subtitle" data-testid="label-hero-subtitle">Hero Subtitle</Label>
                <Textarea
                  id="hero-subtitle"
                  data-testid="input-hero-subtitle"
                  value={landingPageForm.heroSubtitle}
                  onChange={(e) => setLandingPageForm({ ...landingPageForm, heroSubtitle: e.target.value })}
                  placeholder="Automate team management for amateur sports teams..."
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hero-cta" data-testid="label-hero-cta">Hero CTA Button Text</Label>
                <Input
                  id="hero-cta"
                  data-testid="input-hero-cta"
                  value={landingPageForm.heroCta}
                  onChange={(e) => setLandingPageForm({ ...landingPageForm, heroCta: e.target.value })}
                  placeholder="Get Started"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="logo-upload" data-testid="label-logo-upload">Logo (Optional)</Label>
                {landingPageForm.logoUrl && (
                  <div className="mb-2">
                    <img 
                      src={landingPageForm.logoUrl} 
                      alt="Landing page logo" 
                      className="h-16 w-auto object-contain border rounded p-2"
                      data-testid="img-landing-logo-preview"
                    />
                  </div>
                )}
                <div className="flex gap-2">
                  <UploadThingUploader
                    endpoint="logoUploader"
                    onComplete={(url) => {
                      setLandingPageForm({ ...landingPageForm, logoUrl: url });
                      toast({
                        title: "Success",
                        description: "Logo uploaded successfully. Remember to save your changes.",
                      });
                    }}
                    onError={(error) => {
                      toast({
                        title: "Error",
                        description: `Failed to upload logo: ${error.message}`,
                        variant: "destructive",
                      });
                    }}
                    buttonText="Upload Logo"
                  />
                  {landingPageForm.logoUrl && (
                    <Button
                      variant="outline"
                      onClick={() => setLandingPageForm({ ...landingPageForm, logoUrl: null })}
                      data-testid="button-remove-logo"
                    >
                      Remove Logo
                    </Button>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  Upload a logo to display in the landing page hero section
                </p>
              </div>
            </div>
          </div>

          {/* Features Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Features Section</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  if (landingPageForm.features.length < 12) {
                    setLandingPageForm({
                      ...landingPageForm,
                      features: [
                        ...landingPageForm.features,
                        { icon: "MessageSquare", title: "", description: "" }
                      ]
                    });
                  }
                }}
                disabled={landingPageForm.features.length >= 12}
                data-testid="button-add-feature"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Feature
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">
              Add up to 12 feature cards (currently {landingPageForm.features.length}/12)
            </p>
            <div className="space-y-4">
              {landingPageForm.features.map((feature, index) => (
                <div key={index} className="space-y-3 p-4 border rounded-md" data-testid={`feature-card-${index}`}>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Feature {index + 1}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        const newFeatures = landingPageForm.features.filter((_, i) => i !== index);
                        setLandingPageForm({ ...landingPageForm, features: newFeatures });
                      }}
                      data-testid={`button-remove-feature-${index}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor={`feature-icon-${index}`}>Icon</Label>
                    <Select
                      value={feature.icon}
                      onValueChange={(value) => {
                        const newFeatures = landingPageForm.features.map((f, i) => 
                          i === index ? { ...f, icon: value as any } : f
                        );
                        setLandingPageForm({ ...landingPageForm, features: newFeatures });
                      }}
                    >
                      <SelectTrigger id={`feature-icon-${index}`} data-testid={`select-feature-icon-${index}`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="MessageSquare">MessageSquare</SelectItem>
                        <SelectItem value="Calendar">Calendar</SelectItem>
                        <SelectItem value="TrendingUp">TrendingUp</SelectItem>
                        <SelectItem value="Bell">Bell</SelectItem>
                        <SelectItem value="Zap">Zap</SelectItem>
                        <SelectItem value="Users">Users</SelectItem>
                        <SelectItem value="Shield">Shield</SelectItem>
                        <SelectItem value="Database">Database</SelectItem>
                        <SelectItem value="Settings">Settings</SelectItem>
                        <SelectItem value="CheckCircle">CheckCircle</SelectItem>
                        <SelectItem value="Star">Star</SelectItem>
                        <SelectItem value="Target">Target</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor={`feature-title-${index}`}>Title</Label>
                    <Input
                      id={`feature-title-${index}`}
                      data-testid={`input-feature-title-${index}`}
                      value={feature.title}
                      onChange={(e) => {
                        const newFeatures = landingPageForm.features.map((f, i) => 
                          i === index ? { ...f, title: e.target.value } : f
                        );
                        setLandingPageForm({ ...landingPageForm, features: newFeatures });
                      }}
                      placeholder="Feature title"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor={`feature-description-${index}`}>Description</Label>
                    <Textarea
                      id={`feature-description-${index}`}
                      data-testid={`input-feature-description-${index}`}
                      value={feature.description}
                      onChange={(e) => {
                        const newFeatures = landingPageForm.features.map((f, i) => 
                          i === index ? { ...f, description: e.target.value } : f
                        );
                        setLandingPageForm({ ...landingPageForm, features: newFeatures });
                      }}
                      placeholder="Feature description"
                      rows={2}
                    />
                  </div>
                </div>
              ))}
              {landingPageForm.features.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No features added yet. Click "Add Feature" to get started.
                </p>
              )}
            </div>
          </div>

          {/* CTA Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Call-to-Action Section</h3>
            <div className="space-y-4 pl-4 border-l-2">
              <div className="space-y-2">
                <Label htmlFor="cta-heading" data-testid="label-cta-heading">CTA Heading</Label>
                <Input
                  id="cta-heading"
                  data-testid="input-cta-heading"
                  value={landingPageForm.ctaHeading}
                  onChange={(e) => setLandingPageForm({ ...landingPageForm, ctaHeading: e.target.value })}
                  placeholder="Ready to simplify your team management?"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cta-description" data-testid="label-cta-description">CTA Description</Label>
                <Textarea
                  id="cta-description"
                  data-testid="input-cta-description"
                  value={landingPageForm.ctaDescription}
                  onChange={(e) => setLandingPageForm({ ...landingPageForm, ctaDescription: e.target.value })}
                  placeholder="Join coaches who are already saving time..."
                  rows={3}
                />
                <p className="text-sm text-muted-foreground">
                  Use {'{appName}'} to insert the application name dynamically
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="cta-button" data-testid="label-cta-button">CTA Button Text</Label>
                <Input
                  id="cta-button"
                  data-testid="input-cta-button"
                  value={landingPageForm.ctaButton}
                  onChange={(e) => setLandingPageForm({ ...landingPageForm, ctaButton: e.target.value })}
                  placeholder="Start Now"
                />
              </div>
            </div>
          </div>

          {/* Footer Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Footer Section</h3>
            <div className="space-y-4 pl-4 border-l-2">
              <div className="space-y-2">
                <Label htmlFor="footer-text" data-testid="label-footer-text">Footer Text</Label>
                <Textarea
                  id="footer-text"
                  data-testid="input-footer-text"
                  value={landingPageForm.footerText}
                  onChange={(e) => setLandingPageForm({ ...landingPageForm, footerText: e.target.value })}
                  placeholder="© 2025 {appName}. Built for coaches, by coaches."
                  rows={2}
                />
                <p className="text-sm text-muted-foreground">
                  Use {'{appName}'} to insert the application name dynamically
                </p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => window.open("/", "_blank")}
              data-testid="button-preview-landing-page"
            >
              <Eye className="h-4 w-4 mr-2" />
              Preview Landing Page
            </Button>
            <Button
              onClick={() => {
                // Basic validation
                if (!landingPageForm.heroTitle.trim() || !landingPageForm.heroSubtitle.trim()) {
                  toast({
                    title: "Validation Error",
                    description: "Hero title and subtitle are required.",
                    variant: "destructive",
                  });
                  return;
                }

                // Validate features
                const invalidFeature = landingPageForm.features.find(
                  f => !f.icon || !f.title.trim() || !f.description.trim()
                );
                if (invalidFeature) {
                  toast({
                    title: "Validation Error",
                    description: "All features must have an icon, title, and description.",
                    variant: "destructive",
                  });
                  return;
                }

                updateLandingPageMutation.mutate(landingPageForm);
              }}
              disabled={updateLandingPageMutation.isPending}
              data-testid="button-save-landing-page"
            >
              <Save className="h-4 w-4 mr-2" />
              Save Landing Page
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card id="section-user-management">
        <CardHeader>
          <CardTitle>User Management</CardTitle>
          <CardDescription>
            Organize and manage users by role
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {users.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">
              No users found
            </p>
          ) : (
            <>
              {(() => {
                const usersWithTeamInfo = users as (User & { teamCount?: number; isTeamOwner?: boolean })[];
                const adminUsers = usersWithTeamInfo.filter(u => u.isGlobalAdmin);
                const teamOwners = usersWithTeamInfo.filter(u => !u.isGlobalAdmin && u.isTeamOwner);
                const otherUsers = usersWithTeamInfo.filter(u => !u.isGlobalAdmin && !u.isTeamOwner);

                const renderUser = (user: User & { teamCount?: number; isTeamOwner?: boolean }, showAdminToggle: boolean) => (
                  <div
                    key={user.id}
                    className="flex items-center justify-between p-4 rounded-md border"
                    data-testid={`user-row-${user.id}`}
                  >
                    <div className="flex items-center gap-3">
                      {user.profileImageUrl ? (
                        <img
                          src={user.profileImageUrl}
                          alt={`${user.firstName || ''} ${user.lastName || ''}`}
                          className="h-10 w-10 rounded-full"
                          data-testid={`img-user-avatar-${user.id}`}
                        />
                      ) : (
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium">
                          {(user.firstName?.[0] || user.email?.[0] || '?').toUpperCase()}
                        </div>
                      )}
                      <div>
                        <p className="font-medium" data-testid={`text-user-name-${user.id}`}>
                          {user.firstName && user.lastName
                            ? `${user.firstName} ${user.lastName}`
                            : user.email}
                        </p>
                        <p className="text-sm text-muted-foreground" data-testid={`text-user-email-${user.id}`}>
                          {user.email}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {user.isGlobalAdmin && (
                        <Badge variant="default" className="gap-1">
                          <Shield className="h-3 w-3" />
                          Global Admin
                        </Badge>
                      )}
                      {user.isTeamOwner && user.teamCount !== undefined && (
                        <Badge variant="secondary" className="gap-1">
                          <Users className="h-3 w-3" />
                          {user.teamCount} {user.teamCount === 1 ? 'Team' : 'Teams'}
                        </Badge>
                      )}
                      {user.membershipTierId && (
                        <Badge variant="outline" className="gap-1">
                          <Crown className="h-3 w-3" />
                          {membershipTiers.find(t => t.id === user.membershipTierId)?.name || 'Unknown'}
                        </Badge>
                      )}
                      <Select
                        value={user.membershipTierId || "none"}
                        onValueChange={(value) => {
                          if (value === "none") return;
                          assignTierMutation.mutate({ userId: user.id, tierId: value, startTrial: false });
                        }}
                      >
                        <SelectTrigger className="w-[180px]" data-testid={`select-tier-${user.id}`}>
                          <SelectValue placeholder="Assign tier" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">No tier</SelectItem>
                          {membershipTiers.map((tier) => (
                            <SelectItem key={tier.id} value={tier.id}>
                              {tier.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setEditingUser(user);
                          setIsEditUserDialogOpen(true);
                        }}
                        data-testid={`button-edit-user-${user.id}`}
                      >
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                      {showAdminToggle && user.id !== currentUser.id && (
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant={user.isGlobalAdmin ? "destructive" : "default"}
                              size="sm"
                              data-testid={`button-toggle-admin-${user.id}`}
                            >
                              {user.isGlobalAdmin ? (
                                <>
                                  <ShieldOff className="h-4 w-4 mr-2" />
                                  Remove Admin
                                </>
                              ) : (
                                <>
                                  <Shield className="h-4 w-4 mr-2" />
                                  Make Admin
                                </>
                              )}
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>
                                {user.isGlobalAdmin ? "Remove Admin Access" : "Grant Admin Access"}
                              </AlertDialogTitle>
                              <AlertDialogDescription>
                                {user.isGlobalAdmin
                                  ? `Are you sure you want to remove global admin access for ${user.email}? They will no longer have administrative privileges.`
                                  : `Are you sure you want to grant global admin access to ${user.email}? They will have full administrative privileges across all teams.`}
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel data-testid="button-cancel-toggle">Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() =>
                                  toggleAdminMutation.mutate({
                                    userId: user.id,
                                    isGlobalAdmin: !user.isGlobalAdmin,
                                  })
                                }
                                data-testid="button-confirm-toggle"
                              >
                                Confirm
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      )}
                      {user.id !== currentUser.id && (
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              data-testid={`button-delete-user-${user.id}`}
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete User</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to permanently delete {user.email}?
                                {user.isTeamOwner && user.teamCount && user.teamCount > 0 ? (
                                  <span className="block mt-2 text-destructive font-medium">
                                    This user owns {user.teamCount} team{user.teamCount > 1 ? 's' : ''}. You must transfer or delete their teams before you can delete this user.
                                  </span>
                                ) : (
                                  <span className="block mt-2">
                                    This action cannot be undone.
                                  </span>
                                )}
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => deleteUserMutation.mutate(user.id)}
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                data-testid="button-confirm-delete"
                              >
                                Delete User
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      )}
                    </div>
                  </div>
                );

                return (
                  <>
                    <Collapsible open={adminUsersOpen} onOpenChange={setAdminUsersOpen}>
                      <CollapsibleTrigger asChild>
                        <Button
                          variant="ghost"
                          className="w-full justify-between hover-elevate"
                          data-testid="button-toggle-admin-users"
                        >
                          <div className="flex items-center gap-2">
                            <Shield className="h-4 w-4" />
                            <span className="font-semibold">Admin Users ({adminUsers.length})</span>
                          </div>
                          {adminUsersOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="space-y-2 pt-2">
                        {adminUsers.length === 0 ? (
                          <p className="text-sm text-muted-foreground py-4 text-center">No admin users</p>
                        ) : (
                          adminUsers.map(user => renderUser(user, true))
                        )}
                      </CollapsibleContent>
                    </Collapsible>

                    <Collapsible open={teamOwnersOpen} onOpenChange={setTeamOwnersOpen}>
                      <CollapsibleTrigger asChild>
                        <Button
                          variant="ghost"
                          className="w-full justify-between hover-elevate"
                          data-testid="button-toggle-team-owners"
                        >
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4" />
                            <span className="font-semibold">Team Owners ({teamOwners.length})</span>
                          </div>
                          {teamOwnersOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="space-y-2 pt-2">
                        {teamOwners.length === 0 ? (
                          <p className="text-sm text-muted-foreground py-4 text-center">No team owners</p>
                        ) : (
                          teamOwners.map(user => renderUser(user, false))
                        )}
                      </CollapsibleContent>
                    </Collapsible>

                    <Collapsible open={otherUsersOpen} onOpenChange={setOtherUsersOpen}>
                      <CollapsibleTrigger asChild>
                        <Button
                          variant="ghost"
                          className="w-full justify-between hover-elevate"
                          data-testid="button-toggle-other-users"
                        >
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4" />
                            <span className="font-semibold">Other Users ({otherUsers.length})</span>
                          </div>
                          {otherUsersOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="space-y-2 pt-2">
                        {otherUsers.length === 0 ? (
                          <p className="text-sm text-muted-foreground py-4 text-center">No other users</p>
                        ) : (
                          otherUsers.map(user => renderUser(user, false))
                        )}
                      </CollapsibleContent>
                    </Collapsible>
                  </>
                );
              })()}
            </>
          )}
        </CardContent>
      </Card>

      <Card id="section-membership-tiers">
        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
          <div>
            <CardTitle>Membership Tiers</CardTitle>
            <CardDescription>
              Create and manage subscription tiers with customizable limits and features
            </CardDescription>
          </div>
          <Dialog open={isTierDialogOpen} onOpenChange={(open) => {
            setIsTierDialogOpen(open);
            if (!open) {
              setEditingTier(null);
              setTierForm({ name: "", description: "", monthlyPrice: 0, annualPrice: 0, trialPeriodDays: 0, displayOrder: 0, helcimPaymentPlanId: "", helcimMonthlyCheckoutId: "", helcimAnnualCheckoutId: "", isContactForPricing: false, contactInfo: "", isDefault: false, isActive: true });
            }
          }}>
            <DialogTrigger asChild>
              <Button size="sm" data-testid="button-create-tier">
                <Plus className="h-4 w-4 mr-2" />
                New Tier
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingTier ? "Edit Membership Tier" : "Create Membership Tier"}</DialogTitle>
                <DialogDescription>
                  Configure the membership tier details, limits, and features.
                </DialogDescription>
              </DialogHeader>
              
              <Tabs defaultValue="basic" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="basic">Basic Info</TabsTrigger>
                  <TabsTrigger value="limits" disabled={!editingTier}>Limits</TabsTrigger>
                  <TabsTrigger value="features" disabled={!editingTier}>Features</TabsTrigger>
                </TabsList>
                
                <TabsContent value="basic" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="tier-name">Tier Name</Label>
                    <Input
                      id="tier-name"
                      data-testid="input-tier-name"
                      value={tierForm.name}
                      onChange={(e) => setTierForm({ ...tierForm, name: e.target.value })}
                      placeholder="e.g. Free, Pro, Enterprise"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="tier-description">Description</Label>
                    <Textarea
                      id="tier-description"
                      data-testid="input-tier-description"
                      value={tierForm.description}
                      onChange={(e) => setTierForm({ ...tierForm, description: e.target.value })}
                      placeholder="Brief description of this tier"
                      rows={3}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="contact-for-pricing">Pricing Model</Label>
                    <div className="flex items-center gap-2">
                      <Switch
                        id="contact-for-pricing"
                        checked={tierForm.isContactForPricing}
                        onCheckedChange={(checked) => setTierForm({ ...tierForm, isContactForPricing: checked })}
                        data-testid="switch-contact-for-pricing"
                      />
                      <Label htmlFor="contact-for-pricing" className="text-sm text-muted-foreground cursor-pointer">
                        Contact for Pricing (hides pricing fields)
                      </Label>
                    </div>
                  </div>

                  {tierForm.isContactForPricing ? (
                    <div className="space-y-2">
                      <Label htmlFor="contact-info">Contact Information</Label>
                      <Textarea
                        id="contact-info"
                        data-testid="input-contact-info"
                        value={tierForm.contactInfo}
                        onChange={(e) => setTierForm({ ...tierForm, contactInfo: e.target.value })}
                        placeholder="Enter contact information (e.g., email, phone, or custom message like 'sales@company.com' or 'Call us at (555) 123-4567')"
                        rows={3}
                      />
                      <p className="text-xs text-muted-foreground">
                        This information will be displayed to users who want to inquire about this tier
                      </p>
                    </div>
                  ) : (
                    <>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                      <Label htmlFor="price-monthly">Monthly Price ($)</Label>
                      <Input
                        id="price-monthly"
                        data-testid="input-price-monthly"
                        type="number"
                        min="0"
                        step="0.01"
                        value={(tierForm.monthlyPrice / 100).toFixed(2)}
                        onChange={(e) => setTierForm({ ...tierForm, monthlyPrice: Math.round((parseFloat(e.target.value) || 0) * 100) })}
                      />
                      <p className="text-xs text-muted-foreground">
                        Enter price in dollars (stored as cents)
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="price-annual">Annual Price ($)</Label>
                      <Input
                        id="price-annual"
                        data-testid="input-price-annual"
                        type="number"
                        min="0"
                        step="0.01"
                        value={(tierForm.annualPrice / 100).toFixed(2)}
                        onChange={(e) => setTierForm({ ...tierForm, annualPrice: Math.round((parseFloat(e.target.value) || 0) * 100) })}
                      />
                      <p className="text-xs text-muted-foreground">
                        Annual billing price (typically discounted)
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="helcim-plan-id">Helcim Payment Plan ID (Legacy - Optional)</Label>
                    <Input
                      id="helcim-plan-id"
                      data-testid="input-helcim-plan-id"
                      value={tierForm.helcimPaymentPlanId}
                      onChange={(e) => setTierForm({ ...tierForm, helcimPaymentPlanId: e.target.value })}
                      placeholder="Legacy Helcim payment plan ID"
                    />
                    <p className="text-xs text-muted-foreground">
                      Legacy field - use checkout IDs below instead
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="helcim-monthly-checkout">Helcim Monthly Subscription Link</Label>
                      <Input
                        id="helcim-monthly-checkout"
                        data-testid="input-helcim-monthly-checkout"
                        value={tierForm.helcimMonthlyCheckoutId}
                        onChange={(e) => setTierForm({ ...tierForm, helcimMonthlyCheckoutId: e.target.value })}
                        placeholder="https://subscriptions.helcim.com/subscribe/..."
                      />
                      <p className="text-xs text-muted-foreground">
                        Full Helcim subscription link for monthly billing
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="helcim-annual-checkout">Helcim Annual Subscription Link</Label>
                      <Input
                        id="helcim-annual-checkout"
                        data-testid="input-helcim-annual-checkout"
                        value={tierForm.helcimAnnualCheckoutId}
                        onChange={(e) => setTierForm({ ...tierForm, helcimAnnualCheckoutId: e.target.value })}
                        placeholder="https://subscriptions.helcim.com/subscribe/..."
                      />
                      <p className="text-xs text-muted-foreground">
                        Full Helcim subscription link for annual billing
                      </p>
                    </div>
                  </div>
                    </>
                  )}
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="trial-days">Trial Period (days)</Label>
                      <Input
                        id="trial-days"
                        data-testid="input-trial-days"
                        type="number"
                        min="0"
                        value={tierForm.trialPeriodDays}
                        onChange={(e) => setTierForm({ ...tierForm, trialPeriodDays: parseInt(e.target.value) || 0 })}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="display-order">Display Order</Label>
                      <Input
                        id="display-order"
                        data-testid="input-display-order"
                        type="number"
                        min="0"
                        value={tierForm.displayOrder}
                        onChange={(e) => setTierForm({ ...tierForm, displayOrder: parseInt(e.target.value) || 0 })}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="is-default">Default Tier</Label>
                    <div className="flex items-center gap-2">
                      <Switch
                        id="is-default"
                        checked={tierForm.isDefault}
                        onCheckedChange={(checked) => setTierForm({ ...tierForm, isDefault: checked })}
                        data-testid="switch-is-default"
                      />
                      <Label htmlFor="is-default" className="text-sm text-muted-foreground cursor-pointer">
                        Assign to new users
                      </Label>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="limits" className="space-y-4">
                  {editingTier && (
                    <>
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium">Current Limits</h4>
                        <div className="space-y-2">
                          {editingTier.limits.length === 0 ? (
                            <p className="text-sm text-muted-foreground py-4 text-center">
                              No limits configured
                            </p>
                          ) : (
                            editingTier.limits.map((limit) => (
                              <div key={limit.id} className="flex items-center justify-between p-3 border rounded-md">
                                <div>
                                  <p className="font-medium">{limit.limitKey}</p>
                                  <p className="text-sm text-muted-foreground">{limit.limitValue}</p>
                                </div>
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => deleteLimitMutation.mutate({ tierId: editingTier.id, limitKey: limit.limitKey })}
                                  data-testid={`button-delete-limit-${limit.limitKey}`}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-medium">Add New Limit</h4>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setIsLimitHelpOpen(true)}
                            data-testid="button-limit-help"
                          >
                            <HelpCircle className="h-4 w-4 mr-1" />
                            Available Limits
                          </Button>
                        </div>
                        <div className="flex gap-2">
                          <Input
                            placeholder="Limit key (e.g. max_teams)"
                            value={newLimit.key}
                            onChange={(e) => setNewLimit({ ...newLimit, key: e.target.value })}
                            data-testid="input-new-limit-key"
                          />
                          <Input
                            type="number"
                            placeholder="Value"
                            value={newLimit.value}
                            onChange={(e) => setNewLimit({ ...newLimit, value: parseInt(e.target.value) || 0 })}
                            data-testid="input-new-limit-value"
                          />
                          <Button
                            onClick={() => setLimitMutation.mutate({ tierId: editingTier.id, limitKey: newLimit.key, limitValue: newLimit.value })}
                            disabled={!newLimit.key}
                            data-testid="button-add-limit"
                          >
                            Add
                          </Button>
                        </div>
                      </div>
                    </>
                  )}
                </TabsContent>
                
                <TabsContent value="features" className="space-y-4">
                  {editingTier && (
                    <>
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium">Current Features</h4>
                        <div className="space-y-2">
                          {editingTier.features.length === 0 ? (
                            <p className="text-sm text-muted-foreground py-4 text-center">
                              No features configured
                            </p>
                          ) : (
                            editingTier.features.map((feature) => (
                              <div key={feature.id} className="flex items-center justify-between p-3 border rounded-md">
                                <div className="flex items-center gap-2">
                                  {feature.enabled ? (
                                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                                  ) : (
                                    <XCircle className="h-4 w-4 text-red-500" />
                                  )}
                                  <p className="font-medium">{feature.featureKey}</p>
                                </div>
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => deleteFeatureMutation.mutate({ tierId: editingTier.id, featureKey: feature.featureKey })}
                                  data-testid={`button-delete-feature-${feature.featureKey}`}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-medium">Add New Feature</h4>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setIsFeatureHelpOpen(true)}
                            data-testid="button-feature-help"
                          >
                            <HelpCircle className="h-4 w-4 mr-1" />
                            Available Features
                          </Button>
                        </div>
                        <div className="flex gap-2">
                          <Input
                            placeholder="Feature key (e.g. sms_reminders)"
                            value={newFeature.key}
                            onChange={(e) => setNewFeature({ ...newFeature, key: e.target.value })}
                            className="flex-1"
                            data-testid="input-new-feature-key"
                          />
                          <div className="flex items-center gap-2">
                            <Label htmlFor="feature-enabled">Enabled</Label>
                            <Switch
                              id="feature-enabled"
                              checked={newFeature.enabled}
                              onCheckedChange={(checked) => setNewFeature({ ...newFeature, enabled: checked })}
                              data-testid="switch-new-feature-enabled"
                            />
                          </div>
                          <Button
                            onClick={() => setFeatureMutation.mutate({ tierId: editingTier.id, featureKey: newFeature.key, enabled: newFeature.enabled })}
                            disabled={!newFeature.key}
                            data-testid="button-add-feature"
                          >
                            Add
                          </Button>
                        </div>
                      </div>
                    </>
                  )}
                </TabsContent>
              </Tabs>
              
              <DialogFooter>
                {editingTier ? (
                  <Button
                    onClick={() => updateTierMutation.mutate({ id: editingTier.id, data: tierForm })}
                    disabled={updateTierMutation.isPending || !tierForm.name}
                    data-testid="button-save-tier"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </Button>
                ) : (
                  <Button
                    onClick={() => createTierMutation.mutate(tierForm)}
                    disabled={createTierMutation.isPending || !tierForm.name}
                    data-testid="button-create-tier-submit"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Create Tier
                  </Button>
                )}
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {membershipTiers.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">
                No membership tiers configured. Create one to get started.
              </p>
            ) : (
              membershipTiers.map((tier) => (
                <div
                  key={tier.id}
                  className="p-4 rounded-md border"
                  data-testid={`tier-card-${tier.id}`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Crown className="h-5 w-5 text-primary" />
                        <h4 className="font-semibold text-lg">{tier.name}</h4>
                      </div>
                      {tier.description && (
                        <p className="text-sm text-muted-foreground mb-3">{tier.description}</p>
                      )}
                      
                      <div className="flex flex-wrap gap-3 text-sm">
                        <div className="flex items-center gap-1">
                          <DollarSign className="h-4 w-4" />
                          <span className="font-medium">${(tier.monthlyPrice / 100).toFixed(2)}/mo</span>
                        </div>
                        {tier.isDefault && (
                          <Badge variant="default">Default</Badge>
                        )}
                        {!tier.isActive && (
                          <Badge variant="destructive">Inactive</Badge>
                        )}
                        {tier.trialPeriodDays > 0 && (
                          <Badge variant="secondary">
                            {tier.trialPeriodDays}-day trial
                          </Badge>
                        )}
                      </div>
                      
                      <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <p className="text-muted-foreground mb-1">Limits ({tier.limits.length})</p>
                          {tier.limits.slice(0, 2).map((limit) => (
                            <div key={limit.id} className="text-xs">
                              {limit.limitKey}: {limit.limitValue}
                            </div>
                          ))}
                          {tier.limits.length > 2 && (
                            <span className="text-xs text-muted-foreground">+{tier.limits.length - 2} more</span>
                          )}
                        </div>
                        <div>
                          <p className="text-muted-foreground mb-1">Features ({tier.features.length})</p>
                          {tier.features.slice(0, 2).map((feature) => (
                            <div key={feature.id} className="text-xs flex items-center gap-1">
                              {feature.enabled ? (
                                <CheckCircle2 className="h-3 w-3 text-green-500" />
                              ) : (
                                <XCircle className="h-3 w-3 text-red-500" />
                              )}
                              {feature.featureKey}
                            </div>
                          ))}
                          {tier.features.length > 2 && (
                            <span className="text-xs text-muted-foreground">+{tier.features.length - 2} more</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex flex-col gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setEditingTier(tier);
                          setIsTierDialogOpen(true);
                        }}
                        data-testid={`button-edit-tier-${tier.id}`}
                      >
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" size="sm" data-testid={`button-delete-tier-${tier.id}`}>
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Membership Tier</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete the "{tier.name}" membership tier? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => deleteTierMutation.mutate(tier.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={isLimitHelpOpen} onOpenChange={setIsLimitHelpOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Available Limit Variables</DialogTitle>
            <DialogDescription>
              Use these limit keys to control tier restrictions. Enter the exact key name when adding a new limit.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {AVAILABLE_LIMITS.map((limit) => (
              <div
                key={limit.key}
                className="p-3 border rounded-md hover-elevate cursor-pointer"
                onClick={() => {
                  setNewLimit({ ...newLimit, key: limit.key });
                  setIsLimitHelpOpen(false);
                }}
                data-testid={`limit-option-${limit.key}`}
              >
                <div className="font-mono text-sm font-semibold text-primary mb-1">{limit.key}</div>
                <p className="text-sm text-muted-foreground">{limit.description}</p>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsLimitHelpOpen(false)} data-testid="button-close-limit-help">
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isFeatureHelpOpen} onOpenChange={setIsFeatureHelpOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Available Feature Variables</DialogTitle>
            <DialogDescription>
              Use these feature keys to control tier capabilities. Enter the exact key name when adding a new feature.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {AVAILABLE_FEATURES.map((feature) => (
              <div
                key={feature.key}
                className="p-3 border rounded-md hover-elevate cursor-pointer"
                onClick={() => {
                  setNewFeature({ ...newFeature, key: feature.key });
                  setIsFeatureHelpOpen(false);
                }}
                data-testid={`feature-option-${feature.key}`}
              >
                <div className="font-mono text-sm font-semibold text-primary mb-1">{feature.key}</div>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsFeatureHelpOpen(false)} data-testid="button-close-feature-help">
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Card id="section-event-templates">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Event Templates</CardTitle>
              <CardDescription>
                Create reusable event templates organized by sport
              </CardDescription>
            </div>
            <Button
              onClick={() => {
                setEditingTemplate(null);
                resetTemplateForm();
                setIsTemplateDialogOpen(true);
              }}
              data-testid="button-create-template"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Template
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {eventTemplates.length === 0 ? (
            <p className="text-sm text-muted-foreground py-8 text-center">
              No event templates created yet
            </p>
          ) : (
            <div className="space-y-4">
              {AVAILABLE_SPORTS.map((sport) => {
                const sportTemplates = eventTemplates.filter((t) => t.sport === sport);
                if (sportTemplates.length === 0) return null;

                return (
                  <div key={sport} className="space-y-2">
                    <h4 className="font-semibold text-sm">{sport}</h4>
                    <div className="grid gap-2">
                      {sportTemplates.map((template) => (
                        <div
                          key={template.id}
                          className="flex items-center justify-between p-3 border rounded-md"
                          data-testid={`template-row-${template.id}`}
                        >
                          <div>
                            <p className="font-medium" data-testid={`text-template-name-${template.id}`}>
                              {template.name}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Type: {template.type} 
                              {template.durationMinutes && template.durationMinutes > 0 ? ` • ${template.durationMinutes} min` : ""}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setEditingTemplate(template);
                                setIsTemplateDialogOpen(true);
                              }}
                              data-testid={`button-edit-template-${template.id}`}
                            >
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  data-testid={`button-delete-template-${template.id}`}
                                >
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Delete Event Template</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Are you sure you want to delete the "{template.name}" template? This action cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => deleteTemplateMutation.mutate(template.id)}
                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                  >
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <Card id="section-custom-fields">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Custom Fields</CardTitle>
              <CardDescription>
                Create custom fields that can be added to event templates
              </CardDescription>
            </div>
            <Button
              onClick={() => {
                setEditingCustomField(null);
                resetCustomFieldForm();
                setIsCustomFieldDialogOpen(true);
              }}
              data-testid="button-create-custom-field"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Field
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {customFields.length === 0 ? (
            <p className="text-sm text-muted-foreground py-8 text-center">
              No custom fields created yet
            </p>
          ) : (
            <div className="grid gap-2">
              {customFields.map((field) => (
                <div
                  key={field.id}
                  className="flex items-center justify-between p-3 border rounded-md"
                  data-testid={`custom-field-row-${field.id}`}
                >
                  <div>
                    <p className="font-medium" data-testid={`text-custom-field-name-${field.id}`}>
                      {field.name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Type: {field.fieldType}
                      {field.options && field.options.length > 0 && ` • Options: ${field.options.join(", ")}`}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setEditingCustomField(field);
                        setIsCustomFieldDialogOpen(true);
                      }}
                      data-testid={`button-edit-custom-field-${field.id}`}
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="destructive"
                          size="sm"
                          data-testid={`button-delete-custom-field-${field.id}`}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Custom Field</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete the "{field.name}" field? This will remove it from all templates that use it. This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => deleteCustomFieldMutation.mutate(field.id)}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isCustomFieldDialogOpen} onOpenChange={setIsCustomFieldDialogOpen}>
        <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingCustomField ? "Edit Custom Field" : "Create Custom Field"}</DialogTitle>
            <DialogDescription>
              Create a reusable custom field that can be added to event templates
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="field-name">Field Name *</Label>
              <Input
                id="field-name"
                data-testid="input-field-name"
                value={customFieldForm.name}
                onChange={(e) => setCustomFieldForm({ ...customFieldForm, name: e.target.value })}
                placeholder="e.g., Uniform Color, Equipment Needed"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="field-type">Field Type *</Label>
              <Select
                value={customFieldForm.fieldType}
                onValueChange={(value) => setCustomFieldForm({ ...customFieldForm, fieldType: value, options: value !== "select" ? [] : customFieldForm.options })}
              >
                <SelectTrigger id="field-type" data-testid="select-field-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="text">Text</SelectItem>
                  <SelectItem value="textarea">Text Area</SelectItem>
                  <SelectItem value="number">Number</SelectItem>
                  <SelectItem value="select">Select (Dropdown)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {customFieldForm.fieldType === "select" && (
              <div className="space-y-2">
                <Label>Options *</Label>
                <p className="text-sm text-muted-foreground">Add options for the dropdown menu</p>
                <div className="space-y-2">
                  {customFieldForm.options.map((option, index) => (
                    <div key={index} className="flex gap-2">
                      <Input value={option} disabled className="flex-1" />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const newOptions = customFieldForm.options.filter((_, i) => i !== index);
                          setCustomFieldForm({ ...customFieldForm, options: newOptions });
                        }}
                        data-testid={`button-remove-option-${index}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <div className="flex gap-2">
                    <Input
                      value={newOption}
                      onChange={(e) => setNewOption(e.target.value)}
                      placeholder="Enter option text"
                      data-testid="input-new-option"
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && newOption.trim()) {
                          e.preventDefault();
                          setCustomFieldForm({ ...customFieldForm, options: [...customFieldForm.options, newOption.trim()] });
                          setNewOption("");
                        }
                      }}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (newOption.trim()) {
                          setCustomFieldForm({ ...customFieldForm, options: [...customFieldForm.options, newOption.trim()] });
                          setNewOption("");
                        }
                      }}
                      disabled={!newOption.trim()}
                      data-testid="button-add-option"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add
                    </Button>
                  </div>
                </div>
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="field-placeholder">Placeholder Text</Label>
              <Input
                id="field-placeholder"
                data-testid="input-field-placeholder"
                value={customFieldForm.placeholder}
                onChange={(e) => setCustomFieldForm({ ...customFieldForm, placeholder: e.target.value })}
                placeholder="Optional placeholder text"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsCustomFieldDialogOpen(false);
                setEditingCustomField(null);
                resetCustomFieldForm();
              }}
              data-testid="button-cancel-custom-field"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (editingCustomField) {
                  updateCustomFieldMutation.mutate({
                    id: editingCustomField.id,
                    data: customFieldForm,
                  });
                } else {
                  createCustomFieldMutation.mutate(customFieldForm as InsertCustomField);
                }
              }}
              disabled={
                !customFieldForm.name.trim() ||
                (customFieldForm.fieldType === "select" && customFieldForm.options.length === 0)
              }
              data-testid="button-save-custom-field"
            >
              {editingCustomField ? "Update Field" : "Create Field"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingTemplate ? "Edit Event Template" : "Create Event Template"}</DialogTitle>
            <DialogDescription>
              Create a reusable template for common event types
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="template-sport">Sport *</Label>
                <Select
                  value={templateForm.sport}
                  onValueChange={(value) => setTemplateForm({ ...templateForm, sport: value })}
                >
                  <SelectTrigger id="template-sport" data-testid="select-template-sport">
                    <SelectValue placeholder="Select sport" />
                  </SelectTrigger>
                  <SelectContent>
                    {AVAILABLE_SPORTS.map((sport) => (
                      <SelectItem key={sport} value={sport}>
                        {sport}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="template-type">Event Type *</Label>
                <Select
                  value={templateForm.type}
                  onValueChange={(value) => setTemplateForm({ ...templateForm, type: value })}
                >
                  <SelectTrigger id="template-type" data-testid="select-template-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="game">Game</SelectItem>
                    <SelectItem value="practice">Practice</SelectItem>
                    <SelectItem value="team_party">Team Party</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="template-name">Template Name *</Label>
              <Input
                id="template-name"
                data-testid="input-template-name"
                value={templateForm.name}
                onChange={(e) => setTemplateForm({ ...templateForm, name: e.target.value })}
                placeholder="e.g., Home Game, Away Practice"
              />
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="template-title">Default Title</Label>
                <Input
                  id="template-title"
                  data-testid="input-template-title"
                  value={templateForm.defaultTitle}
                  onChange={(e) => setTemplateForm({ ...templateForm, defaultTitle: e.target.value })}
                  placeholder="Optional default event title"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="template-duration">Duration (minutes)</Label>
                <Input
                  id="template-duration"
                  data-testid="input-template-duration"
                  type="number"
                  value={templateForm.durationMinutes}
                  onChange={(e) => setTemplateForm({ ...templateForm, durationMinutes: parseInt(e.target.value) || 0 })}
                  placeholder="0"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="template-location">Default Location</Label>
              <Input
                id="template-location"
                data-testid="input-template-location"
                value={templateForm.defaultLocation}
                onChange={(e) => setTemplateForm({ ...templateForm, defaultLocation: e.target.value })}
                placeholder="Optional default location"
              />
            </div>

            <div className="border rounded-md p-4 space-y-3">
              <Label className="text-sm font-medium">Include Fields (Optional)</Label>
              <p className="text-sm text-muted-foreground">Select which optional fields you want to include in this template</p>
              <div className="grid gap-3 md:grid-cols-2">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="field-opponent"
                    checked={enabledFields.opponent}
                    onCheckedChange={(checked) => {
                      setEnabledFields({ ...enabledFields, opponent: checked });
                      if (!checked) setTemplateForm({ ...templateForm, opponent: "" });
                    }}
                    data-testid="switch-field-opponent"
                  />
                  <Label htmlFor="field-opponent" className="cursor-pointer">Opponent</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="field-homeaway"
                    checked={enabledFields.homeAway}
                    onCheckedChange={(checked) => {
                      setEnabledFields({ ...enabledFields, homeAway: checked });
                      if (!checked) setTemplateForm({ ...templateForm, homeAway: "" });
                    }}
                    data-testid="switch-field-homeaway"
                  />
                  <Label htmlFor="field-homeaway" className="cursor-pointer">Home/Away</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="field-fieldtype"
                    checked={enabledFields.fieldType}
                    onCheckedChange={(checked) => {
                      setEnabledFields({ ...enabledFields, fieldType: checked });
                      if (!checked) setTemplateForm({ ...templateForm, fieldType: "" });
                    }}
                    data-testid="switch-field-fieldtype"
                  />
                  <Label htmlFor="field-fieldtype" className="cursor-pointer">Field Type</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="field-cleats"
                    checked={enabledFields.cleatsAllowed}
                    onCheckedChange={(checked) => {
                      setEnabledFields({ ...enabledFields, cleatsAllowed: checked });
                      if (!checked) setTemplateForm({ ...templateForm, cleatsAllowed: "" });
                    }}
                    data-testid="switch-field-cleats"
                  />
                  <Label htmlFor="field-cleats" className="cursor-pointer">Cleats Allowed</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="field-jersey"
                    checked={enabledFields.jersey}
                    onCheckedChange={(checked) => {
                      setEnabledFields({ ...enabledFields, jersey: checked });
                      if (!checked) setTemplateForm({ ...templateForm, jersey: "" });
                    }}
                    data-testid="switch-field-jersey"
                  />
                  <Label htmlFor="field-jersey" className="cursor-pointer">Jersey</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="field-arrival"
                    checked={enabledFields.arrivalTime}
                    onCheckedChange={(checked) => {
                      setEnabledFields({ ...enabledFields, arrivalTime: checked });
                      if (!checked) setTemplateForm({ ...templateForm, arrivalTime: "" });
                    }}
                    data-testid="switch-field-arrival"
                  />
                  <Label htmlFor="field-arrival" className="cursor-pointer">Arrival Time</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="field-notes"
                    checked={enabledFields.notes}
                    onCheckedChange={(checked) => {
                      setEnabledFields({ ...enabledFields, notes: checked });
                      if (!checked) setTemplateForm({ ...templateForm, notes: "" });
                    }}
                    data-testid="switch-field-notes"
                  />
                  <Label htmlFor="field-notes" className="cursor-pointer">Notes</Label>
                </div>
              </div>
            </div>

            {customFields.length > 0 && (
              <div className="border rounded-md p-4 space-y-3">
                <Label className="text-sm font-medium">Custom Fields</Label>
                <p className="text-sm text-muted-foreground">Select additional custom fields to include in this template</p>
                <div className="grid gap-3 md:grid-cols-2">
                  {customFields.map((field) => (
                    <div key={field.id} className="flex items-center space-x-2">
                      <Switch
                        id={`custom-field-${field.id}`}
                        checked={templateForm.customFieldIds.includes(field.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setTemplateForm({
                              ...templateForm,
                              customFieldIds: [...templateForm.customFieldIds, field.id]
                            });
                          } else {
                            setTemplateForm({
                              ...templateForm,
                              customFieldIds: templateForm.customFieldIds.filter(id => id !== field.id)
                            });
                          }
                        }}
                        data-testid={`switch-custom-field-${field.id}`}
                      />
                      <Label htmlFor={`custom-field-${field.id}`} className="cursor-pointer">
                        {field.name} ({field.fieldType})
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {(enabledFields.opponent || enabledFields.homeAway) && (
              <div className="grid gap-4 md:grid-cols-2">
                {enabledFields.opponent && (
                  <div className="space-y-2">
                    <Label htmlFor="template-opponent">Opponent</Label>
                    <Input
                      id="template-opponent"
                      data-testid="input-template-opponent"
                      value={templateForm.opponent}
                      onChange={(e) => setTemplateForm({ ...templateForm, opponent: e.target.value })}
                      placeholder="Optional opponent"
                    />
                  </div>
                )}
                {enabledFields.homeAway && (
                  <div className="space-y-2">
                    <Label htmlFor="template-homeaway">Home/Away</Label>
                    <Select
                      value={templateForm.homeAway || "none"}
                      onValueChange={(value) => setTemplateForm({ ...templateForm, homeAway: value === "none" ? "" : value })}
                    >
                      <SelectTrigger id="template-homeaway" data-testid="select-template-homeaway">
                        <SelectValue placeholder="Select option" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        <SelectItem value="home">Home</SelectItem>
                        <SelectItem value="away">Away</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            )}
            {(enabledFields.fieldType || enabledFields.cleatsAllowed) && (
              <div className="grid gap-4 md:grid-cols-2">
                {enabledFields.fieldType && (
                  <div className="space-y-2">
                    <Label htmlFor="template-field">Field Type</Label>
                    <Input
                      id="template-field"
                      data-testid="input-template-field"
                      value={templateForm.fieldType}
                      onChange={(e) => setTemplateForm({ ...templateForm, fieldType: e.target.value })}
                      placeholder="e.g., grass, turf"
                    />
                  </div>
                )}
                {enabledFields.cleatsAllowed && (
                  <div className="space-y-2">
                    <Label htmlFor="template-cleats">Cleats Allowed</Label>
                    <Input
                      id="template-cleats"
                      data-testid="input-template-cleats"
                      value={templateForm.cleatsAllowed}
                      onChange={(e) => setTemplateForm({ ...templateForm, cleatsAllowed: e.target.value })}
                      placeholder="e.g., any, non-metal"
                    />
                  </div>
                )}
              </div>
            )}
            {(enabledFields.jersey || enabledFields.arrivalTime) && (
              <div className="grid gap-4 md:grid-cols-2">
                {enabledFields.jersey && (
                  <div className="space-y-2">
                    <Label htmlFor="template-jersey">Jersey</Label>
                    <Input
                      id="template-jersey"
                      data-testid="input-template-jersey"
                      value={templateForm.jersey}
                      onChange={(e) => setTemplateForm({ ...templateForm, jersey: e.target.value })}
                      placeholder="e.g., home, away"
                    />
                  </div>
                )}
                {enabledFields.arrivalTime && (
                  <div className="space-y-2">
                    <Label htmlFor="template-arrival">Arrival Time</Label>
                    <Input
                      id="template-arrival"
                      data-testid="input-template-arrival"
                      value={templateForm.arrivalTime}
                      onChange={(e) => setTemplateForm({ ...templateForm, arrivalTime: e.target.value })}
                      placeholder="e.g., 30 min before"
                    />
                  </div>
                )}
              </div>
            )}
            {enabledFields.notes && (
              <div className="space-y-2">
                <Label htmlFor="template-notes">Notes</Label>
                <Textarea
                  id="template-notes"
                  data-testid="input-template-notes"
                  value={templateForm.notes}
                  onChange={(e) => setTemplateForm({ ...templateForm, notes: e.target.value })}
                  placeholder="Optional notes or instructions"
                  rows={3}
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsTemplateDialogOpen(false);
                setEditingTemplate(null);
                resetTemplateForm();
              }}
              data-testid="button-cancel-template"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (editingTemplate) {
                  updateTemplateMutation.mutate({
                    id: editingTemplate.id,
                    data: templateForm,
                  });
                } else {
                  createTemplateMutation.mutate(templateForm as InsertEventTemplate);
                }
              }}
              disabled={!templateForm.sport || !templateForm.name || !templateForm.type}
              data-testid="button-save-template"
            >
              {editingTemplate ? "Update Template" : "Create Template"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isEditUserDialogOpen} onOpenChange={(open) => {
        setIsEditUserDialogOpen(open);
        if (!open) {
          setEditingUser(null);
        }
      }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit User Account</DialogTitle>
            <DialogDescription>
              Update user account information. Note: Passwords are managed by the authentication provider (Replit/Google).
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="edit-first-name">First Name</Label>
                <Input
                  id="edit-first-name"
                  data-testid="input-edit-first-name"
                  value={userEditForm.firstName}
                  onChange={(e) => setUserEditForm({ ...userEditForm, firstName: e.target.value })}
                  placeholder="John"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-last-name">Last Name</Label>
                <Input
                  id="edit-last-name"
                  data-testid="input-edit-last-name"
                  value={userEditForm.lastName}
                  onChange={(e) => setUserEditForm({ ...userEditForm, lastName: e.target.value })}
                  placeholder="Doe"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-email">Email Address</Label>
              <Input
                id="edit-email"
                data-testid="input-edit-email"
                type="email"
                value={userEditForm.email}
                onChange={(e) => setUserEditForm({ ...userEditForm, email: e.target.value })}
                placeholder="john.doe@example.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-sports">Sports</Label>
              <div className="text-sm text-muted-foreground mb-2">
                Select the sports this user manages
              </div>
              <div className="grid gap-2 grid-cols-2">
                {AVAILABLE_SPORTS.map((sport) => (
                  <div key={sport} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`sport-${sport}`}
                      checked={userEditForm.sports.includes(sport)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setUserEditForm({
                            ...userEditForm,
                            sports: [...userEditForm.sports, sport],
                          });
                        } else {
                          setUserEditForm({
                            ...userEditForm,
                            sports: userEditForm.sports.filter((s) => s !== sport),
                          });
                        }
                      }}
                      className="rounded border-gray-300"
                      data-testid={`checkbox-sport-${sport}`}
                    />
                    <label
                      htmlFor={`sport-${sport}`}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      {sport}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsEditUserDialogOpen(false);
                setEditingUser(null);
              }}
              data-testid="button-cancel-edit-user"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (editingUser) {
                  updateUserMutation.mutate({
                    userId: editingUser.id,
                    userData: userEditForm,
                  });
                }
              }}
              disabled={!userEditForm.email || updateUserMutation.isPending}
              data-testid="button-save-edit-user"
            >
              {updateUserMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Campaign Templates Section */}
      <Card id="section-campaign-templates">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Campaign Templates</CardTitle>
              <CardDescription>
                Create reusable SMS campaign templates with pre-filled messages for coaches
              </CardDescription>
            </div>
            <Button
              onClick={() => {
                setIsCampaignTemplateDialogOpen(true);
                setEditingCampaignTemplate(null);
                setCampaignTemplateForm({
                  name: "",
                  description: "",
                });
              }}
              data-testid="button-create-campaign-template"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Template
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {campaignTemplatesQuery.isLoading ? (
            <p className="text-sm text-muted-foreground">Loading templates...</p>
          ) : campaignTemplates.length === 0 ? (
            <div className="text-center py-8">
              <Bell className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Campaign Templates</h3>
              <p className="text-muted-foreground mb-4">
                Create reusable campaign templates to help coaches send consistent messages
              </p>
              <Button
                onClick={() => {
                  setIsCampaignTemplateDialogOpen(true);
                  setEditingCampaignTemplate(null);
                  setCampaignTemplateForm({
                    name: "",
                    description: "",
                  });
                }}
                data-testid="button-create-first-campaign-template"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Template
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {campaignTemplates.map((template) => (
                <Card key={template.id} data-testid={`card-campaign-template-${template.id}`}>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold">{template.name}</h3>
                          {template.description && (
                            <p className="text-sm text-muted-foreground mt-1">
                              {template.description}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setEditingCampaignTemplate(template);
                              setCampaignTemplateForm({
                                name: template.name,
                                description: template.description || "",
                              });
                              setIsCampaignTemplateDialogOpen(true);
                            }}
                            data-testid={`button-edit-campaign-template-${template.id}`}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                data-testid={`button-delete-campaign-template-${template.id}`}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Campaign Template</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Are you sure you want to delete "{template.name}"? This will also delete all associated reminders.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => deleteCampaignTemplateMutation.mutate(template.id)}
                                  data-testid={`confirm-delete-campaign-template-${template.id}`}
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>

                      {/* Reminders for this template */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-sm font-medium">Reminders</Label>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setEditingReminder(null);
                              setAddingReminderTo(template.id);
                              setReminderForm({
                                intervalHours: 24,
                                messageTemplate: "",
                                minReliability: null,
                                maxReliability: null,
                              });
                            }}
                            data-testid={`button-add-reminder-${template.id}`}
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Add Reminder
                          </Button>
                        </div>

                        {templateRemindersQuery(template.id).isLoading ? (
                          <p className="text-sm text-muted-foreground">Loading reminders...</p>
                        ) : templateReminders[template.id]?.length === 0 ? (
                          <p className="text-sm text-muted-foreground">No reminders configured</p>
                        ) : (
                          <div className="space-y-2">
                            {templateReminders[template.id]?.map((reminder) => (
                              editingReminder?.id === reminder.id ? (
                                <div
                                  key={reminder.id}
                                  className="p-4 border rounded-md space-y-4 bg-muted/50"
                                  data-testid={`edit-reminder-form-${reminder.id}`}
                                >
                                  <h4 className="font-medium">Edit Reminder</h4>
                                  <div className="space-y-3">
                                    <div className="space-y-2">
                                      <Label htmlFor={`edit-reminder-interval-${reminder.id}`}>Hours Before Event</Label>
                                      <Input
                                        id={`edit-reminder-interval-${reminder.id}`}
                                        type="number"
                                        min="1"
                                        value={reminderForm.intervalHours}
                                        onChange={(e) =>
                                          setReminderForm({
                                            ...reminderForm,
                                            intervalHours: parseInt(e.target.value) || 24,
                                          })
                                        }
                                        data-testid="input-edit-reminder-interval"
                                      />
                                    </div>
                                    <div className="space-y-2">
                                      <Label htmlFor={`edit-reminder-message-${reminder.id}`}>Message Template</Label>
                                      <Textarea
                                        id={`edit-reminder-message-${reminder.id}`}
                                        value={reminderForm.messageTemplate}
                                        onChange={(e) =>
                                          setReminderForm({
                                            ...reminderForm,
                                            messageTemplate: e.target.value,
                                          })
                                        }
                                        placeholder="Hi {firstName}, reminder for {eventTitle} on {eventDate} at {eventTime}..."
                                        rows={3}
                                        data-testid="input-edit-reminder-message"
                                      />
                                    </div>
                                    <div className="grid gap-4 md:grid-cols-2">
                                      <div className="space-y-2">
                                        <Label htmlFor={`edit-reminder-min-reliability-${reminder.id}`}>Min Reliability (Optional)</Label>
                                        <Input
                                          id={`edit-reminder-min-reliability-${reminder.id}`}
                                          type="number"
                                          min="0"
                                          max="5"
                                          value={reminderForm.minReliability ?? ""}
                                          onChange={(e) =>
                                            setReminderForm({
                                              ...reminderForm,
                                              minReliability: e.target.value === "" ? null : parseInt(e.target.value),
                                            })
                                          }
                                          data-testid="input-edit-reminder-min-reliability"
                                        />
                                      </div>
                                      <div className="space-y-2">
                                        <Label htmlFor={`edit-reminder-max-reliability-${reminder.id}`}>Max Reliability (Optional)</Label>
                                        <Input
                                          id={`edit-reminder-max-reliability-${reminder.id}`}
                                          type="number"
                                          min="0"
                                          max="5"
                                          value={reminderForm.maxReliability ?? ""}
                                          onChange={(e) =>
                                            setReminderForm({
                                              ...reminderForm,
                                              maxReliability: e.target.value === "" ? null : parseInt(e.target.value),
                                            })
                                          }
                                          data-testid="input-edit-reminder-max-reliability"
                                        />
                                      </div>
                                    </div>
                                    <div className="flex gap-2">
                                      <Button
                                        onClick={() => {
                                          updateTemplateReminderMutation.mutate({
                                            templateId: template.id,
                                            reminderId: reminder.id,
                                            data: {
                                              intervalHours: reminderForm.intervalHours,
                                              messageTemplate: reminderForm.messageTemplate,
                                              minReliability: reminderForm.minReliability,
                                              maxReliability: reminderForm.maxReliability,
                                            },
                                          });
                                        }}
                                        disabled={updateTemplateReminderMutation.isPending}
                                        data-testid="button-update-reminder"
                                      >
                                        {updateTemplateReminderMutation.isPending ? "Updating..." : "Update Reminder"}
                                      </Button>
                                      <Button
                                        variant="outline"
                                        onClick={() => {
                                          setEditingReminder(null);
                                          setReminderForm({ intervalHours: 24, messageTemplate: "", minReliability: null, maxReliability: null });
                                        }}
                                        data-testid="button-cancel-edit-reminder"
                                      >
                                        Cancel
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              ) : (
                                <div
                                  key={reminder.id}
                                  className="p-3 border rounded-md space-y-2"
                                  data-testid={`reminder-${reminder.id}`}
                                >
                                  <div className="flex items-start justify-between">
                                    <div className="flex-1">
                                      <div className="flex items-center gap-2 mb-1">
                                        <Badge variant="outline">
                                          {reminder.intervalHours}h before
                                        </Badge>
                                        {(reminder.minReliability !== null || reminder.maxReliability !== null) && (
                                          <Badge variant="secondary">
                                            Reliability: {reminder.minReliability ?? 0}-{reminder.maxReliability ?? 5}
                                          </Badge>
                                        )}
                                      </div>
                                      <p className="text-sm">{reminder.messageTemplate}</p>
                                    </div>
                                    <div className="flex gap-1">
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => {
                                          setEditingReminder(reminder);
                                          setAddingReminderTo(null);
                                          setReminderForm({
                                            intervalHours: reminder.intervalHours,
                                            messageTemplate: reminder.messageTemplate,
                                            minReliability: reminder.minReliability,
                                            maxReliability: reminder.maxReliability,
                                          });
                                        }}
                                        data-testid={`button-edit-reminder-${reminder.id}`}
                                      >
                                        <Edit className="h-3 w-3" />
                                      </Button>
                                      <AlertDialog>
                                        <AlertDialogTrigger asChild>
                                          <Button
                                            variant="ghost"
                                            size="sm"
                                            data-testid={`button-delete-reminder-${reminder.id}`}
                                          >
                                            <Trash2 className="h-3 w-3" />
                                          </Button>
                                        </AlertDialogTrigger>
                                        <AlertDialogContent>
                                          <AlertDialogHeader>
                                            <AlertDialogTitle>Delete Reminder</AlertDialogTitle>
                                            <AlertDialogDescription>
                                              Are you sure you want to delete this reminder?
                                            </AlertDialogDescription>
                                          </AlertDialogHeader>
                                          <AlertDialogFooter>
                                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                                            <AlertDialogAction
                                              onClick={() => deleteTemplateReminderMutation.mutate({
                                                templateId: template.id,
                                                reminderId: reminder.id,
                                              })}
                                              data-testid={`confirm-delete-reminder-${reminder.id}`}
                                            >
                                              Delete
                                            </AlertDialogAction>
                                          </AlertDialogFooter>
                                        </AlertDialogContent>
                                      </AlertDialog>
                                    </div>
                                  </div>
                                </div>
                              )
                            ))}
                          </div>
                        )}

                        {/* Add Reminder Form */}
                        {addingReminderTo === template.id && (
                          <div className="p-4 border rounded-md space-y-4 bg-muted/50">
                            <h4 className="font-medium">Add New Reminder</h4>
                            <div className="space-y-3">
                              <div className="space-y-2">
                                <Label htmlFor="reminder-interval">Hours Before Event</Label>
                                <Input
                                  id="reminder-interval"
                                  type="number"
                                  min="1"
                                  value={reminderForm.intervalHours}
                                  onChange={(e) =>
                                    setReminderForm({
                                      ...reminderForm,
                                      intervalHours: parseInt(e.target.value) || 24,
                                    })
                                  }
                                  data-testid="input-reminder-interval"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="reminder-message">Message Template</Label>
                                <Textarea
                                  id="reminder-message"
                                  value={reminderForm.messageTemplate}
                                  onChange={(e) =>
                                    setReminderForm({
                                      ...reminderForm,
                                      messageTemplate: e.target.value,
                                    })
                                  }
                                  placeholder="Hi {firstName}, reminder for {eventTitle} on {eventDate} at {eventTime}..."
                                  rows={3}
                                  data-testid="input-reminder-message"
                                />
                                <div className="text-xs text-muted-foreground space-y-1">
                                  <p className="font-medium">Available variables:</p>
                                  <p><strong>Player:</strong> {"{firstName}"}, {"{playerName}"}</p>
                                  <p><strong>Team:</strong> {"{teamName}"}, {"{coachName}"}</p>
                                  <p><strong>Event:</strong> {"{eventTitle}"}, {"{eventType}"}, {"{eventDate}"}, {"{eventTime}"}, {"{location}"}</p>
                                  <p><strong>Details:</strong> {"{opponent}"}, {"{homeAway}"}, {"{fieldType}"}, {"{cleats}"}, {"{jersey}"}, {"{arrivalTime}"}</p>
                                  <p className="text-muted-foreground/70 italic mt-1">Note: Event variables only work for event-based campaigns</p>
                                </div>
                              </div>
                              <div className="grid gap-4 md:grid-cols-2">
                                <div className="space-y-2">
                                  <Label htmlFor="reminder-min-reliability">Min Reliability (Optional)</Label>
                                  <Input
                                    id="reminder-min-reliability"
                                    type="number"
                                    min="0"
                                    max="5"
                                    step="0.1"
                                    value={reminderForm.minReliability ?? ""}
                                    onChange={(e) =>
                                      setReminderForm({
                                        ...reminderForm,
                                        minReliability: e.target.value ? parseFloat(e.target.value) : null,
                                      })
                                    }
                                    placeholder="0"
                                    data-testid="input-reminder-min-reliability"
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="reminder-max-reliability">Max Reliability (Optional)</Label>
                                  <Input
                                    id="reminder-max-reliability"
                                    type="number"
                                    min="0"
                                    max="5"
                                    step="0.1"
                                    value={reminderForm.maxReliability ?? ""}
                                    onChange={(e) =>
                                      setReminderForm({
                                        ...reminderForm,
                                        maxReliability: e.target.value ? parseFloat(e.target.value) : null,
                                      })
                                    }
                                    placeholder="5"
                                    data-testid="input-reminder-max-reliability"
                                  />
                                </div>
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  variant="outline"
                                  onClick={() => {
                                    setAddingReminderTo(null);
                                    setReminderForm({
                                      intervalHours: 24,
                                      messageTemplate: "",
                                      minReliability: null,
                                      maxReliability: null,
                                    });
                                  }}
                                  data-testid="button-cancel-add-reminder"
                                >
                                  Cancel
                                </Button>
                                <Button
                                  onClick={() => {
                                    createTemplateReminderMutation.mutate({
                                      templateId: template.id,
                                      data: {
                                        ...reminderForm,
                                        templateId: template.id,
                                      },
                                    });
                                  }}
                                  disabled={!reminderForm.messageTemplate || createTemplateReminderMutation.isPending}
                                  data-testid="button-save-reminder"
                                >
                                  {createTemplateReminderMutation.isPending ? "Adding..." : "Add Reminder"}
                                </Button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Campaign Template Create/Edit Dialog */}
      <Dialog open={isCampaignTemplateDialogOpen} onOpenChange={setIsCampaignTemplateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingCampaignTemplate ? "Edit Campaign Template" : "Create Campaign Template"}
            </DialogTitle>
            <DialogDescription>
              {editingCampaignTemplate
                ? "Update the template name and description"
                : "Create a new campaign template that coaches can use"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="campaign-template-name">Template Name</Label>
              <Input
                id="campaign-template-name"
                value={campaignTemplateForm.name}
                onChange={(e) =>
                  setCampaignTemplateForm({ ...campaignTemplateForm, name: e.target.value })
                }
                placeholder="e.g., Game Day Reminders, Practice Notifications"
                data-testid="input-campaign-template-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="campaign-template-description">Description (Optional)</Label>
              <Textarea
                id="campaign-template-description"
                value={campaignTemplateForm.description}
                onChange={(e) =>
                  setCampaignTemplateForm({ ...campaignTemplateForm, description: e.target.value })
                }
                placeholder="Brief description of when to use this template..."
                rows={3}
                data-testid="input-campaign-template-description"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsCampaignTemplateDialogOpen(false);
                setEditingCampaignTemplate(null);
              }}
              data-testid="button-cancel-campaign-template"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (editingCampaignTemplate) {
                  updateCampaignTemplateMutation.mutate({
                    id: editingCampaignTemplate.id,
                    data: campaignTemplateForm,
                  });
                } else {
                  createCampaignTemplateMutation.mutate(campaignTemplateForm);
                }
              }}
              disabled={!campaignTemplateForm.name}
              data-testid="button-save-campaign-template"
            >
              {editingCampaignTemplate ? "Update Template" : "Create Template"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Usage Pricing Section */}
      <Card id="section-usage-pricing">
        <CardHeader>
          <CardTitle>Usage Pricing Configuration</CardTitle>
          <CardDescription>
            Configure base costs and markup for SMS messages and phone number rentals
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {!parsedUsagePricing ? (
            <p className="text-sm text-muted-foreground">Loading pricing configuration...</p>
          ) : (
            <>
          {/* SMS Pricing */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">SMS Message Pricing</h3>
            <div className="space-y-4 pl-4 border-l-2">
              <div className="space-y-2">
                <Label htmlFor="sms-base-cost" data-testid="label-sms-base-cost">
                  Base Cost per SMS (USD)
                </Label>
                <Input
                  id="sms-base-cost"
                  type="number"
                  step="0.0001"
                  min="0"
                  data-testid="input-sms-base-cost"
                  value={usagePricingForm.smsBaseCost}
                  onChange={(e) =>
                    setUsagePricingForm({
                      ...usagePricingForm,
                      smsBaseCost: parseFloat(e.target.value) || 0,
                    })
                  }
                  placeholder="0.0079"
                />
                <p className="text-sm text-muted-foreground">
                  The cost you pay to Twilio per SMS message
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="sms-markup-type" data-testid="label-sms-markup-type">
                  Markup Type
                </Label>
                <Select
                  value={usagePricingForm.smsMarkupType}
                  onValueChange={(value: 'percentage' | 'fixed') =>
                    setUsagePricingForm({
                      ...usagePricingForm,
                      smsMarkupType: value,
                    })
                  }
                >
                  <SelectTrigger id="sms-markup-type" data-testid="select-sms-markup-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage (%)</SelectItem>
                    <SelectItem value="fixed">Fixed Amount (USD)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="sms-markup-value" data-testid="label-sms-markup-value">
                  {usagePricingForm.smsMarkupType === 'percentage'
                    ? 'Markup Percentage (%)'
                    : 'Fixed Markup (USD)'}
                </Label>
                <Input
                  id="sms-markup-value"
                  type="number"
                  step={usagePricingForm.smsMarkupType === 'percentage' ? '1' : '0.0001'}
                  min="0"
                  data-testid="input-sms-markup-value"
                  value={usagePricingForm.smsMarkupValue}
                  onChange={(e) =>
                    setUsagePricingForm({
                      ...usagePricingForm,
                      smsMarkupValue: parseFloat(e.target.value) || 0,
                    })
                  }
                  placeholder={usagePricingForm.smsMarkupType === 'percentage' ? '50' : '0.005'}
                />
                <p className="text-sm text-muted-foreground">
                  {usagePricingForm.smsMarkupType === 'percentage'
                    ? `With ${usagePricingForm.smsMarkupValue}% markup, a $${usagePricingForm.smsBaseCost.toFixed(4)} SMS costs $${(
                        usagePricingForm.smsBaseCost *
                        (1 + usagePricingForm.smsMarkupValue / 100)
                      ).toFixed(4)}`
                    : `With $${usagePricingForm.smsMarkupValue.toFixed(4)} markup, a $${usagePricingForm.smsBaseCost.toFixed(4)} SMS costs $${(
                        usagePricingForm.smsBaseCost + usagePricingForm.smsMarkupValue
                      ).toFixed(4)}`}
                </p>
              </div>
            </div>
          </div>

          {/* Phone Number Pricing */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Phone Number Rental Pricing</h3>
            <div className="space-y-4 pl-4 border-l-2">
              <div className="space-y-2">
                <Label htmlFor="phone-base-cost" data-testid="label-phone-base-cost">
                  Base Cost per Month (USD)
                </Label>
                <Input
                  id="phone-base-cost"
                  type="number"
                  step="0.01"
                  min="0"
                  data-testid="input-phone-base-cost"
                  value={usagePricingForm.phoneNumberBaseCost}
                  onChange={(e) =>
                    setUsagePricingForm({
                      ...usagePricingForm,
                      phoneNumberBaseCost: parseFloat(e.target.value) || 0,
                    })
                  }
                  placeholder="2.00"
                />
                <p className="text-sm text-muted-foreground">
                  The monthly cost you pay to Twilio for a dedicated phone number
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone-markup-type" data-testid="label-phone-markup-type">
                  Markup Type
                </Label>
                <Select
                  value={usagePricingForm.phoneNumberMarkupType}
                  onValueChange={(value: 'percentage' | 'fixed') =>
                    setUsagePricingForm({
                      ...usagePricingForm,
                      phoneNumberMarkupType: value,
                    })
                  }
                >
                  <SelectTrigger id="phone-markup-type" data-testid="select-phone-markup-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage (%)</SelectItem>
                    <SelectItem value="fixed">Fixed Amount (USD)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone-markup-value" data-testid="label-phone-markup-value">
                  {usagePricingForm.phoneNumberMarkupType === 'percentage'
                    ? 'Markup Percentage (%)'
                    : 'Fixed Markup (USD)'}
                </Label>
                <Input
                  id="phone-markup-value"
                  type="number"
                  step={usagePricingForm.phoneNumberMarkupType === 'percentage' ? '1' : '0.01'}
                  min="0"
                  data-testid="input-phone-markup-value"
                  value={usagePricingForm.phoneNumberMarkupValue}
                  onChange={(e) =>
                    setUsagePricingForm({
                      ...usagePricingForm,
                      phoneNumberMarkupValue: parseFloat(e.target.value) || 0,
                    })
                  }
                  placeholder={usagePricingForm.phoneNumberMarkupType === 'percentage' ? '25' : '0.50'}
                />
                <p className="text-sm text-muted-foreground">
                  {usagePricingForm.phoneNumberMarkupType === 'percentage'
                    ? `With ${usagePricingForm.phoneNumberMarkupValue}% markup, a $${usagePricingForm.phoneNumberBaseCost.toFixed(2)}/month number costs $${(
                        usagePricingForm.phoneNumberBaseCost *
                        (1 + usagePricingForm.phoneNumberMarkupValue / 100)
                      ).toFixed(2)}/month`
                    : `With $${usagePricingForm.phoneNumberMarkupValue.toFixed(2)} markup, a $${usagePricingForm.phoneNumberBaseCost.toFixed(2)}/month number costs $${(
                        usagePricingForm.phoneNumberBaseCost + usagePricingForm.phoneNumberMarkupValue
                      ).toFixed(2)}/month`}
                </p>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end pt-4 border-t">
            <Button
              onClick={() => {
                updateUsagePricingMutation.mutate({
                  smsBaseCost: usagePricingForm.smsBaseCost.toString(),
                  smsMarkupType: usagePricingForm.smsMarkupType,
                  smsMarkupValue: usagePricingForm.smsMarkupValue.toString(),
                  phoneNumberBaseCost: usagePricingForm.phoneNumberBaseCost.toString(),
                  phoneNumberMarkupType: usagePricingForm.phoneNumberMarkupType,
                  phoneNumberMarkupValue: usagePricingForm.phoneNumberMarkupValue.toString(),
                });
              }}
              disabled={updateUsagePricingMutation.isPending}
              data-testid="button-save-usage-pricing"
            >
              <Save className="h-4 w-4 mr-2" />
              {updateUsagePricingMutation.isPending ? 'Saving...' : 'Save Pricing'}
            </Button>
          </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Payment Providers Section */}
      <Card id="section-payment-providers">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Payment Providers</CardTitle>
              <CardDescription>
                Configure payment providers for team fee collection and platform subscriptions
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {paymentProviders.length === 0 ? (
            <div className="text-center py-8">
              <DollarSign className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Payment Providers</h3>
              <p className="text-muted-foreground mb-4">
                No payment providers are currently configured
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {paymentProviders.map((provider: any) => (
                <Card key={provider.id} data-testid={`card-provider-${provider.name.toLowerCase()}`}>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-lg font-semibold">{provider.name}</h3>
                          <Badge variant={provider.isEnabled ? "default" : "secondary"}>
                            {provider.isEnabled ? "Enabled" : "Disabled"}
                          </Badge>
                        </div>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <span className="text-muted-foreground">API Status:</span>
                            <Badge variant="outline">
                              {provider.apiKey ? "✓ Configured" : "Not configured"}
                            </Badge>
                          </div>
                          {provider.webhookSecret && (
                            <div className="flex items-center gap-2">
                              <span className="text-muted-foreground">Webhook:</span>
                              <Badge variant="outline">
                                ✓ Configured
                              </Badge>
                            </div>
                          )}
                          {provider.isEnabled && (
                            <div className="mt-3">
                              <Label className="text-xs text-muted-foreground">Webhook URL</Label>
                              <div className="flex gap-2 mt-1">
                                <Input
                                  value={`${window.location.origin}/api/webhooks/payment-notifications`}
                                  readOnly
                                  className="text-xs font-mono"
                                  data-testid={`input-webhook-url-${provider.name.toLowerCase()}`}
                                />
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    navigator.clipboard.writeText(
                                      `${window.location.origin}/api/webhooks/payment-notifications`
                                    );
                                    toast({
                                      title: "Copied!",
                                      description: "Webhook URL copied to clipboard",
                                    });
                                  }}
                                  data-testid={`button-copy-webhook-${provider.name.toLowerCase()}`}
                                >
                                  <Copy className="h-4 w-4" />
                                </Button>
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                Add this URL to your {provider.name} dashboard to receive payment notifications
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">
                          {provider.isEnabled ? "Enabled" : "Disabled"}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              <div className="mt-6 p-4 bg-muted rounded-lg">
                <h4 className="font-medium mb-2">Environment Variables Required</h4>
                <div className="text-sm text-muted-foreground space-y-1">
                  <p>• <code className="bg-background px-1 rounded">HELCIM_API_KEY</code> - Your Helcim API key</p>
                  <p>• <code className="bg-background px-1 rounded">HELCIM_WEBHOOK_SECRET</code> - Your Helcim webhook verifier token</p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

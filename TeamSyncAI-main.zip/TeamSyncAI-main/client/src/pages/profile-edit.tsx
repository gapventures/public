import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { User, Player } from "@shared/schema";
import { Loader2, Upload, Baby } from "lucide-react";
import { UploadButton } from "@/utils/uploadthing";
import { autoFormatPhoneInput, formatPhoneForDisplay } from "@shared/phoneUtils";

const profileSchema = z.object({
  email: z.string().email("Invalid email address"),
  phone: z.string().optional(),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  address: z.string().optional(),
  preferredPosition: z.string().optional(),
});

const playerSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  phone: z.string().min(1, "Phone number is required"),
  email: z.string().email("Invalid email address").optional().or(z.literal("")),
  dateOfBirth: z.string().optional(),
  position: z.string().optional(),
});

type ProfileFormData = z.infer<typeof profileSchema>;
type PlayerFormData = z.infer<typeof playerSchema>;

export default function ProfileEdit() {
  const { toast } = useToast();
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  const { data: profile, isLoading } = useQuery<User>({
    queryKey: ["/api/profile"],
  });

  const { data: playerRecord } = useQuery<Player>({
    queryKey: ["/api/profile/player"],
    enabled: profile?.accountType === "parent",
  });

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    values: profile ? {
      email: profile.email || "",
      phone: formatPhoneForDisplay(profile.phone) || "",
      firstName: profile.firstName || "",
      lastName: profile.lastName || "",
      address: profile.address || "",
      preferredPosition: profile.preferredPosition || "",
    } : undefined,
  });

  const playerForm = useForm<PlayerFormData>({
    resolver: zodResolver(playerSchema),
    values: playerRecord ? {
      firstName: playerRecord.firstName || "",
      lastName: playerRecord.lastName || "",
      phone: formatPhoneForDisplay(playerRecord.phone) || "",
      email: playerRecord.email || "",
      dateOfBirth: playerRecord.dateOfBirth || "",
      position: playerRecord.position || "",
    } : undefined,
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormData & { profileImageUrl?: string }) => {
      return await apiRequest("PUT", "/api/profile", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updatePlayerMutation = useMutation({
    mutationFn: async (data: PlayerFormData) => {
      if (!playerRecord?.id) throw new Error("No player record found");
      return await apiRequest("PATCH", `/api/players/${playerRecord.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile/player"] });
      toast({
        title: "Player information updated",
        description: "Your child's information has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update player information. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: ProfileFormData) => {
    updateProfileMutation.mutate({
      ...data,
      profileImageUrl: profile?.profileImageUrl || undefined,
    });
  };

  const handlePlayerSubmit = (data: PlayerFormData) => {
    updatePlayerMutation.mutate(data);
  };

  const handlePhotoUpload = async (url: string) => {
    try {
      if (!profile?.email) {
        throw new Error("Profile email is missing");
      }
      
      await apiRequest("PUT", "/api/profile", {
        email: profile.email,
        phone: profile.phone || '',
        firstName: profile.firstName || '',
        lastName: profile.lastName || '',
        address: profile.address || '',
        preferredPosition: profile.preferredPosition || '',
        profileImageUrl: url,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Photo uploaded",
        description: "Your profile photo has been updated.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to upload photo. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploadingPhoto(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
          <p className="text-muted-foreground">Loading profile...</p>
        </div>
      </div>
    );
  }

  const initials = profile
    ? `${profile.firstName?.[0] || ""}${profile.lastName?.[0] || ""}`.toUpperCase() || profile.email?.[0]?.toUpperCase() || "?"
    : "?";

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="font-bold">Edit Profile</h1>
        <p className="text-muted-foreground mt-2 text-sm md:text-base">
          Update your personal information and preferences
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Profile Photo</CardTitle>
          <CardDescription>Upload a photo to personalize your profile</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center gap-4">
          <Avatar className="h-32 w-32">
            <AvatarImage src={profile?.profileImageUrl || undefined} alt="Profile" />
            <AvatarFallback className="text-2xl">{initials}</AvatarFallback>
          </Avatar>
          <UploadButton
            endpoint="logoUploader"
            onClientUploadComplete={(res) => {
              if (res?.[0]?.ufsUrl) {
                handlePhotoUpload(res[0].ufsUrl);
              }
            }}
            onUploadError={(error: Error) => {
              toast({
                title: "Upload failed",
                description: error.message,
                variant: "destructive",
              });
              setUploadingPhoto(false);
            }}
            onUploadBegin={() => setUploadingPhoto(true)}
            appearance={{
              button: "ut-ready:bg-primary ut-uploading:cursor-not-allowed ut-uploading:bg-primary/50",
              container: "flex items-center gap-2",
            }}
          />
          {uploadingPhoto && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              Uploading...
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Personal Information</CardTitle>
          <CardDescription>Update your contact details and preferences</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="email"
                        placeholder="your.email@example.com"
                        data-testid="input-email"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="tel"
                        placeholder="(555) 123-4567"
                        data-testid="input-phone"
                        onChange={(e) => {
                          const formatted = autoFormatPhoneInput(e.target.value);
                          field.onChange(formatted);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>First Name</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="John"
                          data-testid="input-first-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last Name</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="Doe"
                          data-testid="input-last-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Address</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="123 Main St, City, State, ZIP"
                        rows={3}
                        data-testid="input-address"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="preferredPosition"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Preferred Position</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="e.g., Forward, Pitcher, Goalkeeper"
                        data-testid="input-preferred-position"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-3 pt-4">
                <Button
                  type="submit"
                  disabled={updateProfileMutation.isPending}
                  data-testid="button-save-profile"
                >
                  {updateProfileMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Save Changes
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>

      {profile?.accountType === "parent" && playerRecord && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Baby className="h-5 w-5" />
              Player Information
            </CardTitle>
            <CardDescription>Update your child's player details</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...playerForm}>
              <form onSubmit={playerForm.handleSubmit(handlePlayerSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={playerForm.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>First Name</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder="Sarah"
                            data-testid="input-player-first-name"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={playerForm.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Last Name</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder="Doe"
                            data-testid="input-player-last-name"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={playerForm.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="tel"
                          placeholder="(555) 987-6543"
                          data-testid="input-player-phone"
                          onChange={(e) => {
                            const formatted = autoFormatPhoneInput(e.target.value);
                            field.onChange(formatted);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={playerForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email (Optional)</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="email"
                          placeholder="player@example.com"
                          data-testid="input-player-email"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={playerForm.control}
                  name="dateOfBirth"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date of Birth</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="date"
                          data-testid="input-player-dob"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={playerForm.control}
                  name="position"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Preferred Position</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="e.g., Forward, Pitcher, Goalkeeper"
                          data-testid="input-player-position"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-3 pt-4">
                  <Button
                    type="submit"
                    disabled={updatePlayerMutation.isPending}
                    data-testid="button-save-player"
                  >
                    {updatePlayerMutation.isPending && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    Save Player Information
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

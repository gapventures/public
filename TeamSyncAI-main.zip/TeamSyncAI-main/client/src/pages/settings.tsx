import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Upload, Plus, Trash2, Shield, MessageSquare, Eye, EyeOff, Copy, Calendar, RefreshCw } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { UploadThingUploader } from "@/components/UploadThingUploader";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import type { Team, Role, NotificationSettings as NotificationSettingsType } from "@shared/schema";
import { Switch } from "@/components/ui/switch";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useState, useEffect, useCallback, useReducer } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { TeamInvitationTemplate } from "@/components/TeamInvitationTemplate";

export default function Settings() {
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: teams = [] } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  const team = teams[0];

  const uploadLogoMutation = useMutation({
    mutationFn: async (logoUrl: string) => {
      return apiRequest("PUT", "/api/user/organization-logo", { logoUrl });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Logo uploaded",
        description: "Your organization logo has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to upload logo. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleLogoUploadComplete = useCallback((uploadedUrl: string) => {
    uploadLogoMutation.mutate(uploadedUrl);
  }, [uploadLogoMutation]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">
          Manage your integrations and preferences
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Integrations</CardTitle>
          <CardDescription>
            Connected services for TeamSyncAI
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-md border">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary">
                <svg
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
                  <path d="M12 6c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6z"/>
                </svg>
              </div>
              <div>
                <p className="font-medium">Twilio SMS</p>
                <p className="text-sm text-muted-foreground">
                  Send and receive SMS messages
                </p>
              </div>
            </div>
            <Badge variant="default" className="gap-1" data-testid="badge-twilio-status">
              <CheckCircle2 className="h-3 w-3" />
              Connected
            </Badge>
          </div>

          <div className="flex items-center justify-between p-4 rounded-md border">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary">
                <svg
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z"/>
                </svg>
              </div>
              <div>
                <p className="font-medium">Google Gemini AI</p>
                <p className="text-sm text-muted-foreground">
                  Natural language response parsing
                </p>
              </div>
            </div>
            <Badge variant="default" className="gap-1" data-testid="badge-gemini-status">
              <CheckCircle2 className="h-3 w-3" />
              Connected
            </Badge>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Organization Branding</CardTitle>
          <CardDescription>
            Customize your organization's appearance across all teams
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Organization Logo</label>
            <div className="flex items-center gap-4">
              {user?.organizationLogoUrl ? (
                <img
                  src={user.organizationLogoUrl}
                  alt="Organization logo"
                  className="h-16 w-16 rounded-md object-cover border"
                  data-testid="img-organization-logo"
                />
              ) : (
                <div className="h-16 w-16 rounded-md border border-dashed flex items-center justify-center text-muted-foreground">
                  <Upload className="h-6 w-6" />
                </div>
              )}
              <div className="flex-1">
                <UploadThingUploader
                  endpoint="logoUploader"
                  onComplete={handleLogoUploadComplete}
                  buttonText={user?.organizationLogoUrl ? "Change Logo" : "Upload Logo"}
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Recommended: Square image, max 5MB
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {team && <TeamFeatures team={team} />}

      {team && <JoinCodeManagement team={team} />}

      {team && <RolesManagement teamId={team.id} />}

      {team && <NotificationSettings teamId={team.id} />}

      {team && (
        <TeamInvitationTemplate
          teamId={team.id}
          team={team}
          canManage={true}
        />
      )}

      <Card>
        <CardHeader>
          <CardTitle>About</CardTitle>
          <CardDescription>
            TeamSyncAI version and information
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Version</span>
              <span className="font-medium">1.0.0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Platform</span>
              <span className="font-medium">Replit</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function RolesManagement({ teamId }: { teamId: string }) {
  const { toast } = useToast();
  const [editingRole, setEditingRole] = useState<Role | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  const { data: roles = [], isLoading } = useQuery<Role[]>({
    queryKey: ["/api/teams", teamId, "roles"],
  });

  const createRoleMutation = useMutation({
    mutationFn: async (data: {
      name: string;
      description: string;
      canViewEvents: boolean;
      canManageEvents: boolean;
      canViewPlayers: boolean;
      canManagePlayers: boolean;
      canSendReminders: boolean;
      canManageCampaigns: boolean;
      canViewResponses: boolean;
      canManageAttendance: boolean;
      canManageSettings: boolean;
      canManageRoles: boolean;
    }) => {
      return apiRequest("POST", `/api/teams/${teamId}/roles`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "roles"] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Role created",
        description: "New role has been created successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create role. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateRoleMutation = useMutation({
    mutationFn: async (data: {
      id: string;
      name?: string;
      description?: string;
      canViewEvents?: boolean;
      canManageEvents?: boolean;
      canViewPlayers?: boolean;
      canManagePlayers?: boolean;
      canSendReminders?: boolean;
      canManageCampaigns?: boolean;
      canViewResponses?: boolean;
      canManageAttendance?: boolean;
      canManageSettings?: boolean;
      canManageRoles?: boolean;
    }) => {
      const { id, ...updateData } = data;
      return apiRequest("PUT", `/api/roles/${id}`, updateData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "roles"] });
      setIsEditDialogOpen(false);
      setEditingRole(null);
      toast({
        title: "Role updated",
        description: "Role permissions have been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update role. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteRoleMutation = useMutation({
    mutationFn: async (roleId: string) => {
      return apiRequest("DELETE", `/api/roles/${roleId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "roles"] });
      toast({
        title: "Role deleted",
        description: "Custom role has been deleted successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete role. Default roles cannot be deleted.",
        variant: "destructive",
      });
    },
  });

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Roles & Permissions</CardTitle>
            <CardDescription>
              Manage team member roles and their access permissions
            </CardDescription>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" data-testid="button-create-role">
                <Plus className="h-4 w-4 mr-2" />
                New Role
              </Button>
            </DialogTrigger>
            <DialogContent>
              <RoleForm
                onSubmit={(data) => createRoleMutation.mutate(data)}
                isPending={createRoleMutation.isPending}
              />
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading roles...</p>
        ) : (
          <div className="space-y-3">
            {roles.map((role) => (
              <div
                key={role.id}
                className="flex items-start justify-between p-4 rounded-md border"
                data-testid={`role-card-${role.id}`}
              >
                <div className="flex items-start gap-3 flex-1">
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary">
                    <Shield className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium" data-testid={`text-role-name-${role.id}`}>
                        {role.name}
                      </p>
                      {role.isDefault && (
                        <Badge variant="secondary" className="text-xs">
                          Default
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {role.description}
                    </p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {role.canViewEvents && <Badge variant="outline" className="text-xs">View Events</Badge>}
                      {role.canManageEvents && <Badge variant="outline" className="text-xs">Manage Events</Badge>}
                      {role.canViewPlayers && <Badge variant="outline" className="text-xs">View Players</Badge>}
                      {role.canManagePlayers && <Badge variant="outline" className="text-xs">Manage Players</Badge>}
                      {role.canSendReminders && <Badge variant="outline" className="text-xs">Send Reminders</Badge>}
                      {role.canManageCampaigns && <Badge variant="outline" className="text-xs">Manage Campaigns</Badge>}
                      {role.canViewResponses && <Badge variant="outline" className="text-xs">View Responses</Badge>}
                      {role.canManageAttendance && <Badge variant="outline" className="text-xs">Manage Attendance</Badge>}
                      {role.canManageSettings && <Badge variant="outline" className="text-xs">Manage Settings</Badge>}
                      {role.canManageRoles && <Badge variant="outline" className="text-xs">Manage Roles</Badge>}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Dialog open={isEditDialogOpen && editingRole?.id === role.id} onOpenChange={(open) => {
                    setIsEditDialogOpen(open);
                    if (!open) setEditingRole(null);
                  }}>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingRole(role)}
                        data-testid={`button-edit-role-${role.id}`}
                      >
                        Edit
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <RoleForm
                        role={role}
                        onSubmit={(data) => updateRoleMutation.mutate({ id: role.id, ...data })}
                        isPending={updateRoleMutation.isPending}
                      />
                    </DialogContent>
                  </Dialog>
                  {!role.isDefault && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          data-testid={`button-delete-role-${role.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Role</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete "{role.name}"? This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel data-testid="button-cancel-delete-role">Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => deleteRoleMutation.mutate(role.id)}
                            data-testid="button-confirm-delete-role"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function RoleForm({
  role,
  onSubmit,
  isPending,
}: {
  role?: Role;
  onSubmit: (data: {
    name: string;
    description: string;
    canViewEvents: boolean;
    canManageEvents: boolean;
    canViewPlayers: boolean;
    canManagePlayers: boolean;
    canSendReminders: boolean;
    canManageCampaigns: boolean;
    canViewResponses: boolean;
    canManageAttendance: boolean;
    canManageSettings: boolean;
    canManageRoles: boolean;
  }) => void;
  isPending: boolean;
}) {
  const [formData, setFormData] = useState({
    name: role?.name || "",
    description: role?.description || "",
    canViewEvents: role?.canViewEvents ?? true,
    canManageEvents: role?.canManageEvents ?? false,
    canViewPlayers: role?.canViewPlayers ?? true,
    canManagePlayers: role?.canManagePlayers ?? false,
    canSendReminders: role?.canSendReminders ?? false,
    canManageCampaigns: role?.canManageCampaigns ?? false,
    canViewResponses: role?.canViewResponses ?? true,
    canManageAttendance: role?.canManageAttendance ?? false,
    canManageSettings: role?.canManageSettings ?? false,
    canManageRoles: role?.canManageRoles ?? false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <DialogHeader>
        <DialogTitle>{role ? "Edit Role" : "Create New Role"}</DialogTitle>
        <DialogDescription>
          {role ? "Update role permissions and details." : "Define a new role with specific permissions for team members."}
        </DialogDescription>
      </DialogHeader>
      <div className="space-y-4 py-4">
        <div className="space-y-2">
          <Label htmlFor="name">Role Name</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="e.g., Team Captain"
            required
            data-testid="input-role-name"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Input
            id="description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            placeholder="Brief description of this role"
            data-testid="input-role-description"
          />
        </div>
        <div className="space-y-3">
          <Label>Permissions</Label>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="canViewEvents"
                checked={formData.canViewEvents}
                onCheckedChange={(checked) => 
                  setFormData({ ...formData, canViewEvents: checked as boolean })
                }
                data-testid="checkbox-can-view-events"
              />
              <label htmlFor="canViewEvents" className="text-sm cursor-pointer">
                View Events
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="canManageEvents"
                checked={formData.canManageEvents}
                onCheckedChange={(checked) => 
                  setFormData({ ...formData, canManageEvents: checked as boolean })
                }
                data-testid="checkbox-can-manage-events"
              />
              <label htmlFor="canManageEvents" className="text-sm cursor-pointer">
                Manage Events (create, edit, delete)
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="canViewPlayers"
                checked={formData.canViewPlayers}
                onCheckedChange={(checked) => 
                  setFormData({ ...formData, canViewPlayers: checked as boolean })
                }
                data-testid="checkbox-can-view-players"
              />
              <label htmlFor="canViewPlayers" className="text-sm cursor-pointer">
                View Players
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="canManagePlayers"
                checked={formData.canManagePlayers}
                onCheckedChange={(checked) => 
                  setFormData({ ...formData, canManagePlayers: checked as boolean })
                }
                data-testid="checkbox-can-manage-players"
              />
              <label htmlFor="canManagePlayers" className="text-sm cursor-pointer">
                Manage Players (add, edit, remove)
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="canSendReminders"
                checked={formData.canSendReminders}
                onCheckedChange={(checked) => 
                  setFormData({ ...formData, canSendReminders: checked as boolean })
                }
                data-testid="checkbox-can-send-reminders"
              />
              <label htmlFor="canSendReminders" className="text-sm cursor-pointer">
                Send Manual Reminders
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="canManageCampaigns"
                checked={formData.canManageCampaigns}
                onCheckedChange={(checked) => 
                  setFormData({ ...formData, canManageCampaigns: checked as boolean })
                }
                data-testid="checkbox-can-manage-campaigns"
              />
              <label htmlFor="canManageCampaigns" className="text-sm cursor-pointer">
                Manage Campaigns (create, edit, delete)
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="canViewResponses"
                checked={formData.canViewResponses}
                onCheckedChange={(checked) => 
                  setFormData({ ...formData, canViewResponses: checked as boolean })
                }
                data-testid="checkbox-can-view-responses"
              />
              <label htmlFor="canViewResponses" className="text-sm cursor-pointer">
                View Player Responses
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="canManageAttendance"
                checked={formData.canManageAttendance}
                onCheckedChange={(checked) => 
                  setFormData({ ...formData, canManageAttendance: checked as boolean })
                }
                data-testid="checkbox-can-manage-attendance"
              />
              <label htmlFor="canManageAttendance" className="text-sm cursor-pointer">
                Manage Attendance (mark as attended)
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="canManageSettings"
                checked={formData.canManageSettings}
                onCheckedChange={(checked) => 
                  setFormData({ ...formData, canManageSettings: checked as boolean })
                }
                data-testid="checkbox-can-manage-settings"
              />
              <label htmlFor="canManageSettings" className="text-sm cursor-pointer">
                Manage Settings
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="canManageRoles"
                checked={formData.canManageRoles}
                onCheckedChange={(checked) => 
                  setFormData({ ...formData, canManageRoles: checked as boolean })
                }
                data-testid="checkbox-can-manage-roles"
              />
              <label htmlFor="canManageRoles" className="text-sm cursor-pointer">
                Manage Roles
              </label>
            </div>
          </div>
        </div>
      </div>
      <DialogFooter>
        <Button type="submit" disabled={isPending || !formData.name} data-testid="button-submit-role">
          {isPending ? "Saving..." : role ? "Update Role" : "Create Role"}
        </Button>
      </DialogFooter>
    </form>
  );
}

type NotificationFormState = {
  enabled: boolean;
  roleIds: string[];
  cadence: string;
  timeOfDay: string;
  dayOfWeek: number;
  eventTimingHours: number;
  includeUpcomingEvents: boolean;
  includeRecentResponses: boolean;
  includeAttendanceStats: boolean;
  includePendingResponses: boolean;
};

type NotificationFormAction = 
  | { type: "RESET"; payload: Partial<NotificationFormState> }
  | { type: "SET_ENABLED"; value: boolean }
  | { type: "SET_ROLE_IDS"; value: string[] }
  | { type: "TOGGLE_ROLE"; roleId: string }
  | { type: "SET_CADENCE"; value: string }
  | { type: "SET_TIME_OF_DAY"; value: string }
  | { type: "SET_DAY_OF_WEEK"; value: number }
  | { type: "SET_EVENT_TIMING_HOURS"; value: number }
  | { type: "SET_INCLUDE_UPCOMING"; value: boolean }
  | { type: "SET_INCLUDE_RECENT"; value: boolean }
  | { type: "SET_INCLUDE_ATTENDANCE"; value: boolean }
  | { type: "SET_INCLUDE_PENDING"; value: boolean };

const notificationFormReducer = (state: NotificationFormState, action: NotificationFormAction): NotificationFormState => {
  switch (action.type) {
    case "RESET":
      return { ...state, ...action.payload };
    case "SET_ENABLED":
      return { ...state, enabled: action.value };
    case "SET_ROLE_IDS":
      return { ...state, roleIds: action.value };
    case "TOGGLE_ROLE":
      return {
        ...state,
        roleIds: state.roleIds.includes(action.roleId)
          ? state.roleIds.filter(id => id !== action.roleId)
          : [...state.roleIds, action.roleId]
      };
    case "SET_CADENCE":
      return { ...state, cadence: action.value };
    case "SET_TIME_OF_DAY":
      return { ...state, timeOfDay: action.value };
    case "SET_DAY_OF_WEEK":
      return { ...state, dayOfWeek: action.value };
    case "SET_EVENT_TIMING_HOURS":
      return { ...state, eventTimingHours: action.value };
    case "SET_INCLUDE_UPCOMING":
      return { ...state, includeUpcomingEvents: action.value };
    case "SET_INCLUDE_RECENT":
      return { ...state, includeRecentResponses: action.value };
    case "SET_INCLUDE_ATTENDANCE":
      return { ...state, includeAttendanceStats: action.value };
    case "SET_INCLUDE_PENDING":
      return { ...state, includePendingResponses: action.value };
    default:
      return state;
  }
};

function NotificationSettings({ teamId }: { teamId: string }) {
  const { toast } = useToast();
  
  const [formState, dispatch] = useReducer(notificationFormReducer, {
    enabled: false,
    roleIds: [],
    cadence: "daily",
    timeOfDay: "09:00",
    dayOfWeek: 1,
    eventTimingHours: 24,
    includeUpcomingEvents: true,
    includeRecentResponses: true,
    includeAttendanceStats: true,
    includePendingResponses: true,
  });

  const { data: roles = [] } = useQuery<Role[]>({
    queryKey: ["/api/teams", teamId, "roles"],
  });

  const { data: settings, isLoading } = useQuery<NotificationSettingsType>({
    queryKey: ["/api/teams", teamId, "notification-settings"],
    enabled: !!teamId,
  });

  useEffect(() => {
    if (settings) {
      dispatch({
        type: "RESET",
        payload: {
          enabled: settings.enabled || false,
          roleIds: settings.roleIds || [],
          cadence: settings.cadence || "daily",
          timeOfDay: settings.timeOfDay || "09:00",
          dayOfWeek: settings.dayOfWeek || 1,
          eventTimingHours: settings.eventTimingHours || 24,
          includeUpcomingEvents: settings.includeUpcomingEvents ?? true,
          includeRecentResponses: settings.includeRecentResponses ?? true,
          includeAttendanceStats: settings.includeAttendanceStats ?? true,
          includePendingResponses: settings.includePendingResponses ?? true,
        }
      });
    }
  }, [settings]);

  const saveSettingsMutation = useMutation({
    mutationFn: async () => {
      const data = {
        enabled: formState.enabled,
        roleIds: formState.roleIds,
        cadence: formState.cadence,
        timeOfDay: formState.timeOfDay,
        dayOfWeek: formState.dayOfWeek,
        eventTimingHours: formState.eventTimingHours,
        includeUpcomingEvents: formState.includeUpcomingEvents,
        includeRecentResponses: formState.includeRecentResponses,
        includeAttendanceStats: formState.includeAttendanceStats,
        includePendingResponses: formState.includePendingResponses,
      };

      // Create or update
      if (settings) {
        return apiRequest("PUT", `/api/teams/${teamId}/notification-settings`, data);
      } else {
        return apiRequest("POST", `/api/teams/${teamId}/notification-settings`, data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "notification-settings"] });
      toast({
        title: "Settings saved",
        description: "Notification settings have been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save notification settings.",
        variant: "destructive",
      });
    },
  });

  const toggleRole = (roleId: string) => {
    dispatch({ type: "TOGGLE_ROLE", roleId });
  };

  const { isPending } = saveSettingsMutation;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Automated SMS Updates</CardTitle>
        <CardDescription>
          Send automatic team updates to specific roles on a schedule
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading settings...</p>
        ) : (
          <>
            <div className="flex items-center justify-between p-4 rounded-md border">
              <div>
                <p className="font-medium">Enable Automated Updates</p>
                <p className="text-sm text-muted-foreground">
                  Send SMS updates to selected roles based on the schedule below
                </p>
              </div>
              <Checkbox
                checked={formState.enabled}
                onCheckedChange={(checked) => dispatch({ type: "SET_ENABLED", value: checked as boolean })}
                data-testid="checkbox-enable-notifications"
              />
            </div>

            {formState.enabled && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Roles to Notify</Label>
                  <p className="text-sm text-muted-foreground">
                    Select which roles should receive automated updates
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {roles.map((role) => (
                      <div
                        key={role.id}
                        className="flex items-center space-x-2 p-3 rounded-md border cursor-pointer hover-elevate"
                        onClick={() => toggleRole(role.id)}
                        data-testid={`role-toggle-${role.id}`}
                      >
                        <Checkbox
                          checked={formState.roleIds.includes(role.id)}
                          onCheckedChange={() => toggleRole(role.id)}
                        />
                        <label className="text-sm cursor-pointer flex-1">
                          {role.name}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Update Frequency</Label>
                  <select
                    value={formState.cadence}
                    onChange={(e) => dispatch({ type: "SET_CADENCE", value: e.target.value })}
                    className="w-full p-2 rounded-md border bg-background"
                    data-testid="select-cadence"
                  >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="before_event">Before Each Event</option>
                  </select>
                </div>

                {formState.cadence === "daily" && (
                  <div className="space-y-2">
                    <Label>Time of Day</Label>
                    <Input
                      type="time"
                      value={formState.timeOfDay}
                      onChange={(e) => dispatch({ type: "SET_TIME_OF_DAY", value: e.target.value })}
                      data-testid="input-time-of-day"
                    />
                  </div>
                )}

                {formState.cadence === "weekly" && (
                  <div className="space-y-2">
                    <Label>Day of Week</Label>
                    <select
                      value={formState.dayOfWeek}
                      onChange={(e) => dispatch({ type: "SET_DAY_OF_WEEK", value: parseInt(e.target.value) })}
                      className="w-full p-2 rounded-md border bg-background"
                      data-testid="select-day-of-week"
                    >
                      <option value={0}>Sunday</option>
                      <option value={1}>Monday</option>
                      <option value={2}>Tuesday</option>
                      <option value={3}>Wednesday</option>
                      <option value={4}>Thursday</option>
                      <option value={5}>Friday</option>
                      <option value={6}>Saturday</option>
                    </select>
                  </div>
                )}

                {formState.cadence === "before_event" && (
                  <div className="space-y-2">
                    <Label>Send Notification</Label>
                    <select
                      value={formState.eventTimingHours}
                      onChange={(e) => dispatch({ type: "SET_EVENT_TIMING_HOURS", value: parseInt(e.target.value) })}
                      className="w-full p-2 rounded-md border bg-background"
                      data-testid="select-event-timing"
                    >
                      <option value={1}>1 hour before event</option>
                      <option value={2}>2 hours before event</option>
                      <option value={4}>4 hours before event</option>
                      <option value={12}>12 hours before event</option>
                      <option value={24}>1 day before event</option>
                      <option value={48}>2 days before event</option>
                      <option value={72}>3 days before event</option>
                      <option value={168}>1 week before event</option>
                    </select>
                  </div>
                )}

                <div className="space-y-2">
                  <Label>Update Contents</Label>
                  <p className="text-sm text-muted-foreground">
                    Choose what information to include in the updates
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="includeUpcomingEvents"
                        checked={formState.includeUpcomingEvents}
                        onCheckedChange={(checked) => dispatch({ type: "SET_INCLUDE_UPCOMING", value: checked as boolean })}
                        data-testid="checkbox-include-upcoming-events"
                      />
                      <label htmlFor="includeUpcomingEvents" className="text-sm cursor-pointer">
                        Upcoming Events (next 7 days)
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="includeRecentResponses"
                        checked={formState.includeRecentResponses}
                        onCheckedChange={(checked) => dispatch({ type: "SET_INCLUDE_RECENT", value: checked as boolean })}
                        data-testid="checkbox-include-recent-responses"
                      />
                      <label htmlFor="includeRecentResponses" className="text-sm cursor-pointer">
                        Recent Player Responses (last 24 hours)
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="includeAttendanceStats"
                        checked={formState.includeAttendanceStats}
                        onCheckedChange={(checked) => dispatch({ type: "SET_INCLUDE_ATTENDANCE", value: checked as boolean })}
                        data-testid="checkbox-include-attendance-stats"
                      />
                      <label htmlFor="includeAttendanceStats" className="text-sm cursor-pointer">
                        Next Event Attendance Stats
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="includePendingResponses"
                        checked={formState.includePendingResponses}
                        onCheckedChange={(checked) => dispatch({ type: "SET_INCLUDE_PENDING", value: checked as boolean })}
                        data-testid="checkbox-include-pending-responses"
                      />
                      <label htmlFor="includePendingResponses" className="text-sm cursor-pointer">
                        Pending Response Count
                      </label>
                    </div>
                  </div>
                </div>

                <Button
                  onClick={() => saveSettingsMutation.mutate()}
                  disabled={isPending || formState.roleIds.length === 0}
                  data-testid="button-save-notification-settings"
                >
                  {saveSettingsMutation.isPending ? "Saving..." : "Save Settings"}
                </Button>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}

function JoinCodeManagement({ team }: { team: Team }) {
  const { toast } = useToast();
  const [showCode, setShowCode] = useState(false);
  const [expiryDate, setExpiryDate] = useState<string>("");

  const generateCodeMutation = useMutation({
    mutationFn: async (expiry?: string) => {
      return apiRequest("POST", `/api/teams/${team.id}/join-code/generate`, {
        expiryDate: expiry || null
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      toast({
        title: "Join code generated",
        description: "Your team's join code has been created successfully.",
      });
      setShowCode(true);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate join code. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteCodeMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("DELETE", `/api/teams/${team.id}/join-code`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      toast({
        title: "Join code deleted",
        description: "Your team's join code has been removed.",
      });
      setShowCode(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete join code. Please try again.",
        variant: "destructive",
      });
    },
  });

  const hasJoinCode = team.joinCode && team.joinCodeEnabled;
  const isExpired = team.joinCodeExpiry && new Date(team.joinCodeExpiry) < new Date();

  return (
    <Card>
      <CardHeader>
        <CardTitle>Parent Join Codes</CardTitle>
        <CardDescription>
          Allow parents to register and join your team using a simple code
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {hasJoinCode ? (
          <>
            <div className="p-4 rounded-md border bg-muted/50 space-y-3">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium">Active Join Code</p>
                  <p className="text-xs text-muted-foreground">
                    Share this code with parents to let them join your team
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowCode(!showCode)}
                  data-testid="button-toggle-code-visibility"
                >
                  {showCode ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>

              {showCode && (
                <div className="flex items-center gap-2">
                  <code className="flex-1 px-3 py-2 rounded-md bg-background border text-2xl font-mono font-bold tracking-widest">
                    {team.joinCode}
                  </code>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => {
                      navigator.clipboard.writeText(team.joinCode!);
                      toast({
                        title: "Copied!",
                        description: "Join code copied to clipboard.",
                      });
                    }}
                    data-testid="button-copy-join-code"
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              )}

              {team.joinCodeExpiry && (
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">
                    Expires: {new Date(team.joinCodeExpiry).toLocaleDateString()}
                  </span>
                  {isExpired && (
                    <Badge variant="destructive" className="ml-2">Expired</Badge>
                  )}
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => deleteCodeMutation.mutate()}
                disabled={deleteCodeMutation.isPending}
                data-testid="button-delete-join-code"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Code
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setExpiryDate("");
                  generateCodeMutation.mutate(undefined);
                }}
                disabled={generateCodeMutation.isPending}
                data-testid="button-regenerate-join-code"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Generate New Code
              </Button>
            </div>
          </>
        ) : (
          <div className="space-y-4">
            <div className="p-4 rounded-md border border-dashed">
              <p className="text-sm text-muted-foreground">
                No active join code. Generate one to allow parents to register and request to join your team.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="expiry-date">Expiry Date (Optional)</Label>
              <Input
                id="expiry-date"
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                data-testid="input-join-code-expiry"
              />
              <p className="text-xs text-muted-foreground">
                Leave blank for no expiry
              </p>
            </div>

            <Button
              onClick={() => generateCodeMutation.mutate(expiryDate || undefined)}
              disabled={generateCodeMutation.isPending}
              data-testid="button-generate-join-code"
            >
              <Plus className="h-4 w-4 mr-2" />
              {generateCodeMutation.isPending ? "Generating..." : "Generate Join Code"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function TeamFeatures({ team }: { team: Team }) {
  const { toast } = useToast();
  const [instanceName, setInstanceName] = useState(team.instanceName || "");

  const toggleMessageBoardMutation = useMutation({
    mutationFn: async (enabled: boolean) => {
      return apiRequest("PATCH", `/api/teams/${team.id}/message-board`, { enabled });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/teams", team.id] });
      toast({
        title: "Feature updated",
        description: "Message board setting has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update feature. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateInstanceNameMutation = useMutation({
    mutationFn: async (newInstanceName: string) => {
      return apiRequest("PATCH", `/api/teams/${team.id}/instance-name`, { instanceName: newInstanceName });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/teams", team.id] });
      toast({
        title: "Instance name updated",
        description: "Your team's instance name has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update instance name. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Team Branding</CardTitle>
        <CardDescription>
          Customize your team's branding and features
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="instance-name">Instance Name</Label>
          <div className="flex gap-2">
            <Input
              id="instance-name"
              value={instanceName}
              onChange={(e) => setInstanceName(e.target.value)}
              placeholder={`${team.name} Manager`}
              data-testid="input-instance-name"
            />
            <Button
              onClick={() => updateInstanceNameMutation.mutate(instanceName)}
              disabled={updateInstanceNameMutation.isPending || instanceName === (team.instanceName || "")}
              data-testid="button-save-instance-name"
            >
              {updateInstanceNameMutation.isPending ? "Saving..." : "Save"}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Customize how your team app appears (e.g., "Hawks Manager", "Tigers Team Central")
          </p>
        </div>

        <div className="flex items-center justify-between p-4 rounded-md border">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary">
              <MessageSquare className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <p className="font-medium">Message Board</p>
              <p className="text-sm text-muted-foreground">
                Allow team communication through a shared message board with reactions and pinned messages
              </p>
            </div>
          </div>
          <Switch
            checked={team.messageBoardEnabled || false}
            onCheckedChange={(checked) => toggleMessageBoardMutation.mutate(checked)}
            disabled={toggleMessageBoardMutation.isPending}
            data-testid="switch-message-board"
          />
        </div>
      </CardContent>
    </Card>
  );
}

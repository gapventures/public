import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Calendar, MessageSquare, TrendingUp, Bell, Zap, Shield, Database, Settings, CheckCircle, Star, Target } from "lucide-react";
import { useAppName } from "@/hooks/useAppName";
import { useQuery } from "@tanstack/react-query";
import type { LandingPageContent, LandingPageFeature } from "@shared/schema";
import { Link, useLocation } from "wouter";
import { MarketingFooter } from "@/components/marketing-footer";

// Icon mapping for dynamic feature cards
const iconMap = {
  MessageSquare,
  Calendar,
  TrendingUp,
  Bell,
  Zap,
  Users,
  Shield,
  Database,
  Settings,
  CheckCircle,
  Star,
  Target,
};

// Default fallback content if API fails
const defaultContent = {
  heroTitle: "Your AI-Powered Assistant Manager",
  heroSubtitle: "Automate team management for amateur sports teams. Save hours every week with intelligent SMS reminders, attendance tracking, and player reliability monitoring.",
  heroCta: "Get Started",
  logoUrl: null as string | null,
  features: [
    { icon: "MessageSquare" as const, title: "Smart SMS Reminders", description: "Automatically send customizable SMS reminders to your team. AI parses natural language responses to track who's coming." },
    { icon: "Calendar" as const, title: "Event Management", description: "Create games and practices with all the details. Track attendance, location, and game-specific information in one place." },
    { icon: "TrendingUp" as const, title: "Reliability Tracking", description: "Monitor player reliability over time. Automatically score players based on their attendance history." },
    { icon: "Bell" as const, title: "Automated Updates", description: "Send scheduled team updates to specific roles. Daily, weekly, or before events — you choose when your team gets notified." },
    { icon: "Zap" as const, title: "Campaign Templates", description: "Save time with reusable reminder templates. Create once, apply to any event with a single click." },
    { icon: "Users" as const, title: "Role-Based Access", description: "Control who can manage events, players, and settings. Create custom roles with specific permissions." },
  ],
  ctaHeading: "Ready to simplify your team management?",
  ctaDescription: "Join coaches who are already saving time and staying organized with {appName}.",
  ctaButton: "Start Now",
  footerText: "&copy; 2025 {appName}. Built for coaches, by coaches.",
};

export default function Landing() {
  const appName = useAppName();
  const [, setLocation] = useLocation();
  
  const { data: landingContent, isLoading, isError } = useQuery<LandingPageContent>({
    queryKey: ["/api/landing-page"],
  });
  
  const handleLogin = () => {
    setLocation("/login");
  };
  
  // Replace {appName} placeholder in text
  const replacePlaceholder = (text: string) => {
    return text.replace(/{appName}/g, appName);
  };
  
  // Use loaded content or fallback to defaults
  const content = (isLoading || isError || !landingContent) ? defaultContent : landingContent;

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-3 md:py-4 flex justify-between items-center gap-2">
          <div className="flex items-center gap-2 md:gap-3 min-w-0">
            {content.logoUrl ? (
              <img 
                src={content.logoUrl} 
                alt="Logo" 
                className="h-8 md:h-10 w-auto object-contain flex-shrink-0"
                data-testid="img-header-logo"
              />
            ) : (
              <Users className="h-5 md:h-6 w-5 md:w-6 text-primary flex-shrink-0" />
            )}
            <span className="hidden sm:block text-lg md:text-xl font-bold truncate">{appName}</span>
          </div>
          <nav className="flex items-center gap-1 md:gap-4 flex-shrink-0">
            <Link 
              href="/about" 
              className="hidden md:inline-flex text-sm font-medium hover-elevate rounded-md px-3 py-2" 
              data-testid="link-about"
            >
              About
            </Link>
            <Link 
              href="/features" 
              className="hidden md:inline-flex text-sm font-medium hover-elevate rounded-md px-3 py-2" 
              data-testid="link-features"
            >
              Features
            </Link>
            <Link 
              href="/pricing" 
              className="text-xs md:text-sm font-medium hover-elevate rounded-md px-2 md:px-3 py-2" 
              data-testid="link-pricing"
            >
              Pricing
            </Link>
            <Link 
              href="/contact" 
              className="text-xs md:text-sm font-medium hover-elevate rounded-md px-2 md:px-3 py-2" 
              data-testid="link-contact"
            >
              Contact
            </Link>
            <Button onClick={handleLogin} size="sm" data-testid="button-login">
              Log In
            </Button>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="container mx-auto px-4 py-8 md:py-16 landscape:py-6">
          <div className="max-w-3xl mx-auto text-center mb-8 landscape:mb-6">
            {content.logoUrl && (
              <div className="mb-6 landscape:mb-4 flex justify-center">
                <img 
                  src={content.logoUrl} 
                  alt="Logo" 
                  className="h-32 md:h-40 lg:h-56 landscape:h-24 w-auto object-contain max-w-full"
                  data-testid="img-landing-logo"
                />
              </div>
            )}
            <h1 className="text-3xl md:text-4xl lg:text-5xl landscape:text-3xl font-bold mb-4 landscape:mb-3">
              {content.heroTitle}
            </h1>
            <p className="text-lg md:text-xl landscape:text-base text-muted-foreground mb-6 landscape:mb-4">
              {content.heroSubtitle}
            </p>
            <Button size="lg" onClick={handleLogin} data-testid="button-get-started">
              {content.heroCta}
            </Button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {(content.features as LandingPageFeature[] || []).map((feature, index) => {
              // Use the specified icon or fallback to Star if icon not found in map
              const IconComponent = iconMap[feature.icon] || Star;
              return (
                <Card key={index}>
                  <CardHeader>
                    <IconComponent className="h-8 w-8 mb-2 text-primary" />
                    <CardTitle>{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>{feature.description}</CardDescription>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        <section className="bg-muted py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">
              {content.ctaHeading}
            </h2>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              {replacePlaceholder(content.ctaDescription)}
            </p>
            <Button size="lg" onClick={handleLogin} data-testid="button-start-now">
              {content.ctaButton}
            </Button>
          </div>
        </section>
      </main>

      <MarketingFooter />
    </div>
  );
}

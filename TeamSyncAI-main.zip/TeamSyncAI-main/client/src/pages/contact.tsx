import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Users, Mail, MessageSquare, Phone } from "lucide-react";
import { useAppName } from "@/hooks/useAppName";
import { useOrganizationLogo } from "@/hooks/useOrganizationLogo";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { ContactPageContent } from "@shared/schema";
import { MarketingFooter } from "@/components/marketing-footer";

const contactFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Valid email is required"),
  subject: z.string().min(1, "Subject is required"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

type ContactFormData = z.infer<typeof contactFormSchema>;

const iconMap = {
  Mail,
  MessageSquare,
  Phone,
};

const defaultContent: ContactPageContent = {
  heroTitle: "Get in Touch",
  heroSubtitle: "Have questions? We're here to help. Send us a message and we'll respond as soon as possible.",
  supportEmail: "support@team-sync-ai.com",
  supportEmailLabel: "Email Us",
  supportEmailDescription: "For general inquiries and support",
  salesEmail: "sales@team-sync-ai.com",
  salesEmailLabel: "Sales",
  salesEmailDescription: "Questions about pricing or enterprise plans",
  phone: "(855) 677-3180",
  phoneLabel: "Phone Support",
  phoneDescription: "Available Monday-Friday, 9am-5pm EST",
  formTitle: "Send us a message",
  formDescription: "Fill out the form below and we'll get back to you within 24 hours.",
  formSuccessTitle: "Message Sent!",
  formSuccessMessage: "Thanks for reaching out. We'll get back to you as soon as possible."
};

export default function Contact() {
  const appName = useAppName();
  const logoUrl = useOrganizationLogo();
  const { toast } = useToast();
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const { data: content, isLoading, isError } = useQuery<ContactPageContent>({
    queryKey: ["/api/marketing-pages/contact"],
  });

  const pageContent = content || defaultContent;

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: "",
    },
  });

  const onSubmit = async (data: ContactFormData) => {
    console.log("Contact form submitted:", data);
    
    setIsSubmitted(true);
    form.reset();
    
    toast({
      title: "Message sent!",
      description: "We'll get back to you as soon as possible.",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center" data-testid="loading-state">
          <div className="text-lg text-muted-foreground">Loading...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-3 md:py-4 flex justify-between items-center gap-2">
          <Link href="/" data-testid="link-home-logo">
            <div className="flex items-center gap-2 md:gap-3 cursor-pointer hover-elevate rounded-md p-2 -m-2 min-w-0">
              {logoUrl ? (
                <img 
                  src={logoUrl} 
                  alt="Logo" 
                  className="h-8 md:h-10 w-auto object-contain flex-shrink-0"
                  data-testid="img-header-logo"
                />
              ) : (
                <Users className="h-5 md:h-6 w-5 md:w-6 text-primary flex-shrink-0" />
              )}
              <span className="hidden sm:block text-lg md:text-xl font-bold truncate">{appName}</span>
            </div>
          </Link>
          <nav className="flex items-center gap-1 md:gap-4 flex-shrink-0">
            <Link 
              href="/about" 
              className="hidden md:inline-flex text-sm font-medium hover-elevate rounded-md px-3 py-2" 
              data-testid="link-about"
            >
              About
            </Link>
            <Link 
              href="/features" 
              className="hidden md:inline-flex text-sm font-medium hover-elevate rounded-md px-3 py-2" 
              data-testid="link-features"
            >
              Features
            </Link>
            <Link 
              href="/pricing" 
              className="text-xs md:text-sm font-medium hover-elevate rounded-md px-2 md:px-3 py-2" 
              data-testid="link-pricing"
            >
              Pricing
            </Link>
            <Link 
              href="/contact" 
              className="text-xs md:text-sm font-medium hover-elevate rounded-md px-2 md:px-3 py-2" 
              data-testid="link-contact"
            >
              Contact
            </Link>
            <Link href="/login">
              <Button size="sm" data-testid="button-login">Log In</Button>
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="container mx-auto px-4 py-8 md:py-16 landscape:py-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8 landscape:mb-6">
              <h1 className="text-3xl md:text-4xl lg:text-5xl landscape:text-3xl font-bold mb-4 landscape:mb-3" data-testid="text-heading">
                {pageContent.heroTitle}
              </h1>
              <p className="text-lg md:text-xl landscape:text-base text-muted-foreground max-w-3xl mx-auto" data-testid="text-subheading">
                {pageContent.heroSubtitle}
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 mb-8 landscape:mb-6">
              <Card data-testid="contact-card-0">
                <CardHeader>
                  <Mail className="h-8 w-8 mb-2 text-primary" />
                  <CardTitle data-testid="contact-title-0">{pageContent.supportEmailLabel}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription data-testid="contact-description-0">
                    {pageContent.supportEmailDescription}
                  </CardDescription>
                  <a 
                    href={`mailto:${pageContent.supportEmail}`} 
                    className="text-primary hover:underline mt-2 inline-block" 
                    data-testid="contact-link-0"
                  >
                    {pageContent.supportEmail}
                  </a>
                </CardContent>
              </Card>

              <Card data-testid="contact-card-1">
                <CardHeader>
                  <MessageSquare className="h-8 w-8 mb-2 text-primary" />
                  <CardTitle data-testid="contact-title-1">{pageContent.salesEmailLabel}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription data-testid="contact-description-1">
                    {pageContent.salesEmailDescription}
                  </CardDescription>
                  <a 
                    href={`mailto:${pageContent.salesEmail}`} 
                    className="text-primary hover:underline mt-2 inline-block" 
                    data-testid="contact-link-1"
                  >
                    {pageContent.salesEmail}
                  </a>
                </CardContent>
              </Card>

              <Card data-testid="contact-card-2">
                <CardHeader>
                  <Phone className="h-8 w-8 mb-2 text-primary" />
                  <CardTitle data-testid="contact-title-2">{pageContent.phoneLabel}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription data-testid="contact-description-2">
                    {pageContent.phoneDescription}
                  </CardDescription>
                  <a 
                    href={`tel:${pageContent.phone.replace(/\D/g, '')}`} 
                    className="text-primary hover:underline mt-2 inline-block" 
                    data-testid="contact-link-2"
                  >
                    {pageContent.phone}
                  </a>
                </CardContent>
              </Card>
            </div>

            <div className="max-w-2xl mx-auto">
              <Card>
                <CardHeader>
                  <CardTitle data-testid="text-form-title">{pageContent.formTitle}</CardTitle>
                  <CardDescription data-testid="text-form-description">
                    {pageContent.formDescription}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isSubmitted ? (
                    <div className="text-center py-8">
                      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                        <Mail className="h-8 w-8 text-primary" />
                      </div>
                      <h3 className="text-xl font-semibold mb-2" data-testid="text-success-heading">
                        {pageContent.formSuccessTitle}
                      </h3>
                      <p className="text-muted-foreground mb-6" data-testid="text-success-description">
                        {pageContent.formSuccessMessage}
                      </p>
                      <Button onClick={() => setIsSubmitted(false)} data-testid="button-send-another">
                        Send Another Message
                      </Button>
                    </div>
                  ) : (
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Your name" {...field} data-testid="input-name" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="your.email@example.com" {...field} data-testid="input-email" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="subject"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Subject</FormLabel>
                              <FormControl>
                                <Input placeholder="What's this about?" {...field} data-testid="input-subject" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="message"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Message</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Tell us more..." 
                                  className="min-h-32"
                                  {...field} 
                                  data-testid="input-message"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <Button type="submit" className="w-full" data-testid="button-send-message">
                          Send Message
                        </Button>
                      </form>
                    </Form>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <MarketingFooter />
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import { Plus, Calendar as CalendarIcon, Check, X, HelpCircle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import type { Event, Team, Player, Role } from "@shared/schema";
import { useAuth } from "@/hooks/useAuth";
import { useTestView } from "@/contexts/TestViewContext";

type EventWithStats = Event & {
  stats?: {
    yes: number;
    no: number;
    maybe: number;
    pending: number;
  };
};

export default function Events() {
  const { user } = useAuth();
  const { testViewMode, isTestViewActive } = useTestView();
  const { data: events = [], isLoading } = useQuery<EventWithStats[]>({
    queryKey: ["/api/events"],
  });
  
  const { data: teams = [] } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  // Calculate base permissions
  const hasTeamOwnership = teams.some(team => {
    if (team.userId === user?.id) return true;
    return false;
  });

  // Respect test view mode for global admins
  let canManageEvents = hasTeamOwnership || (user?.isGlobalAdmin && !isTestViewActive);
  
  if (user?.isGlobalAdmin && isTestViewActive) {
    // Override based on test view mode
    switch (testViewMode) {
      case 'team_owner':
      case 'coach':
      case 'assistant_coach':
        canManageEvents = true;
        break;
      case 'player':
      case 'viewer':
        canManageEvents = false;
        break;
      default:
        break;
    }
  }

  const upcomingEvents = events.filter(
    (e) => new Date(e.datetime) >= new Date()
  );
  const pastEvents = events.filter(
    (e) => new Date(e.datetime) < new Date()
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading events...</p>
        </div>
      </div>
    );
  }

  const EventCard = ({ event }: { event: EventWithStats }) => (
    <Link href={`/events/${event.id}`}>
      <Card className="hover-elevate active-elevate-2 h-full" data-testid={`card-event-${event.id}`}>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="capitalize">{event.type}</CardTitle>
              <CardDescription>
                {new Date(event.datetime).toLocaleString('en-US', {
                  weekday: 'short',
                  month: 'short',
                  day: 'numeric',
                  hour: 'numeric',
                  minute: '2-digit',
                })}
              </CardDescription>
            </div>
            <Badge variant={event.type === "game" ? "default" : "secondary"}>
              {event.type}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          {event.opponent && (
            <div>
              <span className="text-muted-foreground">vs </span>
              <span className="font-medium">{event.opponent}</span>
            </div>
          )}
          <div className="text-muted-foreground">{event.location}</div>
          {event.homeAway && (
            <Badge variant="outline" className="capitalize">
              {event.homeAway}
            </Badge>
          )}
          
          {event.stats && (
            <div className="flex items-center gap-3 pt-2 border-t" data-testid={`stats-event-${event.id}`}>
              <div className="flex items-center gap-1" data-testid="stat-yes">
                <Check className="h-3.5 w-3.5 text-green-600 dark:text-green-500" />
                <span className="text-xs font-medium">{event.stats.yes}</span>
              </div>
              <div className="flex items-center gap-1" data-testid="stat-no">
                <X className="h-3.5 w-3.5 text-red-600 dark:text-red-500" />
                <span className="text-xs font-medium">{event.stats.no}</span>
              </div>
              <div className="flex items-center gap-1" data-testid="stat-maybe">
                <HelpCircle className="h-3.5 w-3.5 text-yellow-600 dark:text-yellow-500" />
                <span className="text-xs font-medium">{event.stats.maybe}</span>
              </div>
              <div className="flex items-center gap-1" data-testid="stat-pending">
                <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                <span className="text-xs font-medium text-muted-foreground">{event.stats.pending}</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Schedule</h1>
          <p className="text-muted-foreground">
            {canManageEvents ? "Manage games, practices, and team events" : "View games, practices, and team events"}
          </p>
        </div>
        {canManageEvents && (
          <Link href="/events/new">
            <Button data-testid="button-create-event">
              <Plus className="h-4 w-4 mr-2" />
              Create Event
            </Button>
          </Link>
        )}
      </div>

      {events.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <CalendarIcon className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No events yet</h3>
            <p className="text-sm text-muted-foreground text-center mb-6 max-w-md">
              {canManageEvents 
                ? "Create your first event to start sending reminders and managing attendance."
                : "No events have been created yet. Check back later."}
            </p>
            {canManageEvents && (
              <Link href="/events/new">
                <Button data-testid="button-create-first-event">
                  <Plus className="h-4 w-4 mr-2" />
                  Create Your First Event
                </Button>
              </Link>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-8">
          {upcomingEvents.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold mb-4">
                Upcoming Events ({upcomingEvents.length})
              </h2>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {upcomingEvents.map((event) => (
                  <EventCard key={event.id} event={event} />
                ))}
              </div>
            </div>
          )}

          {pastEvents.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold mb-4">
                Past Events ({pastEvents.length})
              </h2>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {pastEvents.map((event) => (
                  <EventCard key={event.id} event={event} />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Users, UserCircle2, Baby } from "lucide-react";
import { useAppName } from "@/hooks/useAppName";

export default function Register() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const appName = useAppName();
  const [accountType, setAccountType] = useState<"coach" | "parent">("coach");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [smsConsentGranted, setSmsConsentGranted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const [playerFirstName, setPlayerFirstName] = useState("");
  const [playerLastName, setPlayerLastName] = useState("");
  const [playerPhone, setPlayerPhone] = useState("");
  const [playerEmail, setPlayerEmail] = useState("");
  const [playerDateOfBirth, setPlayerDateOfBirth] = useState("");
  
  const [joinCode, setJoinCode] = useState("");
  const [teamInfo, setTeamInfo] = useState<{ teamName: string; sport: string } | null>(null);
  const [isValidatingCode, setIsValidatingCode] = useState(false);

  const validateJoinCode = async (code: string) => {
    if (!code || code.length < 6) {
      setTeamInfo(null);
      return;
    }

    setIsValidatingCode(true);
    try {
      const response = await fetch(`/api/teams/join-code/${code.toUpperCase()}`);
      if (response.ok) {
        const data = await response.json();
        setTeamInfo({ teamName: data.teamName, sport: data.sport });
        toast({
          title: "Valid join code!",
          description: `You'll be joining ${data.teamName} (${data.sport})`,
        });
      } else {
        setTeamInfo(null);
        toast({
          title: "Invalid join code",
          description: "This join code is not valid or has expired",
          variant: "destructive",
        });
      }
    } catch (error) {
      setTeamInfo(null);
      toast({
        title: "Error validating join code",
        description: "Could not validate the join code. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsValidatingCode(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure your passwords match",
        variant: "destructive",
      });
      return;
    }

    if (password.length < 6) {
      toast({
        title: "Password too short",
        description: "Password must be at least 6 characters long",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const requestBody: any = {
        email,
        password,
        firstName,
        lastName,
        phone,
        smsConsentGranted,
        accountType,
      };

      if (accountType === "parent") {
        if (!playerFirstName || !playerLastName || !playerPhone) {
          toast({
            title: "Missing player information",
            description: "Please fill in all required player details",
            variant: "destructive",
          });
          setIsLoading(false);
          return;
        }
        
        if (joinCode && !teamInfo) {
          toast({
            title: "Invalid join code",
            description: "Please enter a valid team join code",
            variant: "destructive",
          });
          setIsLoading(false);
          return;
        }
        
        requestBody.playerDetails = {
          firstName: playerFirstName,
          lastName: playerLastName,
          phone: playerPhone,
          email: playerEmail || undefined,
          dateOfBirth: playerDateOfBirth || undefined,
        };
        
        if (joinCode && teamInfo) {
          requestBody.joinCode = joinCode.toUpperCase();
        }
      }

      const response = await fetch("/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || "Registration failed");
      }

      toast({
        title: "Account created!",
        description: "Welcome to " + appName,
      });

      // Invalidate auth cache
      await queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      
      // Check if user came from an invitation link
      const pendingInvitationToken = sessionStorage.getItem("pendingInvitationToken");
      if (pendingInvitationToken) {
        // Skip onboarding and go directly to invitation acceptance
        sessionStorage.removeItem("pendingInvitationToken");
        setLocation(`/invite/${pendingInvitationToken}`);
      } else {
        // Normal registration flow - go to onboarding
        setLocation("/onboarding");
      }
    } catch (error: any) {
      toast({
        title: "Registration Failed",
        description: error.message || "Could not create account",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-4">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Users className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold">{appName}</span>
          </div>
          <CardTitle className="text-center">Create Account</CardTitle>
          <CardDescription className="text-center">
            Sign up to get started with {appName}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleRegister} className="space-y-4">
            <div className="space-y-3">
              <Label>I am a...</Label>
              <RadioGroup value={accountType} onValueChange={(value) => setAccountType(value as "coach" | "parent")} className="flex gap-4">
                <div className="flex items-center space-x-2 flex-1">
                  <RadioGroupItem value="coach" id="coach" data-testid="radio-coach" />
                  <Label htmlFor="coach" className="flex items-center gap-2 cursor-pointer font-normal">
                    <UserCircle2 className="h-4 w-4" />
                    Coach/Manager
                  </Label>
                </div>
                <div className="flex items-center space-x-2 flex-1">
                  <RadioGroupItem value="parent" id="parent" data-testid="radio-parent" />
                  <Label htmlFor="parent" className="flex items-center gap-2 cursor-pointer font-normal">
                    <Baby className="h-4 w-4" />
                    Parent
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-3 p-4 border rounded-md bg-muted/20">
              <h3 className="font-medium text-sm">Your Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    placeholder="John"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    required
                    data-testid="input-firstname"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    placeholder="Doe"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    required
                    data-testid="input-lastname"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number (Primary Contact)</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="(555) 123-4567"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  data-testid="input-phone"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  data-testid="input-email"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="At least 6 characters"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  data-testid="input-password"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="Re-enter password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  data-testid="input-confirm-password"
                />
              </div>
            </div>

            {accountType === "parent" && (
              <>
                <div className="space-y-3 p-4 border rounded-md bg-primary/10">
                  <h3 className="font-medium text-sm">Team Join Code (Optional)</h3>
                  <p className="text-xs text-muted-foreground">
                    If your coach provided a join code, enter it here to request to join the team
                  </p>
                  <div className="space-y-2">
                    <Label htmlFor="joinCode">Join Code</Label>
                    <Input
                      id="joinCode"
                      placeholder="HAWKS24"
                      value={joinCode}
                      onChange={(e) => {
                        const code = e.target.value.toUpperCase();
                        setJoinCode(code);
                        if (code.length >= 6) {
                          validateJoinCode(code);
                        } else {
                          setTeamInfo(null);
                        }
                      }}
                      disabled={isValidatingCode}
                      data-testid="input-join-code"
                    />
                    {isValidatingCode && (
                      <p className="text-xs text-muted-foreground">Validating code...</p>
                    )}
                    {teamInfo && (
                      <div className="mt-2 p-2 bg-primary/20 rounded border border-primary/30">
                        <p className="text-sm font-medium">Team: {teamInfo.teamName}</p>
                        <p className="text-xs text-muted-foreground">Sport: {teamInfo.sport}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          You'll need coach approval to join
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-3 p-4 border rounded-md bg-accent/10">
                  <h3 className="font-medium text-sm">Player Information (Your Child)</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="playerFirstName">Player First Name</Label>
                    <Input
                      id="playerFirstName"
                      placeholder="Sarah"
                      value={playerFirstName}
                      onChange={(e) => setPlayerFirstName(e.target.value)}
                      required={accountType === "parent"}
                      data-testid="input-player-firstname"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="playerLastName">Player Last Name</Label>
                    <Input
                      id="playerLastName"
                      placeholder="Doe"
                      value={playerLastName}
                      onChange={(e) => setPlayerLastName(e.target.value)}
                      required={accountType === "parent"}
                      data-testid="input-player-lastname"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="playerPhone">Player Phone Number</Label>
                  <Input
                    id="playerPhone"
                    type="tel"
                    placeholder="(555) 987-6543"
                    value={playerPhone}
                    onChange={(e) => setPlayerPhone(e.target.value)}
                    required={accountType === "parent"}
                    data-testid="input-player-phone"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="playerEmail">Player Email (Optional)</Label>
                  <Input
                    id="playerEmail"
                    type="email"
                    placeholder="player@example.com"
                    value={playerEmail}
                    onChange={(e) => setPlayerEmail(e.target.value)}
                    data-testid="input-player-email"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="playerDateOfBirth">Player Date of Birth (Optional)</Label>
                  <Input
                    id="playerDateOfBirth"
                    type="date"
                    value={playerDateOfBirth}
                    onChange={(e) => setPlayerDateOfBirth(e.target.value)}
                    data-testid="input-player-dob"
                  />
                </div>
              </div>
              </>
            )}
            <div className="flex items-start space-x-2 p-4 border rounded-md bg-muted/30">
              <Checkbox
                id="sms-consent"
                checked={smsConsentGranted}
                onCheckedChange={(checked) => setSmsConsentGranted(checked as boolean)}
                required
                data-testid="checkbox-sms-consent"
              />
              <div className="space-y-1 leading-none">
                <label
                  htmlFor="sms-consent"
                  className="text-sm font-medium leading-tight cursor-pointer"
                >
                  I agree to receive SMS text messages
                </label>
                <p className="text-xs text-muted-foreground">
                  By checking this box, you consent to receive automated SMS messages from {appName} about game reminders, event updates, and team notifications. Message and data rates may apply. You can opt out at any time.
                </p>
              </div>
            </div>
            <Button
              type="submit"
              className="w-full"
              disabled={isLoading || !smsConsentGranted}
              data-testid="button-register"
            >
              {isLoading ? "Creating account..." : "Create Account"}
            </Button>
          </form>
          <div className="mt-4 text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <button
              onClick={() => setLocation("/login")}
              className="text-primary hover:underline"
              data-testid="link-login"
            >
              Log in
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { CheckCircle2, FileText, Calendar, ExternalLink, CheckSquare, AlertCircle, UserPlus, Check, X } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { formatDistanceToNow } from "date-fns";

const signatureSchema = z.object({
  acknowledgmentText: z.string().min(1, "Please enter your full name"),
  agreed: z.boolean().refine((val) => val === true, {
    message: "You must agree to the document to continue",
  }),
});

interface TasksSummary {
  documentsPending: number;
  eventsPending: number;
  total: number;
}

interface DocumentTask {
  id: string;
  type: "document";
  teamId: string;
  teamName: string;
  title: string;
  description: string | null;
  fileUrl: string;
  createdAt: Date;
}

interface EventTask {
  id: string;
  type: "event";
  teamId: string;
  teamName: string;
  title: string;
  datetime: Date;
  location: string | null;
  eventType: string;
}

interface PendingJoinTask {
  id: string;
  type: "pending_join";
  teamId: string;
  teamName: string;
  parentFirstName: string;
  parentLastName: string;
  parentPhone: string;
  parentEmail: string;
  playerFirstName: string;
  playerLastName: string;
  playerPhone: string;
  joinCode: string;
  createdAt: Date;
}

interface TasksList {
  documents: DocumentTask[];
  events: EventTask[];
  pendingJoins: PendingJoinTask[];
}

export default function Tasks() {
  const { toast } = useToast();
  const [signDialogOpen, setSignDialogOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<DocumentTask | null>(null);

  const form = useForm<z.infer<typeof signatureSchema>>({
    resolver: zodResolver(signatureSchema),
    defaultValues: {
      acknowledgmentText: "",
      agreed: false,
    },
  });

  const { data: summary } = useQuery<TasksSummary>({
    queryKey: ["/api/tasks/summary"],
  });

  const { data: tasks, isLoading, isError, error } = useQuery<TasksList>({
    queryKey: ["/api/tasks/list"],
  });

  const signDocumentMutation = useMutation({
    mutationFn: async ({ documentId, acknowledgmentText }: { documentId: string; acknowledgmentText: string }) => {
      return await apiRequest("POST", `/api/documents/${documentId}/signatures`, { acknowledgmentText });
    },
    onSuccess: () => {
      toast({
        title: "Document signed",
        description: "Your signature has been recorded successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/list"] });
      setSignDialogOpen(false);
      setSelectedDocument(null);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to sign document",
        variant: "destructive",
      });
    },
  });

  const rsvpMutation = useMutation({
    mutationFn: async ({ eventId, response }: { eventId: string; response: string }) => {
      return await apiRequest("POST", `/api/events/${eventId}/attendance`, { response });
    },
    onSuccess: () => {
      toast({
        title: "RSVP recorded",
        description: "Your response has been saved.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/list"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit RSVP",
        variant: "destructive",
      });
    },
  });

  const approveJoinMutation = useMutation({
    mutationFn: async ({ teamId, joinId }: { teamId: string; joinId: string }) => {
      return await apiRequest("POST", `/api/teams/${teamId}/pending-joins/${joinId}/approve`);
    },
    onSuccess: () => {
      toast({
        title: "Join request approved",
        description: "The parent and player have been added to your team.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/list"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to approve join request",
        variant: "destructive",
      });
    },
  });

  const rejectJoinMutation = useMutation({
    mutationFn: async ({ teamId, joinId }: { teamId: string; joinId: string }) => {
      return await apiRequest("POST", `/api/teams/${teamId}/pending-joins/${joinId}/reject`);
    },
    onSuccess: () => {
      toast({
        title: "Join request rejected",
        description: "The join request has been declined.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/list"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reject join request",
        variant: "destructive",
      });
    },
  });

  const handleSignDocument = (doc: DocumentTask) => {
    setSelectedDocument(doc);
    form.reset();
    setSignDialogOpen(true);
  };

  const handleSubmitSignature = (values: z.infer<typeof signatureSchema>) => {
    if (!selectedDocument) return;

    signDocumentMutation.mutate({
      documentId: selectedDocument.id,
      acknowledgmentText: values.acknowledgmentText,
    });
  };

  const handleRsvp = (eventId: string, response: string) => {
    rsvpMutation.mutate({ eventId, response });
  };

  const totalTasks = (tasks?.documents.length || 0) + (tasks?.events.length || 0) + (tasks?.pendingJoins?.length || 0);

  if (isLoading) {
    return (
      <div className="container mx-auto p-4 max-w-4xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Tasks</h1>
          <p className="text-muted-foreground mt-1">Loading your pending tasks...</p>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="container mx-auto p-4 max-w-4xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Tasks</h1>
        </div>
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="h-16 w-16 rounded-full bg-destructive/10 flex items-center justify-center mb-4">
              <AlertCircle className="h-8 w-8 text-destructive" />
            </div>
            <h3 className="text-lg font-medium mb-2">Failed to load tasks</h3>
            <p className="text-sm text-muted-foreground text-center max-w-md">
              {error instanceof Error ? error.message : "There was an error loading your tasks. Please try again later."}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold" data-testid="heading-tasks">Tasks</h1>
        <p className="text-muted-foreground mt-1">
          {totalTasks === 0 ? "You're all caught up!" : `${totalTasks} pending ${totalTasks === 1 ? 'task' : 'tasks'}`}
        </p>
      </div>

      {totalTasks === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="h-16 w-16 rounded-full bg-green-100 dark:bg-green-900/20 flex items-center justify-center mb-4">
              <CheckCircle2 className="h-8 w-8 text-green-600 dark:text-green-500" />
            </div>
            <h3 className="text-lg font-medium mb-2">All caught up!</h3>
            <p className="text-sm text-muted-foreground text-center max-w-md">
              You have no pending documents to sign or events to RSVP to.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {/* Documents Section */}
          {tasks && tasks.documents.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Documents to Sign
                  <Badge variant="secondary">{tasks.documents.length}</Badge>
                </CardTitle>
                <CardDescription>
                  These documents require your signature
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {tasks.documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="flex items-start justify-between p-4 rounded-md border"
                    data-testid={`task-document-${doc.id}`}
                  >
                    <div className="flex-1">
                      <div className="font-medium">{doc.title}</div>
                      <div className="text-sm text-muted-foreground mt-1">
                        {doc.teamName}
                      </div>
                      {doc.description && (
                        <p className="text-sm text-muted-foreground mt-2">{doc.description}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-2 ml-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => window.open(doc.fileUrl, '_blank')}
                        data-testid={`button-view-doc-${doc.id}`}
                      >
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => handleSignDocument(doc)}
                        data-testid={`button-sign-doc-${doc.id}`}
                      >
                        <CheckSquare className="h-4 w-4 mr-2" />
                        Sign
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Events Section */}
          {tasks && tasks.events.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Events Awaiting RSVP
                  <Badge variant="secondary">{tasks.events.length}</Badge>
                </CardTitle>
                <CardDescription>
                  Please respond to these upcoming events
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {tasks.events.map((event) => (
                  <div
                    key={event.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-md border gap-4"
                    data-testid={`task-event-${event.id}`}
                  >
                    <div className="flex-1">
                      <div className="font-medium">{event.title}</div>
                      <div className="text-sm text-muted-foreground mt-1">
                        {event.teamName} • {event.eventType}
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">
                        {new Date(event.datetime).toLocaleDateString()} at {new Date(event.datetime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        {event.location && ` • ${event.location}`}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {formatDistanceToNow(new Date(event.datetime), { addSuffix: true })}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleRsvp(event.id, "yes")}
                        disabled={rsvpMutation.isPending}
                        data-testid={`button-rsvp-yes-${event.id}`}
                      >
                        Going
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleRsvp(event.id, "maybe")}
                        disabled={rsvpMutation.isPending}
                        data-testid={`button-rsvp-maybe-${event.id}`}
                      >
                        Maybe
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleRsvp(event.id, "no")}
                        disabled={rsvpMutation.isPending}
                        data-testid={`button-rsvp-no-${event.id}`}
                      >
                        Can't Go
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Pending Join Requests Section */}
          {tasks && tasks.pendingJoins && tasks.pendingJoins.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserPlus className="h-5 w-5" />
                  Pending Join Requests
                  <Badge variant="secondary">{tasks.pendingJoins.length}</Badge>
                </CardTitle>
                <CardDescription>
                  Parents requesting to join your team
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {tasks.pendingJoins.map((join) => (
                  <div
                    key={join.id}
                    className="flex flex-col sm:flex-row sm:items-start justify-between p-4 rounded-md border gap-4"
                    data-testid={`task-join-${join.id}`}
                  >
                    <div className="flex-1 space-y-2">
                      <div>
                        <div className="font-medium">
                          {join.playerFirstName} {join.playerLastName}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Player: {join.playerPhone}
                        </div>
                      </div>
                      <Separator />
                      <div>
                        <div className="text-sm font-medium">
                          Parent: {join.parentFirstName} {join.parentLastName}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {join.parentPhone} • {join.parentEmail}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>Join Code: {join.joinCode}</span>
                        <span>•</span>
                        <span>{formatDistanceToNow(new Date(join.createdAt), { addSuffix: true })}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => approveJoinMutation.mutate({ teamId: join.teamId, joinId: join.id })}
                        disabled={approveJoinMutation.isPending || rejectJoinMutation.isPending}
                        data-testid={`button-approve-join-${join.id}`}
                      >
                        <Check className="h-4 w-4 mr-2" />
                        Approve
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => rejectJoinMutation.mutate({ teamId: join.teamId, joinId: join.id })}
                        disabled={approveJoinMutation.isPending || rejectJoinMutation.isPending}
                        data-testid={`button-reject-join-${join.id}`}
                      >
                        <X className="h-4 w-4 mr-2" />
                        Reject
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Document Signing Dialog */}
      <Dialog open={signDialogOpen} onOpenChange={(open) => {
        setSignDialogOpen(open);
        if (!open) {
          setSelectedDocument(null);
          form.reset();
        }
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Sign Document</DialogTitle>
            <DialogDescription>
              Please review the document and provide your acknowledgment.
            </DialogDescription>
          </DialogHeader>
          {selectedDocument && (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmitSignature)} className="space-y-4">
                <div>
                  <p className="text-base font-medium">{selectedDocument.title}</p>
                  <p className="text-sm text-muted-foreground mt-1">{selectedDocument.teamName}</p>
                  {selectedDocument.description && (
                    <p className="text-sm text-muted-foreground mt-2">{selectedDocument.description}</p>
                  )}
                </div>
                <Separator />
                <div>
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={() => window.open(selectedDocument.fileUrl, '_blank')}
                    data-testid="button-view-document-modal"
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    View Document
                  </Button>
                </div>
                <FormField
                  control={form.control}
                  name="acknowledgmentText"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type your full name to acknowledge</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Full Name"
                          {...field}
                          data-testid="input-acknowledgment"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="agreed"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="checkbox-agree"
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="cursor-pointer">
                          I have read and agree to this document
                        </FormLabel>
                        <FormMessage />
                      </div>
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setSignDialogOpen(false);
                      setSelectedDocument(null);
                      form.reset();
                    }}
                    data-testid="button-cancel-sign"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={signDocumentMutation.isPending}
                    data-testid="button-submit-signature"
                  >
                    {signDocumentMutation.isPending ? "Signing..." : "Sign Document"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

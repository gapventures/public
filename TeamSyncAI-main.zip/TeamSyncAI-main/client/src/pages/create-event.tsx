import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Link, useLocation } from "wouter";
import type { Team, EventTemplate, CustomField } from "@shared/schema";
import { GooglePlacesAutocomplete } from "@/components/GooglePlacesAutocomplete";
import { useAvailableSports } from "@/hooks/useAvailableSports";

// Helper to get default datetime (next Saturday at 10am, or tomorrow if Saturday is today)
function getDefaultDateTime(): string {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0 = Sunday, 6 = Saturday
  
  // Find next Saturday (or tomorrow if today is Saturday)
  let daysUntilSaturday = (6 - dayOfWeek) % 7;
  if (daysUntilSaturday === 0) {
    daysUntilSaturday = 7; // If today is Saturday, use next Saturday
  }
  
  const nextSaturday = new Date(now);
  nextSaturday.setDate(now.getDate() + daysUntilSaturday);
  nextSaturday.setHours(10, 0, 0, 0); // 10:00 AM
  
  // Format as YYYY-MM-DDTHH:MM for datetime-local input
  const year = nextSaturday.getFullYear();
  const month = String(nextSaturday.getMonth() + 1).padStart(2, '0');
  const day = String(nextSaturday.getDate()).padStart(2, '0');
  const hours = String(nextSaturday.getHours()).padStart(2, '0');
  const minutes = String(nextSaturday.getMinutes()).padStart(2, '0');
  
  return `${year}-${month}-${day}T${hours}:${minutes}`;
}

export default function CreateEvent() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const { availableSports } = useAvailableSports();
  const [titleManuallyEdited, setTitleManuallyEdited] = useState(false);
  const [sportManuallyEdited, setSportManuallyEdited] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("");
  const [customFieldValues, setCustomFieldValues] = useState<Record<string, string>>({});
  const [formData, setFormData] = useState({
    teamId: "",
    title: "",
    type: "game",
    sport: "",
    datetime: getDefaultDateTime(),
    location: "",
    opponent: "",
    homeAway: "",
    fieldType: "",
    cleatsAllowed: "",
    jersey: "",
    arrivalTime: "",
    notes: "",
  });

  const { data: teams = [] } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  const { data: locations = [] } = useQuery<string[]>({
    queryKey: ["/api/events/locations"],
  });

  const { data: eventTemplates = [] } = useQuery<EventTemplate[]>({
    queryKey: ["/api/admin/event-templates"],
  });

  const { data: customFields = [] } = useQuery<CustomField[]>({
    queryKey: ["/api/admin/custom-fields"],
  });

  // Helper to generate event title based on current form state
  const generateEventTitle = (teamId: string, type: string, opponent: string, location: string) => {
    const selectedTeam = teams.find(t => t.id === teamId);
    if (!selectedTeam) return "";
    
    if (type === "game") {
      return `${selectedTeam.name} vs ${opponent || "Opponent"}`;
    } else if (type === "practice") {
      return `${selectedTeam.name} [practice] at ${location || "Location TBD"}`;
    } else {
      return `${selectedTeam.name} [${type}] at ${location || "Location TBD"}`;
    }
  };

  const createEventMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const eventData = {
        ...data,
        datetime: new Date(data.datetime).toISOString(),
        opponent: data.opponent || null,
        homeAway: data.homeAway || null,
        fieldType: data.fieldType || null,
        cleatsAllowed: data.cleatsAllowed || null,
        jersey: data.jersey || null,
        arrivalTime: data.arrivalTime || null,
        notes: data.notes || null,
        customFieldValues: Object.keys(customFieldValues).length > 0 ? customFieldValues : null,
      };
      const response = await apiRequest("POST", "/api/events", eventData);
      return await response.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      queryClient.invalidateQueries({ queryKey: ["/api/events/locations"] });
      toast({
        title: "Event created",
        description: "Your event has been created successfully.",
      });
      setLocation(`/events/${data.id}`);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create event. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!formData.teamId || !formData.title || !formData.sport || !formData.datetime || !formData.location) {
      console.error("Validation failed - missing required fields:", {
        teamId: !!formData.teamId,
        title: !!formData.title,
        sport: !!formData.sport,
        datetime: formData.datetime,
        location: !!formData.location,
      });
      toast({
        title: "Missing information",
        description: "Please fill in all required fields (Team, Title, Sport, Date & Time, Location).",
        variant: "destructive",
      });
      return;
    }
    
    // Validate datetime is actually a valid date
    const dateObj = new Date(formData.datetime);
    if (isNaN(dateObj.getTime())) {
      console.error("Invalid datetime value:", formData.datetime);
      toast({
        title: "Invalid Date",
        description: "Please enter a valid date and time.",
        variant: "destructive",
      });
      return;
    }
    
    createEventMutation.mutate(formData);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/events">
          <Button variant="ghost" size="icon" data-testid="button-back">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <div>
          <h1 className="font-semibold tracking-tight">Create Event</h1>
          <p className="text-muted-foreground text-sm md:text-base">
            Create a new game, practice, or team event
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Event Details</CardTitle>
            <CardDescription>
              Fill in the event information. Fields marked with * are required.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="team">Team *</Label>
                <Select
                  value={formData.teamId}
                  onValueChange={(value) => {
                    const selectedTeam = teams.find(t => t.id === value);
                    const newTitle = !titleManuallyEdited || formData.title === "" 
                      ? generateEventTitle(value, formData.type, formData.opponent, formData.location)
                      : formData.title;
                    
                    // Auto-set sport from team (only if not manually edited)
                    const newSport = selectedTeam?.sport && !sportManuallyEdited 
                      ? selectedTeam.sport 
                      : formData.sport;
                    
                    setFormData({ ...formData, teamId: value, title: newTitle, sport: newSport });
                    setSportManuallyEdited(false);
                    if (formData.title === "") {
                      setTitleManuallyEdited(false);
                    }
                  }}
                  required
                >
                  <SelectTrigger id="team" data-testid="select-team">
                    <SelectValue placeholder="Select a team" />
                  </SelectTrigger>
                  <SelectContent>
                    {teams.map((team) => (
                      <SelectItem key={team.id} value={team.id}>
                        {team.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="template">Use Template (Optional)</Label>
                <Select
                  value={selectedTemplateId}
                  onValueChange={(value) => {
                    if (value === "none") {
                      setSelectedTemplateId("");
                      setCustomFieldValues({});
                    } else {
                      setSelectedTemplateId(value);
                      
                      // Apply template defaults immediately (moved from useEffect)
                      const template = eventTemplates?.find(t => t.id === value);
                      if (template) {
                        setFormData(prev => ({
                          ...prev,
                          type: template.type,
                          title: template.defaultTitle || prev.title,
                          location: template.defaultLocation || prev.location,
                          opponent: template.opponent || "",
                          homeAway: template.homeAway || "",
                          fieldType: template.fieldType || "",
                          cleatsAllowed: template.cleatsAllowed || "",
                          jersey: template.jersey || "",
                          arrivalTime: template.arrivalTime || "",
                          notes: template.notes || "",
                        }));
                        
                        // Initialize custom field values for this template
                        const newCustomFieldValues: Record<string, string> = {};
                        if (template.customFieldIds) {
                          template.customFieldIds.forEach(fieldId => {
                            newCustomFieldValues[fieldId] = "";
                          });
                        }
                        setCustomFieldValues(newCustomFieldValues);
                      }
                    }
                  }}
                >
                  <SelectTrigger id="template" data-testid="select-template">
                    <SelectValue placeholder="No template" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No template</SelectItem>
                    {eventTemplates
                      .filter(t => !formData.sport || t.sport === formData.sport)
                      .map((template) => (
                        <SelectItem key={template.id} value={template.id}>
                          {template.name} ({template.sport})
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Event Type *</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value) => {
                    const newTitle = !titleManuallyEdited || formData.title === ""
                      ? generateEventTitle(formData.teamId, value, formData.opponent, formData.location)
                      : formData.title;
                    setFormData({ ...formData, type: value, title: newTitle });
                    if (formData.title === "") {
                      setTitleManuallyEdited(false);
                    }
                  }}
                  required
                >
                  <SelectTrigger id="type" data-testid="select-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="game">Game</SelectItem>
                    <SelectItem value="practice">Practice</SelectItem>
                    <SelectItem value="team_party">Team Party</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="sport">Sport *</Label>
                <Select
                  value={formData.sport}
                  onValueChange={(value) => {
                    setFormData({ ...formData, sport: value });
                    setSportManuallyEdited(true);
                  }}
                  required
                  disabled={!formData.teamId}
                >
                  <SelectTrigger id="sport" data-testid="select-sport">
                    <SelectValue placeholder="Select a sport" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableSports.map((sport) => (
                      <SelectItem key={sport} value={sport}>
                        {sport}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">Event Title *</Label>
              <Input
                id="title"
                placeholder="Event title will auto-generate based on type..."
                value={formData.title}
                onChange={(e) => {
                  setFormData({ ...formData, title: e.target.value });
                  setTitleManuallyEdited(true);
                }}
                data-testid="input-title"
                required
              />
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="datetime">Date & Time *</Label>
                <Input
                  id="datetime"
                  type="datetime-local"
                  value={formData.datetime}
                  onChange={(e) => setFormData({ ...formData, datetime: e.target.value })}
                  data-testid="input-datetime"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Location *</Label>
                <GooglePlacesAutocomplete
                  value={formData.location}
                  onChange={(value) => {
                    const newTitle = !titleManuallyEdited || formData.title === ""
                      ? generateEventTitle(formData.teamId, formData.type, formData.opponent, value)
                      : formData.title;
                    setFormData({ ...formData, location: value, title: newTitle });
                  }}
                  placeholder="Search address or venue name..."
                  previousLocations={locations}
                  data-testid="input-location"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="opponent">Opponent</Label>
                <Input
                  id="opponent"
                  placeholder="Team name"
                  value={formData.opponent}
                  onChange={(e) => {
                    const newValue = e.target.value;
                    const newTitle = !titleManuallyEdited || formData.title === ""
                      ? generateEventTitle(formData.teamId, formData.type, newValue, formData.location)
                      : formData.title;
                    setFormData({ ...formData, opponent: newValue, title: newTitle });
                  }}
                  data-testid="input-opponent"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="homeAway">Home/Away</Label>
                <Select
                  value={formData.homeAway}
                  onValueChange={(value) => setFormData({ ...formData, homeAway: value })}
                >
                  <SelectTrigger id="homeAway" data-testid="select-home-away">
                    <SelectValue placeholder="Select..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="home">Home</SelectItem>
                    <SelectItem value="away">Away</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="fieldType">Field Type</Label>
                <Select
                  value={formData.fieldType}
                  onValueChange={(value) => setFormData({ ...formData, fieldType: value })}
                >
                  <SelectTrigger id="fieldType" data-testid="select-field-type">
                    <SelectValue placeholder="Select..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="grass">Grass</SelectItem>
                    <SelectItem value="turf">Turf</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="cleatsAllowed">Cleats Allowed</Label>
                <Select
                  value={formData.cleatsAllowed}
                  onValueChange={(value) => setFormData({ ...formData, cleatsAllowed: value })}
                >
                  <SelectTrigger id="cleatsAllowed" data-testid="select-cleats">
                    <SelectValue placeholder="Select..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any</SelectItem>
                    <SelectItem value="non-metal">Non-Metal Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="jersey">Jersey Color/Type</Label>
                <Input
                  id="jersey"
                  placeholder="e.g., Blue home jersey"
                  value={formData.jersey}
                  onChange={(e) => setFormData({ ...formData, jersey: e.target.value })}
                  data-testid="input-jersey"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="arrivalTime">Arrival Time</Label>
                <Input
                  id="arrivalTime"
                  placeholder="e.g., 30 minutes before"
                  value={formData.arrivalTime}
                  onChange={(e) => setFormData({ ...formData, arrivalTime: e.target.value })}
                  data-testid="input-arrival-time"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                placeholder="Additional information for players..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                data-testid="input-notes"
              />
            </div>

            {selectedTemplateId && (() => {
              const selectedTemplate = eventTemplates.find(t => t.id === selectedTemplateId);
              const templateCustomFieldIds = selectedTemplate?.customFieldIds || [];
              return templateCustomFieldIds.length > 0;
            })() && (
              <>
                <div className="border-t pt-6 mt-6">
                  <h3 className="text-lg font-medium mb-4">Custom Fields</h3>
                  <div className="grid gap-6 md:grid-cols-2">
                    {(() => {
                      const selectedTemplate = eventTemplates.find(t => t.id === selectedTemplateId);
                      return selectedTemplate?.customFieldIds || [];
                    })().map((fieldId) => {
                        const field = customFields.find(f => f.id === fieldId);
                        if (!field) return null;

                        return (
                          <div key={field.id} className="space-y-2">
                            <Label htmlFor={`custom-field-${field.id}`}>{field.name}</Label>
                            {field.fieldType === "text" && (
                              <Input
                                id={`custom-field-${field.id}`}
                                data-testid={`input-custom-field-${field.id}`}
                                placeholder={field.placeholder || ""}
                                value={customFieldValues[field.id] || ""}
                                onChange={(e) => setCustomFieldValues({ ...customFieldValues, [field.id]: e.target.value })}
                              />
                            )}
                            {field.fieldType === "textarea" && (
                              <Textarea
                                id={`custom-field-${field.id}`}
                                data-testid={`input-custom-field-${field.id}`}
                                placeholder={field.placeholder || ""}
                                value={customFieldValues[field.id] || ""}
                                onChange={(e) => setCustomFieldValues({ ...customFieldValues, [field.id]: e.target.value })}
                                rows={3}
                              />
                            )}
                            {field.fieldType === "number" && (
                              <Input
                                id={`custom-field-${field.id}`}
                                data-testid={`input-custom-field-${field.id}`}
                                type="number"
                                placeholder={field.placeholder || ""}
                                value={customFieldValues[field.id] || ""}
                                onChange={(e) => setCustomFieldValues({ ...customFieldValues, [field.id]: e.target.value })}
                              />
                            )}
                            {field.fieldType === "select" && field.options && (
                              <Select
                                value={customFieldValues[field.id] || ""}
                                onValueChange={(value) => setCustomFieldValues({ ...customFieldValues, [field.id]: value })}
                              >
                                <SelectTrigger id={`custom-field-${field.id}`} data-testid={`select-custom-field-${field.id}`}>
                                  <SelectValue placeholder={field.placeholder || "Select an option"} />
                                </SelectTrigger>
                                <SelectContent>
                                  {field.options.map((option) => (
                                    <SelectItem key={option} value={option}>
                                      {option}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            )}
                          </div>
                        );
                      })}
                  </div>
                </div>
              </>
            )}

            <div className="flex gap-4 pt-4">
              <Link href="/events" className="flex-1 md:flex-initial">
                <Button
                  type="button"
                  variant="outline"
                  className="w-full md:w-auto"
                  data-testid="button-cancel"
                >
                  Cancel
                </Button>
              </Link>
              <Button
                type="submit"
                className="flex-1 md:flex-initial"
                disabled={createEventMutation.isPending}
                data-testid="button-submit"
              >
                {createEventMutation.isPending ? "Creating..." : "Create Event"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Check } from "lucide-react";
import { useAppName } from "@/hooks/useAppName";
import { useOrganizationLogo } from "@/hooks/useOrganizationLogo";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import type { MembershipTier, TierFeature, TierLimit } from "@shared/schema";
import { MarketingFooter } from "@/components/marketing-footer";

interface TierWithDetails extends MembershipTier {
  features: TierFeature[];
  limits: TierLimit[];
}

const formatPrice = (cents: number, isContactPricing: boolean): string => {
  if (isContactPricing) return "Contact Us";
  if (cents === 0) return "Free";
  const dollars = (cents / 100).toFixed(2);
  return `$${dollars}/month`;
};

const formatFeatureList = (tier: TierWithDetails): string[] => {
  const features: string[] = [];
  
  // Add limits as features
  tier.limits.forEach(limit => {
    const value = limit.limitValue === -1 ? "Unlimited" : limit.limitValue.toString();
    const key = limit.limitKey;
    
    // Format limit keys into readable features
    if (key === "maxTeams") features.push(`${value} ${value === "1" ? "team" : "teams"}`);
    else if (key === "maxPlayers") features.push(`Up to ${value} players`);
    else if (key === "maxEvents") features.push(`${value} events`);
    else if (key === "maxSmsPerMonth") features.push(`${value} SMS messages/month`);
  });
  
  // Add enabled features
  tier.features.forEach(feature => {
    if (feature.enabled) {
      const key = feature.featureKey;
      
      // Format feature keys into readable features
      if (key === "messageBoard") features.push("Team message board");
      else if (key === "campaignTemplates") features.push("Automated reminder templates");
      else if (key === "calendarSubscription") features.push("Calendar subscription");
      else if (key === "paymentIntegration") features.push("Payment integration");
      else if (key === "advancedAnalytics") features.push("Advanced analytics");
      else if (key === "customBranding") features.push("Custom branding");
      else if (key === "apiAccess") features.push("API access");
      else if (key === "dedicatedSupport") features.push("Dedicated support");
      else if (key === "aiLineupGeneration") features.push("AI lineup generation");
    }
  });
  
  return features;
};

export default function Pricing() {
  const appName = useAppName();
  const logoUrl = useOrganizationLogo();
  
  const { data: tiers, isLoading: tiersLoading, isError: tiersError } = useQuery<TierWithDetails[]>({
    queryKey: ["/api/public/membership-tiers"],
    retry: 2,
  });

  const { data: heroContent, isError: heroError } = useQuery<{ heroTitle: string; heroSubtitle: string }>({
    queryKey: ["/api/marketing-pages/pricing"],
    retry: 1,
    throwOnError: false,
  });

  if (tiersLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center" data-testid="loading-state">
          <div className="text-lg text-muted-foreground">Loading...</div>
        </div>
      </div>
    );
  }

  const displayTiers = (tiersError || !tiers) ? [] : tiers;
  const middleIndex = Math.floor(displayTiers.length / 2);
  
  const heroTitle = heroContent?.heroTitle || "Simple, Transparent Pricing";
  const heroSubtitle = heroContent?.heroSubtitle || "Choose the plan that's right for your team.";

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-3 md:py-4 flex justify-between items-center gap-2">
          <Link href="/" data-testid="link-home-logo">
            <div className="flex items-center gap-2 md:gap-3 cursor-pointer hover-elevate rounded-md p-2 -m-2 min-w-0">
              {logoUrl ? (
                <img 
                  src={logoUrl} 
                  alt="Logo" 
                  className="h-8 md:h-10 w-auto object-contain flex-shrink-0"
                  data-testid="img-header-logo"
                />
              ) : (
                <Users className="h-5 md:h-6 w-5 md:w-6 text-primary flex-shrink-0" />
              )}
              <span className="hidden sm:block text-lg md:text-xl font-bold truncate">{appName}</span>
            </div>
          </Link>
          <nav className="flex items-center gap-1 md:gap-4 flex-shrink-0">
            <Link 
              href="/about" 
              className="hidden md:inline-flex text-sm font-medium hover-elevate rounded-md px-3 py-2" 
              data-testid="link-about"
            >
              About
            </Link>
            <Link 
              href="/features" 
              className="hidden md:inline-flex text-sm font-medium hover-elevate rounded-md px-3 py-2" 
              data-testid="link-features"
            >
              Features
            </Link>
            <Link 
              href="/pricing" 
              className="text-xs md:text-sm font-medium hover-elevate rounded-md px-2 md:px-3 py-2" 
              data-testid="link-pricing"
            >
              Pricing
            </Link>
            <Link 
              href="/contact" 
              className="text-xs md:text-sm font-medium hover-elevate rounded-md px-2 md:px-3 py-2" 
              data-testid="link-contact"
            >
              Contact
            </Link>
            <Link href="/login">
              <Button size="sm" data-testid="button-login">Log In</Button>
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="container mx-auto px-4 py-8 md:py-16 landscape:py-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8 landscape:mb-6">
              <h1 className="text-3xl md:text-4xl lg:text-5xl landscape:text-3xl font-bold mb-4 landscape:mb-3" data-testid="text-heading">
                {heroTitle}
              </h1>
              <p className="text-lg md:text-xl landscape:text-base text-muted-foreground max-w-3xl mx-auto" data-testid="text-subheading">
                {heroSubtitle}
              </p>
            </div>

            {displayTiers.length > 0 ? (
              <div className="grid md:grid-cols-3 gap-8 mb-8 landscape:mb-6">
                {displayTiers.map((tier, index) => {
                  const features = formatFeatureList(tier);
                  const isHighlighted = index === middleIndex;
                  const price = formatPrice(tier.monthlyPrice, tier.isContactForPricing);
                  const buttonText = tier.isContactForPricing ? "Contact Sales" : "Start Free Trial";
                  
                  return (
                    <Card 
                      key={tier.id} 
                      className={isHighlighted ? "border-primary shadow-lg" : ""}
                      data-testid={`plan-card-${index}`}
                    >
                      <CardHeader>
                        {isHighlighted && (
                          <div className="inline-block bg-primary text-primary-foreground text-xs font-semibold px-3 py-1 rounded-full mb-2 w-fit" data-testid="badge-featured">
                            Most Popular
                          </div>
                        )}
                        <CardTitle className="text-2xl" data-testid={`plan-name-${index}`}>{tier.name}</CardTitle>
                        <CardDescription data-testid={`plan-description-${index}`}>{tier.description || `Perfect for ${tier.name.toLowerCase()} teams`}</CardDescription>
                        <div className="mt-4">
                          <span className="text-4xl font-bold" data-testid={`plan-price-${index}`}>{price}</span>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-3 mb-6">
                          {features.map((feature, idx) => (
                            <li key={idx} className="flex items-start gap-2" data-testid={`plan-feature-${index}-${idx}`}>
                              <Check className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                              <span className="text-sm">{feature}</span>
                            </li>
                          ))}
                        </ul>
                        <Link href={tier.isContactForPricing ? "/contact" : "/login"}>
                          <Button 
                            className="w-full" 
                            variant={isHighlighted ? "default" : "outline"}
                            data-testid={`button-plan-${tier.name.toLowerCase()}`}
                          >
                            {buttonText}
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12" data-testid="no-tiers-message">
                <p className="text-muted-foreground">Pricing information is being configured. Please check back soon.</p>
              </div>
            )}

            <div className="bg-muted rounded-lg p-8 md:p-12 text-center">
              <h2 className="text-2xl font-bold mb-4" data-testid="text-cta-heading">
                Ready to get started?
              </h2>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto" data-testid="text-cta-subtitle">
                Join coaches who are saving hours every week with automated team management.
              </p>
              <Link href="/login">
                <Button size="lg" data-testid="button-get-started">
                  Start Your Free Trial
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      <MarketingFooter />
    </div>
  );
}

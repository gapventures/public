import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Bell, Check, CheckCheck, Calendar, Users } from "lucide-react";
import { format } from "date-fns";
import type { TeamNotification } from "@shared/schema";

export default function NotificationsPage() {
  const { toast } = useToast();

  const { data: notifications = [], isLoading } = useQuery<TeamNotification[]>({
    queryKey: ["/api/team-notifications"],
    refetchInterval: 30000,
  });

  const markAsReadMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("PATCH", `/api/team-notifications/${id}/mark-read`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/team-notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/team-notifications/unread-count"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to mark notification as read",
      });
    },
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("PATCH", "/api/team-notifications/mark-all-read");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/team-notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/team-notifications/unread-count"] });
      toast({
        title: "Success",
        description: "All notifications marked as read",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to mark all notifications as read",
      });
    },
  });

  const unreadNotifications = notifications.filter((n) => !n.isRead);
  const readNotifications = notifications.filter((n) => n.isRead);

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "rsvp_response":
        return <Calendar className="h-4 w-4" />;
      default:
        return <Bell className="h-4 w-4" />;
    }
  };

  const getNotificationBadgeVariant = (status?: string) => {
    switch (status) {
      case "yes":
        return "default";
      case "no":
        return "destructive";
      case "maybe":
        return "secondary";
      default:
        return "secondary";
    }
  };

  const renderNotification = (notification: TeamNotification) => {
    const metadata = notification.metadata as any;

    return (
      <Card
        key={notification.id}
        className={`${!notification.isRead ? "border-primary" : ""}`}
        data-testid={`notification-${notification.id}`}
      >
        <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0 pb-2">
          <div className="flex items-start gap-3 flex-1">
            <div className="mt-1">{getNotificationIcon(notification.type)}</div>
            <div className="flex-1 space-y-1">
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-sm" data-testid="text-notification-title">
                  {notification.title}
                </h3>
                {!notification.isRead && (
                  <Badge variant="destructive" className="h-2 w-2 rounded-full p-0" />
                )}
              </div>
              <p className="text-sm text-muted-foreground" data-testid="text-notification-message">
                {notification.message}
              </p>
              {metadata?.status && (
                <Badge variant={getNotificationBadgeVariant(metadata.status)}>
                  {metadata.status.toUpperCase()}
                </Badge>
              )}
              <p className="text-xs text-muted-foreground">
                {format(new Date(notification.createdAt), "PPp")}
              </p>
            </div>
          </div>
          {!notification.isRead && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => markAsReadMutation.mutate(notification.id)}
              disabled={markAsReadMutation.isPending}
              data-testid={`button-mark-read-${notification.id}`}
            >
              <Check className="h-4 w-4" />
            </Button>
          )}
        </CardHeader>
      </Card>
    );
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Notifications</h1>
        </div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-4 bg-muted rounded w-3/4" />
              </CardHeader>
              <CardContent>
                <div className="h-3 bg-muted rounded w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-notifications-title">
            Notifications
          </h1>
          <p className="text-sm text-muted-foreground">
            Stay updated on player RSVPs and team activity
          </p>
        </div>
        {unreadNotifications.length > 0 && (
          <Button
            onClick={() => markAllAsReadMutation.mutate()}
            disabled={markAllAsReadMutation.isPending}
            data-testid="button-mark-all-read"
          >
            <CheckCheck className="h-4 w-4 mr-2" />
            Mark All as Read
          </Button>
        )}
      </div>

      {notifications.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Bell className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2" data-testid="text-no-notifications">
              No notifications yet
            </h3>
            <p className="text-sm text-muted-foreground text-center max-w-md">
              You'll receive notifications here when players RSVP to events and other team activities occur.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {unreadNotifications.length > 0 && (
            <div className="space-y-3">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Unread ({unreadNotifications.length})
              </h2>
              {unreadNotifications.map(renderNotification)}
            </div>
          )}

          {readNotifications.length > 0 && (
            <div className="space-y-3">
              <h2 className="text-lg font-semibold text-muted-foreground">
                Read ({readNotifications.length})
              </h2>
              {readNotifications.map(renderNotification)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

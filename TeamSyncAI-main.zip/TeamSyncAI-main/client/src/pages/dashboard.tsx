import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Users, Calendar, TrendingUp } from "lucide-react";
import { Link } from "wouter";
import type { Team, Event } from "@shared/schema";
import { useTestView } from "@/contexts/TestViewContext";

export default function Dashboard() {
  const { testViewMode, isTestViewActive } = useTestView();

  const queryKey = isTestViewActive && testViewMode 
    ? `/api/teams?testViewMode=${testViewMode}`
    : "/api/teams";
    
  const { data: teams = [], isLoading: teamsLoading } = useQuery<Team[]>({
    queryKey: [queryKey],
  });

  const { data: upcomingEvents = [], isLoading: eventsLoading } = useQuery<Event[]>({
    queryKey: ["/api/events/upcoming"],
  });

  const isLoading = teamsLoading || eventsLoading;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="font-semibold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground text-sm md:text-base">
            Manage your teams, events, and attendance
          </p>
        </div>
        <Link href="/events/new">
          <Button data-testid="button-create-event">
            <Plus className="h-4 w-4 mr-2" />
            Create Event
          </Button>
        </Link>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Teams</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold" data-testid="text-total-teams">
              {teams.length}
            </div>
            <p className="text-xs text-muted-foreground">
              Active teams managed
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Events</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold" data-testid="text-upcoming-events">
              {upcomingEvents.length}
            </div>
            <p className="text-xs text-muted-foreground">
              In the next 30 days
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Response Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold" data-testid="text-response-rate">
              --
            </div>
            <p className="text-xs text-muted-foreground">
              Average player response
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Teams</CardTitle>
            <CardDescription>Manage your sports teams</CardDescription>
          </CardHeader>
          <CardContent>
            {teams.length === 0 ? (
              <div className="text-center py-8">
                <Users className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-sm text-muted-foreground mb-4">
                  No teams yet. Create your first team to get started.
                </p>
                <Link href="/teams">
                  <Button variant="outline" data-testid="button-goto-teams">
                    Go to Teams
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-3">
                {teams.slice(0, 3).map((team) => (
                  <Link key={team.id} href={`/teams/${team.id}`}>
                    <div
                      className="flex items-center justify-between p-3 rounded-md border hover-elevate active-elevate-2"
                      data-testid={`card-team-${team.id}`}
                    >
                      <div>
                        <p className="font-medium">{team.name}</p>
                        <p className="text-sm text-muted-foreground">
                          View roster
                        </p>
                      </div>
                      <Button variant="ghost" size="sm">
                        View
                      </Button>
                    </div>
                  </Link>
                ))}
                {teams.length > 3 && (
                  <Link href="/teams">
                    <Button variant="outline" className="w-full" data-testid="button-view-all-teams">
                      View All Teams
                    </Button>
                  </Link>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upcoming Events</CardTitle>
            <CardDescription>Events scheduled in the next 30 days</CardDescription>
          </CardHeader>
          <CardContent>
            {upcomingEvents.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-sm text-muted-foreground mb-4">
                  No upcoming events. Create an event to start managing attendance.
                </p>
                <Link href="/events/new">
                  <Button variant="outline" data-testid="button-create-first-event">
                    Create Event
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-3">
                {upcomingEvents.slice(0, 3).map((event) => (
                  <Link key={event.id} href={`/events/${event.id}`}>
                    <div
                      className="flex items-center justify-between p-3 rounded-md border hover-elevate active-elevate-2"
                      data-testid={`card-event-${event.id}`}
                    >
                      <div>
                        <p className="font-medium">{event.type}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(event.datetime).toLocaleDateString()}
                        </p>
                      </div>
                      <Button variant="ghost" size="sm">
                        View
                      </Button>
                    </div>
                  </Link>
                ))}
                {upcomingEvents.length > 3 && (
                  <Link href="/events">
                    <Button variant="outline" className="w-full" data-testid="button-view-all-events">
                      View All Events
                    </Button>
                  </Link>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

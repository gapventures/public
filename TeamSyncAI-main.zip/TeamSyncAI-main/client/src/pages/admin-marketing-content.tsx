import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  aboutPageContentSchema, 
  featuresPageContentSchema, 
  pricingPageContentSchema, 
  contactPageContentSchema,
  type AboutPageContent,
  type FeaturesPageContent,
  type PricingPageContent,
  type ContactPageContent,
} from "@shared/schema";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Save, Plus, Trash2, Loader2 } from "lucide-react";
import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "wouter";

const ABOUT_ICONS = ["Target", "Users", "Heart", "Zap", "Shield", "Star", "TrendingUp", "Award"] as const;
const FEATURES_ICONS = ["MessageSquare", "Calendar", "Bell", "Users", "TrendingUp", "Shield", "Database", "Zap", "CheckCircle", "Settings", "Star", "Award"] as const;

export default function AdminMarketingContent() {
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState("about");

  if (!currentUser?.isGlobalAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen" data-testid="unauthorized-message">
        <Card>
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>You do not have permission to access this page.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="w-full max-w-7xl mx-auto px-4 py-6 sm:px-6">
      <div className="mb-6">
        <h1 className="text-3xl font-semibold" data-testid="page-title">Marketing Pages Content</h1>
        <p className="text-sm text-muted-foreground mt-2" data-testid="page-description">
          Edit content for About, Features, Pricing, and Contact pages
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} data-testid="tabs-marketing-content">
        <TabsList className="grid w-full grid-cols-4" data-testid="tabs-list">
          <TabsTrigger value="about" data-testid="tab-trigger-about">About</TabsTrigger>
          <TabsTrigger value="features" data-testid="tab-trigger-features">Features</TabsTrigger>
          <TabsTrigger value="pricing" data-testid="tab-trigger-pricing">Pricing</TabsTrigger>
          <TabsTrigger value="contact" data-testid="tab-trigger-contact">Contact</TabsTrigger>
        </TabsList>

        <TabsContent value="about" data-testid="tab-content-about">
          <AboutPageForm />
        </TabsContent>

        <TabsContent value="features" data-testid="tab-content-features">
          <FeaturesPageForm />
        </TabsContent>

        <TabsContent value="pricing" data-testid="tab-content-pricing">
          <PricingPageForm />
        </TabsContent>

        <TabsContent value="contact" data-testid="tab-content-contact">
          <ContactPageForm />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function AboutPageForm() {
  const { toast } = useToast();
  const { data: content, isLoading } = useQuery<AboutPageContent>({
    queryKey: ["/api/marketing-pages", "about"],
  });

  const form = useForm<AboutPageContent>({
    resolver: zodResolver(aboutPageContentSchema),
    defaultValues: content || {
      heroTitle: "",
      heroSubtitle: "",
      missionTitle: "",
      missionText: "",
      valuesTitle: "",
      values: [],
      ctaTitle: "",
      ctaButton: "",
    },
  });

  const { mutate: updateContent, isPending } = useMutation({
    mutationFn: async (data: AboutPageContent) => {
      return await apiRequest("PUT", "/api/admin/marketing-pages/about", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/marketing-pages", "about"] });
      toast({
        title: "Success",
        description: "About page content updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update content",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (content) {
      form.reset(content);
    }
  }, [content, form]);

  if (isLoading) {
    return (
      <Card data-testid="loading-state">
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin" data-testid="spinner-loading" />
        </CardContent>
      </Card>
    );
  }

  const onSubmit = (data: AboutPageContent) => {
    updateContent(data);
  };

  const addValue = () => {
    const currentValues = form.getValues("values") || [];
    form.setValue("values", [...currentValues, { icon: "Target", title: "", description: "" }]);
  };

  const removeValue = (index: number) => {
    const currentValues = form.getValues("values") || [];
    form.setValue("values", currentValues.filter((_, i) => i !== index));
  };

  return (
    <Card data-testid="card-about-form">
      <CardHeader>
        <CardTitle data-testid="title-about-form">About Page Content</CardTitle>
        <CardDescription data-testid="description-about-form">
          Edit the content for the About page
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-medium" data-testid="heading-hero-section">Hero Section</h3>
              
              <FormField
                control={form.control}
                name="heroTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-hero-title">Hero Title</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-hero-title" />
                    </FormControl>
                    <FormMessage data-testid="error-hero-title" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="heroSubtitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-hero-subtitle">Hero Subtitle</FormLabel>
                    <FormControl>
                      <Textarea {...field} data-testid="input-hero-subtitle" rows={3} />
                    </FormControl>
                    <FormMessage data-testid="error-hero-subtitle" />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium" data-testid="heading-mission-section">Mission Section</h3>
              
              <FormField
                control={form.control}
                name="missionTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-mission-title">Mission Title</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-mission-title" />
                    </FormControl>
                    <FormMessage data-testid="error-mission-title" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="missionText"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-mission-text">Mission Text</FormLabel>
                    <FormControl>
                      <Textarea {...field} data-testid="input-mission-text" rows={5} />
                    </FormControl>
                    <FormMessage data-testid="error-mission-text" />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium" data-testid="heading-values-section">Values Section</h3>
                <Button type="button" onClick={addValue} size="sm" data-testid="button-add-value">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Value
                </Button>
              </div>

              <FormField
                control={form.control}
                name="valuesTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-values-title">Values Title</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-values-title" />
                    </FormControl>
                    <FormMessage data-testid="error-values-title" />
                  </FormItem>
                )}
              />

              {form.watch("values")?.map((_, index) => (
                <Card key={index} data-testid={`card-value-${index}`}>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium" data-testid={`heading-value-${index}`}>Value {index + 1}</h4>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeValue(index)}
                          data-testid={`button-remove-value-${index}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <FormField
                        control={form.control}
                        name={`values.${index}.icon`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel data-testid={`label-value-icon-${index}`}>Icon</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid={`select-value-icon-${index}`}>
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {ABOUT_ICONS.map((icon) => (
                                  <SelectItem key={icon} value={icon} data-testid={`option-value-icon-${index}-${icon}`}>
                                    {icon}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage data-testid={`error-value-icon-${index}`} />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name={`values.${index}.title`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel data-testid={`label-value-title-${index}`}>Title</FormLabel>
                            <FormControl>
                              <Input {...field} data-testid={`input-value-title-${index}`} />
                            </FormControl>
                            <FormMessage data-testid={`error-value-title-${index}`} />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name={`values.${index}.description`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel data-testid={`label-value-description-${index}`}>Description</FormLabel>
                            <FormControl>
                              <Textarea {...field} data-testid={`input-value-description-${index}`} rows={2} />
                            </FormControl>
                            <FormMessage data-testid={`error-value-description-${index}`} />
                          </FormItem>
                        )}
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium" data-testid="heading-cta-section">CTA Section</h3>
              
              <FormField
                control={form.control}
                name="ctaTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-cta-title">CTA Title</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-cta-title" />
                    </FormControl>
                    <FormMessage data-testid="error-cta-title" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="ctaButton"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-cta-button">CTA Button Text</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-cta-button" />
                    </FormControl>
                    <FormMessage data-testid="error-cta-button" />
                  </FormItem>
                )}
              />
            </div>

            <Button type="submit" disabled={isPending} data-testid="button-save-about">
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" data-testid="spinner-saving" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Changes
                </>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function FeaturesPageForm() {
  const { toast } = useToast();
  const { data: content, isLoading } = useQuery<FeaturesPageContent>({
    queryKey: ["/api/marketing-pages", "features"],
  });

  const form = useForm<FeaturesPageContent>({
    resolver: zodResolver(featuresPageContentSchema),
    defaultValues: content || {
      heroTitle: "",
      heroSubtitle: "",
      features: [],
      ctaTitle: "",
      ctaSubtitle: "",
      ctaPrimaryButton: "",
      ctaSecondaryButton: "",
    },
  });

  const { mutate: updateContent, isPending } = useMutation({
    mutationFn: async (data: FeaturesPageContent) => {
      return await apiRequest("PUT", "/api/admin/marketing-pages/features", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/marketing-pages", "features"] });
      toast({
        title: "Success",
        description: "Features page content updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update content",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (content) {
      form.reset(content);
    }
  }, [content, form]);

  if (isLoading) {
    return (
      <Card data-testid="loading-state">
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin" data-testid="spinner-loading" />
        </CardContent>
      </Card>
    );
  }

  const onSubmit = (data: FeaturesPageContent) => {
    updateContent(data);
  };

  const addFeature = () => {
    const currentFeatures = form.getValues("features") || [];
    form.setValue("features", [...currentFeatures, { icon: "MessageSquare", title: "", description: "" }]);
  };

  const removeFeature = (index: number) => {
    const currentFeatures = form.getValues("features") || [];
    form.setValue("features", currentFeatures.filter((_, i) => i !== index));
  };

  return (
    <Card data-testid="card-features-form">
      <CardHeader>
        <CardTitle data-testid="title-features-form">Features Page Content</CardTitle>
        <CardDescription data-testid="description-features-form">
          Edit the content for the Features page
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-medium" data-testid="heading-hero-section">Hero Section</h3>
              
              <FormField
                control={form.control}
                name="heroTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-hero-title">Hero Title</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-hero-title" />
                    </FormControl>
                    <FormMessage data-testid="error-hero-title" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="heroSubtitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-hero-subtitle">Hero Subtitle</FormLabel>
                    <FormControl>
                      <Textarea {...field} data-testid="input-hero-subtitle" rows={3} />
                    </FormControl>
                    <FormMessage data-testid="error-hero-subtitle" />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium" data-testid="heading-features-section">Features</h3>
                <Button type="button" onClick={addFeature} size="sm" data-testid="button-add-feature">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Feature
                </Button>
              </div>

              {form.watch("features")?.map((_, index) => (
                <Card key={index} data-testid={`card-feature-${index}`}>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium" data-testid={`heading-feature-${index}`}>Feature {index + 1}</h4>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeFeature(index)}
                          data-testid={`button-remove-feature-${index}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <FormField
                        control={form.control}
                        name={`features.${index}.icon`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel data-testid={`label-feature-icon-${index}`}>Icon</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid={`select-feature-icon-${index}`}>
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {FEATURES_ICONS.map((icon) => (
                                  <SelectItem key={icon} value={icon} data-testid={`option-feature-icon-${index}-${icon}`}>
                                    {icon}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage data-testid={`error-feature-icon-${index}`} />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name={`features.${index}.title`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel data-testid={`label-feature-title-${index}`}>Title</FormLabel>
                            <FormControl>
                              <Input {...field} data-testid={`input-feature-title-${index}`} />
                            </FormControl>
                            <FormMessage data-testid={`error-feature-title-${index}`} />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name={`features.${index}.description`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel data-testid={`label-feature-description-${index}`}>Description</FormLabel>
                            <FormControl>
                              <Textarea {...field} data-testid={`input-feature-description-${index}`} rows={3} />
                            </FormControl>
                            <FormMessage data-testid={`error-feature-description-${index}`} />
                          </FormItem>
                        )}
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium" data-testid="heading-cta-section">CTA Section</h3>
              
              <FormField
                control={form.control}
                name="ctaTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-cta-title">CTA Title</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-cta-title" />
                    </FormControl>
                    <FormMessage data-testid="error-cta-title" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="ctaSubtitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-cta-subtitle">CTA Subtitle</FormLabel>
                    <FormControl>
                      <Textarea {...field} data-testid="input-cta-subtitle" rows={2} />
                    </FormControl>
                    <FormMessage data-testid="error-cta-subtitle" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="ctaPrimaryButton"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-cta-primary-button">Primary Button Text</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-cta-primary-button" />
                    </FormControl>
                    <FormMessage data-testid="error-cta-primary-button" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="ctaSecondaryButton"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-cta-secondary-button">Secondary Button Text</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-cta-secondary-button" />
                    </FormControl>
                    <FormMessage data-testid="error-cta-secondary-button" />
                  </FormItem>
                )}
              />
            </div>

            <Button type="submit" disabled={isPending} data-testid="button-save-features">
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" data-testid="spinner-saving" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Changes
                </>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function PricingPageForm() {
  const { toast } = useToast();
  const { data: content, isLoading } = useQuery<PricingPageContent>({
    queryKey: ["/api/marketing-pages", "pricing"],
  });

  const form = useForm<PricingPageContent>({
    resolver: zodResolver(pricingPageContentSchema),
    defaultValues: {
      heroTitle: content?.heroTitle || "",
      heroSubtitle: content?.heroSubtitle || "",
      plans: content?.plans || [],
    },
  });

  const { mutate: updateContent, isPending } = useMutation({
    mutationFn: async (data: PricingPageContent) => {
      return await apiRequest("PUT", "/api/admin/marketing-pages/pricing", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/marketing-pages", "pricing"] });
      toast({
        title: "Success",
        description: "Pricing page hero section updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update content",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (content) {
      form.reset({
        heroTitle: content.heroTitle,
        heroSubtitle: content.heroSubtitle,
        plans: content.plans || [],
      });
    }
  }, [content, form]);

  if (isLoading) {
    return (
      <Card data-testid="loading-state">
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin" data-testid="spinner-loading" />
        </CardContent>
      </Card>
    );
  }

  const onSubmit = (data: PricingPageContent) => {
    updateContent(data);
  };

  return (
    <Card data-testid="card-pricing-form">
      <CardHeader>
        <CardTitle data-testid="title-pricing-form">Pricing Page Content</CardTitle>
        <CardDescription data-testid="description-pricing-form">
          Pricing plans are managed via Membership Tiers. Edit the hero section here.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-medium" data-testid="heading-hero-section">Hero Section</h3>
              
              <FormField
                control={form.control}
                name="heroTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-hero-title">Hero Title</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-hero-title" placeholder="Simple, Transparent Pricing" />
                    </FormControl>
                    <FormMessage data-testid="error-hero-title" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="heroSubtitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-hero-subtitle">Hero Subtitle</FormLabel>
                    <FormControl>
                      <Textarea {...field} data-testid="input-hero-subtitle" rows={3} placeholder="Choose the plan that's right for your team." />
                    </FormControl>
                    <FormMessage data-testid="error-hero-subtitle" />
                  </FormItem>
                )}
              />
            </div>

            <Button type="submit" disabled={isPending} data-testid="button-save-pricing">
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" data-testid="spinner-saving" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Hero Section
                </>
              )}
            </Button>
          </form>
        </Form>

        <div className="rounded-lg border p-6 space-y-4 bg-muted/50" data-testid="info-pricing-integration">
          <div className="space-y-2">
            <h3 className="text-lg font-semibold">Pricing Plans Management</h3>
            <p className="text-sm text-muted-foreground">
              Pricing plans are now directly integrated with your <strong>Membership Tiers</strong>. The pricing page automatically displays your active membership tiers with their configured prices, features, and limits.
            </p>
          </div>
          
          <div className="space-y-2">
            <h3 className="text-lg font-semibold">How to Update Pricing Plans</h3>
            <ol className="list-decimal list-inside text-sm text-muted-foreground space-y-1 ml-2">
              <li>Navigate to <strong>Admin Center</strong> → <strong>Settings</strong></li>
              <li>Scroll to the <strong>Membership Tiers</strong> section</li>
              <li>Create, edit, or configure your tiers</li>
              <li>Changes will automatically appear on the public pricing page</li>
            </ol>
          </div>

          <div className="flex justify-center pt-2">
            <Link href="/admin/settings" data-testid="link-manage-tiers">
              <Button variant="outline" data-testid="button-manage-tiers">
                Manage Membership Tiers
              </Button>
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ContactPageForm() {
  const { toast } = useToast();
  const { data: content, isLoading } = useQuery<ContactPageContent>({
    queryKey: ["/api/marketing-pages", "contact"],
  });

  const form = useForm<ContactPageContent>({
    resolver: zodResolver(contactPageContentSchema),
    defaultValues: content || {
      heroTitle: "",
      heroSubtitle: "",
      supportEmail: "",
      supportEmailLabel: "",
      supportEmailDescription: "",
      salesEmail: "",
      salesEmailLabel: "",
      salesEmailDescription: "",
      phone: "",
      phoneLabel: "",
      phoneDescription: "",
      formTitle: "",
      formDescription: "",
      formSuccessTitle: "",
      formSuccessMessage: "",
    },
  });

  const { mutate: updateContent, isPending } = useMutation({
    mutationFn: async (data: ContactPageContent) => {
      return await apiRequest("PUT", "/api/admin/marketing-pages/contact", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/marketing-pages", "contact"] });
      toast({
        title: "Success",
        description: "Contact page content updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update content",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (content) {
      form.reset(content);
    }
  }, [content, form]);

  if (isLoading) {
    return (
      <Card data-testid="loading-state">
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin" data-testid="spinner-loading" />
        </CardContent>
      </Card>
    );
  }

  const onSubmit = (data: ContactPageContent) => {
    updateContent(data);
  };

  return (
    <Card data-testid="card-contact-form">
      <CardHeader>
        <CardTitle data-testid="title-contact-form">Contact Page Content</CardTitle>
        <CardDescription data-testid="description-contact-form">
          Edit the content for the Contact page
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-medium" data-testid="heading-hero-section">Hero Section</h3>
              
              <FormField
                control={form.control}
                name="heroTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-hero-title">Hero Title</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-hero-title" />
                    </FormControl>
                    <FormMessage data-testid="error-hero-title" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="heroSubtitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-hero-subtitle">Hero Subtitle</FormLabel>
                    <FormControl>
                      <Textarea {...field} data-testid="input-hero-subtitle" rows={3} />
                    </FormControl>
                    <FormMessage data-testid="error-hero-subtitle" />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium" data-testid="heading-support-email">Support Email</h3>
              
              <FormField
                control={form.control}
                name="supportEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-support-email">Support Email</FormLabel>
                    <FormControl>
                      <Input {...field} type="email" data-testid="input-support-email" />
                    </FormControl>
                    <FormMessage data-testid="error-support-email" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="supportEmailLabel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-support-email-label">Support Email Label</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-support-email-label" />
                    </FormControl>
                    <FormMessage data-testid="error-support-email-label" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="supportEmailDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-support-email-description">Support Email Description</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-support-email-description" />
                    </FormControl>
                    <FormMessage data-testid="error-support-email-description" />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium" data-testid="heading-sales-email">Sales Email</h3>
              
              <FormField
                control={form.control}
                name="salesEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-sales-email">Sales Email</FormLabel>
                    <FormControl>
                      <Input {...field} type="email" data-testid="input-sales-email" />
                    </FormControl>
                    <FormMessage data-testid="error-sales-email" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="salesEmailLabel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-sales-email-label">Sales Email Label</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-sales-email-label" />
                    </FormControl>
                    <FormMessage data-testid="error-sales-email-label" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="salesEmailDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-sales-email-description">Sales Email Description</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-sales-email-description" />
                    </FormControl>
                    <FormMessage data-testid="error-sales-email-description" />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium" data-testid="heading-phone">Phone</h3>
              
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-phone">Phone</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-phone" />
                    </FormControl>
                    <FormMessage data-testid="error-phone" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phoneLabel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-phone-label">Phone Label</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-phone-label" />
                    </FormControl>
                    <FormMessage data-testid="error-phone-label" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phoneDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-phone-description">Phone Description</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-phone-description" />
                    </FormControl>
                    <FormMessage data-testid="error-phone-description" />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium" data-testid="heading-contact-form">Contact Form</h3>
              
              <FormField
                control={form.control}
                name="formTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-form-title">Form Title</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-form-title" />
                    </FormControl>
                    <FormMessage data-testid="error-form-title" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="formDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-form-description">Form Description</FormLabel>
                    <FormControl>
                      <Textarea {...field} data-testid="input-form-description" rows={2} />
                    </FormControl>
                    <FormMessage data-testid="error-form-description" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="formSuccessTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-form-success-title">Success Title</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-form-success-title" />
                    </FormControl>
                    <FormMessage data-testid="error-form-success-title" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="formSuccessMessage"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel data-testid="label-form-success-message">Success Message</FormLabel>
                    <FormControl>
                      <Textarea {...field} data-testid="input-form-success-message" rows={2} />
                    </FormControl>
                    <FormMessage data-testid="error-form-success-message" />
                  </FormItem>
                )}
              />
            </div>

            <Button type="submit" disabled={isPending} data-testid="button-save-contact">
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" data-testid="spinner-saving" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Changes
                </>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArrowLeft, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Link, useLocation, useParams } from "wouter";
import type { Team, Event, CustomField } from "@shared/schema";
import { GooglePlacesAutocomplete } from "@/components/GooglePlacesAutocomplete";
import { useAvailableSports } from "@/hooks/useAvailableSports";

function formatDateTimeLocal(date: Date | string): string {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  return `${year}-${month}-${day}T${hours}:${minutes}`;
}

export default function EditEvent() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { availableSports } = useAvailableSports();
  const [formData, setFormData] = useState({
    teamId: "",
    title: "",
    type: "game",
    sport: "",
    datetime: "",
    location: "",
    opponent: "",
    homeAway: "",
    fieldType: "",
    cleatsAllowed: "",
    jersey: "",
    arrivalTime: "",
    notes: "",
  });
  const [customFieldValues, setCustomFieldValues] = useState<Record<string, string>>({});
  const [isInitialized, setIsInitialized] = useState(false);

  const { data: event, isLoading: eventLoading } = useQuery<Event>({
    queryKey: ["/api/events", id],
    enabled: !!id,
  });

  const { data: teams = [] } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  const { data: locations = [] } = useQuery<string[]>({
    queryKey: ["/api/events/locations"],
  });

  const { data: customFields = [] } = useQuery<CustomField[]>({
    queryKey: ["/api/admin/custom-fields"],
  });

  useEffect(() => {
    if (event && !isInitialized) {
      setFormData({
        teamId: event.teamId,
        title: event.title,
        type: event.type,
        sport: event.sport,
        datetime: formatDateTimeLocal(event.datetime),
        location: event.location,
        opponent: event.opponent || "",
        homeAway: event.homeAway || "",
        fieldType: event.fieldType || "",
        cleatsAllowed: event.cleatsAllowed || "",
        jersey: event.jersey || "",
        arrivalTime: event.arrivalTime || "",
        notes: event.notes || "",
      });
      if (event.customFieldValues && typeof event.customFieldValues === 'object') {
        setCustomFieldValues(event.customFieldValues as Record<string, string>);
      }
      setIsInitialized(true);
    }
  }, [event, isInitialized]);

  const updateEventMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const eventData = {
        ...data,
        datetime: new Date(data.datetime).toISOString(),
        opponent: data.opponent || null,
        homeAway: data.homeAway || null,
        fieldType: data.fieldType || null,
        cleatsAllowed: data.cleatsAllowed || null,
        jersey: data.jersey || null,
        arrivalTime: data.arrivalTime || null,
        notes: data.notes || null,
        customFieldValues: Object.keys(customFieldValues).length > 0 ? customFieldValues : null,
      };
      const response = await apiRequest("PATCH", `/api/events/${id}`, eventData);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      queryClient.invalidateQueries({ queryKey: ["/api/events", id] });
      queryClient.invalidateQueries({ queryKey: ["/api/events/locations"] });
      toast({
        title: "Event updated",
        description: "Your event has been updated successfully.",
      });
      setLocation(`/events/${id}`);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update event. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.teamId || !formData.title || !formData.sport || !formData.datetime || !formData.location) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields (Team, Title, Sport, Date & Time, Location).",
        variant: "destructive",
      });
      return;
    }
    
    const dateObj = new Date(formData.datetime);
    if (isNaN(dateObj.getTime())) {
      toast({
        title: "Invalid Date",
        description: "Please enter a valid date and time.",
        variant: "destructive",
      });
      return;
    }
    
    updateEventMutation.mutate(formData);
  };

  if (eventLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!event) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/events">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="font-semibold tracking-tight">Event Not Found</h1>
            <p className="text-muted-foreground text-sm">
              The event you're looking for doesn't exist.
            </p>
          </div>
        </div>
      </div>
    );
  }

  const hasCustomFields = event.customFieldValues && Object.keys(event.customFieldValues).length > 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href={`/events/${id}`}>
          <Button variant="ghost" size="icon" data-testid="button-back">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <div>
          <h1 className="font-semibold tracking-tight">Edit Event</h1>
          <p className="text-muted-foreground text-sm md:text-base">
            Update the event details
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Event Details</CardTitle>
            <CardDescription>
              Update the event information. Fields marked with * are required.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="team">Team *</Label>
                <Select
                  value={formData.teamId}
                  onValueChange={(value) => {
                    setFormData({ ...formData, teamId: value });
                  }}
                  required
                >
                  <SelectTrigger id="team" data-testid="select-team">
                    <SelectValue placeholder="Select a team" />
                  </SelectTrigger>
                  <SelectContent>
                    {teams.map((team) => (
                      <SelectItem key={team.id} value={team.id}>
                        {team.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Event Type *</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value) => {
                    setFormData({ ...formData, type: value });
                  }}
                  required
                >
                  <SelectTrigger id="type" data-testid="select-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="game">Game</SelectItem>
                    <SelectItem value="practice">Practice</SelectItem>
                    <SelectItem value="team_party">Team Party</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="sport">Sport *</Label>
                <Select
                  value={formData.sport}
                  onValueChange={(value) => {
                    setFormData({ ...formData, sport: value });
                  }}
                  required
                >
                  <SelectTrigger id="sport" data-testid="select-sport">
                    <SelectValue placeholder="Select a sport" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableSports.map((sport) => (
                      <SelectItem key={sport} value={sport}>
                        {sport}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">Event Title *</Label>
              <Input
                id="title"
                placeholder="Event title..."
                value={formData.title}
                onChange={(e) => {
                  setFormData({ ...formData, title: e.target.value });
                }}
                data-testid="input-title"
                required
              />
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="datetime">Date & Time *</Label>
                <Input
                  id="datetime"
                  type="datetime-local"
                  value={formData.datetime}
                  onChange={(e) => setFormData({ ...formData, datetime: e.target.value })}
                  data-testid="input-datetime"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Location *</Label>
                <GooglePlacesAutocomplete
                  value={formData.location}
                  onChange={(value) => {
                    setFormData({ ...formData, location: value });
                  }}
                  placeholder="Search address or venue name..."
                  previousLocations={locations}
                  data-testid="input-location"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="opponent">Opponent</Label>
                <Input
                  id="opponent"
                  placeholder="Team name"
                  value={formData.opponent}
                  onChange={(e) => {
                    setFormData({ ...formData, opponent: e.target.value });
                  }}
                  data-testid="input-opponent"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="homeAway">Home/Away</Label>
                <Select
                  value={formData.homeAway}
                  onValueChange={(value) => setFormData({ ...formData, homeAway: value })}
                >
                  <SelectTrigger id="homeAway" data-testid="select-home-away">
                    <SelectValue placeholder="Select..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="home">Home</SelectItem>
                    <SelectItem value="away">Away</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="fieldType">Field Type</Label>
                <Select
                  value={formData.fieldType}
                  onValueChange={(value) => setFormData({ ...formData, fieldType: value })}
                >
                  <SelectTrigger id="fieldType" data-testid="select-field-type">
                    <SelectValue placeholder="Select..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="grass">Grass</SelectItem>
                    <SelectItem value="turf">Turf</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="cleatsAllowed">Cleats Allowed</Label>
                <Select
                  value={formData.cleatsAllowed}
                  onValueChange={(value) => setFormData({ ...formData, cleatsAllowed: value })}
                >
                  <SelectTrigger id="cleatsAllowed" data-testid="select-cleats">
                    <SelectValue placeholder="Select..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any</SelectItem>
                    <SelectItem value="non-metal">Non-Metal Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="jersey">Jersey Color/Type</Label>
                <Input
                  id="jersey"
                  placeholder="e.g., Blue home jersey"
                  value={formData.jersey}
                  onChange={(e) => setFormData({ ...formData, jersey: e.target.value })}
                  data-testid="input-jersey"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="arrivalTime">Arrival Time</Label>
                <Input
                  id="arrivalTime"
                  placeholder="e.g., 30 minutes before"
                  value={formData.arrivalTime}
                  onChange={(e) => setFormData({ ...formData, arrivalTime: e.target.value })}
                  data-testid="input-arrival-time"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                placeholder="Additional information for players..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                data-testid="input-notes"
              />
            </div>

            {hasCustomFields && (
              <div className="border-t pt-6 mt-6">
                <h3 className="text-lg font-medium mb-4">Custom Fields</h3>
                <div className="grid gap-6 md:grid-cols-2">
                  {Object.keys(event.customFieldValues as Record<string, string>)
                    .map((fieldId: string) => customFields.find(f => f.id === fieldId))
                    .filter((field): field is CustomField => field !== undefined)
                    .map((field) => (
                      <div key={field.id} className="space-y-2">
                        <Label htmlFor={`custom-field-${field.id}`}>{field.name}</Label>
                        {field.fieldType === "text" && (
                          <Input
                            id={`custom-field-${field.id}`}
                            data-testid={`input-custom-field-${field.id}`}
                            placeholder={field.placeholder || ""}
                            value={customFieldValues[field.id] || ""}
                            onChange={(e) => setCustomFieldValues({ ...customFieldValues, [field.id]: e.target.value })}
                          />
                        )}
                        {field.fieldType === "textarea" && (
                          <Textarea
                            id={`custom-field-${field.id}`}
                            data-testid={`input-custom-field-${field.id}`}
                            placeholder={field.placeholder || ""}
                            value={customFieldValues[field.id] || ""}
                            onChange={(e) => setCustomFieldValues({ ...customFieldValues, [field.id]: e.target.value })}
                            rows={3}
                          />
                        )}
                        {field.fieldType === "number" && (
                          <Input
                            id={`custom-field-${field.id}`}
                            data-testid={`input-custom-field-${field.id}`}
                            type="number"
                            placeholder={field.placeholder || ""}
                            value={customFieldValues[field.id] || ""}
                            onChange={(e) => setCustomFieldValues({ ...customFieldValues, [field.id]: e.target.value })}
                          />
                        )}
                        {field.fieldType === "select" && field.options && (
                          <Select
                            value={customFieldValues[field.id] || ""}
                            onValueChange={(value) => setCustomFieldValues({ ...customFieldValues, [field.id]: value })}
                          >
                            <SelectTrigger id={`custom-field-${field.id}`} data-testid={`select-custom-field-${field.id}`}>
                              <SelectValue placeholder={field.placeholder || "Select an option"} />
                            </SelectTrigger>
                            <SelectContent>
                              {field.options.map((option: string) => (
                                <SelectItem key={option} value={option}>
                                  {option}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            )}

            <div className="flex gap-4 pt-4">
              <Link href={`/events/${id}`} className="flex-1 md:flex-initial">
                <Button
                  type="button"
                  variant="outline"
                  className="w-full md:w-auto"
                  data-testid="button-cancel"
                >
                  Cancel
                </Button>
              </Link>
              <Button
                type="submit"
                className="flex-1 md:flex-initial"
                disabled={updateEventMutation.isPending}
                data-testid="button-submit"
              >
                {updateEventMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}

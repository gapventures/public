import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Target, Heart, Zap } from "lucide-react";
import { useAppName } from "@/hooks/useAppName";
import { useOrganizationLogo } from "@/hooks/useOrganizationLogo";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import type { AboutPageContent } from "@shared/schema";
import { MarketingFooter } from "@/components/marketing-footer";

const defaultContent: AboutPageContent = {
  heroTitle: "About {appName}",
  heroSubtitle: "Built for coaches, by coaches. We understand the challenges of managing amateur sports teams.",
  missionTitle: "Our Mission",
  missionText: "Managing a sports team shouldn't feel like a full-time job. {appName} was born to automate the tedious parts of team management, giving coaches their time back. Using AI-powered SMS communication, automated reminders, and smart attendance tracking, we help teams stay organized and coaches stay focused on the game.",
  valuesTitle: "Our Values",
  values: [
    {
      icon: "Target",
      title: "Purpose-Built",
      description: "Unlike generic team management tools, we're purpose-built for amateur sports. Our AI understands natural language responses and tracks player reliability automatically."
    },
    {
      icon: "Heart",
      title: "Coach-First",
      description: "We believe in simplicity and putting coaches first. Every feature we build is designed to save time and reduce stress, helping amateur sports thrive."
    },
    {
      icon: "Users",
      title: "Growing Community",
      description: "Hundreds of coaches across the country are already using {appName} to manage their teams, from youth soccer to adult softball leagues."
    }
  ],
  ctaTitle: "Ready to get started?",
  ctaButton: "Get Started Today"
};

const iconMap = {
  Target,
  Heart,
  Zap,
  Users,
};

export default function About() {
  const appName = useAppName();
  const logoUrl = useOrganizationLogo();
  
  const { data: content, isLoading, isError } = useQuery<AboutPageContent>({
    queryKey: ["/api/marketing-pages/about"],
  });

  const pageContent = content || defaultContent;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center" data-testid="loading-state">
          <div className="text-lg text-muted-foreground">Loading...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-3 md:py-4 flex justify-between items-center gap-2">
          <Link href="/" data-testid="link-home-logo">
            <div className="flex items-center gap-2 md:gap-3 cursor-pointer hover-elevate rounded-md p-2 -m-2 min-w-0">
              {logoUrl ? (
                <img 
                  src={logoUrl} 
                  alt="Logo" 
                  className="h-8 md:h-10 w-auto object-contain flex-shrink-0"
                  data-testid="img-header-logo"
                />
              ) : (
                <Users className="h-5 md:h-6 w-5 md:w-6 text-primary flex-shrink-0" />
              )}
              <span className="hidden sm:block text-lg md:text-xl font-bold truncate">{appName}</span>
            </div>
          </Link>
          <nav className="flex items-center gap-1 md:gap-4 flex-shrink-0">
            <Link 
              href="/about" 
              className="hidden md:inline-flex text-sm font-medium hover-elevate rounded-md px-3 py-2" 
              data-testid="link-about"
            >
              About
            </Link>
            <Link 
              href="/features" 
              className="hidden md:inline-flex text-sm font-medium hover-elevate rounded-md px-3 py-2" 
              data-testid="link-features"
            >
              Features
            </Link>
            <Link 
              href="/pricing" 
              className="text-xs md:text-sm font-medium hover-elevate rounded-md px-2 md:px-3 py-2" 
              data-testid="link-pricing"
            >
              Pricing
            </Link>
            <Link 
              href="/contact" 
              className="text-xs md:text-sm font-medium hover-elevate rounded-md px-2 md:px-3 py-2" 
              data-testid="link-contact"
            >
              Contact
            </Link>
            <Link href="/login">
              <Button size="sm" data-testid="button-login">Log In</Button>
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="container mx-auto px-4 py-8 md:py-16 landscape:py-6" data-testid="section-about-hero">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8 landscape:mb-6">
              <h1 className="text-3xl md:text-4xl lg:text-5xl landscape:text-3xl font-bold mb-4 landscape:mb-3" data-testid="text-heading">
                {pageContent.heroTitle.replace('{appName}', appName)}
              </h1>
              <p className="text-lg md:text-xl landscape:text-base text-muted-foreground" data-testid="text-subheading">
                {pageContent.heroSubtitle}
              </p>
            </div>

            <div className="mb-8 landscape:mb-6">
              <h2 className="text-2xl md:text-3xl landscape:text-2xl font-bold mb-3 landscape:mb-2 text-center">{pageContent.missionTitle}</h2>
              <p className="text-base md:text-lg landscape:text-base text-muted-foreground text-center" data-testid="text-mission-description">
                {pageContent.missionText.replace('{appName}', appName)}
              </p>
            </div>

            <h3 className="text-xl md:text-2xl landscape:text-xl font-bold mb-4 landscape:mb-3 text-center">{pageContent.valuesTitle}</h3>
            <div className="grid md:grid-cols-3 gap-6 mb-8 landscape:mb-6">
              {pageContent.values.map((value, index) => {
                const IconComponent = iconMap[value.icon as keyof typeof iconMap];
                return (
                  <Card key={index} data-testid={`card-value-${index}`}>
                    <CardHeader>
                      <IconComponent className="h-8 w-8 mb-2 text-primary" />
                      <CardTitle data-testid={`card-value-title-${index}`}>{value.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription data-testid={`card-value-description-${index}`}>
                        {value.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <div className="text-center">
              <h2 className="text-3xl font-bold mb-4" data-testid="text-cta-heading">
                {pageContent.ctaTitle}
              </h2>
              <Link href="/login">
                <Button size="lg" data-testid="button-get-started">
                  {pageContent.ctaButton}
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      <MarketingFooter />
    </div>
  );
}

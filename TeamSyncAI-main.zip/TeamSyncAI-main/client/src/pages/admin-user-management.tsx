import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, ShieldOff, User, Pencil, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useState } from "react";

interface AdminUser {
  id: string;
  email: string;
  firstName: string | null;
  lastName: string | null;
  isGlobalAdmin: boolean;
  createdAt: string;
  teamCount?: number;
  isTeamOwner?: boolean;
}

export default function AdminUserManagement() {
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  const [userToToggle, setUserToToggle] = useState<AdminUser | null>(null);
  const [userToDelete, setUserToDelete] = useState<AdminUser | null>(null);
  const [userToEdit, setUserToEdit] = useState<AdminUser | null>(null);
  const [editForm, setEditForm] = useState({ firstName: "", lastName: "", email: "" });

  const { data: users, isLoading } = useQuery<AdminUser[]>({
    queryKey: ["/api/admin/users"],
  });

  const toggleAdminMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("PATCH", `/api/admin/users/${userId}/toggle-admin`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Success",
        description: "Admin status updated successfully",
      });
      setUserToToggle(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update admin status",
        variant: "destructive",
      });
      setUserToToggle(null);
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("DELETE", `/api/admin/users/${userId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Success",
        description: "User deleted successfully",
      });
      setUserToDelete(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete user",
        variant: "destructive",
      });
      setUserToDelete(null);
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: async ({ userId, data }: { userId: string; data: { firstName: string; lastName: string; email: string } }) => {
      return await apiRequest("PATCH", `/api/admin/users/${userId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Success",
        description: "User updated successfully",
      });
      setUserToEdit(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update user",
        variant: "destructive",
      });
    },
  });

  const getUserDisplayName = (user: AdminUser) => {
    if (user.firstName && user.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    return user.email;
  };

  const handleToggleClick = (user: AdminUser) => {
    setUserToToggle(user);
  };

  const handleConfirmToggle = () => {
    if (userToToggle) {
      toggleAdminMutation.mutate(userToToggle.id);
    }
  };

  const handleDeleteClick = (user: AdminUser) => {
    setUserToDelete(user);
  };

  const handleConfirmDelete = () => {
    if (userToDelete) {
      deleteUserMutation.mutate(userToDelete.id);
    }
  };

  const handleEditClick = (user: AdminUser) => {
    setUserToEdit(user);
    setEditForm({
      firstName: user.firstName || "",
      lastName: user.lastName || "",
      email: user.email,
    });
  };

  const handleSaveEdit = () => {
    if (userToEdit) {
      updateUserMutation.mutate({
        userId: userToEdit.id,
        data: editForm,
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-muted-foreground">Loading users...</div>
      </div>
    );
  }

  const adminUsers = users?.filter(u => u.isGlobalAdmin) || [];
  const regularUsers = users?.filter(u => !u.isGlobalAdmin) || [];

  const renderUserRow = (user: AdminUser, isAdmin: boolean) => (
    <div
      key={user.id}
      className="flex items-center justify-between p-3 rounded-md border"
      data-testid={`${isAdmin ? "admin" : "regular"}-user-${user.id}`}
    >
      <div className="flex items-center gap-3">
        <div className={`flex h-10 w-10 items-center justify-center rounded-full ${isAdmin ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>
          <User className="h-5 w-5" />
        </div>
        <div>
          <div className="font-medium" data-testid={`text-user-name-${user.id}`}>
            {getUserDisplayName(user)}
          </div>
          <div className="text-sm text-muted-foreground">
            {user.email}
          </div>
          {user.isTeamOwner && (
            <div className="text-xs text-muted-foreground">
              Owns {user.teamCount} team{user.teamCount !== 1 ? "s" : ""}
            </div>
          )}
        </div>
      </div>
      <div className="flex items-center gap-2">
        {isAdmin && (
          <Badge variant="default" data-testid={`badge-admin-${user.id}`}>
            Admin
          </Badge>
        )}
        {user.id === currentUser?.id ? (
          <span className="text-sm text-muted-foreground">(You)</span>
        ) : (
          <>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleEditClick(user)}
              data-testid={`button-edit-user-${user.id}`}
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleDeleteClick(user)}
              disabled={deleteUserMutation.isPending}
              data-testid={`button-delete-user-${user.id}`}
            >
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
            {isAdmin ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleToggleClick(user)}
                disabled={toggleAdminMutation.isPending}
                data-testid={`button-remove-admin-${user.id}`}
              >
                <ShieldOff className="h-4 w-4 mr-1" />
                Remove Admin
              </Button>
            ) : (
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleToggleClick(user)}
                disabled={toggleAdminMutation.isPending}
                data-testid={`button-make-admin-${user.id}`}
              >
                <Shield className="h-4 w-4 mr-1" />
                Make Admin
              </Button>
            )}
          </>
        )}
      </div>
    </div>
  );

  return (
    <div className="container mx-auto max-w-5xl py-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">User Management</h1>
        <p className="text-muted-foreground">
          Manage users, edit their information, or remove them from the platform
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Global Administrators
          </CardTitle>
          <CardDescription>
            Users with full administrative access to the platform
          </CardDescription>
        </CardHeader>
        <CardContent>
          {adminUsers.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No global administrators found
            </div>
          ) : (
            <div className="space-y-3">
              {adminUsers.map((user) => renderUserRow(user, true))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Regular Users
          </CardTitle>
          <CardDescription>
            Standard users without administrative privileges
          </CardDescription>
        </CardHeader>
        <CardContent>
          {regularUsers.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No regular users found
            </div>
          ) : (
            <div className="space-y-3">
              {regularUsers.map((user) => renderUserRow(user, false))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Toggle Admin Dialog */}
      {userToToggle && (
        <AlertDialog open={true} onOpenChange={() => setUserToToggle(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>
                {userToToggle.isGlobalAdmin ? "Remove Administrator" : "Grant Administrator"}
              </AlertDialogTitle>
              <AlertDialogDescription>
                {userToToggle.isGlobalAdmin ? (
                  <>
                    Are you sure you want to remove admin privileges from{" "}
                    <strong>{getUserDisplayName(userToToggle)}</strong>? They will no longer
                    have access to administrative features.
                  </>
                ) : (
                  <>
                    Are you sure you want to grant admin privileges to{" "}
                    <strong>{getUserDisplayName(userToToggle)}</strong>? They will have full
                    access to all administrative features.
                  </>
                )}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel data-testid="button-cancel-toggle">Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleConfirmToggle}
                data-testid="button-confirm-toggle"
              >
                Confirm
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}

      {/* Delete User Dialog */}
      {userToDelete && (
        <AlertDialog open={true} onOpenChange={() => setUserToDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete User</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to permanently delete{" "}
                <strong>{getUserDisplayName(userToDelete)}</strong>? This action cannot be undone.
                {userToDelete.isTeamOwner && (
                  <span className="block mt-2 text-destructive">
                    Warning: This user owns {userToDelete.teamCount} team(s). You must transfer or delete their teams first.
                  </span>
                )}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleConfirmDelete}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                data-testid="button-confirm-delete"
              >
                Delete User
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}

      {/* Edit User Dialog */}
      {userToEdit && (
        <Dialog open={true} onOpenChange={() => setUserToEdit(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit User</DialogTitle>
              <DialogDescription>
                Update user information for {getUserDisplayName(userToEdit)}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  value={editForm.firstName}
                  onChange={(e) => setEditForm({ ...editForm, firstName: e.target.value })}
                  data-testid="input-edit-first-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  value={editForm.lastName}
                  onChange={(e) => setEditForm({ ...editForm, lastName: e.target.value })}
                  data-testid="input-edit-last-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={editForm.email}
                  onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                  data-testid="input-edit-email"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setUserToEdit(null)} data-testid="button-cancel-edit">
                Cancel
              </Button>
              <Button 
                onClick={handleSaveEdit} 
                disabled={updateUserMutation.isPending}
                data-testid="button-save-edit"
              >
                {updateUserMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

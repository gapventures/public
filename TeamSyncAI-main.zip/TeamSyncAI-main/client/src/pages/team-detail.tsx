import { useState, useRef, useCallback } from "react";
import { useParams, Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArrowLeft, Plus, Trash2, Edit, Upload, Download, Calendar, Copy, Check, Mail, DollarSign, Smartphone } from "lucide-react";
import Papa from "papaparse";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { UploadThingUploader } from "@/components/UploadThingUploader";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { usePermissions } from "@/hooks/usePermissions";
import type { Team, Player, Role, TeamDocument, DocumentSignature, Invitation } from "@shared/schema";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { FileText, Archive, ExternalLink, Send, RefreshCw, X, Clock, CheckCircle2, XCircle, ChevronDown, ChevronUp } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ImportContactsDialog } from "@/components/ImportContactsDialog";
import { autoFormatPhoneInput } from "@shared/phoneUtils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TeamSMSPhoneNumber } from "@/components/TeamSMSPhoneNumber";
import { TeamUsageBilling } from "@/components/TeamUsageBilling";

interface SignatureWithUser extends DocumentSignature {
  userFirstName: string | null;
  userLastName: string | null;
  userEmail: string | null;
}

export default function TeamDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isCalendarDialogOpen, setIsCalendarDialogOpen] = useState(false);
  const [isDocumentDialogOpen, setIsDocumentDialogOpen] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState<Player | null>(null);
  const [playerForm, setPlayerForm] = useState({
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    dateOfBirth: "",
    position: "",
    jerseyNumber: "",
    reliabilityScore: 3,
    roleId: "",
    sendInvitation: false,
    preferredBattingOrder: "",
    preferredPitchingOrder: "",
  });
  const [documentForm, setDocumentForm] = useState({
    title: "",
    description: "",
    fileUrl: "",
    requiresSignature: true,
  });
  const [invitationForm, setInvitationForm] = useState({
    contactType: "phone" as "phone" | "email",
    contactValue: "",
    roleId: "",
  });
  const [expandedDocuments, setExpandedDocuments] = useState<Set<string>>(new Set());
  const [isImportContactsOpen, setIsImportContactsOpen] = useState(false);
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const csvInputRef = useRef<HTMLInputElement>(null);

  const { data: team, isLoading: teamLoading } = useQuery<Team>({
    queryKey: ["/api/teams", id],
  });

  const { data: players = [], isLoading: playersLoading } = useQuery<Player[]>({
    queryKey: ["/api/teams", id, "players"],
  });

  const { data: roles = [] } = useQuery<Role[]>({
    queryKey: ["/api/teams", id, "roles"],
  });

  const permissions = usePermissions(id);

  const { data: documents = [] } = useQuery<TeamDocument[]>({
    queryKey: [`/api/teams/${id}/documents`],
    enabled: permissions.canManageSettings,
  });

  const { data: signatures = [] } = useQuery<SignatureWithUser[]>({
    queryKey: [`/api/teams/${id}/signatures`],
    enabled: permissions.canManageSettings && documents.length > 0,
  });

  const { data: invitations = [] } = useQuery<Invitation[]>({
    queryKey: [`/api/teams/${id}/invitations`],
    enabled: permissions.canManagePlayers,
  });

  const createPlayerMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", `/api/teams/${id}/players`, data);
      return await response.json();
    },
    onSuccess: async (newPlayer: Player) => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", id, "players"] });
      
      let invitationSent = false;
      
      // Send invitation if requested
      if (playerForm.sendInvitation && newPlayer.phone) {
        try {
          const contactType = "phone";
          const contactValue = newPlayer.phone;
          // Use the role from the form, or the player's role, or find the default Player role
          let roleId = playerForm.roleId || newPlayer.roleId;
          
          // If still no role, try to find a default Player role or use any role as fallback
          if (!roleId) {
            const playerRole = roles.find(r => r.name === "Player");
            roleId = playerRole?.id || roles[0]?.id;
          }
          
          if (roleId) {
            const response = await apiRequest("POST", `/api/teams/${id}/invitations`, {
              contactType,
              contactValue,
              roleId,
              sendNotification: true
            });
            
            if (!response.ok) {
              throw new Error("Failed to send invitation");
            }
            
            queryClient.invalidateQueries({ queryKey: [`/api/teams/${id}/invitations`] });
            invitationSent = true;
          } else {
            toast({
              title: "Warning",
              description: "Player added but invitation not sent - no role assigned.",
              variant: "destructive",
            });
          }
        } catch (error) {
          console.error("Failed to send invitation:", error);
          toast({
            title: "Warning",
            description: "Player added but invitation failed to send. You can resend it from the Invitations section.",
            variant: "destructive",
          });
        }
      }
      
      setIsDialogOpen(false);
      resetForm();
      
      // Only show success with invitation message if invitation was actually sent
      if (invitationSent) {
        toast({
          title: "Player added",
          description: "Player has been added and invitation sent.",
        });
      } else if (playerForm.sendInvitation) {
        // Invitation was requested but failed - warning already shown above
        toast({
          title: "Player added",
          description: "Player has been added to the team.",
        });
      } else {
        toast({
          title: "Player added",
          description: "Player has been added to the team.",
        });
      }
    },
  });

  const updatePlayerMutation = useMutation({
    mutationFn: async ({ playerId, data }: { playerId: string; data: Partial<Player> }) => {
      return await apiRequest("PATCH", `/api/players/${playerId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", id, "players"] });
      toast({
        title: "Player updated",
        description: "Player information has been updated.",
      });
    },
  });

  const deletePlayerMutation = useMutation({
    mutationFn: async (playerId: string) => {
      return await apiRequest("DELETE", `/api/players/${playerId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", id, "players"] });
      toast({
        title: "Player removed",
        description: "Player has been removed from the team.",
      });
    },
  });

  const deleteTeamMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("DELETE", `/api/teams/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/teams", id] });
      toast({
        title: "Team deleted",
        description: "Team has been deleted successfully.",
      });
      setLocation("/teams");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete team. Please try again.",
        variant: "destructive",
      });
    },
  });

  const bulkUploadMutation = useMutation({
    mutationFn: async (players: any[]) => {
      return await apiRequest("POST", `/api/teams/${id}/players/bulk`, { players });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", id, "players"] });
      
      if (data.errors && data.errors.length > 0) {
        toast({
          title: "Partial upload",
          description: `${data.created} players created, ${data.errors.length} errors. Check console for details.`,
          variant: "destructive",
        });
        console.error("CSV Upload Errors:", data.errors);
      } else {
        toast({
          title: "Upload successful",
          description: `${data.created} players added to the roster.`,
        });
      }
      
      if (csvInputRef.current) {
        csvInputRef.current.value = "";
      }
    },
    onError: () => {
      toast({
        title: "Upload failed",
        description: "Failed to upload roster. Please check the CSV format.",
        variant: "destructive",
      });
    },
  });

  const sendInvitationsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/teams/${id}/send-invitations`, {});
      return await response.json();
    },
    onSuccess: (data: any) => {
      toast({
        title: "Invitations sent",
        description: `Sent ${data.sent} invitation${data.sent !== 1 ? 's' : ''}${data.failed > 0 ? `, ${data.failed} failed` : ''}.`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send invitations. Please try again.",
        variant: "destructive",
      });
    },
  });

  const uploadTeamLogoMutation = useMutation({
    mutationFn: async (logoUrl: string) => {
      return apiRequest("PUT", `/api/teams/${id}/logo`, { logoUrl });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", id] });
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      toast({
        title: "Logo uploaded",
        description: "Team logo has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to upload logo. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createDocumentMutation = useMutation({
    mutationFn: async (data: typeof documentForm) => {
      return await apiRequest("POST", `/api/teams/${id}/documents`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/teams/${id}/documents`] });
      setIsDocumentDialogOpen(false);
      setDocumentForm({ title: "", description: "", fileUrl: "", requiresSignature: true });
      toast({
        title: "Document added",
        description: "Document has been added to the team.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add document. Please try again.",
        variant: "destructive",
      });
    },
  });

  const archiveDocumentMutation = useMutation({
    mutationFn: async (documentId: string) => {
      return await apiRequest("PATCH", `/api/documents/${documentId}/archive`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/teams/${id}/documents`] });
      toast({
        title: "Document archived",
        description: "Document has been archived successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to archive document. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createInvitationMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", `/api/teams/${id}/invitations`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/teams/${id}/invitations`] });
      setInvitationForm({ contactType: "phone", contactValue: "", roleId: "" });
      toast({
        title: "Invitation sent",
        description: "Invitation has been sent successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send invitation. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resendInvitationMutation = useMutation({
    mutationFn: async (invitationId: string) => {
      return await apiRequest("POST", `/api/invitations/${invitationId}/resend`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/teams/${id}/invitations`] });
      toast({
        title: "Invitation resent",
        description: "Invitation has been resent successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to resend invitation. Please try again.",
        variant: "destructive",
      });
    },
  });

  const cancelInvitationMutation = useMutation({
    mutationFn: async (invitationId: string) => {
      return await apiRequest("PATCH", `/api/invitations/${invitationId}/cancel`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/teams/${id}/invitations`] });
      toast({
        title: "Invitation cancelled",
        description: "Invitation has been cancelled successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to cancel invitation. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleLogoUploadComplete = useCallback((uploadedUrl: string) => {
    uploadTeamLogoMutation.mutate(uploadedUrl);
  }, [uploadTeamLogoMutation]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const csvText = event.target?.result as string;
        const lines = csvText.split("\n").filter((line) => line.trim());
        
        if (lines.length < 2) {
          toast({
            title: "Invalid CSV",
            description: "CSV file must have a header row and at least one data row.",
            variant: "destructive",
          });
          return;
        }

        const headers = lines[0].split(",").map((h) => h.trim());
        const players = [];

        for (let i = 1; i < lines.length; i++) {
          const values = lines[i].split(",").map((v) => v.trim());
          const player: any = {};

          headers.forEach((header, index) => {
            if (header === "reliabilityScore" || header === "jerseyNumber") {
              player[header] = values[index] ? parseFloat(values[index]) : undefined;
            } else {
              player[header] = values[index] || undefined;
            }
          });

          // Only add if we have at least first name, last name, and phone
          if (player.firstName && player.lastName && player.phone) {
            players.push(player);
          }
        }

        if (players.length === 0) {
          toast({
            title: "No valid players",
            description: "CSV must contain valid player data with first name, last name, and phone.",
            variant: "destructive",
          });
          return;
        }

        bulkUploadMutation.mutate(players);
      } catch (error) {
        console.error("Error parsing CSV:", error);
        toast({
          title: "Parse error",
          description: "Failed to parse CSV file. Please check the format.",
          variant: "destructive",
        });
      }
    };

    reader.readAsText(file);
  };

  const resetForm = () => {
    setPlayerForm({ 
      firstName: "", 
      lastName: "", 
      phone: "", 
      email: "",
      dateOfBirth: "",
      position: "",
      jerseyNumber: "",
      reliabilityScore: 3,
      roleId: "",
      sendInvitation: false,
      preferredBattingOrder: "",
      preferredPitchingOrder: "",
    });
    setEditingPlayer(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const submitData = {
      ...playerForm,
      jerseyNumber: playerForm.jerseyNumber ? parseInt(playerForm.jerseyNumber) : undefined,
      email: playerForm.email || undefined,
      dateOfBirth: playerForm.dateOfBirth || undefined,
      position: playerForm.position || undefined,
      roleId: playerForm.roleId || undefined,
      preferredBattingOrder: playerForm.preferredBattingOrder ? parseInt(playerForm.preferredBattingOrder) : undefined,
      preferredPitchingOrder: playerForm.preferredPitchingOrder ? parseInt(playerForm.preferredPitchingOrder) : undefined,
    };
    
    if (editingPlayer) {
      updatePlayerMutation.mutate({ playerId: editingPlayer.id, data: submitData });
      setIsDialogOpen(false);
      resetForm();
    } else {
      createPlayerMutation.mutate(submitData);
    }
  };

  const openEditDialog = (player: Player) => {
    setEditingPlayer(player);
    setPlayerForm({
      firstName: player.firstName,
      lastName: player.lastName,
      phone: player.phone,
      email: player.email || "",
      dateOfBirth: player.dateOfBirth || "",
      position: player.position || "",
      jerseyNumber: player.jerseyNumber?.toString() || "",
      reliabilityScore: player.reliabilityScore,
      roleId: player.roleId || "",
      sendInvitation: false, // Not applicable for editing
      preferredBattingOrder: player.preferredBattingOrder?.toString() || "",
      preferredPitchingOrder: player.preferredPitchingOrder?.toString() || "",
    });
    setIsDialogOpen(true);
  };

  const handleReliabilityChange = (playerId: string, newScore: number) => {
    updatePlayerMutation.mutate({ playerId, data: { reliabilityScore: newScore } });
  };

  const getInitials = (firstName: string, lastName: string) => {
    const first = String(firstName || '')[0] || '';
    const last = String(lastName || '')[0] || '';
    return (first + last).toUpperCase() || '?';
  };

  const getFullName = (player: Player) => {
    return `${player.firstName} ${player.lastName}`;
  };

  const getReliabilityColor = (score: number) => {
    if (score >= 4) return "bg-green-500";
    if (score >= 3) return "bg-yellow-500";
    return "bg-red-500";
  };

  const parseCSV = (csvText: string): any[] => {
    const parseResult = Papa.parse(csvText, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (header: string) => header.trim(),
    });
    
    if (parseResult.errors.length > 0) {
      console.error("CSV Parse Errors:", parseResult.errors);
    }
    
    const players = [];
    
    for (const row of parseResult.data as any[]) {
      const firstName = row['First']?.trim();
      const lastName = row['Last']?.trim();
      const phone = row['Phone Number']?.trim();
      
      if (!firstName || !lastName || !phone) continue;
      
      players.push({
        firstName,
        lastName,
        phone,
        email: row['Email']?.trim() || undefined,
        dateOfBirth: row['Birthdate']?.trim() || undefined,
        gender: row['Gender']?.trim() || undefined,
        address: row['Address']?.trim() || undefined,
        city: row['City']?.trim() || undefined,
        state: row['State']?.trim() || undefined,
        zip: row['Zip']?.trim() || undefined,
        position: row['Position']?.trim() || undefined,
        jerseyNumber: row['Jersey Number'] ? parseInt(row['Jersey Number']) : undefined,
        contact1Name: row['Contact 1 Name']?.trim() || undefined,
        contact1Phone: row['Contact 1 Phone']?.trim() || undefined,
        contact1Email: row['Contact 1 Email']?.trim() || undefined,
        contact1Address: row['Contact 1 Address']?.trim() || undefined,
        contact2Name: row['Contact 2 Name']?.trim() || undefined,
        contact2Phone: row['Contact 2 Phone']?.trim() || undefined,
        contact2Email: row['Contact 2 Email']?.trim() || undefined,
        contact2Address: row['Contact 2 Address']?.trim() || undefined,
      });
    }
    
    return players;
  };

  const handleCSVUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      const csvText = event.target?.result as string;
      const players = parseCSV(csvText);
      
      if (players.length === 0) {
        toast({
          title: "Error",
          description: "No valid players found in CSV file.",
          variant: "destructive",
        });
        return;
      }
      
      bulkUploadMutation.mutate(players);
    };
    reader.readAsText(file);
  };

  const handleExportCSV = () => {
    window.location.href = `/api/teams/${id}/players/export`;
  };

  const handleDownloadTemplate = () => {
    window.location.href = '/api/teams/csv-template';
  };

  const handleDocumentUploadComplete = useCallback((uploadedUrl: string) => {
    setDocumentForm(prev => ({ ...prev, fileUrl: uploadedUrl }));
    toast({
      title: "Upload successful",
      description: "Document uploaded. Fill in the details below.",
    });
  }, [toast]);

  const handleDocumentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!documentForm.fileUrl) {
      toast({
        title: "Error",
        description: "Please upload a document file first.",
        variant: "destructive",
      });
      return;
    }
    createDocumentMutation.mutate(documentForm);
  };

  const getSignatureCount = (documentId: string) => {
    return signatures.filter(sig => sig.documentId === documentId).length;
  };

  const getDocumentSignatures = (documentId: string) => {
    return signatures.filter(sig => sig.documentId === documentId);
  };

  const toggleDocumentExpanded = (documentId: string) => {
    setExpandedDocuments(prev => {
      const newSet = new Set(prev);
      if (newSet.has(documentId)) {
        newSet.delete(documentId);
      } else {
        newSet.add(documentId);
      }
      return newSet;
    });
  };

  const handleInvitationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!invitationForm.roleId) {
      toast({
        title: "Error",
        description: "Please select a role for the invitation.",
        variant: "destructive",
      });
      return;
    }
    createInvitationMutation.mutate({ ...invitationForm, sendNotification: true });
  };

  const getInvitationStatus = (invitation: Invitation) => {
    // The backend sets status field directly
    return invitation.status;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "accepted":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200"><CheckCircle2 className="h-3 w-3 mr-1" />Accepted</Badge>;
      case "cancelled":
        return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200"><XCircle className="h-3 w-3 mr-1" />Cancelled</Badge>;
      case "expired":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200"><Clock className="h-3 w-3 mr-1" />Expired</Badge>;
      default:
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
    }
  };

  const calendarUrl = `${window.location.origin}/api/teams/${id}/calendar.ics`;
  const webcalUrl = calendarUrl.replace(/^https?:/, 'webcal:');

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
      toast({
        title: "Copied!",
        description: "Calendar URL copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  if (teamLoading || playersLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading team...</p>
        </div>
      </div>
    );
  }

  if (!team) {
    return <div>Team not found</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-2 sm:gap-4">
          <Link href="/teams">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div className="flex-1 min-w-0">
            <h1 className="font-semibold tracking-tight truncate">{team.name}</h1>
            <p className="text-muted-foreground text-sm md:text-base">Team Roster</p>
          </div>
          <Dialog open={isCalendarDialogOpen} onOpenChange={setIsCalendarDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="hidden sm:inline-flex" data-testid="button-calendar-subscription">
                <Calendar className="h-4 w-4 mr-2" />
                Subscribe to Calendar
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-2xl">
              <DialogHeader>
                <DialogTitle>Team Calendar</DialogTitle>
                <DialogDescription>
                  Download a calendar file or subscribe for automatic updates when events change.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                {/* Download button - Primary action */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Quick Download</Label>
                  <p className="text-sm text-muted-foreground mb-2">
                    Download the calendar file and import it into your calendar app. This creates a one-time snapshot.
                  </p>
                  <a 
                    href={calendarUrl}
                    download
                    className="inline-block w-full"
                  >
                    <Button 
                      className="w-full" 
                      data-testid="button-download-calendar"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download Calendar File
                    </Button>
                  </a>
                </div>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background px-2 text-muted-foreground">
                      Or subscribe for auto-updates
                    </span>
                  </div>
                </div>

                {/* Subscription URL - Secondary option */}
                <div className="space-y-2">
                  <Label>Calendar Subscription URL</Label>
                  <p className="text-sm text-muted-foreground mb-2">
                    Subscribe to keep your calendar automatically synced with event changes.
                  </p>
                  <div className="flex gap-2">
                    <Input
                      readOnly
                      value={webcalUrl}
                      className="font-mono text-sm"
                      data-testid="input-calendar-url"
                    />
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => copyToClipboard(webcalUrl)}
                      data-testid="button-copy-url"
                    >
                      {copiedUrl ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
                <div className="space-y-3 text-sm">
                  <div>
                    <h4 className="font-semibold mb-2">How to Subscribe:</h4>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <p className="font-medium">Google Calendar:</p>
                      <ol className="list-decimal list-inside text-muted-foreground space-y-1 ml-2">
                        <li>Open Google Calendar on your computer</li>
                        <li>On the left, find "Other calendars" and click the + icon</li>
                        <li>Select "From URL"</li>
                        <li>Paste the calendar URL above</li>
                        <li>Click "Add calendar"</li>
                      </ol>
                    </div>
                    <div>
                      <p className="font-medium">Apple Calendar (iPhone/Mac):</p>
                      <ol className="list-decimal list-inside text-muted-foreground space-y-1 ml-2">
                        <li>Copy the calendar URL using the button above</li>
                        <li>Open Settings → Calendar → Accounts → Add Account</li>
                        <li>Select "Other" → "Add Subscribed Calendar"</li>
                        <li>Paste the URL and tap "Next"</li>
                      </ol>
                    </div>
                    <div>
                      <p className="font-medium">Outlook:</p>
                      <ol className="list-decimal list-inside text-muted-foreground space-y-1 ml-2">
                        <li>Open Outlook Calendar</li>
                        <li>Go to "Add calendar" → "Subscribe from web"</li>
                        <li>Paste the calendar URL</li>
                        <li>Give it a name and click "Import"</li>
                      </ol>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-4 border-t pt-3">
                    Note: Calendar apps typically sync every 30 minutes to a few hours. Changes made in TeamSyncAI 
                    will appear in your calendar after the next sync.
                  </p>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          {permissions.canManagePlayers && (
            <Link href={`/teams/${id}/payments`}>
              <Button variant="outline" size="sm" className="hidden sm:inline-flex" data-testid="button-team-payments">
                <DollarSign className="h-4 w-4 mr-2" />
                Payments
              </Button>
            </Link>
          )}
          {permissions.isTeamOwner && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm" className="hidden md:inline-flex" data-testid="button-delete-team">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Team
                </Button>
              </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the team "{team.name}" 
                  and remove all associated players, events, and campaigns.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => deleteTeamMutation.mutate()}
                  disabled={deleteTeamMutation.isPending}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  data-testid="button-confirm-delete"
                >
                  {deleteTeamMutation.isPending ? "Deleting..." : "Delete Team"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          )}
          {permissions.canManagePlayers && (
            <Dialog open={isDialogOpen} onOpenChange={(open) => {
              setIsDialogOpen(open);
              if (!open) resetForm();
            }}>
              <DialogTrigger asChild>
                <Button size="sm" data-testid="button-add-player">
                  <Plus className="h-4 w-4 sm:mr-2" />
                  <span className="hidden sm:inline">Add Player</span>
                </Button>
              </DialogTrigger>
          <DialogContent>
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>
                  {editingPlayer ? "Edit Player" : "Add New Player"}
                </DialogTitle>
                <DialogDescription>
                  {editingPlayer ? "Update player information" : "Add a new player to your team roster"}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="player-firstName">First Name</Label>
                    <Input
                      id="player-firstName"
                      placeholder="John"
                      value={playerForm.firstName}
                      onChange={(e) => setPlayerForm({ ...playerForm, firstName: e.target.value })}
                      className="mt-2"
                      data-testid="input-player-firstName"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="player-lastName">Last Name</Label>
                    <Input
                      id="player-lastName"
                      placeholder="Doe"
                      value={playerForm.lastName}
                      onChange={(e) => setPlayerForm({ ...playerForm, lastName: e.target.value })}
                      className="mt-2"
                      data-testid="input-player-lastName"
                      required
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="player-phone">Phone Number</Label>
                  <Input
                    id="player-phone"
                    type="tel"
                    placeholder="+1 (555) 123-4567"
                    value={playerForm.phone}
                    onChange={(e) => setPlayerForm({ ...playerForm, phone: e.target.value })}
                    className="mt-2"
                    data-testid="input-player-phone"
                    required
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Used for SMS reminders
                  </p>
                </div>
                <div>
                  <Label htmlFor="player-email">Email Address</Label>
                  <Input
                    id="player-email"
                    type="email"
                    placeholder="john.doe@example.com"
                    value={playerForm.email}
                    onChange={(e) => setPlayerForm({ ...playerForm, email: e.target.value })}
                    className="mt-2"
                    data-testid="input-player-email"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="player-dateOfBirth">Date of Birth</Label>
                    <Input
                      id="player-dateOfBirth"
                      type="date"
                      value={playerForm.dateOfBirth}
                      onChange={(e) => setPlayerForm({ ...playerForm, dateOfBirth: e.target.value })}
                      className="mt-2"
                      data-testid="input-player-dateOfBirth"
                    />
                  </div>
                  <div>
                    <Label htmlFor="player-jerseyNumber">Jersey Number</Label>
                    <Input
                      id="player-jerseyNumber"
                      type="number"
                      placeholder="10"
                      value={playerForm.jerseyNumber}
                      onChange={(e) => setPlayerForm({ ...playerForm, jerseyNumber: e.target.value })}
                      className="mt-2"
                      data-testid="input-player-jerseyNumber"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="player-position">Position</Label>
                  <Input
                    id="player-position"
                    placeholder="e.g. Forward, Midfielder, Defender"
                    value={playerForm.position}
                    onChange={(e) => setPlayerForm({ ...playerForm, position: e.target.value })}
                    className="mt-2"
                    data-testid="input-player-position"
                  />
                </div>
                {(team?.sport === 'Baseball' || team?.sport === 'Softball') && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="player-battingOrder">Preferred Batting Order</Label>
                      <Input
                        id="player-battingOrder"
                        type="number"
                        min="1"
                        placeholder="Position in batting order"
                        value={playerForm.preferredBattingOrder}
                        onChange={(e) => setPlayerForm({ ...playerForm, preferredBattingOrder: e.target.value })}
                        className="mt-2"
                        data-testid="input-player-battingOrder"
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Preferred slot in batting lineup (1-15+)
                      </p>
                    </div>
                    <div>
                      <Label htmlFor="player-pitchingOrder">Preferred Pitching Order</Label>
                      <Input
                        id="player-pitchingOrder"
                        type="number"
                        min="0"
                        placeholder="0 (non-pitcher), 1 (SP), 2-4 (RP)"
                        value={playerForm.preferredPitchingOrder}
                        onChange={(e) => setPlayerForm({ ...playerForm, preferredPitchingOrder: e.target.value })}
                        className="mt-2"
                        data-testid="input-player-pitchingOrder"
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        0 = Does not pitch, 1 = Starting pitcher, 2-4 = Relief pitcher
                      </p>
                    </div>
                  </div>
                )}
                <div>
                  <Label htmlFor="player-role">Role</Label>
                  <Select
                    value={playerForm.roleId}
                    onValueChange={(value) => setPlayerForm({ ...playerForm, roleId: value })}
                  >
                    <SelectTrigger className="mt-2" data-testid="select-player-role">
                      <SelectValue placeholder="Select a role" />
                    </SelectTrigger>
                    <SelectContent>
                      {roles.map((role) => (
                        <SelectItem key={role.id} value={role.id} data-testid={`select-role-${role.id}`}>
                          {role.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">
                    Optional - assign a role to define permissions
                  </p>
                </div>
                {permissions.canManagePlayers && (
                  <div>
                    <Label htmlFor="player-reliability">
                      Reliability Score: {playerForm.reliabilityScore}
                    </Label>
                    <Input
                      id="player-reliability"
                      type="range"
                      min="1"
                      max="5"
                      step="0.5"
                      value={playerForm.reliabilityScore}
                      onChange={(e) => setPlayerForm({ ...playerForm, reliabilityScore: parseFloat(e.target.value) })}
                      className="mt-2"
                      data-testid="input-player-reliability"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      1 = Unreliable, 5 = Very Reliable
                    </p>
                  </div>
                )}
                {!editingPlayer && documents.filter(d => !d.archivedAt).length > 0 && (
                  <div className="flex items-center justify-between p-3 rounded-md border bg-muted/50">
                    <div className="flex-1">
                      <Label htmlFor="send-invitation" className="cursor-pointer">Send Invitation</Label>
                      <p className="text-xs text-muted-foreground mt-1">
                        Send an invitation with documents to sign
                      </p>
                    </div>
                    <Switch
                      id="send-invitation"
                      checked={playerForm.sendInvitation}
                      onCheckedChange={(checked) => setPlayerForm({ ...playerForm, sendInvitation: checked })}
                      data-testid="switch-send-invitation"
                    />
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsDialogOpen(false);
                    resetForm();
                  }}
                  data-testid="button-cancel-player"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createPlayerMutation.isPending || updatePlayerMutation.isPending}
                  data-testid="button-submit-player"
                >
                  {createPlayerMutation.isPending || updatePlayerMutation.isPending
                    ? "Saving..."
                    : editingPlayer
                    ? "Update Player"
                    : "Add Player"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
          )}
      </div>

        {/* Mobile-only quick actions */}
        <div className="flex sm:hidden gap-2 flex-wrap">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1" 
            onClick={() => setIsCalendarDialogOpen(true)}
            data-testid="button-calendar-subscription-mobile"
          >
            <Calendar className="h-4 w-4 mr-2" />
            Calendar
          </Button>
          {permissions.canManagePlayers && (
            <Link href={`/teams/${id}/payments`} className="flex-1">
              <Button variant="outline" size="sm" className="w-full" data-testid="button-team-payments-mobile">
                <DollarSign className="h-4 w-4 mr-2" />
                Payments
              </Button>
            </Link>
          )}
          {permissions.isTeamOwner && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm" className="flex-1 md:hidden" data-testid="button-delete-team-mobile">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the team "{team.name}" 
                    and remove all associated players, events, and campaigns.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel data-testid="button-cancel-delete-mobile">Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => deleteTeamMutation.mutate()}
                    disabled={deleteTeamMutation.isPending}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    data-testid="button-confirm-delete-mobile"
                  >
                    {deleteTeamMutation.isPending ? "Deleting..." : "Delete Team"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>

      <input
        ref={csvInputRef}
        type="file"
        accept=".csv"
        onChange={handleCSVUpload}
        className="hidden"
        data-testid="input-csv-file"
      />
      </div>

      {permissions.canManageSettings && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <div>
              <CardTitle>Team Documents & Waivers</CardTitle>
              <CardDescription>
                Manage documents that new members must sign when joining
              </CardDescription>
            </div>
            <Dialog open={isDocumentDialogOpen} onOpenChange={setIsDocumentDialogOpen}>
              <DialogTrigger asChild>
                <Button data-testid="button-add-document">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Document
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Add Team Document</DialogTitle>
                  <DialogDescription>
                    Upload a document that new team members must review or sign when accepting invitations
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleDocumentSubmit} className="space-y-4">
                  <div>
                    <Label>Document File</Label>
                    <div className="mt-2">
                      <UploadThingUploader
                        endpoint="documentUploader"
                        onComplete={handleDocumentUploadComplete}
                        buttonText={documentForm.fileUrl ? "Change Document" : "Upload Document"}
                      />
                      {documentForm.fileUrl && (
                        <p className="text-xs text-green-600 mt-1">✓ Document uploaded</p>
                      )}
                      <p className="text-xs text-muted-foreground mt-1">
                        PDF or Word documents (.pdf, .doc, .docx), max 10MB. This can be a waiver, code of conduct, or any document.
                      </p>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="doc-title">Document Title</Label>
                    <Input
                      id="doc-title"
                      placeholder="e.g., Team Waiver, Code of Conduct"
                      value={documentForm.title}
                      onChange={(e) => setDocumentForm({ ...documentForm, title: e.target.value })}
                      className="mt-2"
                      data-testid="input-document-title"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="doc-description">Description</Label>
                    <Textarea
                      id="doc-description"
                      placeholder="Brief description of what this document covers..."
                      value={documentForm.description}
                      onChange={(e) => setDocumentForm({ ...documentForm, description: e.target.value })}
                      className="mt-2"
                      rows={3}
                      data-testid="input-document-description"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="doc-requires-signature">Requires Signature</Label>
                      <p className="text-xs text-muted-foreground mt-1">
                        Members must digitally sign this document to join
                      </p>
                    </div>
                    <Switch
                      id="doc-requires-signature"
                      checked={documentForm.requiresSignature}
                      onCheckedChange={(checked) => setDocumentForm({ ...documentForm, requiresSignature: checked })}
                      data-testid="switch-requires-signature"
                    />
                  </div>
                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setIsDocumentDialogOpen(false);
                        setDocumentForm({ title: "", description: "", fileUrl: "", requiresSignature: true });
                      }}
                      data-testid="button-cancel-document"
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createDocumentMutation.isPending}
                      data-testid="button-submit-document"
                    >
                      {createDocumentMutation.isPending ? "Adding..." : "Add Document"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            {documents.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No documents added yet</p>
                <p className="text-xs mt-1">Upload waivers or documents for new members to sign</p>
              </div>
            ) : (
              <div className="space-y-3">
                {documents.filter(doc => !doc.archivedAt).map((doc) => {
                  const docSignatures = getDocumentSignatures(doc.id);
                  const isExpanded = expandedDocuments.has(doc.id);
                  
                  return (
                    <div
                      key={doc.id}
                      className="rounded-md border"
                      data-testid={`card-document-${doc.id}`}
                    >
                      <div className="flex items-center justify-between p-4">
                        <div className="flex items-start gap-3 flex-1">
                          <FileText className="h-5 w-5 text-muted-foreground mt-0.5" />
                          <div className="flex-1">
                            <div className="font-medium">{doc.title}</div>
                            {doc.description && (
                              <p className="text-sm text-muted-foreground mt-1">{doc.description}</p>
                            )}
                            <div className="flex items-center gap-4 mt-2">
                              {doc.requiresSignature && (
                                <Badge variant="outline" className="text-xs">
                                  Requires Signature
                                </Badge>
                              )}
                              {docSignatures.length > 0 && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-auto p-0 text-xs text-muted-foreground hover:text-foreground"
                                  onClick={() => toggleDocumentExpanded(doc.id)}
                                  data-testid={`button-toggle-signatures-${doc.id}`}
                                >
                                  {docSignatures.length} {docSignatures.length === 1 ? 'signature' : 'signatures'}
                                  {isExpanded ? (
                                    <ChevronUp className="h-3 w-3 ml-1" />
                                  ) : (
                                    <ChevronDown className="h-3 w-3 ml-1" />
                                  )}
                                </Button>
                              )}
                              {docSignatures.length === 0 && (
                                <span className="text-xs text-muted-foreground">No signatures yet</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => window.open(doc.fileUrl, '_blank')}
                            data-testid={`button-view-document-${doc.id}`}
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                data-testid={`button-archive-document-${doc.id}`}
                              >
                                <Archive className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Archive this document?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This document will be hidden from new invitations. Existing signatures will be preserved.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel data-testid="button-cancel-archive">Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => archiveDocumentMutation.mutate(doc.id)}
                                  data-testid="button-confirm-archive"
                                >
                                  Archive
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                      
                      {/* Expandable signatures list */}
                      {isExpanded && docSignatures.length > 0 && (
                        <div className="border-t px-4 py-3 bg-muted/30">
                          <div className="space-y-2">
                            {docSignatures.map((sig) => (
                              <div
                                key={sig.id}
                                className="flex items-start justify-between text-sm"
                                data-testid={`signature-${sig.id}`}
                              >
                                <div className="flex-1">
                                  <div className="font-medium">
                                    {sig.userFirstName && sig.userLastName
                                      ? `${sig.userFirstName} ${sig.userLastName}`
                                      : sig.userEmail || 'Unknown User'}
                                  </div>
                                  {sig.acknowledgmentText && (
                                    <div className="text-xs text-muted-foreground mt-0.5">
                                      Signed as: "{sig.acknowledgmentText}"
                                    </div>
                                  )}
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  {new Date(sig.signedAt).toLocaleDateString()}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {permissions.canManagePlayers && (
        <Card>
          <CardHeader>
            <CardTitle>Manage Roster & Invitations</CardTitle>
            <CardDescription>
              Add players to your team using individual invitations, CSV import, contacts, or bulk operations
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="individual" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="individual" data-testid="tab-individual-invitation">
                  Individual
                </TabsTrigger>
                <TabsTrigger value="csv" data-testid="tab-csv-import">
                  CSV Import
                </TabsTrigger>
                <TabsTrigger value="contacts" data-testid="tab-import-contacts">
                  Contacts
                </TabsTrigger>
                <TabsTrigger value="bulk" data-testid="tab-bulk-send">
                  Bulk Send
                </TabsTrigger>
              </TabsList>

              <TabsContent value="individual" className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Send an individual invitation via SMS or email. The recipient will receive a link to join the team.
                </p>
                <form onSubmit={handleInvitationSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="inv-contact-type">Send Via</Label>
                    <Select
                      value={invitationForm.contactType}
                      onValueChange={(value: "phone" | "email") => setInvitationForm({ ...invitationForm, contactType: value, contactValue: "" })}
                    >
                      <SelectTrigger className="mt-2" data-testid="select-contact-type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="phone">SMS</SelectItem>
                        <SelectItem value="email">Email</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {invitationForm.contactType === "phone" ? (
                    <div>
                      <Label htmlFor="inv-contact-value">Phone Number</Label>
                      <Input
                        id="inv-contact-value"
                        type="tel"
                        placeholder="(555) 123-4567"
                        value={invitationForm.contactValue}
                        onChange={(e) => {
                          const formatted = autoFormatPhoneInput(e.target.value);
                          setInvitationForm({ ...invitationForm, contactValue: formatted });
                        }}
                        className="mt-2"
                        data-testid="input-invitation-contact"
                        required
                      />
                    </div>
                  ) : (
                    <div>
                      <Label htmlFor="inv-contact-value">Email Address</Label>
                      <Input
                        id="inv-contact-value"
                        type="email"
                        placeholder="player@example.com"
                        value={invitationForm.contactValue}
                        onChange={(e) => setInvitationForm({ ...invitationForm, contactValue: e.target.value })}
                        className="mt-2"
                        data-testid="input-invitation-contact"
                        required
                      />
                    </div>
                  )}
                  <div>
                    <Label htmlFor="inv-role">Assign Role</Label>
                    <Select
                      value={invitationForm.roleId}
                      onValueChange={(value) => setInvitationForm({ ...invitationForm, roleId: value })}
                    >
                      <SelectTrigger className="mt-2" data-testid="select-invitation-role">
                        <SelectValue placeholder="Select a role" />
                      </SelectTrigger>
                      <SelectContent>
                        {roles.map((role) => (
                          <SelectItem key={role.id} value={role.id} data-testid={`select-role-${role.id}`}>
                            {role.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground mt-1">
                      The invitee will be assigned this role when they accept
                    </p>
                  </div>
                  <Button
                    type="submit"
                    disabled={createInvitationMutation.isPending}
                    data-testid="button-submit-invitation"
                  >
                    <Send className="h-4 w-4 mr-2" />
                    {createInvitationMutation.isPending ? "Sending..." : "Send Invitation"}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="csv" className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Import multiple players at once using a CSV file. Download the template to see the required format.
                </p>
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={handleDownloadTemplate}
                      data-testid="button-download-template"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download CSV Template
                    </Button>
                    <Button
                      onClick={() => csvInputRef.current?.click()}
                      disabled={bulkUploadMutation.isPending}
                      data-testid="button-import-roster"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      {bulkUploadMutation.isPending ? "Importing..." : "Upload CSV File"}
                    </Button>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-md">
                    <h4 className="text-sm font-medium mb-2">CSV Format Instructions:</h4>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      <li>• First row must contain column headers</li>
                      <li>• Required: firstName, lastName, phone</li>
                      <li>• Optional: email, position, jerseyNumber, dateOfBirth</li>
                      <li>• Phone numbers can be in any format</li>
                    </ul>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="contacts" className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Import players from your device contacts. Select multiple contacts to add them to your roster.
                </p>
                <Button
                  onClick={() => setIsImportContactsOpen(true)}
                  data-testid="button-import-contacts"
                >
                  <Smartphone className="h-4 w-4 mr-2" />
                  Open Contact Picker
                </Button>
                <div className="p-4 bg-muted/50 rounded-md">
                  <h4 className="text-sm font-medium mb-2">How it works:</h4>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>• Click the button to open your device's contact picker</li>
                    <li>• Select one or more contacts to import</li>
                    <li>• Contact names and phone numbers will be added to your roster</li>
                    <li>• Works on mobile devices and modern browsers</li>
                  </ul>
                </div>
              </TabsContent>

              <TabsContent value="bulk" className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Send invitations to all players on your roster who haven't accepted yet. Great for initial team setup.
                </p>
                <Button
                  onClick={() => sendInvitationsMutation.mutate()}
                  disabled={sendInvitationsMutation.isPending || players.length === 0}
                  data-testid="button-send-invitations"
                >
                  <Mail className="h-4 w-4 mr-2" />
                  {sendInvitationsMutation.isPending ? "Sending..." : "Send Invitations to All"}
                </Button>
                {players.length === 0 && (
                  <p className="text-xs text-muted-foreground">
                    No players in roster. Add players first using one of the other methods.
                  </p>
                )}
                {players.length > 0 && (
                  <div className="p-4 bg-muted/50 rounded-md">
                    <h4 className="text-sm font-medium mb-2">Will send to:</h4>
                    <p className="text-xs text-muted-foreground">
                      {players.length} player{players.length !== 1 ? 's' : ''} in your roster who haven't accepted invitations yet
                    </p>
                  </div>
                )}
              </TabsContent>
            </Tabs>

            {invitations.length > 0 && (
              <div className="mt-6 pt-6 border-t">
                <h3 className="text-sm font-medium mb-3">Pending Invitations ({invitations.length})</h3>
                <div className="space-y-2">
                  {invitations.map((invitation) => {
                    const status = getInvitationStatus(invitation);
                    const role = roles.find(r => r.id === invitation.roleId);
                    return (
                      <div
                        key={invitation.id}
                        className="flex items-center justify-between p-3 rounded-md border"
                        data-testid={`card-invitation-${invitation.id}`}
                      >
                        <div className="flex-1">
                          <div className="font-medium text-sm">{invitation.contactValue}</div>
                          <div className="text-xs text-muted-foreground mt-1">
                            {invitation.contactType === "phone" ? "SMS" : "Email"} • {role?.name || "No role"}
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            {getStatusBadge(status)}
                            {invitation.acceptedAt && (
                              <span className="text-xs text-muted-foreground">
                                Accepted {new Date(invitation.acceptedAt).toLocaleDateString()}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          {status === "pending" && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => resendInvitationMutation.mutate(invitation.id)}
                                disabled={resendInvitationMutation.isPending}
                                data-testid={`button-resend-invitation-${invitation.id}`}
                              >
                                <RefreshCw className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => cancelInvitationMutation.mutate(invitation.id)}
                                disabled={cancelInvitationMutation.isPending}
                                data-testid={`button-cancel-invitation-${invitation.id}`}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {players.length === 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>Roster (0 players)</CardTitle>
            <CardDescription>
              Use the "Manage Roster & Invitations" section above to add players
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Plus className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium mb-2">No players yet</h3>
            <p className="text-sm text-muted-foreground text-center mb-6 max-w-md">
              {permissions.canManagePlayers 
                ? "Add players individually or import using the methods above."
                : "No players have been added to this team yet."}
            </p>
            {permissions.canManagePlayers && (
              <Button onClick={() => setIsDialogOpen(true)} data-testid="button-add-first-player">
                <Plus className="h-4 w-4 mr-2" />
                Add Player Manually
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Roster ({players.length} players)</CardTitle>
            {permissions.canManagePlayers && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleExportCSV}
                data-testid="button-export-roster"
              >
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
            )}
          </CardHeader>
          <CardContent>
            <div className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Player</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Role</TableHead>
                    {permissions.canManagePlayers && (
                      <TableHead>Reliability</TableHead>
                    )}
                    {permissions.canManagePlayers && (
                      <TableHead className="text-right">Actions</TableHead>
                    )}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {players.map((player) => {
                    const playerRole = roles.find(r => r.id === player.roleId);
                    return (
                    <TableRow key={player.id} data-testid={`row-player-${player.id}`}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback>{getInitials(player.firstName, player.lastName)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">{getFullName(player)}</div>
                            {player.jerseyNumber && (
                              <div className="text-xs text-muted-foreground">#{player.jerseyNumber}</div>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {player.phone}
                      </TableCell>
                      <TableCell>
                        {playerRole ? (
                          <Badge variant="outline" data-testid={`badge-role-${player.id}`}>
                            {playerRole.name}
                          </Badge>
                        ) : (
                          <span className="text-xs text-muted-foreground">No role</span>
                        )}
                      </TableCell>
                      {permissions.canManagePlayers && (
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="flex gap-1">
                              {[1, 2, 3, 4, 5].map((score) => (
                                <button
                                  key={score}
                                  onClick={() => handleReliabilityChange(player.id, score)}
                                  className={`h-6 w-6 rounded-sm transition-colors ${
                                    score <= player.reliabilityScore
                                      ? getReliabilityColor(player.reliabilityScore)
                                      : "bg-muted"
                                  }`}
                                  data-testid={`button-reliability-${player.id}-${score}`}
                                />
                              ))}
                            </div>
                            <span className="text-sm text-muted-foreground">
                              {player.reliabilityScore.toFixed(1)}
                            </span>
                          </div>
                        </TableCell>
                      )}
                      {permissions.canManagePlayers && (
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openEditDialog(player)}
                              data-testid={`button-edit-player-${player.id}`}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deletePlayerMutation.mutate(player.id)}
                              data-testid={`button-delete-player-${player.id}`}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            <div className="md:hidden space-y-3">
              {players.map((player) => {
                const playerRole = roles.find(r => r.id === player.roleId);
                return (
                <div
                  key={player.id}
                  className="flex items-center gap-3 p-4 rounded-md border"
                  data-testid={`card-player-${player.id}`}
                >
                  <Avatar className="h-12 w-12">
                    <AvatarFallback>{getInitials(player.firstName, player.lastName)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">
                      {getFullName(player)}
                      {player.jerseyNumber && (
                        <span className="text-xs text-muted-foreground ml-2">#{player.jerseyNumber}</span>
                      )}
                    </p>
                    <p className="text-sm text-muted-foreground truncate">{player.phone}</p>
                    {playerRole && (
                      <Badge variant="outline" className="text-xs mt-1" data-testid={`badge-role-mobile-${player.id}`}>
                        {playerRole.name}
                      </Badge>
                    )}
                    {player.position && (
                      <p className="text-xs text-muted-foreground">{player.position}</p>
                    )}
                    {permissions.canManagePlayers && (
                      <div className="flex items-center gap-1 mt-1">
                        {[1, 2, 3, 4, 5].map((score) => (
                          <div
                            key={score}
                            className={`h-4 w-4 rounded-sm ${
                              score <= player.reliabilityScore
                                ? getReliabilityColor(player.reliabilityScore)
                                : "bg-muted"
                            }`}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                  {permissions.canManagePlayers && (
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEditDialog(player)}
                        data-testid={`button-edit-player-mobile-${player.id}`}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deletePlayerMutation.mutate(player.id)}
                        data-testid={`button-delete-player-mobile-${player.id}`}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  )}
                </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Team Settings Section */}
      {permissions.canManageSettings && id && team && (
        <div className="space-y-6 mt-8">
          <div className="border-t pt-6">
            <h2 className="text-2xl font-semibold mb-6">Team Settings</h2>
          </div>
          
          <TeamSMSPhoneNumber 
            teamId={id} 
            team={team} 
            canManage={permissions.canManageSettings} 
          />
          
          <TeamUsageBilling 
            teamId={id} 
            canManage={permissions.canManageSettings} 
          />
        </div>
      )}

      {/* Import Contacts Dialog */}
      {id && (
        <ImportContactsDialog
          open={isImportContactsOpen}
          onOpenChange={setIsImportContactsOpen}
          teamId={id}
        />
      )}
    </div>
  );
}

import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { useTierAccess } from "@/hooks/useTierAccess";
import { usePermissions } from "@/hooks/usePermissions";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Check, X, Crown, Clock, AlertCircle, XCircle, ExternalLink } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { MembershipTier, TierLimit, TierFeature, Team, User } from "@shared/schema";

type TierWithDetails = MembershipTier & { limits: TierLimit[]; features: TierFeature[] };

export default function Membership() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { tier: userTier, isLoading: isUserTierLoading } = useTierAccess();
  const [billingPeriod, setBillingPeriod] = useState<"monthly" | "annual">("monthly");
  
  const { data: teams = [] } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });
  
  const { data: currentUser } = useQuery<User>({
    queryKey: ["/api/auth/user"],
  });
  
  const team = teams[0];
  const permissions = usePermissions(team?.id);

  const cancelSubscriptionMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/subscriptions/cancel", "POST");
    },
    onSuccess: () => {
      toast({
        title: "Subscription Canceled",
        description: "Your subscription has been successfully canceled and you've been downgraded to the free tier.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/membership-tier"] });
    },
    onError: (error: any) => {
      const errorMessage = error?.data?.message || error?.message || "Failed to cancel subscription. Please try again.";
      toast({
        title: "Cancellation Failed",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });
  
  useEffect(() => {
    if (!isUserTierLoading && team && !permissions.canViewMembership) {
      setLocation("/");
    }
  }, [isUserTierLoading, team, permissions.canViewMembership, setLocation]);
  
  const { data: allTiers, isLoading: isAllTiersLoading } = useQuery<TierWithDetails[]>({
    queryKey: ["/api/membership-tiers"],
  });

  const activeTiers = allTiers?.filter(t => t.isActive).sort((a, b) => a.displayOrder - b.displayOrder) || [];

  if (isUserTierLoading || isAllTiersLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-muted-foreground">Loading membership information...</div>
        </div>
      </div>
    );
  }

  const formatPrice = (priceInCents: number) => {
    return (priceInCents / 100).toFixed(2);
  };

  const getPrice = (tier: TierWithDetails) => {
    return billingPeriod === "annual" ? (tier as any).annualPrice || tier.monthlyPrice * 12 : tier.monthlyPrice;
  };

  const getPeriodLabel = () => {
    return billingPeriod === "annual" ? "/year" : "/month";
  };

  const trialDaysRemaining = () => {
    if (!userTier?.tier || !userTier.isOnTrial()) return null;
    const user = userTier.tier as any;
    if (!user.trialEndDate) return null;
    const now = new Date();
    const endDate = new Date(user.trialEndDate);
    const diffTime = endDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2" data-testid="text-membership-title">Your Membership</h1>
        <p className="text-muted-foreground">
          Manage your subscription and explore available plans
        </p>
      </div>

      {userTier && (
        <Card data-testid="card-current-tier">
          <CardHeader>
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <CardTitle className="flex flex-wrap items-center gap-2">
                  {userTier.tier.name}
                  {userTier.isOnTrial() && (
                    <Badge variant="secondary" data-testid="badge-trial">
                      <Clock className="w-3 h-3 mr-1" />
                      Trial
                    </Badge>
                  )}
                  {currentUser?.subscriptionStatus === 'canceled' && (
                    <Badge variant="destructive" data-testid="badge-canceled">
                      <XCircle className="w-3 h-3 mr-1" />
                      Canceled
                    </Badge>
                  )}
                  {currentUser?.subscriptionStatus === 'active' && currentUser.helcimSubscriptionId && (
                    <Badge variant="default" data-testid="badge-active">
                      Active Subscription
                    </Badge>
                  )}
                </CardTitle>
                <CardDescription>Your current membership tier</CardDescription>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold" data-testid="text-current-price">
                  ${formatPrice(userTier.tier.monthlyPrice)}
                  <span className="text-sm font-normal text-muted-foreground">/month</span>
                </div>
                {userTier.isOnTrial() && trialDaysRemaining() !== null && (
                  <div className="text-sm text-muted-foreground mt-1" data-testid="text-trial-days">
                    {trialDaysRemaining()} days remaining in trial
                  </div>
                )}
                {currentUser?.subscriptionStatus === 'active' && currentUser.helcimSubscriptionId && (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="mt-2"
                        data-testid="button-cancel-subscription"
                      >
                        Cancel Subscription
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Cancel Subscription?</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to cancel your subscription? Your subscription will be canceled immediately and you'll be downgraded to the free tier.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel data-testid="button-cancel-cancel">
                          Keep Subscription
                        </AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => cancelSubscriptionMutation.mutate()}
                          data-testid="button-confirm-cancel"
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          {cancelSubscriptionMutation.isPending ? "Canceling..." : "Yes, Cancel"}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold mb-3">Features</h3>
                <ul className="space-y-2">
                  {userTier.tier.features.map((feature) => (
                    <li
                      key={feature.featureKey}
                      className="flex items-start gap-2"
                      data-testid={`feature-${feature.featureKey}`}
                    >
                      {feature.enabled ? (
                        <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                      ) : (
                        <X className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                      )}
                      <span className={feature.enabled ? "" : "text-muted-foreground"}>
                        {feature.featureKey}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="font-semibold mb-3">Limits</h3>
                <ul className="space-y-2">
                  {userTier.tier.limits.map((limit) => (
                    <li
                      key={limit.limitKey}
                      className="flex justify-between"
                      data-testid={`limit-${limit.limitKey}`}
                    >
                      <span className="text-muted-foreground">
                        {limit.limitKey}
                      </span>
                      <span className="font-medium">{limit.limitValue}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div>
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <h2 className="text-2xl font-bold">Available Plans</h2>
          <Tabs value={billingPeriod} onValueChange={(v) => setBillingPeriod(v as "monthly" | "annual")}>
            <TabsList>
              <TabsTrigger value="monthly" data-testid="tab-monthly">Monthly</TabsTrigger>
              <TabsTrigger value="annual" data-testid="tab-annual">Annual</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {activeTiers.map((tier) => {
            const isCurrentTier = userTier?.tier.id === tier.id;
            const price = getPrice(tier);
            const helcimCheckoutId = billingPeriod === "annual" 
              ? (tier as any).helcimAnnualCheckoutId 
              : (tier as any).helcimMonthlyCheckoutId;
            const isContactForPricing = (tier as any).isContactForPricing || false;
            const contactInfo = (tier as any).contactInfo || "";
            
            return (
              <Card
                key={tier.id}
                className={isCurrentTier ? "border-primary" : ""}
                data-testid={`card-tier-${tier.id}`}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      {tier.name}
                      {isCurrentTier && (
                        <Crown className="w-4 h-4 text-primary" />
                      )}
                    </CardTitle>
                    {tier.trialPeriodDays > 0 && (
                      <Badge variant="outline" data-testid={`badge-trial-${tier.id}`}>
                        {tier.trialPeriodDays} day trial
                      </Badge>
                    )}
                  </div>
                  <CardDescription>{tier.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-3xl font-bold" data-testid={`text-price-${tier.id}`}>
                    {isContactForPricing ? (
                      <>
                        Contact Us
                        <span className="text-sm font-normal text-muted-foreground"> for Pricing</span>
                      </>
                    ) : (
                      <>
                        ${formatPrice(price)}
                        <span className="text-sm font-normal text-muted-foreground">{getPeriodLabel()}</span>
                      </>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">Features</h4>
                    <ul className="space-y-1">
                      {tier.features
                        .filter(f => f.enabled)
                        .map((feature) => (
                          <li
                            key={feature.featureKey}
                            className="flex items-start gap-2 text-sm"
                            data-testid={`tier-feature-${tier.id}-${feature.featureKey}`}
                          >
                            <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>{feature.featureKey}</span>
                          </li>
                        ))}
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">Limits</h4>
                    <ul className="space-y-1">
                      {tier.limits.map((limit) => (
                        <li
                          key={limit.limitKey}
                          className="flex justify-between text-sm"
                          data-testid={`tier-limit-${tier.id}-${limit.limitKey}`}
                        >
                          <span className="text-muted-foreground">
                            {limit.limitKey}
                          </span>
                          <span className="font-medium">{limit.limitValue}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {isContactForPricing && contactInfo ? (
                    <div className="space-y-2">
                      <div className="p-4 border rounded-md bg-muted/50" data-testid={`contact-info-${tier.id}`}>
                        <p className="text-sm font-medium mb-1">Contact Information:</p>
                        <p className="text-sm whitespace-pre-wrap">{contactInfo}</p>
                      </div>
                    </div>
                  ) : (
                    <Button
                      className="w-full"
                      variant={isCurrentTier ? "secondary" : "default"}
                      disabled={isCurrentTier || (!helcimCheckoutId && price > 0 && !isContactForPricing)}
                      onClick={() => {
                        if (helcimCheckoutId && !isCurrentTier) {
                          window.location.href = helcimCheckoutId;
                        }
                      }}
                      data-testid={`button-select-tier-${tier.id}`}
                    >
                      {isCurrentTier ? "Current Plan" : (isContactForPricing && !contactInfo) ? (
                        "Contact Us"
                      ) : (helcimCheckoutId || price === 0) ? (
                        <>
                          {price === 0 ? "Free Plan" : "Subscribe"}
                          {helcimCheckoutId && price > 0 && <ExternalLink className="ml-2 h-4 w-4" />}
                        </>
                      ) : "Coming Soon"}
                    </Button>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Pin, Smile, Trash2, MessageSquare, X, ImageIcon } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { UploadThingUploader } from "@/components/UploadThingUploader";
import type { Message, MessageReaction, User, Team } from "@shared/schema";

type MessageWithRelations = Message & {
  user: User;
  reactions: Array<MessageReaction & { user: User }>;
};

const EMOJI_OPTIONS = ["👍", "❤️", "😄", "🎉", "👏", "🔥", "✅", "👀"];

export default function MessageBoard() {
  const { teamId } = useParams<{ teamId: string }>();
  const { user } = useAuth();
  const { toast } = useToast();
  const [messageContent, setMessageContent] = useState("");
  const [imageUrl, setImageUrl] = useState<string | null>(null);

  const { data: team } = useQuery<Team>({
    queryKey: ["/api/teams", teamId],
  });

  const { data: messages = [], isLoading } = useQuery<MessageWithRelations[]>({
    queryKey: ["/api/teams", teamId, "messages"],
    enabled: !!teamId,
  });

  const createMessageMutation = useMutation({
    mutationFn: async ({ content, imageUrl }: { content: string | null; imageUrl: string | null }) => {
      return await apiRequest("POST", `/api/teams/${teamId}/messages`, { content, imageUrl });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "messages"] });
      setMessageContent("");
      setImageUrl(null);
      toast({
        title: "Message posted",
        description: "Your message has been posted successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error?.message || "Failed to post message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteMessageMutation = useMutation({
    mutationFn: async (messageId: string) => {
      return await apiRequest("DELETE", `/api/messages/${messageId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "messages"] });
      toast({
        title: "Message deleted",
        description: "The message has been deleted successfully.",
      });
    },
  });

  const pinMessageMutation = useMutation({
    mutationFn: async ({ messageId, isPinned }: { messageId: string; isPinned: boolean }) => {
      return await apiRequest("PATCH", `/api/messages/${messageId}/pin`, { isPinned });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "messages"] });
    },
  });

  const toggleReactionMutation = useMutation({
    mutationFn: async ({ messageId, emoji }: { messageId: string; emoji: string }) => {
      return await apiRequest("POST", `/api/messages/${messageId}/reactions`, { emoji });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "messages"] });
    },
  });

  const isTeamOwner = team?.userId === user?.id || !team?.userId;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const trimmedContent = messageContent.trim();
    
    // Validate that at least one of content or imageUrl is provided
    if (!trimmedContent && !imageUrl) {
      toast({
        title: "Empty message",
        description: "Please enter text or upload an image.",
        variant: "destructive",
      });
      return;
    }
    
    createMessageMutation.mutate({ 
      content: trimmedContent.length > 0 ? trimmedContent : null, 
      imageUrl: imageUrl || null 
    });
  };

  const getReactionCounts = (reactions: Array<MessageReaction & { user: User }>) => {
    const counts: Record<string, { count: number; users: User[]; hasUserReacted: boolean }> = {};
    
    reactions.forEach((reaction) => {
      if (!counts[reaction.emoji]) {
        counts[reaction.emoji] = { count: 0, users: [], hasUserReacted: false };
      }
      counts[reaction.emoji].count++;
      counts[reaction.emoji].users.push(reaction.user);
      if (reaction.userId === user?.id) {
        counts[reaction.emoji].hasUserReacted = true;
      }
    });
    
    return counts;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading messages...</p>
        </div>
      </div>
    );
  }

  if (!team?.messageBoardEnabled) {
    return (
      <div className="flex items-center justify-center h-full">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              Message Board Disabled
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              The message board is currently disabled for this team. Contact your coach to enable it.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">Message Board</h1>
        <p className="text-muted-foreground">
          Team communication and announcements
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Post a Message</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <Textarea
              placeholder="What's on your mind?"
              value={messageContent}
              onChange={(e) => setMessageContent(e.target.value)}
              rows={3}
              data-testid="textarea-message"
            />
            
            {imageUrl && (
              <div className="relative">
                <AspectRatio ratio={16 / 9} className="bg-muted rounded-md overflow-hidden">
                  <img
                    src={imageUrl}
                    alt="Uploaded preview"
                    className="object-cover w-full h-full"
                    data-testid="img-message-preview"
                  />
                </AspectRatio>
                <Button
                  type="button"
                  variant="destructive"
                  size="icon"
                  className="absolute top-2 right-2"
                  onClick={() => setImageUrl(null)}
                  data-testid="button-remove-image"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}
            
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <UploadThingUploader
                  endpoint="messageImageUploader"
                  onComplete={(url: string) => {
                    setImageUrl(url);
                    toast({
                      title: "Image uploaded",
                      description: "Image added to your message.",
                    });
                  }}
                  onError={(error: Error) => {
                    toast({
                      title: "Upload failed",
                      description: error.message,
                      variant: "destructive",
                    });
                  }}
                  buttonText={imageUrl ? "Change Image" : "Add Image"}
                  disabled={createMessageMutation.isPending}
                  buttonClassName="bg-secondary text-secondary-foreground hover:bg-secondary/90"
                />
                <p className="text-xs text-muted-foreground">
                  {imageUrl ? "Image ready to post" : "Optional: Add an image to your message"}
                </p>
              </div>
              <Button
                type="submit"
                disabled={createMessageMutation.isPending}
                data-testid="button-post-message"
              >
                {createMessageMutation.isPending ? "Posting..." : "Post Message"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <ScrollArea className="h-[600px]">
        <div className="space-y-4">
          {messages.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center">
                <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No messages yet. Be the first to post!</p>
              </CardContent>
            </Card>
          ) : (
            messages.map((message) => {
              const reactionCounts = getReactionCounts(message.reactions);
              const canDelete = message.userId === user?.id || isTeamOwner;
              const canPin = isTeamOwner;

              return (
                <Card
                  key={message.id}
                  className={message.isPinned ? "border-primary" : ""}
                  data-testid={`message-${message.id}`}
                >
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-start gap-3 flex-1">
                          <Avatar>
                            <AvatarImage src={message.user.profileImageUrl || undefined} />
                            <AvatarFallback>
                              {message.user.firstName?.[0] || message.user.email?.[0] || "?"}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-medium">
                                {message.user.firstName && message.user.lastName
                                  ? `${message.user.firstName} ${message.user.lastName}`
                                  : message.user.email}
                              </span>
                              {message.isPinned && (
                                <Badge variant="secondary" className="gap-1">
                                  <Pin className="h-3 w-3" />
                                  Pinned
                                </Badge>
                              )}
                              <span className="text-sm text-muted-foreground">
                                {formatDistanceToNow(new Date(message.createdAt), { addSuffix: true })}
                              </span>
                            </div>
                            {message.content && (
                              <p className="mt-2 whitespace-pre-wrap">{message.content}</p>
                            )}
                            {message.imageUrl && (
                              <div className="mt-2 max-w-md">
                                <AspectRatio ratio={16 / 9} className="bg-muted rounded-md overflow-hidden">
                                  <img
                                    src={message.imageUrl}
                                    alt="Message attachment"
                                    className="object-cover w-full h-full cursor-pointer hover-elevate"
                                    onClick={() => window.open(message.imageUrl!, '_blank')}
                                    data-testid={`img-message-${message.id}`}
                                  />
                                </AspectRatio>
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {canPin && (
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() =>
                                pinMessageMutation.mutate({
                                  messageId: message.id,
                                  isPinned: !message.isPinned,
                                })
                              }
                              data-testid={`button-pin-${message.id}`}
                            >
                              <Pin className={`h-4 w-4 ${message.isPinned ? "fill-current" : ""}`} />
                            </Button>
                          )}
                          {canDelete && (
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => deleteMessageMutation.mutate(message.id)}
                              data-testid={`button-delete-${message.id}`}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 flex-wrap">
                        {Object.entries(reactionCounts).map(([emoji, data]) => (
                          <Badge
                            key={emoji}
                            variant={data.hasUserReacted ? "default" : "secondary"}
                            className="cursor-pointer gap-1 hover-elevate active-elevate-2"
                            onClick={() => toggleReactionMutation.mutate({ messageId: message.id, emoji })}
                            data-testid={`reaction-${message.id}-${emoji}`}
                          >
                            <span>{emoji}</span>
                            <span>{data.count}</span>
                          </Badge>
                        ))}
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 gap-1"
                              data-testid={`button-add-reaction-${message.id}`}
                            >
                              <Smile className="h-3 w-3" />
                              Add
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-2">
                            <div className="flex gap-1">
                              {EMOJI_OPTIONS.map((emoji) => (
                                <Button
                                  key={emoji}
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0 text-lg"
                                  onClick={() => {
                                    toggleReactionMutation.mutate({ messageId: message.id, emoji });
                                  }}
                                  data-testid={`emoji-picker-${emoji}`}
                                >
                                  {emoji}
                                </Button>
                              ))}
                            </div>
                          </PopoverContent>
                        </Popover>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

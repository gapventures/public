import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plus, Users as UsersIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useTestView } from "@/contexts/TestViewContext";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import type { Team } from "@shared/schema";
import { useAvailableSports } from "@/hooks/useAvailableSports";

export default function Teams() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [teamName, setTeamName] = useState("");
  const [selectedSport, setSelectedSport] = useState("");
  const { toast } = useToast();
  const { user } = useAuth();
  const { testViewMode, isTestViewActive } = useTestView();
  const { availableSports } = useAvailableSports();

  const queryKey = isTestViewActive && testViewMode 
    ? `/api/teams?testViewMode=${testViewMode}`
    : "/api/teams";
    
  const { data: teams = [], isLoading } = useQuery<Team[]>({
    queryKey: [queryKey],
  });

  const createTeamMutation = useMutation({
    mutationFn: async (teamData: { name: string; sport: string }) => {
      return await apiRequest("POST", "/api/teams", teamData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        predicate: (query) => {
          const key = query.queryKey[0];
          return typeof key === 'string' && key.startsWith('/api/teams');
        }
      });
      setIsDialogOpen(false);
      setTeamName("");
      setSelectedSport("");
      toast({
        title: "Team created",
        description: "Your team has been created successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create team. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateTeam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!teamName.trim() || !selectedSport) return;
    createTeamMutation.mutate({ 
      name: teamName.trim(),
      sport: selectedSport
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading teams...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Teams</h1>
          <p className="text-muted-foreground">
            Manage your sports teams and rosters
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-team">
              <Plus className="h-4 w-4 mr-2" />
              Create Team
            </Button>
          </DialogTrigger>
          <DialogContent>
            <form onSubmit={handleCreateTeam}>
              <DialogHeader>
                <DialogTitle>Create New Team</DialogTitle>
                <DialogDescription>
                  Add a new team to manage players and events.
                </DialogDescription>
              </DialogHeader>
              <div className="py-4 space-y-4">
                <div>
                  <Label htmlFor="team-name">Team Name</Label>
                  <Input
                    id="team-name"
                    placeholder="e.g., Eagles U12, Warriors Soccer"
                    value={teamName}
                    onChange={(e) => setTeamName(e.target.value)}
                    className="mt-2"
                    data-testid="input-team-name"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="team-sport">Sport</Label>
                  <Select value={selectedSport} onValueChange={setSelectedSport} required>
                    <SelectTrigger className="mt-2" data-testid="select-team-sport">
                      <SelectValue placeholder="Select a sport" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableSports.map((sport) => (
                        <SelectItem key={sport} value={sport} data-testid={`option-sport-${sport.toLowerCase().replace(/\s+/g, '-')}`}>
                          {sport}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                  data-testid="button-cancel-team"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createTeamMutation.isPending || !selectedSport}
                  data-testid="button-submit-team"
                >
                  {createTeamMutation.isPending ? "Creating..." : "Create Team"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {teams.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <UsersIcon className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No teams yet</h3>
            <p className="text-sm text-muted-foreground text-center mb-6 max-w-md">
              Create your first team to start managing players, events, and attendance.
            </p>
            <Button onClick={() => setIsDialogOpen(true)} data-testid="button-create-first-team">
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Team
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {teams.map((team) => (
            <Link key={team.id} href={`/teams/${team.id}`}>
              <Card className="hover-elevate active-elevate-2 h-full" data-testid={`card-team-${team.id}`}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary">
                      <UsersIcon className="h-5 w-5" />
                    </div>
                    <span className="line-clamp-1">{team.name}</span>
                  </CardTitle>
                  <CardDescription>
                    {team.sport} • Created {new Date(team.createdAt).toLocaleDateString()}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">View roster</span>
                    <Button variant="ghost" size="sm" data-testid={`button-view-team-${team.id}`}>
                      Manage
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

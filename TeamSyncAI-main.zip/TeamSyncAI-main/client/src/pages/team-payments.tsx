import { useState } from "react";
import { useParams, Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArrowLeft, Plus, DollarSign, Send, Mail, MessageSquare, Copy, Check, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { usePermissions } from "@/hooks/usePermissions";
import { format } from "date-fns";
import type { Team, Player } from "@shared/schema";

interface PaymentRequest {
  id: string;
  teamId: string;
  title: string;
  description: string | null;
  amount: number;
  dueDate: string | null;
  createdAt: string;
}

interface TeamPayment {
  id: string;
  paymentRequestId: string;
  playerId: string;
  playerFirstName: string;
  playerLastName: string;
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  paidAt: string | null;
}

export default function TeamPayments() {
  const { teamId } = useParams();
  const { toast } = useToast();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isSendLinksDialogOpen, setIsSendLinksDialogOpen] = useState(false);
  const [selectedRequestId, setSelectedRequestId] = useState<string>("");
  const [selectedPlayerIds, setSelectedPlayerIds] = useState<string[]>([]);
  const [sendChannel, setSendChannel] = useState<"sms" | "email" | "manual">("manual");
  const [copiedLinks, setCopiedLinks] = useState<Record<string, boolean>>({});
  const [generatedLinks, setGeneratedLinks] = useState<Array<{ playerId: string; playerName: string; paymentLink: string }>>([]);
  
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    amount: "",
    dueDate: "",
  });

  const { data: team } = useQuery<Team>({
    queryKey: ["/api/teams", teamId],
  });

  const { data: players = [] } = useQuery<Player[]>({
    queryKey: ["/api/teams", teamId, "players"],
    enabled: !!teamId,
  });

  const { data: paymentRequests = [] } = useQuery<PaymentRequest[]>({
    queryKey: [`/api/payment-requests?team=${teamId}`],
    enabled: !!teamId,
  });

  const permissions = usePermissions(teamId);
  const canManagePayments = permissions.canManagePlayers;

  const createPaymentRequestMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return await apiRequest("POST", `/api/teams/${teamId}/payment-requests`, {
        title: data.title,
        description: data.description || null,
        amount: parseFloat(data.amount),
        dueDate: data.dueDate || null,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/payment-requests?team=${teamId}`] });
      setIsCreateDialogOpen(false);
      setFormData({ title: "", description: "", amount: "", dueDate: "" });
      toast({
        title: "Payment request created",
        description: "You can now send payment links to players.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error?.message || "Failed to create payment request",
        variant: "destructive",
      });
    },
  });

  const sendLinksMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", `/api/payment-requests/${selectedRequestId}/send-links`, {
        playerIds: selectedPlayerIds,
        channel: sendChannel,
      });
    },
    onSuccess: (response: any) => {
      queryClient.invalidateQueries({ queryKey: [`/api/payment-requests?team=${teamId}`] });
      
      // If manual channel, show generated links
      if (sendChannel === "manual" && response.results) {
        const links = response.results
          .filter((r: any) => r.success && r.paymentLink)
          .map((r: any) => {
            const player = players.find(p => p.id === r.playerId);
            return {
              playerId: r.playerId,
              playerName: player ? `${player.firstName} ${player.lastName}` : "Unknown",
              paymentLink: r.paymentLink,
            };
          });
        setGeneratedLinks(links);
      } else {
        setIsSendLinksDialogOpen(false);
        setSelectedPlayerIds([]);
        setGeneratedLinks([]);
      }
      
      const successCount = response.results?.filter((r: any) => r.success).length || 0;
      toast({
        title: sendChannel === "manual" ? "Links generated" : "Links sent",
        description: `${successCount} payment link${successCount !== 1 ? 's' : ''} ${sendChannel === "manual" ? "generated" : "sent"} successfully`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error?.message || "Failed to send payment links",
        variant: "destructive",
      });
    },
  });

  const deletePaymentRequestMutation = useMutation({
    mutationFn: async (requestId: string) => {
      return await apiRequest("DELETE", `/api/payment-requests/${requestId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/payment-requests?team=${teamId}`] });
      toast({
        title: "Payment request deleted",
        description: "The payment request has been removed.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error?.message || "Failed to delete payment request",
        variant: "destructive",
      });
    },
  });

  const handleCreateRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.amount) return;
    createPaymentRequestMutation.mutate(formData);
  };

  const handleSendLinks = () => {
    if (!selectedRequestId || selectedPlayerIds.length === 0) return;
    sendLinksMutation.mutate();
  };

  const togglePlayer = (playerId: string) => {
    setSelectedPlayerIds(prev =>
      prev.includes(playerId)
        ? prev.filter(id => id !== playerId)
        : [...prev, playerId]
    );
  };

  const toggleAllPlayers = () => {
    if (selectedPlayerIds.length === players.length) {
      setSelectedPlayerIds([]);
    } else {
      setSelectedPlayerIds(players.map(p => p.id));
    }
  };

  const copyToClipboard = async (link: string, playerId: string) => {
    try {
      await navigator.clipboard.writeText(link);
      setCopiedLinks(prev => ({ ...prev, [playerId]: true }));
      setTimeout(() => {
        setCopiedLinks(prev => ({ ...prev, [playerId]: false }));
      }, 2000);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy link",
        variant: "destructive",
      });
    }
  };

  if (!canManagePayments) {
    return (
      <div className="flex items-center justify-center h-full">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">
              You don't have permission to manage payments for this team.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-4">
          <Link href={`/teams/${teamId}`}>
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">Team Payments</h1>
            <p className="text-muted-foreground">
              {team?.name} - Collect fees from players
            </p>
          </div>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-payment-request">
              <Plus className="h-4 w-4 mr-2" />
              New Payment Request
            </Button>
          </DialogTrigger>
          <DialogContent>
            <form onSubmit={handleCreateRequest}>
              <DialogHeader>
                <DialogTitle>Create Payment Request</DialogTitle>
                <DialogDescription>
                  Create a payment request to collect fees from your players
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Tournament Fee"
                    required
                    data-testid="input-payment-title"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount ($) *</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    placeholder="25.00"
                    required
                    data-testid="input-payment-amount"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Payment for spring tournament entry fee"
                    rows={3}
                    data-testid="input-payment-description"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dueDate">Due Date (Optional)</Label>
                  <Input
                    id="dueDate"
                    type="date"
                    value={formData.dueDate}
                    onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                    data-testid="input-payment-due-date"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsCreateDialogOpen(false)}
                  data-testid="button-cancel-payment"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={!formData.title || !formData.amount || createPaymentRequestMutation.isPending}
                  data-testid="button-submit-payment"
                >
                  {createPaymentRequestMutation.isPending ? "Creating..." : "Create Request"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {paymentRequests.length === 0 ? (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <DollarSign className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No payment requests</h3>
              <p className="text-muted-foreground mb-4">
                Create your first payment request to collect fees from players
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {paymentRequests.map((request) => (
            <Card key={request.id} data-testid={`card-payment-request-${request.id}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-xl">{request.title}</CardTitle>
                    <CardDescription>
                      ${(request.amount / 100).toFixed(2)}
                      {request.dueDate && ` · Due ${format(new Date(request.dueDate), "MMM d, yyyy")}`}
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedRequestId(request.id);
                        setSelectedPlayerIds([]);
                        setGeneratedLinks([]);
                        setIsSendLinksDialogOpen(true);
                      }}
                      data-testid={`button-send-links-${request.id}`}
                    >
                      <Send className="h-4 w-4 mr-2" />
                      Send Links
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon" data-testid={`button-delete-${request.id}`}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete payment request?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This will permanently delete this payment request. This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => deletePaymentRequestMutation.mutate(request.id)}
                            className="bg-destructive hover:bg-destructive/90"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardHeader>
              {request.description && (
                <CardContent>
                  <p className="text-sm text-muted-foreground">{request.description}</p>
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      )}

      {/* Send Links Dialog */}
      <Dialog open={isSendLinksDialogOpen} onOpenChange={setIsSendLinksDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Send Payment Links</DialogTitle>
            <DialogDescription>
              Select players and choose how to send payment links
            </DialogDescription>
          </DialogHeader>

          {generatedLinks.length > 0 ? (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Payment links generated. Copy and share them with your players:
              </p>
              <div className="space-y-2">
                {generatedLinks.map((link) => (
                  <Card key={link.playerId}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex-1">
                          <p className="font-medium">{link.playerName}</p>
                          <p className="text-xs text-muted-foreground truncate">{link.paymentLink}</p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard(link.paymentLink, link.playerId)}
                          data-testid={`button-copy-link-${link.playerId}`}
                        >
                          {copiedLinks[link.playerId] ? (
                            <>
                              <Check className="h-4 w-4 mr-2" />
                              Copied
                            </>
                          ) : (
                            <>
                              <Copy className="h-4 w-4 mr-2" />
                              Copy
                            </>
                          )}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ) : (
            <>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Delivery Method</Label>
                  <Select value={sendChannel} onValueChange={(v: any) => setSendChannel(v)}>
                    <SelectTrigger data-testid="select-send-channel">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manual">
                        <div className="flex items-center gap-2">
                          <Copy className="h-4 w-4" />
                          Manual - Generate links to copy
                        </div>
                      </SelectItem>
                      <SelectItem value="sms">
                        <div className="flex items-center gap-2">
                          <MessageSquare className="h-4 w-4" />
                          SMS - Send via text message
                        </div>
                      </SelectItem>
                      <SelectItem value="email">
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4" />
                          Email - Send via email
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Select Players</Label>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={toggleAllPlayers}
                      data-testid="button-toggle-all-players"
                    >
                      {selectedPlayerIds.length === players.length ? "Deselect All" : "Select All"}
                    </Button>
                  </div>
                  <div className="border rounded-md max-h-64 overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-12"></TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Phone</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {players.map((player) => (
                          <TableRow key={player.id}>
                            <TableCell>
                              <Checkbox
                                checked={selectedPlayerIds.includes(player.id)}
                                onCheckedChange={() => togglePlayer(player.id)}
                                data-testid={`checkbox-player-${player.id}`}
                              />
                            </TableCell>
                            <TableCell>
                              {player.firstName} {player.lastName}
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              {player.email || "-"}
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              {player.phone || "-"}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
            </>
          )}

          <DialogFooter>
            {generatedLinks.length > 0 ? (
              <Button
                onClick={() => {
                  setIsSendLinksDialogOpen(false);
                  setGeneratedLinks([]);
                  setSelectedPlayerIds([]);
                }}
                data-testid="button-close-links"
              >
                Done
              </Button>
            ) : (
              <>
                <Button
                  variant="outline"
                  onClick={() => setIsSendLinksDialogOpen(false)}
                  data-testid="button-cancel-send"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSendLinks}
                  disabled={selectedPlayerIds.length === 0 || sendLinksMutation.isPending}
                  data-testid="button-submit-send"
                >
                  {sendLinksMutation.isPending ? "Sending..." : sendChannel === "manual" ? "Generate Links" : "Send Links"}
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

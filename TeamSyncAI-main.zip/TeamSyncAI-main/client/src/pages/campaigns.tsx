import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { MessageSquare, Plus, Calendar, Clock, Trash2, Edit, ExternalLink, Settings, DollarSign, Send, Mail, Copy, ChevronDown, ChevronRight, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { VariableButtons } from "@/components/variable-buttons";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { CampaignTemplate, TemplateReminder, Team, Event } from "@shared/schema";

interface Campaign {
  id: string;
  teamId: string;
  eventId: string | null;
  eventTitle?: string;
  eventDate?: string;
  eventType?: string;
  reminders?: Array<{
    id: string;
    intervalHours: number;
    messageTemplate?: string;
  }>;
}

function formatReliabilityRange(minReliability: number | null | undefined, maxReliability: number | null | undefined): { label: string; variant: "default" | "secondary" | "outline" } {
  if (minReliability === null || minReliability === undefined) {
    if (maxReliability === null || maxReliability === undefined) {
      return { label: "All Players", variant: "outline" };
    }
  }
  
  if (minReliability === 4 && maxReliability === 5) {
    return { label: "High (4-5)", variant: "default" };
  }
  if (minReliability === 2 && maxReliability === 3) {
    return { label: "Medium (2-3)", variant: "secondary" };
  }
  if (minReliability === 0 && maxReliability === 1) {
    return { label: "Low (0-1)", variant: "outline" };
  }
  
  if (minReliability !== null && minReliability !== undefined && maxReliability !== null && maxReliability !== undefined) {
    return { label: `${minReliability}-${maxReliability}`, variant: "outline" };
  }
  
  return { label: "All Players", variant: "outline" };
}

interface Player {
  id: string;
  firstName: string;
  lastName: string;
  email: string | null;
  phone: string | null;
}

interface PaymentRequest {
  id: string;
  teamId: string;
  title: string;
  description: string | null;
  amount: number;
  dueDate: string | null;
  createdAt: string;
}

interface PaymentStatusData {
  totalPlayers: number;
  completedCount: number;
  pendingCount: number;
  playerPayments: Array<{
    playerId: string;
    playerName: string;
    playerEmail: string | null;
    linkSent: boolean;
    linkChannel: string | null;
    linkSentAt: string | null;
    status: string;
    paidAt: string | null;
  }>;
}

interface PaymentRequestRowProps {
  request: PaymentRequest;
  isExpanded: boolean;
  onToggleExpand: () => void;
  onSendLinks: () => void;
  onDelete: () => void;
}

function PaymentRequestRow({ request, isExpanded, onToggleExpand, onSendLinks, onDelete }: PaymentRequestRowProps) {
  // Fetch payment status for this request
  const { data: paymentStatus, isLoading: statusLoading } = useQuery<PaymentStatusData>({
    queryKey: [`/api/payment-requests/${request.id}/status`],
    enabled: true,
  });

  return (
    <>
      <TableRow data-testid={`row-payment-request-${request.id}`}>
        <TableCell>
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleExpand}
            className="h-8 w-8 p-0"
            data-testid={`button-toggle-payment-${request.id}`}
          >
            {isExpanded ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
          </Button>
        </TableCell>
        <TableCell>
          <div className="flex flex-col gap-1">
            <p className="font-medium">{request.title}</p>
            {request.description && (
              <p className="text-xs text-muted-foreground line-clamp-1">
                {request.description}
              </p>
            )}
          </div>
        </TableCell>
        <TableCell>
          <Badge variant="outline">
            ${(request.amount / 100).toFixed(2)}
          </Badge>
        </TableCell>
        <TableCell>
          {statusLoading ? (
            <span className="text-sm text-muted-foreground">Loading...</span>
          ) : paymentStatus ? (
            <div className="flex items-center gap-2">
              <Badge variant={paymentStatus.completedCount === paymentStatus.totalPlayers ? "default" : "secondary"}>
                {paymentStatus.completedCount} of {paymentStatus.totalPlayers} paid
              </Badge>
            </div>
          ) : (
            <span className="text-sm text-muted-foreground">No links sent</span>
          )}
        </TableCell>
        <TableCell>
          {request.dueDate ? (
            <span className="text-sm">
              {new Date(request.dueDate).toLocaleDateString()}
            </span>
          ) : (
            <span className="text-sm text-muted-foreground">No due date</span>
          )}
        </TableCell>
        <TableCell className="text-right">
          <div className="flex items-center justify-end gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onSendLinks}
              data-testid={`button-send-links-${request.id}`}
            >
              <Send className="h-4 w-4 mr-2" />
              Send Links
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onDelete}
              data-testid={`button-delete-payment-${request.id}`}
            >
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          </div>
        </TableCell>
      </TableRow>
      {isExpanded && paymentStatus && paymentStatus.playerPayments && paymentStatus.playerPayments.length > 0 && (
        <TableRow>
          <TableCell colSpan={6} className="bg-muted/50 p-0">
            <div className="p-4 space-y-2">
              <p className="text-sm font-medium mb-3">Payment Details</p>
              <div className="space-y-2">
                {paymentStatus.playerPayments.map((payment: any) => (
                  <div
                    key={payment.playerId}
                    className="flex items-center justify-between p-2 bg-background rounded border"
                    data-testid={`payment-detail-${payment.playerId}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex items-center justify-center w-6 h-6 rounded-full bg-muted">
                        {payment.status === 'completed' ? (
                          <Check className="h-4 w-4 text-green-600" />
                        ) : (
                          <X className="h-4 w-4 text-muted-foreground" />
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-medium">{payment.playerName}</p>
                        {payment.playerEmail && (
                          <p className="text-xs text-muted-foreground">{payment.playerEmail}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {payment.linkSent && (
                        <Badge variant="outline" className="text-xs">
                          Link sent via {payment.linkChannel}
                        </Badge>
                      )}
                      <Badge variant={payment.status === 'completed' ? 'default' : 'secondary'}>
                        {payment.status === 'completed' ? 'Paid' : 'Pending'}
                      </Badge>
                      {payment.paidAt && (
                        <span className="text-xs text-muted-foreground">
                          {new Date(payment.paidAt).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TableCell>
        </TableRow>
      )}
    </>
  );
}

export default function Campaigns() {
  const { toast } = useToast();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [selectedTeamId, setSelectedTeamId] = useState<string>("");
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("");
  const [isCreateTemplateOpen, setIsCreateTemplateOpen] = useState(false);
  const [isAddReminderOpen, setIsAddReminderOpen] = useState(false);
  const [templateForm, setTemplateForm] = useState({ name: "", description: "" });
  const [reminderForm, setReminderForm] = useState({ 
    intervalHours: "24", 
    messageTemplate: "",
    reliabilityRanges: ["all"] as ("all" | "high" | "medium" | "low")[]
  });
  const [isCreateCampaignOpen, setIsCreateCampaignOpen] = useState(false);
  const [createCampaignTeamId, setCreateCampaignTeamId] = useState<string>("");
  const [selectedEventId, setSelectedEventId] = useState<string>("");
  const [applyTemplateId, setApplyTemplateId] = useState<string>("");
  
  // Payment request state
  const [isCreatePaymentOpen, setIsCreatePaymentOpen] = useState(false);
  const [isSendLinksOpen, setIsSendLinksOpen] = useState(false);
  const [isShowLinksDialogOpen, setIsShowLinksDialogOpen] = useState(false);
  const [isDeletePaymentOpen, setIsDeletePaymentOpen] = useState(false);
  const [selectedPaymentToDelete, setSelectedPaymentToDelete] = useState<string>("");
  const [paymentTeamId, setPaymentTeamId] = useState<string>("");
  const [selectedPaymentRequestId, setSelectedPaymentRequestId] = useState<string>("");
  const [selectedPlayerIds, setSelectedPlayerIds] = useState<string[]>([]);
  const [sendChannel, setSendChannel] = useState<"sms" | "email" | "manual">("manual");
  const [expandedPayments, setExpandedPayments] = useState<Set<string>>(new Set());
  const [generatedPaymentLinks, setGeneratedPaymentLinks] = useState<Array<{ 
    playerId: string; 
    playerName: string; 
    success: boolean; 
    error?: string; 
    paymentLink?: string 
  }>>([]);
  const [paymentFormData, setPaymentFormData] = useState({
    title: "",
    description: "",
    amount: "",
    dueDate: "",
  });
  
  const reminderMessageTextareaRef = useRef<HTMLTextAreaElement>(null);

  const { data: campaigns = [], isLoading } = useQuery<Campaign[]>({
    queryKey: ["/api/campaigns"],
  });

  const { data: teams = [] } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  const { data: templates = [] } = useQuery<CampaignTemplate[]>({
    queryKey: ["/api/teams", selectedTeamId, "campaign-templates"],
    enabled: !!selectedTeamId,
  });

  const { data: reminders = [] } = useQuery<TemplateReminder[]>({
    queryKey: ["/api/campaign-templates", selectedTemplateId, "reminders"],
    enabled: !!selectedTemplateId,
  });

  const { data: eventsWithoutCampaigns = [] } = useQuery<Event[]>({
    queryKey: ["/api/teams", createCampaignTeamId, "events-without-campaigns"],
    enabled: !!createCampaignTeamId,
  });

  const { data: createCampaignTemplates = [] } = useQuery<CampaignTemplate[]>({
    queryKey: ["/api/campaign-templates"],
  });

  // Queries for cost estimation
  const { data: usagePricing } = useQuery<{
    smsBaseCost: number;
    smsMarkupType: 'percentage' | 'fixed';
    smsMarkupValue: number;
  }>({
    queryKey: ["/api/admin/usage-pricing"],
    enabled: isCreateCampaignOpen && !!selectedEventId && selectedEventId !== "standalone",
  });

  const { data: selectedTemplateReminders = [] } = useQuery<TemplateReminder[]>({
    queryKey: ["/api/campaign-templates", applyTemplateId, "reminders"],
    enabled: !!applyTemplateId && applyTemplateId !== "none",
  });

  const { data: eventPlayers = [] } = useQuery<Player[]>({
    queryKey: [`/api/teams/${createCampaignTeamId}/players`],
    enabled: !!createCampaignTeamId && !!selectedEventId && selectedEventId !== "standalone",
  });

  // Payment request queries
  const { data: paymentPlayers = [] } = useQuery<Player[]>({
    queryKey: [`/api/teams/${paymentTeamId}/players`],
    enabled: !!paymentTeamId,
  });

  const { data: paymentRequests = [] } = useQuery<PaymentRequest[]>({
    queryKey: [`/api/payment-requests?team=${paymentTeamId}`],
    enabled: !!paymentTeamId,
  });

  const deleteCampaignMutation = useMutation({
    mutationFn: async (campaignId: string) => {
      return await apiRequest("DELETE", `/api/campaigns/${campaignId}`, undefined);
    },
    onSuccess: () => {
      toast({
        title: "Campaign deleted",
        description: "The reminder campaign has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      setDeleteDialogOpen(false);
      setSelectedCampaign(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete campaign. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createTemplateMutation = useMutation({
    mutationFn: async (data: { name: string; description?: string }) => {
      return await apiRequest("POST", `/api/teams/${selectedTeamId}/campaign-templates`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", selectedTeamId, "campaign-templates"] });
      setIsCreateTemplateOpen(false);
      setTemplateForm({ name: "", description: "" });
      toast({
        title: "Template created",
        description: "Campaign template created successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create template.",
        variant: "destructive",
      });
    },
  });

  const deleteTemplateMutation = useMutation({
    mutationFn: async (templateId: string) => {
      return await apiRequest("DELETE", `/api/campaign-templates/${templateId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", selectedTeamId, "campaign-templates"] });
      setSelectedTemplateId("");
      toast({
        title: "Template deleted",
        description: "Campaign template deleted successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete template.",
        variant: "destructive",
      });
    },
  });

  const addReminderMutation = useMutation({
    mutationFn: async (data: { intervalHours: number; messageTemplate: string; minReliability?: number | null; maxReliability?: number | null }) => {
      return await apiRequest("POST", `/api/campaign-templates/${selectedTemplateId}/reminders`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaign-templates", selectedTemplateId, "reminders"] });
      setIsAddReminderOpen(false);
      setReminderForm({ intervalHours: "24", messageTemplate: "", reliabilityRanges: ["all"] });
      toast({
        title: "Reminder added",
        description: "Reminder added to template successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add reminder.",
        variant: "destructive",
      });
    },
  });

  const deleteReminderMutation = useMutation({
    mutationFn: async (reminderId: string) => {
      return await apiRequest("DELETE", `/api/template-reminders/${reminderId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaign-templates", selectedTemplateId, "reminders"] });
      toast({
        title: "Reminder deleted",
        description: "Reminder removed from template.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete reminder.",
        variant: "destructive",
      });
    },
  });

  const insertVariable = (variable: string) => {
    const textarea = reminderMessageTextareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const currentValue = reminderForm.messageTemplate;
    const newValue = currentValue.substring(0, start) + variable + currentValue.substring(end);
    
    setReminderForm({ ...reminderForm, messageTemplate: newValue });
    
    setTimeout(() => {
      textarea.focus();
      const newCursorPos = start + variable.length;
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  const createCampaignMutation = useMutation({
    mutationFn: async () => {
      let campaign;
      
      // Create either event-based or standalone campaign
      if (selectedEventId && selectedEventId !== "standalone") {
        campaign = await apiRequest("POST", `/api/events/${selectedEventId}/campaign`, {});
        
        if (applyTemplateId && applyTemplateId !== "none") {
          await apiRequest("POST", `/api/events/${selectedEventId}/apply-template`, {
            templateId: applyTemplateId,
          });
        }
      } else {
        // Create standalone campaign (no event)
        campaign = await apiRequest("POST", `/api/teams/${createCampaignTeamId}/campaigns`, {});
      }
      
      return campaign;
    },
    onSuccess: () => {
      // Capture values before clearing state
      const hadEvent = Boolean(selectedEventId && selectedEventId !== "standalone");
      const hadTemplate = applyTemplateId && applyTemplateId !== "none";
      
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      queryClient.invalidateQueries({ queryKey: ["/api/teams", createCampaignTeamId, "events-without-campaigns"] });
      setIsCreateCampaignOpen(false);
      setCreateCampaignTeamId("");
      setSelectedEventId("");
      setApplyTemplateId("");
      toast({
        title: "Campaign created",
        description: hadEvent
          ? (hadTemplate
              ? "Campaign created successfully. Template applied and reminders added to the event." 
              : "Campaign created successfully. You can now add reminders from the event page.")
          : "Standalone campaign created successfully. Note: Standalone campaigns cannot send time-based reminders yet.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create campaign.",
        variant: "destructive",
      });
    },
  });

  // Payment request mutations
  const createPaymentRequestMutation = useMutation({
    mutationFn: async (data: typeof paymentFormData) => {
      return await apiRequest("POST", "/api/payment-requests", {
        teamId: paymentTeamId,
        title: data.title,
        description: data.description || null,
        amount: parseFloat(data.amount),
        dueDate: data.dueDate || null,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/payment-requests?team=${paymentTeamId}`] });
      setIsCreatePaymentOpen(false);
      setPaymentFormData({ title: "", description: "", amount: "", dueDate: "" });
      toast({
        title: "Payment request created",
        description: "You can now send payment links to players.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create payment request.",
        variant: "destructive",
      });
    },
  });

  const sendPaymentLinksMutation = useMutation({
    mutationFn: async () => {
      const channelToUse = sendChannel;
      const response = await apiRequest("POST", `/api/payment-requests/${selectedPaymentRequestId}/send-links`, {
        playerIds: selectedPlayerIds,
        channel: channelToUse,
      });
      return await response.json();
    },
    onSuccess: (data: any, variables, context) => {
      const channelUsed = sendChannel;
      setIsSendLinksOpen(false);
      setSelectedPlayerIds([]);
      
      // If manual channel, show the links dialog
      if (channelUsed === "manual" && data.results) {
        // Enrich results with player names
        const enrichedLinks = data.results.map((result: any) => {
          const player = paymentPlayers.find(p => p.id === result.playerId);
          return {
            ...result,
            playerName: player ? `${player.firstName} ${player.lastName}` : "Unknown Player"
          };
        });
        setGeneratedPaymentLinks(enrichedLinks);
        setIsShowLinksDialogOpen(true);
        // Don't reset channel yet - let user close the links dialog first
      } else if (channelUsed === "sms") {
        setSendChannel("manual"); // Reset only after SMS success
        toast({
          title: "Payment links sent",
          description: `Successfully sent ${data.sent || 0} payment link${data.sent !== 1 ? 's' : ''} via SMS.`,
        });
      } else if (channelUsed === "email") {
        setSendChannel("manual"); // Reset only after email success
        toast({
          title: "Payment emails sent",
          description: `Successfully sent ${data.sent || 0} payment link${data.sent !== 1 ? 's' : ''} via email.`,
        });
      }
      
      // Invalidate payment status queries
      queryClient.invalidateQueries({ queryKey: [`/api/payment-requests/${selectedPaymentRequestId}/status`] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send payment links.",
        variant: "destructive",
      });
    },
  });

  const deletePaymentRequestMutation = useMutation({
    mutationFn: async (paymentRequestId: string) => {
      return await apiRequest("DELETE", `/api/payment-requests/${paymentRequestId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/payment-requests?team=${paymentTeamId}`] });
      setIsDeletePaymentOpen(false);
      setSelectedPaymentToDelete("");
      toast({
        title: "Payment request deleted",
        description: "The payment request has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete payment request.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Campaigns</h1>
          <p className="text-muted-foreground">
            Manage SMS reminder campaigns for your events
          </p>
        </div>
        <Card>
          <CardContent className="py-16 flex justify-center">
            <p className="text-muted-foreground">Loading campaigns...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">Campaigns & Payments</h1>
        <p className="text-muted-foreground">
          Manage SMS campaigns and payment requests for your teams
        </p>
      </div>

      <Tabs defaultValue="campaigns" className="w-full">
        <TabsList data-testid="tabs-campaigns-payments">
          <TabsTrigger value="campaigns" data-testid="tab-campaigns">
            <MessageSquare className="h-4 w-4 mr-2" />
            Campaigns
          </TabsTrigger>
          <TabsTrigger value="payments" data-testid="tab-payments">
            <DollarSign className="h-4 w-4 mr-2" />
            Payment Requests
          </TabsTrigger>
        </TabsList>

        <TabsContent value="campaigns" className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold">SMS Reminder Campaigns</h2>
              <p className="text-sm text-muted-foreground">
                Automated reminders for events
              </p>
            </div>
            <Button
              onClick={() => setIsCreateCampaignOpen(true)}
              data-testid="button-create-campaign"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Campaign
            </Button>
          </div>

      {campaigns.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <MessageSquare className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No campaigns yet</h3>
            <p className="text-sm text-muted-foreground text-center max-w-md mb-4">
              Campaigns are created and managed from individual event pages.
              Navigate to an event to set up reminder campaigns.
            </p>
            <Link href="/events">
              <Button data-testid="link-view-events">
                <Calendar className="h-4 w-4 mr-2" />
                View Events
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Active Campaigns</CardTitle>
            <CardDescription>
              View and manage all reminder campaigns across your events
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Event</TableHead>
                  <TableHead>Message Template</TableHead>
                  <TableHead>Reminders</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {campaigns.map((campaign) => (
                  <TableRow key={campaign.id} data-testid={`row-campaign-${campaign.id}`}>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <Link href={`/events/${campaign.eventId}`}>
                          <button className="text-sm font-medium hover-elevate text-left rounded-sm px-1 -ml-1" data-testid={`link-event-${campaign.eventId}`}>
                            {campaign.eventTitle || "Untitled Event"}
                            <ExternalLink className="h-3 w-3 inline ml-1" />
                          </button>
                        </Link>
                        {campaign.eventDate && (
                          <p className="text-xs text-muted-foreground">
                            {new Date(campaign.eventDate).toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                            })}
                          </p>
                        )}
                        {campaign.eventType && (
                          <Badge variant="outline" className="w-fit text-xs">
                            {campaign.eventType}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <p className="text-sm line-clamp-2 max-w-md">
                        {campaign.reminders && campaign.reminders.length > 0 && campaign.reminders[0].messageTemplate
                          ? campaign.reminders[0].messageTemplate
                          : "No message template"}
                      </p>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        {campaign.reminders && campaign.reminders.length > 0 ? (
                          campaign.reminders.map((reminder) => (
                            <div key={reminder.id} className="flex items-center gap-2 text-xs text-muted-foreground">
                              <Clock className="h-3 w-3" />
                              <span>{reminder.intervalHours}h before event</span>
                            </div>
                          ))
                        ) : (
                          <p className="text-xs text-muted-foreground">No reminders scheduled</p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Link href={`/events/${campaign.eventId}`}>
                          <Button variant="ghost" size="icon" data-testid={`button-edit-campaign-${campaign.id}`}>
                            <Edit className="h-4 w-4" />
                          </Button>
                        </Link>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setSelectedCampaign(campaign);
                            setDeleteDialogOpen(true);
                          }}
                          data-testid={`button-delete-campaign-${campaign.id}`}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Campaign Templates
          </CardTitle>
          <CardDescription>
            Create reusable reminder templates for quick campaign setup
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-end gap-4">
            <div className="flex-1">
              <Label htmlFor="team-select">Select Team</Label>
              <Select value={selectedTeamId} onValueChange={setSelectedTeamId}>
                <SelectTrigger id="team-select" className="mt-1" data-testid="select-team">
                  <SelectValue placeholder="Choose a team..." />
                </SelectTrigger>
                <SelectContent>
                  {teams.map((team) => (
                    <SelectItem key={team.id} value={team.id}>
                      {team.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button
              onClick={() => setIsCreateTemplateOpen(true)}
              disabled={!selectedTeamId}
              data-testid="button-new-template"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Template
            </Button>
          </div>

          {selectedTeamId && (
            <div className="space-y-4 pt-4 border-t">
              <div className="flex items-end gap-4">
                <div className="flex-1">
                  <Label htmlFor="template-select">Select Template</Label>
                  <Select
                    value={selectedTemplateId}
                    onValueChange={setSelectedTemplateId}
                  >
                    <SelectTrigger id="template-select" className="mt-1" data-testid="select-template">
                      <SelectValue placeholder={templates.length === 0 ? "No templates yet" : "Choose a template..."} />
                    </SelectTrigger>
                    <SelectContent>
                      {templates.map((template) => (
                        <SelectItem key={template.id} value={template.id}>
                          {template.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {selectedTemplateId && templates.find(t => t.id === selectedTemplateId)?.description && (
                    <p className="text-sm text-muted-foreground mt-2">
                      {templates.find(t => t.id === selectedTemplateId)?.description}
                    </p>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsAddReminderOpen(true)}
                    disabled={!selectedTemplateId}
                    data-testid="button-add-reminder"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Reminder
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => selectedTemplateId && deleteTemplateMutation.mutate(selectedTemplateId)}
                    disabled={!selectedTemplateId || deleteTemplateMutation.isPending}
                    data-testid="button-delete-template"
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>

              {selectedTemplateId && reminders.length > 0 && (
                <div className="space-y-2">
                  <Label>Reminder Schedule</Label>
                  {reminders
                    .sort((a, b) => b.intervalHours - a.intervalHours)
                    .map((reminder) => (
                      <div
                        key={reminder.id}
                        className="flex items-start gap-3 p-3 rounded-md border bg-muted/30"
                        data-testid={`reminder-${reminder.id}`}
                      >
                        <Clock className="h-4 w-4 text-muted-foreground mt-0.5" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="text-sm font-medium">
                              {reminder.intervalHours} hours before event
                            </p>
                            <Badge 
                              variant={formatReliabilityRange(reminder.minReliability, reminder.maxReliability).variant}
                              className="text-xs"
                              data-testid={`badge-reliability-${reminder.id}`}
                            >
                              {formatReliabilityRange(reminder.minReliability, reminder.maxReliability).label}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1 break-words">
                            {reminder.messageTemplate}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteReminderMutation.mutate(reminder.id)}
                          disabled={deleteReminderMutation.isPending}
                          data-testid={`button-delete-reminder-${reminder.id}`}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    ))}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
        </TabsContent>

        <TabsContent value="payments" className="space-y-6">
          <div className="flex items-end gap-4">
            <div className="flex-1">
              <Label htmlFor="payment-team-select">Select Team</Label>
              <Select value={paymentTeamId} onValueChange={setPaymentTeamId}>
                <SelectTrigger id="payment-team-select" className="mt-1" data-testid="select-payment-team">
                  <SelectValue placeholder="Choose a team..." />
                </SelectTrigger>
                <SelectContent>
                  {teams.map((team) => (
                    <SelectItem key={team.id} value={team.id}>
                      {team.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button 
              onClick={() => setIsCreatePaymentOpen(true)}
              disabled={!paymentTeamId}
              data-testid="button-create-payment-request"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Payment Request
            </Button>
          </div>

          {paymentTeamId && (
            <>
              {paymentRequests.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-16">
                    <DollarSign className="h-16 w-16 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No payment requests yet</h3>
                    <p className="text-sm text-muted-foreground text-center max-w-md mb-4">
                      Create a payment request to collect fees from players. You can send payment links via SMS, email, or copy them manually.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle>Payment Requests</CardTitle>
                    <CardDescription>
                      Manage team fees and send payment links to players
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-8"></TableHead>
                          <TableHead>Title</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Due Date</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {paymentRequests.map((request) => {
                          const isExpanded = expandedPayments.has(request.id);
                          return (
                            <PaymentRequestRow
                              key={request.id}
                              request={request}
                              isExpanded={isExpanded}
                              onToggleExpand={() => {
                                const newExpanded = new Set(expandedPayments);
                                if (isExpanded) {
                                  newExpanded.delete(request.id);
                                } else {
                                  newExpanded.add(request.id);
                                }
                                setExpandedPayments(newExpanded);
                              }}
                              onSendLinks={() => {
                                setSelectedPaymentRequestId(request.id);
                                queryClient.invalidateQueries({ queryKey: [`/api/teams/${paymentTeamId}/players`] });
                                setIsSendLinksOpen(true);
                              }}
                              onDelete={() => {
                                setSelectedPaymentToDelete(request.id);
                                setIsDeletePaymentOpen(true);
                              }}
                            />
                          );
                        })}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Campaign</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this campaign? This will remove all scheduled reminders for this event.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
              data-testid="button-cancel-delete"
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => selectedCampaign && deleteCampaignMutation.mutate(selectedCampaign.id)}
              disabled={deleteCampaignMutation.isPending}
              data-testid="button-confirm-delete"
            >
              {deleteCampaignMutation.isPending ? "Deleting..." : "Delete Campaign"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isCreateTemplateOpen} onOpenChange={setIsCreateTemplateOpen}>
        <DialogContent data-testid="dialog-create-template">
          <DialogHeader>
            <DialogTitle>Create Campaign Template</DialogTitle>
            <DialogDescription>
              Create a reusable template with pre-configured reminder schedules
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="template-name">Template Name</Label>
              <Input
                id="template-name"
                value={templateForm.name}
                onChange={(e) => setTemplateForm({ ...templateForm, name: e.target.value })}
                placeholder="e.g., Weekly Game Reminder"
                data-testid="input-template-name"
              />
            </div>
            <div>
              <Label htmlFor="template-description">Description (Optional)</Label>
              <Textarea
                id="template-description"
                value={templateForm.description}
                onChange={(e) => setTemplateForm({ ...templateForm, description: e.target.value })}
                placeholder="Describe when to use this template..."
                data-testid="input-template-description"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsCreateTemplateOpen(false)}
              data-testid="button-cancel-create-template"
            >
              Cancel
            </Button>
            <Button
              onClick={() => createTemplateMutation.mutate(templateForm)}
              disabled={!templateForm.name || createTemplateMutation.isPending}
              data-testid="button-save-template"
            >
              {createTemplateMutation.isPending ? "Creating..." : "Create Template"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isAddReminderOpen} onOpenChange={setIsAddReminderOpen}>
        <DialogContent data-testid="dialog-add-reminder">
          <DialogHeader>
            <DialogTitle>Add Reminder to Template</DialogTitle>
            <DialogDescription>
              Configure a reminder that will be sent before the event
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="reminder-interval">Hours Before Event</Label>
              <Select
                value={reminderForm.intervalHours}
                onValueChange={(value) => setReminderForm({ ...reminderForm, intervalHours: value })}
              >
                <SelectTrigger id="reminder-interval" className="mt-1" data-testid="select-reminder-interval">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 hour before</SelectItem>
                  <SelectItem value="2">2 hours before</SelectItem>
                  <SelectItem value="4">4 hours before</SelectItem>
                  <SelectItem value="12">12 hours before</SelectItem>
                  <SelectItem value="24">24 hours (1 day) before</SelectItem>
                  <SelectItem value="48">48 hours (2 days) before</SelectItem>
                  <SelectItem value="72">72 hours (3 days) before</SelectItem>
                  <SelectItem value="168">1 week before</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Player Reliability Target</Label>
              <p className="text-xs text-muted-foreground mb-2">
                Select which reliability levels should receive this reminder
              </p>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="reliability-all"
                    checked={reminderForm.reliabilityRanges.includes("all")}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setReminderForm({ ...reminderForm, reliabilityRanges: ["all"] });
                      } else {
                        setReminderForm({ ...reminderForm, reliabilityRanges: [] });
                      }
                    }}
                    data-testid="checkbox-reliability-all"
                  />
                  <Label htmlFor="reliability-all" className="font-normal cursor-pointer">
                    All Players (regardless of reliability)
                  </Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="reliability-high"
                    checked={reminderForm.reliabilityRanges.includes("high")}
                    onCheckedChange={(checked) => {
                      const newRanges = reminderForm.reliabilityRanges.filter(r => r !== "all");
                      if (checked) {
                        setReminderForm({ ...reminderForm, reliabilityRanges: [...newRanges, "high"] });
                      } else {
                        setReminderForm({ ...reminderForm, reliabilityRanges: newRanges.filter(r => r !== "high") });
                      }
                    }}
                    disabled={reminderForm.reliabilityRanges.includes("all")}
                    data-testid="checkbox-reliability-high"
                  />
                  <Label htmlFor="reliability-high" className="font-normal cursor-pointer">
                    High Reliability (4-5 rating)
                  </Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="reliability-medium"
                    checked={reminderForm.reliabilityRanges.includes("medium")}
                    onCheckedChange={(checked) => {
                      const newRanges = reminderForm.reliabilityRanges.filter(r => r !== "all");
                      if (checked) {
                        setReminderForm({ ...reminderForm, reliabilityRanges: [...newRanges, "medium"] });
                      } else {
                        setReminderForm({ ...reminderForm, reliabilityRanges: newRanges.filter(r => r !== "medium") });
                      }
                    }}
                    disabled={reminderForm.reliabilityRanges.includes("all")}
                    data-testid="checkbox-reliability-medium"
                  />
                  <Label htmlFor="reliability-medium" className="font-normal cursor-pointer">
                    Medium Reliability (2-3 rating)
                  </Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="reliability-low"
                    checked={reminderForm.reliabilityRanges.includes("low")}
                    onCheckedChange={(checked) => {
                      const newRanges = reminderForm.reliabilityRanges.filter(r => r !== "all");
                      if (checked) {
                        setReminderForm({ ...reminderForm, reliabilityRanges: [...newRanges, "low"] });
                      } else {
                        setReminderForm({ ...reminderForm, reliabilityRanges: newRanges.filter(r => r !== "low") });
                      }
                    }}
                    disabled={reminderForm.reliabilityRanges.includes("all")}
                    data-testid="checkbox-reliability-low"
                  />
                  <Label htmlFor="reliability-low" className="font-normal cursor-pointer">
                    Low Reliability (0-1 rating)
                  </Label>
                </div>
              </div>
            </div>
            <div>
              <Label htmlFor="reminder-message">Message Template</Label>
              <Textarea
                ref={reminderMessageTextareaRef}
                id="reminder-message"
                value={reminderForm.messageTemplate}
                onChange={(e) => setReminderForm({ ...reminderForm, messageTemplate: e.target.value })}
                placeholder="Reminder: Game at {location} on {date}"
                className="mt-1"
                data-testid="input-reminder-message"
              />
              <div className="mt-2">
                <VariableButtons onInsert={insertVariable} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsAddReminderOpen(false)}
              data-testid="button-cancel-add-reminder"
            >
              Cancel
            </Button>
            <Button
              onClick={async () => {
                if (reminderForm.reliabilityRanges.length === 0) {
                  toast({
                    title: "No reliability range selected",
                    description: "Please select at least one reliability range.",
                    variant: "destructive",
                  });
                  return;
                }

                const intervalHours = parseInt(reminderForm.intervalHours);
                const messageTemplate = reminderForm.messageTemplate;

                const rangeConfigs = reminderForm.reliabilityRanges.map((range) => {
                  if (range === "all") return { minReliability: null, maxReliability: null };
                  if (range === "high") return { minReliability: 4, maxReliability: 5 };
                  if (range === "medium") return { minReliability: 2, maxReliability: 3 };
                  if (range === "low") return { minReliability: 0, maxReliability: 1 };
                  return { minReliability: null, maxReliability: null };
                });

                for (const config of rangeConfigs) {
                  await addReminderMutation.mutateAsync({
                    intervalHours,
                    messageTemplate,
                    ...config,
                  });
                }
              }}
              disabled={!reminderForm.messageTemplate || reminderForm.reliabilityRanges.length === 0 || addReminderMutation.isPending}
              data-testid="button-save-reminder"
            >
              {addReminderMutation.isPending ? "Adding..." : `Add Reminder${reminderForm.reliabilityRanges.length > 1 && !reminderForm.reliabilityRanges.includes("all") ? "s" : ""}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isCreateCampaignOpen} onOpenChange={setIsCreateCampaignOpen}>
        <DialogContent data-testid="dialog-create-campaign">
          <DialogHeader>
            <DialogTitle>Create Campaign</DialogTitle>
            <DialogDescription>
              Create a new SMS reminder campaign for an event (or standalone for general announcements)
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="campaign-team">Select Team</Label>
              <Select
                value={createCampaignTeamId}
                onValueChange={(value) => {
                  setCreateCampaignTeamId(value);
                  setSelectedEventId("");
                  setApplyTemplateId("");
                }}
              >
                <SelectTrigger id="campaign-team" className="mt-1" data-testid="select-campaign-team">
                  <SelectValue placeholder="Choose a team..." />
                </SelectTrigger>
                <SelectContent>
                  {teams.map((team) => (
                    <SelectItem key={team.id} value={team.id}>
                      {team.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {createCampaignTeamId && (
              <>
                <div>
                  <Label htmlFor="campaign-event">Select Event (Optional)</Label>
                  <Select
                    value={selectedEventId}
                    onValueChange={setSelectedEventId}
                  >
                    <SelectTrigger id="campaign-event" className="mt-1" data-testid="select-campaign-event">
                      <SelectValue placeholder="Skip for standalone campaign" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standalone">No event (standalone campaign)</SelectItem>
                      {eventsWithoutCampaigns.map((event) => (
                        <SelectItem key={event.id} value={event.id}>
                          {event.title} - {new Date(event.datetime).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric',
                          })}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">
                    Select an event for time-based reminders, or skip to create a standalone campaign for general announcements
                  </p>
                </div>

                <div>
                  <Label htmlFor="campaign-template">Apply Template (Optional)</Label>
                  <Select
                    value={applyTemplateId}
                    onValueChange={setApplyTemplateId}
                  >
                    <SelectTrigger id="campaign-template" className="mt-1" data-testid="select-campaign-template">
                      <SelectValue placeholder={createCampaignTemplates.length === 0 ? "No templates available" : "Choose a template or skip..."} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No template</SelectItem>
                      {createCampaignTemplates.map((template) => (
                        <SelectItem key={template.id} value={template.id}>
                          {template.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">
                    Optionally apply a template to automatically create reminders
                  </p>
                </div>

                {selectedEventId && selectedEventId !== "standalone" && usagePricing && (() => {
                  // Count only SMS-eligible players (unique players with phone numbers)
                  const smsEligiblePlayers = eventPlayers.filter(p => p.phone && p.phone.trim().length > 0);
                  const playerCount = smsEligiblePlayers.length;
                  
                  // Use template reminders if selected, otherwise show 0 (campaign can have reminders added later)
                  const reminderCount = applyTemplateId && applyTemplateId !== "none" 
                    ? selectedTemplateReminders.length 
                    : 0;
                  
                  // Calculate SMS cost (reusing same logic from usage tracking)
                  // Note: PostgreSQL numeric columns return as strings, so we must parse them
                  const baseCostNum = parseFloat(usagePricing.smsBaseCost as any) || 0;
                  let smsCost = baseCostNum;
                  if (usagePricing.smsMarkupType === 'percentage') {
                    const markupValue = parseFloat(usagePricing.smsMarkupValue as any) || 0;
                    smsCost = baseCostNum * (1 + markupValue / 100);
                  } else {
                    const markupValue = parseFloat(usagePricing.smsMarkupValue as any) || 0;
                    smsCost = baseCostNum + markupValue;
                  }
                  
                  const totalMessages = playerCount * reminderCount;
                  const estimatedCost = totalMessages * smsCost;

                  return (
                    <div className="p-4 bg-muted/50 rounded-md space-y-2" data-testid="cost-estimation">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">Cost Estimation</p>
                        <DollarSign className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <p className="text-xs text-muted-foreground">SMS-Eligible Players</p>
                          <p className="font-semibold" data-testid="text-player-count">{playerCount}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Reminders</p>
                          <p className="font-semibold" data-testid="text-reminder-count">
                            {reminderCount}
                            {reminderCount === 0 && <span className="text-xs text-muted-foreground ml-1">(add later)</span>}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Total Messages</p>
                          <p className="font-semibold" data-testid="text-total-messages">{totalMessages}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Cost per SMS</p>
                          <p className="font-semibold" data-testid="text-sms-cost">${smsCost.toFixed(4)}</p>
                        </div>
                      </div>
                      {totalMessages > 0 ? (
                        <div className="pt-2 border-t">
                          <div className="flex items-center justify-between">
                            <p className="text-sm font-medium">Estimated Total</p>
                            <p className="text-lg font-bold" data-testid="text-estimated-total">${estimatedCost.toFixed(2)}</p>
                          </div>
                        </div>
                      ) : (
                        <div className="pt-2 border-t">
                          <p className="text-xs text-muted-foreground">
                            No reminders selected. Add reminders after creating the campaign to see total cost estimate.
                          </p>
                        </div>
                      )}
                    </div>
                  );
                })()}
              </>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsCreateCampaignOpen(false);
                setCreateCampaignTeamId("");
                setSelectedEventId("");
                setApplyTemplateId("");
              }}
              data-testid="button-cancel-create-campaign"
            >
              Cancel
            </Button>
            <Button
              onClick={() => createCampaignMutation.mutate()}
              disabled={!createCampaignTeamId || createCampaignMutation.isPending}
              data-testid="button-save-campaign"
            >
              {createCampaignMutation.isPending ? "Creating..." : "Create Campaign"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isCreatePaymentOpen} onOpenChange={setIsCreatePaymentOpen}>
        <DialogContent data-testid="dialog-create-payment">
          <DialogHeader>
            <DialogTitle>Create Payment Request</DialogTitle>
            <DialogDescription>
              Create a new payment request to collect fees from players
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="payment-title">Title</Label>
              <Input
                id="payment-title"
                value={paymentFormData.title}
                onChange={(e) => setPaymentFormData({ ...paymentFormData, title: e.target.value })}
                placeholder="e.g., Uniform Fee, Tournament Entry"
                data-testid="input-payment-title"
              />
            </div>
            <div>
              <Label htmlFor="payment-amount">Amount ($)</Label>
              <Input
                id="payment-amount"
                type="number"
                step="0.01"
                min="0"
                value={paymentFormData.amount}
                onChange={(e) => setPaymentFormData({ ...paymentFormData, amount: e.target.value })}
                placeholder="0.00"
                data-testid="input-payment-amount"
              />
            </div>
            <div>
              <Label htmlFor="payment-description">Description (Optional)</Label>
              <Textarea
                id="payment-description"
                value={paymentFormData.description}
                onChange={(e) => setPaymentFormData({ ...paymentFormData, description: e.target.value })}
                placeholder="Additional details about this payment..."
                data-testid="input-payment-description"
              />
            </div>
            <div>
              <Label htmlFor="payment-due-date">Due Date (Optional)</Label>
              <Input
                id="payment-due-date"
                type="date"
                value={paymentFormData.dueDate}
                onChange={(e) => setPaymentFormData({ ...paymentFormData, dueDate: e.target.value })}
                data-testid="input-payment-due-date"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsCreatePaymentOpen(false);
                setPaymentFormData({ title: "", description: "", amount: "", dueDate: "" });
              }}
              data-testid="button-cancel-payment"
            >
              Cancel
            </Button>
            <Button
              onClick={() => createPaymentRequestMutation.mutate(paymentFormData)}
              disabled={!paymentFormData.title || !paymentFormData.amount || parseFloat(paymentFormData.amount) <= 0 || createPaymentRequestMutation.isPending}
              data-testid="button-save-payment"
            >
              {createPaymentRequestMutation.isPending ? "Creating..." : "Create Payment Request"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isSendLinksOpen} onOpenChange={setIsSendLinksOpen}>
        <DialogContent data-testid="dialog-send-links">
          <DialogHeader>
            <DialogTitle>Send Payment Links</DialogTitle>
            <DialogDescription>
              Select players and choose how to send payment links
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Select Players</Label>
              <div className="mt-2 space-y-2 max-h-64 overflow-y-auto border rounded-md p-3">
                <div className="flex items-center gap-2 pb-2 border-b">
                  <Checkbox
                    id="select-all-players"
                    checked={selectedPlayerIds.length === paymentPlayers.length && paymentPlayers.length > 0}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setSelectedPlayerIds(paymentPlayers.map(p => p.id));
                      } else {
                        setSelectedPlayerIds([]);
                      }
                    }}
                    data-testid="checkbox-select-all-players"
                  />
                  <Label htmlFor="select-all-players" className="font-medium cursor-pointer">
                    Select All ({paymentPlayers.length})
                  </Label>
                </div>
                {paymentPlayers.map((player) => (
                  <div key={player.id} className="flex items-center gap-2">
                    <Checkbox
                      id={`player-${player.id}`}
                      checked={selectedPlayerIds.includes(player.id)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedPlayerIds([...selectedPlayerIds, player.id]);
                        } else {
                          setSelectedPlayerIds(selectedPlayerIds.filter(id => id !== player.id));
                        }
                      }}
                      data-testid={`checkbox-player-${player.id}`}
                    />
                    <Label htmlFor={`player-${player.id}`} className="font-normal cursor-pointer flex-1">
                      {player.firstName} {player.lastName}
                      {player.phone && (
                        <span className="text-xs text-muted-foreground ml-2">
                          {player.phone}
                        </span>
                      )}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label htmlFor="send-channel">Distribution Channel</Label>
              <Select value={sendChannel} onValueChange={(value: "sms" | "email" | "manual") => setSendChannel(value)}>
                <SelectTrigger id="send-channel" className="mt-1" data-testid="select-send-channel">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sms">
                    <div className="flex items-center gap-2">
                      <MessageSquare className="h-4 w-4" />
                      <span>SMS (Text Message)</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="email" disabled>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4" />
                      <span>Email (Coming Soon)</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="manual">
                    <div className="flex items-center gap-2">
                      <Copy className="h-4 w-4" />
                      <span>Manual (Copy Links)</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground mt-1">
                {sendChannel === "sms" && "Payment links will be sent via SMS to selected players"}
                {sendChannel === "email" && "Payment links will be sent via email to selected players"}
                {sendChannel === "manual" && "You'll receive payment links to copy and share manually"}
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsSendLinksOpen(false);
                setSelectedPlayerIds([]);
                setSendChannel("manual");
              }}
              data-testid="button-cancel-send-links"
            >
              Cancel
            </Button>
            <Button
              onClick={() => sendPaymentLinksMutation.mutate()}
              disabled={selectedPlayerIds.length === 0 || sendPaymentLinksMutation.isPending}
              data-testid="button-send-links"
            >
              {sendPaymentLinksMutation.isPending ? "Sending..." : `Send to ${selectedPlayerIds.length} Player${selectedPlayerIds.length !== 1 ? 's' : ''}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Show Payment Links Dialog */}
      <Dialog open={isShowLinksDialogOpen} onOpenChange={setIsShowLinksDialogOpen}>
        <DialogContent className="max-w-2xl" data-testid="dialog-show-payment-links">
          <DialogHeader>
            <DialogTitle>Payment Links Generated</DialogTitle>
            <DialogDescription>
              Copy and share these payment links with your players
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {generatedPaymentLinks.map((link) => (
              <div key={link.playerId} className="border rounded-md p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{link.playerName}</span>
                  {link.success ? (
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      Ready
                    </Badge>
                  ) : (
                    <Badge variant="destructive">
                      Failed
                    </Badge>
                  )}
                </div>
                {link.success && link.paymentLink ? (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={link.paymentLink}
                        readOnly
                        className="flex-1 px-3 py-2 text-sm border rounded-md bg-muted"
                        data-testid={`input-payment-link-${link.playerId}`}
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          navigator.clipboard.writeText(link.paymentLink!);
                          toast({
                            title: "Link copied",
                            description: `Payment link for ${link.playerName} copied to clipboard.`,
                          });
                        }}
                        data-testid={`button-copy-link-${link.playerId}`}
                      >
                        <Copy className="h-4 w-4 mr-2" />
                        Copy
                      </Button>
                    </div>
                  </div>
                ) : link.success && !link.paymentLink ? (
                  <p className="text-sm text-destructive">Payment link was not generated</p>
                ) : (
                  <p className="text-sm text-destructive">{link.error || "Unknown error"}</p>
                )}
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button
              onClick={() => {
                setIsShowLinksDialogOpen(false);
                setGeneratedPaymentLinks([]);
                setSendChannel("manual"); // Reset channel after manual flow completes
              }}
              data-testid="button-close-payment-links"
            >
              Done
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isDeletePaymentOpen} onOpenChange={setIsDeletePaymentOpen}>
        <DialogContent data-testid="dialog-delete-payment">
          <DialogHeader>
            <DialogTitle>Delete Payment Request</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this payment request? This will remove all payment links and cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsDeletePaymentOpen(false)}
              data-testid="button-cancel-delete-payment"
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => deletePaymentRequestMutation.mutate(selectedPaymentToDelete)}
              disabled={deletePaymentRequestMutation.isPending}
              data-testid="button-confirm-delete-payment"
            >
              {deletePaymentRequestMutation.isPending ? "Deleting..." : "Delete Payment Request"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

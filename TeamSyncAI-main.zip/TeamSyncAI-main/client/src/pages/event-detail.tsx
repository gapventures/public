import { useState, useEffect, useRef } from "react";
import { useParams, Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArrowLeft, Users, CheckCircle2, XCircle, HelpCircle, Clock, MessageSquare, Download, Send, Calendar, Plus, Trash2, Settings, Edit2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { VariableButtons } from "@/components/variable-buttons";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Event, Player, Response, CampaignTemplate, TemplateReminder, CustomField } from "@shared/schema";
import { usePermissions } from "@/hooks/usePermissions";
import { LineupManager } from "@/components/LineupManager";

interface PlayerResponse extends Player {
  response?: Response;
}

export default function EventDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [messageTemplate, setMessageTemplate] = useState("");
  const [pollingInterval, setPollingInterval] = useState<number | null>(null);
  const [reminderDialogOpen, setReminderDialogOpen] = useState(false);
  const [campaignDialogOpen, setCampaignDialogOpen] = useState(false);
  const [newReminderHours, setNewReminderHours] = useState("");
  const [newReminderTemplate, setNewReminderTemplate] = useState("");
  const [newReliabilityThreshold, setNewReliabilityThreshold] = useState<string>("all");
  const [editingReminderId, setEditingReminderId] = useState<string | null>(null);
  const [editInterval, setEditInterval] = useState("");
  const [editTemplate, setEditTemplate] = useState("");
  const [editReliabilityThreshold, setEditReliabilityThreshold] = useState<string>("all");
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  
  const newReminderTextareaRef = useRef<HTMLTextAreaElement>(null);
  const editReminderTextareaRef = useRef<HTMLTextAreaElement>(null);
  const manualMessageTextareaRef = useRef<HTMLTextAreaElement>(null);

  const { data: event, isLoading: eventLoading } = useQuery<Event>({
    queryKey: ["/api/events", id],
  });

  const permissions = usePermissions(event?.teamId);

  const { data: templates = [] } = useQuery<CampaignTemplate[]>({
    queryKey: ["/api/teams", event?.teamId, "campaign-templates"],
    enabled: !!event?.teamId,
  });

  const { data: customFields = [] } = useQuery<CustomField[]>({
    queryKey: ["/api/admin/custom-fields"],
  });

  const { data: playersWithResponses = [], isLoading: playersLoading } = useQuery<PlayerResponse[]>({
    queryKey: ["/api/events", id, "responses"],
  });

  const { data: campaign } = useQuery<any>({
    queryKey: ["/api/events", id, "campaign"],
    enabled: !!event,
  });

  const { data: reminders = [] } = useQuery<any[]>({
    queryKey: ["/api/campaigns", campaign?.id, "reminders"],
    enabled: !!campaign,
  });

  const { data: nextReminderData } = useQuery<{ nextReminder: any; allUpcoming: any[] }>({
    queryKey: ["/api/events", id, "next-reminder"],
    enabled: !!event,
  });

  // Poll for updates every 5 seconds
  useEffect(() => {
    const interval = window.setInterval(() => {
      queryClient.invalidateQueries({ queryKey: ["/api/events", id, "responses"] });
    }, 5000);

    return () => {
      window.clearInterval(interval);
    };
  }, [id]);

  const sendReminderMutation = useMutation({
    mutationFn: async (template: string) => {
      return await apiRequest("POST", `/api/events/${id}/send-reminder-now`, { messageTemplate: template });
    },
    onSuccess: () => {
      toast({
        title: "Reminder sent",
        description: "SMS reminders have been sent to all players.",
      });
      setReminderDialogOpen(false);
      setMessageTemplate("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send reminders. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateResponseMutation = useMutation({
    mutationFn: async ({ playerId, status }: { playerId: string; status: string }) => {
      return await apiRequest("POST", `/api/events/${id}/responses/${playerId}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events", id, "responses"] });
    },
  });

  const createCampaignMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", `/api/events/${id}/campaign`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events", id, "campaign"] });
      toast({
        title: "Campaign created",
        description: "You can now add reminder schedules.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create campaign.",
        variant: "destructive",
      });
    },
  });

  const applyTemplateMutation = useMutation({
    mutationFn: async (templateId: string) => {
      return await apiRequest("POST", `/api/events/${id}/apply-template`, { templateId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events", id, "campaign"] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      queryClient.invalidateQueries({ queryKey: ["/api/events", id, "next-reminder"] });
      setSelectedTemplateId("");
      toast({
        title: "Template applied",
        description: "Campaign created with reminders from the template.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to apply template. Please try again.",
        variant: "destructive",
      });
    },
  });

  const addReminderMutation = useMutation({
    mutationFn: async ({ intervalHours, messageTemplate, targetReliabilityThreshold }: { intervalHours: number; messageTemplate: string; targetReliabilityThreshold: number | null }) => {
      return await apiRequest("POST", `/api/campaigns/${campaign.id}/reminders`, {
        intervalHours,
        messageTemplate,
        targetReliabilityThreshold,
        targetStatusFilter: null,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns", campaign?.id, "reminders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      queryClient.invalidateQueries({ queryKey: ["/api/events", id, "next-reminder"] });
      setNewReminderHours("");
      setNewReminderTemplate("");
      setNewReliabilityThreshold("all");
      toast({
        title: "Reminder added",
        description: "The reminder has been added to your campaign.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add reminder.",
        variant: "destructive",
      });
    },
  });

  const updateReminderMutation = useMutation({
    mutationFn: async ({ id, intervalHours, messageTemplate, targetReliabilityThreshold }: { id: string; intervalHours: number; messageTemplate: string; targetReliabilityThreshold: number | null }) => {
      return await apiRequest("PUT", `/api/reminders/${id}`, {
        intervalHours,
        messageTemplate,
        targetReliabilityThreshold,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns", campaign?.id, "reminders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      queryClient.invalidateQueries({ queryKey: ["/api/events", id, "next-reminder"] });
      setEditingReminderId(null);
      setEditInterval("");
      setEditTemplate("");
      setEditReliabilityThreshold("all");
      toast({
        title: "Reminder updated",
        description: "The reminder has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update reminder.",
        variant: "destructive",
      });
    },
  });

  const deleteReminderMutation = useMutation({
    mutationFn: async (reminderId: string) => {
      return await apiRequest("DELETE", `/api/reminders/${reminderId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns", campaign?.id, "reminders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      queryClient.invalidateQueries({ queryKey: ["/api/events", id, "next-reminder"] });
      toast({
        title: "Reminder deleted",
        description: "The reminder has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete reminder.",
        variant: "destructive",
      });
    },
  });

  const deleteEventMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("DELETE", `/api/events/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      toast({
        title: "Event deleted",
        description: "The event has been deleted successfully.",
      });
      setLocation("/events");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete event.",
        variant: "destructive",
      });
    },
  });

  const insertVariable = (textareaRef: React.RefObject<HTMLTextAreaElement>, setter: (value: string) => void, currentValue: string, variable: string) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const newValue = currentValue.substring(0, start) + variable + currentValue.substring(end);
    
    setter(newValue);
    
    setTimeout(() => {
      textarea.focus();
      const newCursorPos = start + variable.length;
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  const exportToCSV = () => {
    const headers = permissions.canManagePlayers
      ? ["Player", "Phone", "Status", "Note", "Reliability Score"]
      : ["Player", "Phone", "Status", "Note"];
    
    const rows = playersWithResponses.map((p) => {
      const baseRow = [
        `${p.firstName} ${p.lastName}`,
        p.phone,
        p.response?.status || "No Response",
        p.response?.note || "",
      ];
      
      if (permissions.canManagePlayers) {
        baseRow.push(p.reliabilityScore.toString());
      }
      
      return baseRow;
    });
    
    const csv = [headers, ...rows]
      .map((row) => row.map((cell) => `"${cell}"`).join(","))
      .join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `attendance-${event?.type}-${new Date(event?.datetime || "").toISOString().split("T")[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const yesPlayers = playersWithResponses.filter((p) => p.response?.status === "yes");
  const noPlayers = playersWithResponses.filter((p) => p.response?.status === "no");
  const maybePlayers = playersWithResponses.filter((p) => p.response?.status === "maybe");
  const pendingPlayers = playersWithResponses.filter((p) => !p.response || p.response.status === "pending");

  if (eventLoading || playersLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading event...</p>
        </div>
      </div>
    );
  }

  if (!event) {
    return <div>Event not found</div>;
  }

  const PlayerCard = ({ player }: { player: PlayerResponse }) => (
    <div
      className="flex items-start gap-3 p-3 rounded-md border hover-elevate"
      data-testid={`card-player-${player.response?.status || 'pending'}-${player.id}`}
    >
      <Avatar className="h-10 w-10 flex-shrink-0">
        <AvatarFallback>{getInitials(`${player.firstName} ${player.lastName}`)}</AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <p className="font-medium">{`${player.firstName} ${player.lastName}`}</p>
        {!player.response?.status && (
          <p className="text-sm text-muted-foreground">No reply</p>
        )}
        {player.response?.note && (
          <p className="text-sm text-muted-foreground line-clamp-2">{player.response.note}</p>
        )}
        {player.response?.responseText && (
          <p className="text-xs text-muted-foreground italic mt-1">
            "{player.response.responseText}"
          </p>
        )}
      </div>
      {permissions.canManageAttendance && (
        <div className="flex gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => updateResponseMutation.mutate({ playerId: player.id, status: "yes" })}
            data-testid={`button-status-yes-${player.id}`}
          >
            <CheckCircle2 className={`h-4 w-4 ${player.response?.status === "yes" ? "text-green-600" : "text-muted-foreground"}`} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => updateResponseMutation.mutate({ playerId: player.id, status: "no" })}
            data-testid={`button-status-no-${player.id}`}
          >
            <XCircle className={`h-4 w-4 ${player.response?.status === "no" ? "text-red-600" : "text-muted-foreground"}`} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => updateResponseMutation.mutate({ playerId: player.id, status: "maybe" })}
            data-testid={`button-status-maybe-${player.id}`}
          >
            <HelpCircle className={`h-4 w-4 ${player.response?.status === "maybe" ? "text-yellow-600" : "text-muted-foreground"}`} />
          </Button>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-6 pb-20 md:pb-6">
      <div className="flex items-start gap-4">
        <Link href="/events">
          <Button variant="ghost" size="icon" data-testid="button-back">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <div className="flex-1">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div>
              <h1 className="text-3xl font-semibold tracking-tight capitalize">{event.type}</h1>
              <p className="text-muted-foreground">
                {new Date(event.datetime).toLocaleString('en-US', {
                  weekday: 'long',
                  month: 'long',
                  day: 'numeric',
                  hour: 'numeric',
                  minute: '2-digit',
                })}
              </p>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button variant="outline" onClick={exportToCSV} data-testid="button-export-csv">
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
              {permissions.canManageEvents && (
                <Link href={`/events/${id}/edit`}>
                  <Button variant="outline" data-testid="button-edit-event">
                    <Edit2 className="h-4 w-4 mr-2" />
                    Edit Event
                  </Button>
                </Link>
              )}
              {permissions.canManageEvents && (
                <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline" data-testid="button-delete-event">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete Event
                    </Button>
                  </AlertDialogTrigger>
                <AlertDialogContent data-testid="dialog-delete-event">
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete Event?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to delete this {event.type}? This action cannot be undone. 
                      All associated campaigns, reminders, and responses will also be deleted.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => deleteEventMutation.mutate()}
                      disabled={deleteEventMutation.isPending}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      data-testid="button-confirm-delete"
                    >
                      {deleteEventMutation.isPending ? "Deleting..." : "Delete Event"}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
              )}
            </div>
          </div>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Event Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <p className="text-sm text-muted-foreground">Location</p>
              <p className="font-medium">{event.location}</p>
            </div>
            {event.opponent && (
              <div>
                <p className="text-sm text-muted-foreground">Opponent</p>
                <p className="font-medium">{event.opponent}</p>
              </div>
            )}
            {event.homeAway && (
              <div>
                <p className="text-sm text-muted-foreground">Home/Away</p>
                <Badge variant="outline" className="capitalize">{event.homeAway}</Badge>
              </div>
            )}
            {event.fieldType && (
              <div>
                <p className="text-sm text-muted-foreground">Field Type</p>
                <Badge variant="outline" className="capitalize">{event.fieldType}</Badge>
              </div>
            )}
            {event.cleatsAllowed && (
              <div>
                <p className="text-sm text-muted-foreground">Cleats</p>
                <p className="font-medium capitalize">{event.cleatsAllowed}</p>
              </div>
            )}
            {event.jersey && (
              <div>
                <p className="text-sm text-muted-foreground">Jersey</p>
                <p className="font-medium">{event.jersey}</p>
              </div>
            )}
            {event.arrivalTime && (
              <div>
                <p className="text-sm text-muted-foreground">Arrival Time</p>
                <p className="font-medium">{event.arrivalTime}</p>
              </div>
            )}
          </div>
          {event.notes && (
            <div className="mt-4">
              <p className="text-sm text-muted-foreground">Notes</p>
              <p className="mt-1">{event.notes}</p>
            </div>
          )}
          {event.customFieldValues && Object.keys(event.customFieldValues).length > 0 && (() => {
            const customFieldEntries = Object.entries(event.customFieldValues as Record<string, string>);
            const validEntries = customFieldEntries.filter(([fieldId, value]) => {
              const field = customFields.find(f => f.id === fieldId);
              return field && value !== undefined && value !== null && value !== "";
            });
            
            if (validEntries.length === 0) return null;
            
            return (
              <div className="mt-6 pt-6 border-t" key="custom-fields-section">
                <h3 className="text-lg font-medium mb-4">Additional Information</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  {validEntries.map(([fieldId, value]) => {
                    const field = customFields.find(f => f.id === fieldId);
                    if (!field) return null;
                    return (
                      <div key={fieldId}>
                        <p className="text-sm text-muted-foreground">{field.name}</p>
                        <p className="font-medium">{String(value)}</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })() as React.ReactNode}
        </CardContent>
      </Card>

      {(event.sport === 'Baseball' || event.sport === 'Softball') && event.teamId && (
        <LineupManager event={event} teamId={event.teamId} />
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Confirmed</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold" data-testid="text-yes-count">{yesPlayers.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Declined</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold" data-testid="text-no-count">{noPlayers.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Maybe</CardTitle>
            <HelpCircle className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold" data-testid="text-maybe-count">{maybePlayers.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">No Response</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold" data-testid="text-pending-count">{pendingPlayers.length}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-600">
              <CheckCircle2 className="h-5 w-5" />
              YES ({yesPlayers.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 max-h-96 overflow-y-auto">
            {yesPlayers.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                No confirmed players yet
              </p>
            ) : (
              yesPlayers.map((player) => <PlayerCard key={player.id} player={player} />)
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-600">
              <XCircle className="h-5 w-5" />
              NO ({noPlayers.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 max-h-96 overflow-y-auto">
            {noPlayers.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                No declined players
              </p>
            ) : (
              noPlayers.map((player) => <PlayerCard key={player.id} player={player} />)
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              NO RESPONSE / MAYBE ({pendingPlayers.length + maybePlayers.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 max-h-96 overflow-y-auto">
            {[...maybePlayers, ...pendingPlayers].length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                All players have responded
              </p>
            ) : (
              <>
                {maybePlayers.map((player) => <PlayerCard key={player.id} player={player} />)}
                {pendingPlayers.map((player) => (
                  <div
                    key={player.id}
                    className="flex items-center gap-3 p-3 rounded-md border"
                    data-testid={`card-player-pending-${player.id}`}
                  >
                    <Avatar className="h-10 w-10">
                      <AvatarFallback>{getInitials(`${player.firstName} ${player.lastName}`)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-medium">{`${player.firstName} ${player.lastName}`}</p>
                      <p className="text-sm text-muted-foreground">No reply</p>
                    </div>
                  </div>
                ))}
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {permissions.canManageCampaigns && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Reminder Campaign
            </CardTitle>
            <CardDescription>
              Configure automated SMS reminder schedule for this event
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {!campaign ? (
            <div className="space-y-4 p-6 border rounded-md bg-muted/20">
              <div className="flex items-center gap-3 mb-4">
                <Clock className="h-8 w-8 text-muted-foreground" />
                <div>
                  <h3 className="font-medium">No campaign configured yet</h3>
                  <p className="text-sm text-muted-foreground">Create a campaign or use a template to get started</p>
                </div>
              </div>
              
              <div className="space-y-3">
                <Label>Use Campaign Template</Label>
                {templates.length > 0 ? (
                  <>
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <Select value={selectedTemplateId} onValueChange={setSelectedTemplateId}>
                          <SelectTrigger data-testid="select-template">
                            <SelectValue placeholder="Choose a template..." />
                          </SelectTrigger>
                          <SelectContent>
                            {templates.map((template) => (
                              <SelectItem key={template.id} value={template.id}>
                                {template.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <Button
                        onClick={() => selectedTemplateId && applyTemplateMutation.mutate(selectedTemplateId)}
                        disabled={!selectedTemplateId || applyTemplateMutation.isPending}
                        data-testid="button-apply-template"
                      >
                        {applyTemplateMutation.isPending ? "Applying..." : "Apply"}
                      </Button>
                    </div>
                    {selectedTemplateId && (
                      <p className="text-sm text-muted-foreground">
                        {templates.find(t => t.id === selectedTemplateId)?.description}
                      </p>
                    )}
                  </>
                ) : (
                  <div className="p-4 border rounded-md bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-3">
                      No templates available yet. Create reusable templates to save time on future campaigns.
                    </p>
                    <Link href="/campaigns">
                      <Button variant="outline" size="sm" className="w-full" data-testid="link-create-templates">
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Go to Campaigns to Create Templates
                      </Button>
                    </Link>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-3">
                <div className="flex-1 border-t"></div>
                <span className="text-sm text-muted-foreground">OR</span>
                <div className="flex-1 border-t"></div>
              </div>

              <Button
                onClick={() => createCampaignMutation.mutate()}
                disabled={createCampaignMutation.isPending}
                variant="outline"
                className="w-full"
                data-testid="button-create-campaign"
              >
                {createCampaignMutation.isPending ? "Creating..." : "Create Empty Campaign"}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {reminders.length > 0 && (
                <div className="space-y-2">
                  <Label>Scheduled Reminders</Label>
                  {reminders
                    .sort((a: any, b: any) => b.intervalHours - a.intervalHours)
                    .map((reminder: any) => (
                      editingReminderId === reminder.id ? (
                        <div
                          key={reminder.id}
                          className="p-3 rounded-md border bg-muted/30 space-y-3"
                          data-testid={`reminder-edit-${reminder.id}`}
                        >
                          <div>
                            <Label className="text-sm">Hours Before Event</Label>
                            <Select value={editInterval} onValueChange={setEditInterval}>
                              <SelectTrigger className="mt-1" data-testid={`select-edit-interval-${reminder.id}`}>
                                <SelectValue placeholder="Select interval" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="1">1 hour before</SelectItem>
                                <SelectItem value="2">2 hours before</SelectItem>
                                <SelectItem value="4">4 hours before</SelectItem>
                                <SelectItem value="12">12 hours before</SelectItem>
                                <SelectItem value="24">24 hours (1 day) before</SelectItem>
                                <SelectItem value="48">48 hours (2 days) before</SelectItem>
                                <SelectItem value="72">72 hours (3 days) before</SelectItem>
                                <SelectItem value="168">1 week before</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label className="text-sm">Target Reliability (Optional)</Label>
                            <Select value={editReliabilityThreshold} onValueChange={setEditReliabilityThreshold}>
                              <SelectTrigger className="mt-1" data-testid={`select-edit-reliability-${reminder.id}`}>
                                <SelectValue placeholder="All players" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="all">All players</SelectItem>
                                <SelectItem value="3">Players rated 3 or below</SelectItem>
                                <SelectItem value="2">Players rated 2 or below</SelectItem>
                                <SelectItem value="1">Players rated 1 only</SelectItem>
                              </SelectContent>
                            </Select>
                            <p className="text-xs text-muted-foreground mt-1">
                              Target players with lower reliability for more frequent reminders
                            </p>
                          </div>
                          <div>
                            <Label className="text-sm">Message Template</Label>
                            <Textarea
                              ref={editReminderTextareaRef}
                              placeholder="Message template..."
                              value={editTemplate}
                              onChange={(e) => setEditTemplate(e.target.value)}
                              rows={3}
                              className="mt-1"
                              data-testid={`input-edit-template-${reminder.id}`}
                            />
                            <div className="mt-2">
                              <VariableButtons 
                                onInsert={(variable) => insertVariable(editReminderTextareaRef, setEditTemplate, editTemplate, variable)}
                              />
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              onClick={() => updateReminderMutation.mutate({
                                id: reminder.id,
                                intervalHours: parseInt(editInterval),
                                messageTemplate: editTemplate,
                                targetReliabilityThreshold: editReliabilityThreshold && editReliabilityThreshold !== "all" ? parseInt(editReliabilityThreshold) : null,
                              })}
                              disabled={!editInterval || !editTemplate.trim() || updateReminderMutation.isPending}
                              className="flex-1"
                              data-testid={`button-save-reminder-${reminder.id}`}
                            >
                              {updateReminderMutation.isPending ? "Saving..." : "Save Changes"}
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setEditingReminderId(null);
                                setEditInterval("");
                                setEditTemplate("");
                                setEditReliabilityThreshold("all");
                              }}
                              data-testid={`button-cancel-edit-${reminder.id}`}
                            >
                              Cancel
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div
                          key={reminder.id}
                          className="flex items-start gap-3 p-3 rounded-md border bg-muted/30"
                          data-testid={`reminder-item-${reminder.id}`}
                        >
                          <Clock className="h-5 w-5 text-muted-foreground mt-0.5" />
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm">
                              {reminder.intervalHours} hours before event
                              {reminder.targetReliabilityThreshold && (
                                <span className="ml-2 text-xs font-normal text-muted-foreground">
                                  (Players ≤{reminder.targetReliabilityThreshold})
                                </span>
                              )}
                            </p>
                            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                              {reminder.messageTemplate}
                            </p>
                          </div>
                          <div className="flex gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                setEditingReminderId(reminder.id);
                                setEditInterval(reminder.intervalHours.toString());
                                setEditTemplate(reminder.messageTemplate);
                                setEditReliabilityThreshold(reminder.targetReliabilityThreshold?.toString() || "all");
                              }}
                              data-testid={`button-edit-reminder-${reminder.id}`}
                            >
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => deleteReminderMutation.mutate(reminder.id)}
                              disabled={deleteReminderMutation.isPending}
                              data-testid={`button-delete-reminder-${reminder.id}`}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </div>
                      )
                    ))}
                </div>
              )}

              <div className="space-y-3 pt-4 border-t">
                <Label>Apply Campaign Template</Label>
                {templates.length > 0 ? (
                  <>
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <Select value={selectedTemplateId} onValueChange={setSelectedTemplateId}>
                          <SelectTrigger data-testid="select-template-existing">
                            <SelectValue placeholder="Choose a template..." />
                          </SelectTrigger>
                          <SelectContent>
                            {templates.map((template) => (
                              <SelectItem key={template.id} value={template.id}>
                                {template.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <Button
                        onClick={() => selectedTemplateId && applyTemplateMutation.mutate(selectedTemplateId)}
                        disabled={!selectedTemplateId || applyTemplateMutation.isPending}
                        data-testid="button-apply-template-existing"
                      >
                        {applyTemplateMutation.isPending ? "Applying..." : "Apply"}
                      </Button>
                    </div>
                    {selectedTemplateId && (
                      <p className="text-sm text-muted-foreground">
                        {templates.find(t => t.id === selectedTemplateId)?.description}
                      </p>
                    )}
                  </>
                ) : (
                  <div className="p-4 border rounded-md bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-3">
                      No templates available yet. Create reusable templates to quickly add reminder sets.
                    </p>
                    <Link href="/campaigns">
                      <Button variant="outline" size="sm" className="w-full" data-testid="link-create-templates-existing">
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Go to Campaigns to Create Templates
                      </Button>
                    </Link>
                  </div>
                )}
              </div>

              <div className="space-y-3 pt-4 border-t">
                <Label>Add New Reminder</Label>
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="interval" className="text-sm">Hours Before Event</Label>
                    <Select value={newReminderHours} onValueChange={setNewReminderHours}>
                      <SelectTrigger id="interval" className="mt-1" data-testid="select-reminder-interval">
                        <SelectValue placeholder="Select interval" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 hour before</SelectItem>
                        <SelectItem value="2">2 hours before</SelectItem>
                        <SelectItem value="4">4 hours before</SelectItem>
                        <SelectItem value="12">12 hours before</SelectItem>
                        <SelectItem value="24">24 hours (1 day) before</SelectItem>
                        <SelectItem value="48">48 hours (2 days) before</SelectItem>
                        <SelectItem value="72">72 hours (3 days) before</SelectItem>
                        <SelectItem value="168">1 week before</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="reliability" className="text-sm">Target Reliability (Optional)</Label>
                    <Select value={newReliabilityThreshold} onValueChange={setNewReliabilityThreshold}>
                      <SelectTrigger id="reliability" className="mt-1" data-testid="select-reliability-threshold">
                        <SelectValue placeholder="All players" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All players</SelectItem>
                        <SelectItem value="3">Players rated 3 or below</SelectItem>
                        <SelectItem value="2">Players rated 2 or below</SelectItem>
                        <SelectItem value="1">Players rated 1 only</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground mt-1">
                      Target players with lower reliability for more frequent reminders
                    </p>
                  </div>
                  <div>
                    <Label htmlFor="template" className="text-sm">Message Template</Label>
                    <Textarea
                      ref={newReminderTextareaRef}
                      id="template"
                      placeholder="Hey [Player Name]! We have a [Event Type] vs. [Opponent] on [Date] at [Time]. Can you make it? Reply 1 for YES, 2 for NO, 3 for MAYBE."
                      value={newReminderTemplate}
                      onChange={(e) => setNewReminderTemplate(e.target.value)}
                      rows={3}
                      className="mt-1"
                      data-testid="input-reminder-template"
                    />
                    <div className="mt-2">
                      <VariableButtons 
                        onInsert={(variable) => insertVariable(newReminderTextareaRef, setNewReminderTemplate, newReminderTemplate, variable)}
                      />
                    </div>
                  </div>
                  <Button
                    onClick={() => addReminderMutation.mutate({
                      intervalHours: parseInt(newReminderHours),
                      messageTemplate: newReminderTemplate,
                      targetReliabilityThreshold: newReliabilityThreshold && newReliabilityThreshold !== "all" ? parseInt(newReliabilityThreshold) : null,
                    })}
                    disabled={!newReminderHours || !newReminderTemplate.trim() || addReminderMutation.isPending}
                    className="w-full"
                    data-testid="button-add-reminder"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    {addReminderMutation.isPending ? "Adding..." : "Add Reminder"}
                  </Button>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      )}

      {permissions.canSendReminders && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Send className="h-5 w-5" />
              Manual Communication
          </CardTitle>
          <CardDescription>
            Send an immediate SMS to all players right now
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Dialog open={reminderDialogOpen} onOpenChange={setReminderDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="default" className="w-full" data-testid="button-open-reminder-dialog">
                <Send className="h-4 w-4 mr-2" />
                Send Manual Reminder Now
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Send SMS Reminder</DialogTitle>
                <DialogDescription>
                  Send an immediate SMS reminder to all players on the team
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <Label htmlFor="message">Message Template</Label>
                  <Textarea
                    ref={manualMessageTextareaRef}
                    id="message"
                    placeholder="Hey {firstName}! We have a {eventType} vs. {opponent} on {date} at {time}. Can you make it? Reply 1 for YES, 2 for NO, 3 for MAYBE."
                    value={messageTemplate}
                    onChange={(e) => setMessageTemplate(e.target.value)}
                    rows={5}
                    className="mt-2"
                    data-testid="input-message-template"
                  />
                  <div className="mt-2">
                    <VariableButtons 
                      onInsert={(variable) => insertVariable(manualMessageTextareaRef, setMessageTemplate, messageTemplate, variable)}
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setReminderDialogOpen(false)}
                  data-testid="button-cancel-reminder"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => sendReminderMutation.mutate(messageTemplate)}
                  disabled={sendReminderMutation.isPending || !messageTemplate}
                  data-testid="button-send-reminder"
                >
                  {sendReminderMutation.isPending ? "Sending..." : "Send to All Players"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>
      )}
    </div>
  );
}

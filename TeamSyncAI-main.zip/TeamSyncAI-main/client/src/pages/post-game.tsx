import { useState } from "react";
import { useParams, Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArrowLeft, CheckCircle2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Event, Player, Response } from "@shared/schema";
import { usePermissions } from "@/hooks/usePermissions";

interface PlayerResponse extends Player {
  response?: Response;
}

export default function PostGame() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [attendance, setAttendance] = useState<Record<string, boolean>>({});

  const { data: event, isLoading: eventLoading } = useQuery<Event>({
    queryKey: ["/api/events", id],
  });

  const permissions = usePermissions(event?.teamId);

  const { data: playersWithResponses = [], isLoading: playersLoading } = useQuery<PlayerResponse[]>({
    queryKey: ["/api/events", id, "responses"],
  });

  const confirmAttendanceMutation = useMutation({
    mutationFn: async (attendanceData: Record<string, boolean>) => {
      return await apiRequest("POST", `/api/events/${id}/confirm-attendance`, { attendance: attendanceData });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events", id] });
      toast({
        title: "Attendance confirmed",
        description: "Reliability scores have been updated automatically.",
      });
      setLocation(`/events/${id}`);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to confirm attendance. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    confirmAttendanceMutation.mutate(attendance);
  };

  const toggleAttendance = (playerId: string) => {
    setAttendance((prev) => ({
      ...prev,
      [playerId]: !prev[playerId],
    }));
  };

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName[0]}${lastName[0]}`.toUpperCase();
  };

  const getFullName = (player: PlayerResponse) => {
    return `${player.firstName} ${player.lastName}`;
  };

  const getReliabilityImpact = (player: PlayerResponse, attended: boolean) => {
    const committed = player.response?.status === "yes";
    const declined = player.response?.status === "no";
    const maybe = player.response?.status === "maybe";

    if (committed && attended) return { change: "+1", color: "text-green-600" };
    if (committed && !attended) return { change: "-1", color: "text-red-600" };
    if ((declined || maybe) && attended) return { change: "+0.5", color: "text-green-600" };
    if (maybe && !attended) return { change: "-0.5", color: "text-yellow-600" };
    return { change: "0", color: "text-muted-foreground" };
  };

  if (eventLoading || playersLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading event...</p>
        </div>
      </div>
    );
  }

  if (!event) {
    return <div>Event not found</div>;
  }

  const yesPlayers = playersWithResponses.filter((p) => p.response?.status === "yes");
  const otherPlayers = playersWithResponses.filter((p) => p.response?.status !== "yes");

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href={`/events/${id}`}>
          <Button variant="ghost" size="icon" data-testid="button-back">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Post-Game Confirmation</h1>
          <p className="text-muted-foreground capitalize">
            {event.type} - {new Date(event.datetime).toLocaleDateString()}
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                Confirmed Players ({yesPlayers.length})
              </CardTitle>
              <CardDescription>
                Mark which players actually showed up. Reliability scores will be adjusted automatically.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {yesPlayers.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No confirmed players for this event
                </p>
              ) : (
                yesPlayers.map((player) => {
                  const attended = attendance[player.id] || false;
                  const impact = getReliabilityImpact(player, attended);
                  return (
                    <div
                      key={player.id}
                      className="flex items-center gap-4 p-3 rounded-md border"
                      data-testid={`card-attendance-${player.id}`}
                    >
                      <Checkbox
                        id={`attend-${player.id}`}
                        checked={attended}
                        onCheckedChange={() => toggleAttendance(player.id)}
                        data-testid={`checkbox-attendance-${player.id}`}
                      />
                      <label
                        htmlFor={`attend-${player.id}`}
                        className="flex items-center gap-3 flex-1 cursor-pointer"
                      >
                        <Avatar className="h-10 w-10">
                          <AvatarFallback>{getInitials(player.firstName, player.lastName)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="font-medium">{getFullName(player)}</p>
                          {permissions.canManagePlayers && (
                            <p className="text-sm text-muted-foreground">
                              Current reliability: {player.reliabilityScore.toFixed(1)}
                            </p>
                          )}
                        </div>
                      </label>
                      {permissions.canManagePlayers && (
                        <Badge variant={attended ? "default" : "secondary"} className={impact.color}>
                          {impact.change}
                        </Badge>
                      )}
                    </div>
                  );
                })
              )}
            </CardContent>
          </Card>

          {otherPlayers.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Other Players</CardTitle>
                <CardDescription>
                  Players who didn't confirm or declined. Mark if they showed up anyway.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {otherPlayers.map((player) => {
                  const attended = attendance[player.id] || false;
                  const impact = getReliabilityImpact(player, attended);
                  return (
                    <div
                      key={player.id}
                      className="flex items-center gap-4 p-3 rounded-md border"
                      data-testid={`card-attendance-other-${player.id}`}
                    >
                      <Checkbox
                        id={`attend-${player.id}`}
                        checked={attended}
                        onCheckedChange={() => toggleAttendance(player.id)}
                        data-testid={`checkbox-attendance-other-${player.id}`}
                      />
                      <label
                        htmlFor={`attend-${player.id}`}
                        className="flex items-center gap-3 flex-1 cursor-pointer"
                      >
                        <Avatar className="h-10 w-10">
                          <AvatarFallback>{getInitials(player.firstName, player.lastName)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="font-medium">{getFullName(player)}</p>
                          <p className="text-sm text-muted-foreground">
                            {player.response?.status
                              ? `Replied: ${player.response.status}`
                              : "No reply"}
                          </p>
                        </div>
                      </label>
                      {permissions.canManagePlayers && attended && (
                        <Badge variant="default" className={impact.color}>
                          {impact.change}
                        </Badge>
                      )}
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          )}

          <div className="flex gap-4">
            <Link href={`/events/${id}`} className="flex-1 md:flex-initial">
              <Button
                type="button"
                variant="outline"
                className="w-full md:w-auto"
                data-testid="button-cancel"
              >
                Cancel
              </Button>
            </Link>
            <Button
              type="submit"
              className="flex-1 md:flex-initial"
              disabled={confirmAttendanceMutation.isPending}
              data-testid="button-confirm-attendance"
            >
              {confirmAttendanceMutation.isPending ? "Confirming..." : "Confirm Attendance"}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}

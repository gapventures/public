import { Button } from "@/components/ui/button";
import { Users } from "lucide-react";
import { useAppName } from "@/hooks/useAppName";
import { useOrganizationLogo } from "@/hooks/useOrganizationLogo";
import { Link } from "wouter";
import { MarketingFooter } from "@/components/marketing-footer";

export default function Privacy() {
  const appName = useAppName();
  const logoUrl = useOrganizationLogo();

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-3 md:py-4 flex justify-between items-center gap-2">
          <Link href="/" data-testid="link-home-logo">
            <div className="flex items-center gap-2 md:gap-3 cursor-pointer hover-elevate rounded-md p-2 -m-2 min-w-0">
              {logoUrl ? (
                <img 
                  src={logoUrl} 
                  alt="Logo" 
                  className="h-8 md:h-10 w-auto object-contain flex-shrink-0"
                  data-testid="img-header-logo"
                />
              ) : (
                <Users className="h-5 md:h-6 w-5 md:w-6 text-primary flex-shrink-0" />
              )}
              <span className="hidden sm:block text-lg md:text-xl font-bold truncate">{appName}</span>
            </div>
          </Link>
          <nav className="flex items-center gap-1 md:gap-4 flex-shrink-0">
            <Link 
              href="/about" 
              className="hidden md:inline-flex text-sm font-medium hover-elevate rounded-md px-3 py-2" 
              data-testid="link-about"
            >
              About
            </Link>
            <Link 
              href="/features" 
              className="hidden md:inline-flex text-sm font-medium hover-elevate rounded-md px-3 py-2" 
              data-testid="link-features"
            >
              Features
            </Link>
            <Link 
              href="/pricing" 
              className="text-xs md:text-sm font-medium hover-elevate rounded-md px-2 md:px-3 py-2" 
              data-testid="link-pricing"
            >
              Pricing
            </Link>
            <Link 
              href="/contact" 
              className="text-xs md:text-sm font-medium hover-elevate rounded-md px-2 md:px-3 py-2" 
              data-testid="link-contact"
            >
              Contact
            </Link>
            <Link href="/login">
              <Button size="sm" data-testid="button-login">Log In</Button>
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="container mx-auto px-4 py-8 md:py-16 landscape:py-6">
          <div className="max-w-4xl mx-auto prose dark:prose-invert">
            <h1 className="text-3xl md:text-4xl font-bold mb-2" data-testid="text-heading">
              Privacy Policy
            </h1>
            <p className="text-muted-foreground mb-8" data-testid="text-effective-date">
              Effective Date: November 2025 | Last Updated: 11/25/2025
            </p>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Introduction</h2>
              <p className="text-muted-foreground mb-4">
                TeamSyncAI ("we," "us," or "our") respects the privacy of our users ("user" or "you"). 
                This Privacy Policy explains how we collect, use, disclose, and safeguard your information 
                when you visit our website at team-sync-ai.com or use our services. Please read this privacy 
                policy carefully. If you do not agree with the terms of this privacy policy, please do not 
                access the site.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Collection of Your Information</h2>
              <p className="text-muted-foreground mb-4">
                We may collect information about you in a variety of ways. The information we may collect includes:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
                <li>
                  <strong>Personal Data:</strong> Personally identifiable information, such as your name, 
                  shipping address, email address, and telephone number, that you voluntarily give to us 
                  when you register with the site or our mobile application, or when you choose to participate 
                  in various activities related to the site and our services.
                </li>
                <li>
                  <strong>Derivative Data:</strong> Information our servers automatically collect when you 
                  access the Site, such as your IP address, your browser type, your operating system, your 
                  access times, and the pages you have viewed directly before and after accessing the Site.
                </li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Use of Your Information</h2>
              <p className="text-muted-foreground mb-4">
                Having accurate information about you permits us to provide you with a smooth, efficient, 
                and customized experience. Specifically, we may use information collected about you via the Site to:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
                <li>Create and manage your account.</li>
                <li>Process payments and refunds.</li>
                <li>Send you a welcome email or SMS message.</li>
                <li>Notify you of updates to the product.</li>
                <li>Request feedback and contact you about your use of the Site.</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Disclosure of Your Information</h2>
              <p className="text-muted-foreground mb-4">
                We may share information we have collected about you in certain situations. Your information 
                may be disclosed as follows:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
                <li>
                  <strong>By Law or to Protect Rights:</strong> If we believe the release of information about 
                  you is necessary to respond to legal process, to investigate or remedy potential violations 
                  of our policies, or to protect the rights, property, and safety of others, we may share your 
                  information as permitted or required by any applicable law, rule, or regulation.
                </li>
                <li>
                  <strong>Third-Party Service Providers:</strong> We may share your information with third 
                  parties that perform services for us or on our behalf, including payment processing, data 
                  analysis, email delivery, hosting services, customer service, and marketing assistance.
                </li>
              </ul>
            </section>

            <section className="mb-8 bg-muted p-6 rounded-lg">
              <h2 className="text-2xl font-semibold mb-4">IMPORTANT: SMS/Mobile Privacy Clause</h2>
              <p className="text-muted-foreground mb-4">
                Notwithstanding the above, <strong>no mobile information will be shared with third parties/affiliates 
                for marketing/promotional purposes</strong>. All the above categories exclude text messaging originator 
                opt-in data and consent; this information will not be shared with any third parties.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Security of Your Information</h2>
              <p className="text-muted-foreground mb-4">
                We use administrative, technical, and physical security measures to help protect your personal 
                information. While we have taken reasonable steps to secure the personal information you provide 
                to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, 
                and no method of data transmission can be guaranteed against any interception or other type of misuse.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Policy for Children</h2>
              <p className="text-muted-foreground mb-4">
                We do not knowingly solicit information from or market to children under the age of 13. If you 
                become aware of any data we have collected from children under age 13, please contact us using 
                the contact information provided below.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Controls for Do-Not-Track Features</h2>
              <p className="text-muted-foreground mb-4">
                Most web browsers and some mobile operating systems include a Do-Not-Track ("DNT") feature or 
                setting you can activate to signal your privacy preference not to have data about your online 
                browsing activities monitored and collected. No uniform technology standard for recognizing and 
                implementing DNT signals has been finalized. As such, we do not currently respond to DNT browser 
                signals or any other mechanism that automatically communicates your choice not to be tracked online.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
              <p className="text-muted-foreground mb-4">
                If you have questions or comments about this Privacy Policy, please contact us at:
              </p>
              <div className="bg-muted p-6 rounded-lg">
                <p className="font-semibold mb-2">TeamSyncAI</p>
                <p className="text-muted-foreground">St. Louis, MO</p>
                <p className="text-muted-foreground">
                  Email: <a href="mailto:support@team-sync-ai.com" className="text-primary hover:underline">support@team-sync-ai.com</a>
                </p>
                <p className="text-muted-foreground">
                  Phone: <a href="tel:8556773180" className="text-primary hover:underline">855-677-3180</a>
                </p>
              </div>
            </section>
          </div>
        </section>
      </main>

      <MarketingFooter />
    </div>
  );
}

import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CheckCircle2, CreditCard, Loader2, AlertCircle } from "lucide-react";
import { z } from "zod";

const emailSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  confirmEmail: z.string().email("Please enter a valid email address"),
}).refine((data) => data.email === data.confirmEmail, {
  message: "Email addresses must match",
  path: ["confirmEmail"],
});

type PaymentInfo = {
  paymentRequestId: string;
  playerId: string;
  playerName: string;
  title: string;
  amount: number;
};

export default function GuestPaymentPage() {
  const { token } = useParams<{ token: string }>();
  const { toast } = useToast();

  const [email, setEmail] = useState("");
  const [confirmEmail, setConfirmEmail] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [helcimScriptLoaded, setHelcimScriptLoaded] = useState(false);
  const [processingPayment, setProcessingPayment] = useState(false);
  const [checkoutToken, setCheckoutToken] = useState<string | null>(null);

  // Fetch payment info using the token
  const { data: paymentInfo, isLoading, error } = useQuery<PaymentInfo>({
    queryKey: ["/api/payment-links", token],
    queryFn: async () => {
      const response = await fetch(`/api/payment-links/${token}`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Invalid or expired payment link");
      }
      return response.json();
    },
    enabled: !!token,
    retry: false,
  });

  // Load HelcimPay.js script
  useEffect(() => {
    // Check if script already loaded
    const existingScript = document.querySelector('script[src="https://secure.helcim.app/helcim-pay/services/start.js"]');
    if (existingScript) {
      setHelcimScriptLoaded(true);
      return;
    }

    const script = document.createElement("script");
    script.src = "https://secure.helcim.app/helcim-pay/services/start.js";
    script.async = true;
    
    script.onload = () => {
      setHelcimScriptLoaded(true);
    };

    script.onerror = () => {
      toast({
        title: "Payment system unavailable",
        description: "Unable to load payment processing. Please try again later.",
        variant: "destructive",
      });
    };

    document.body.appendChild(script);

    return () => {
      // Keep script loaded for reuse
    };
  }, [toast]);

  // Listen for HelcimPay message events
  useEffect(() => {
    if (!checkoutToken) return;

    const handleMessage = async (event: MessageEvent) => {
      // Verify message is from Helcim
      if (event.origin !== 'https://secure.helcim.app') {
        return;
      }

      // Parse event data (some browsers send as string)
      let eventData;
      try {
        eventData = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
      } catch (e) {
        console.error('Failed to parse HelcimPay event data:', e);
        return;
      }

      // Validate parsed data is an object with required properties
      if (!eventData || typeof eventData !== 'object' || Array.isArray(eventData)) {
        return;
      }

      // Ensure required fields are strings
      if (typeof eventData.eventName !== 'string' || typeof eventData.eventStatus !== 'string') {
        console.warn('HelcimPay event missing required fields:', eventData);
        return;
      }

      // Check if message is for our checkout session
      const helcimEventName = `helcim-pay-js-${checkoutToken}`;
      if (eventData.eventName !== helcimEventName) {
        return;
      }

      console.log('HelcimPay event:', eventData);

      // Handle SUCCESS status
      if (eventData.eventStatus === 'SUCCESS') {
        setProcessingPayment(true);

        try {
          const transactionData = eventData.eventMessage?.data;
          if (!transactionData?.id) {
            throw new Error('No transaction ID received from payment processor');
          }

          // Record payment on backend
          const response = await apiRequest(
            "POST",
            `/api/payment-links/${token}/pay`,
            {
              email,
              helcimTransactionId: transactionData.id,
            }
          );

          if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || "Failed to record payment");
          }

          setPaymentSuccess(true);
          toast({
            title: "Payment successful!",
            description: "Your payment has been processed. You will receive a confirmation email shortly.",
          });
        } catch (error) {
          console.error('Error recording payment:', error);
          toast({
            title: "Payment processed but confirmation failed",
            description: error instanceof Error ? error.message : "Please contact support if you don't receive confirmation.",
            variant: "destructive",
          });
        } finally {
          setProcessingPayment(false);
        }
      }
      // Handle ABORTED status
      else if (eventData.eventStatus === 'ABORTED') {
        console.error('HelcimPay aborted:', eventData.eventMessage);
        setProcessingPayment(false);
        toast({
          title: "Payment failed",
          description: eventData.eventMessage?.message || "Please try again or use a different payment method.",
          variant: "destructive",
        });
      }
      // Handle HIDE status (modal closed)
      else if (eventData.eventStatus === 'HIDE') {
        console.log('HelcimPay modal closed');
        setProcessingPayment(false);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [checkoutToken, email, token, toast]);

  const initializePaymentMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest(
        "POST",
        `/api/payment-links/${token}/initialize`,
        {}
      );
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to initialize payment");
      }
      
      return response.json();
    },
    onSuccess: (data: { checkoutToken: string; secretToken: string }) => {
      // Store checkout token for event handling
      setCheckoutToken(data.checkoutToken);
      
      // Open HelcimPay modal
      // @ts-expect-error - HelcimPay global function
      if (window.appendHelcimPayIframe) {
        setProcessingPayment(true);
        // @ts-expect-error - HelcimPay global function
        window.appendHelcimPayIframe(data.checkoutToken);
      } else {
        toast({
          title: "Payment system not ready",
          description: "Please refresh the page and try again.",
          variant: "destructive",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to start payment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    // Validate email
    const validation = emailSchema.safeParse({ email, confirmEmail });
    if (!validation.success) {
      const fieldErrors: Record<string, string> = {};
      validation.error.errors.forEach((err) => {
        if (err.path[0]) {
          fieldErrors[err.path[0] as string] = err.message;
        }
      });
      setErrors(fieldErrors);
      return;
    }

    // Initialize payment
    initializePaymentMutation.mutate();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
          <p className="text-muted-foreground">Loading payment information...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="max-w-md w-full">
          <CardHeader>
            <div className="flex items-center gap-2 text-destructive mb-2">
              <AlertCircle className="h-5 w-5" />
              <CardTitle>Invalid Payment Link</CardTitle>
            </div>
            <CardDescription>
              {(error as Error).message || "This payment link is invalid or has expired."}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Please contact your team administrator for a new payment link.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!paymentInfo) {
    return null;
  }

  if (paymentSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="max-w-md w-full">
          <CardHeader>
            <div className="flex items-center gap-2 text-green-600 dark:text-green-500 mb-2">
              <CheckCircle2 className="h-6 w-6" />
              <CardTitle>Payment Successful!</CardTitle>
            </div>
            <CardDescription>
              Your payment has been processed successfully
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-muted p-4 rounded-md space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Payment For:</span>
                <span className="font-medium">{paymentInfo.title}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Amount:</span>
                <span className="font-medium">${(paymentInfo.amount / 100).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Email:</span>
                <span className="font-medium">{email}</span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              A confirmation email has been sent to {email}. If you have any questions, please contact your team administrator.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 py-8">
      <div className="max-w-md mx-auto space-y-6">
        {/* Payment Summary Card */}
        <Card>
          <CardHeader>
            <CardTitle>Payment Request</CardTitle>
            <CardDescription>
              Complete your payment securely
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-muted p-4 rounded-md space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Player:</span>
                <span className="font-medium">{paymentInfo.playerName}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Description:</span>
                <span className="font-medium">{paymentInfo.title}</span>
              </div>
              <div className="flex justify-between text-lg border-t mt-2 pt-2">
                <span className="font-semibold">Amount Due:</span>
                <span className="font-bold text-primary">${(paymentInfo.amount / 100).toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Form Card */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              <CardTitle>Your Information</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handlePayment} className="space-y-4">
              {/* Email Fields */}
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  required
                  data-testid="input-guest-email"
                  disabled={processingPayment || initializePaymentMutation.isPending}
                />
                {errors.email && (
                  <p className="text-sm text-destructive">{errors.email}</p>
                )}
                <p className="text-xs text-muted-foreground">
                  Receipt will be sent to this email
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmEmail">Confirm Email</Label>
                <Input
                  id="confirmEmail"
                  type="email"
                  value={confirmEmail}
                  onChange={(e) => setConfirmEmail(e.target.value)}
                  placeholder="your@email.com"
                  required
                  data-testid="input-guest-confirm-email"
                  disabled={processingPayment || initializePaymentMutation.isPending}
                />
                {errors.confirmEmail && (
                  <p className="text-sm text-destructive">{errors.confirmEmail}</p>
                )}
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                className="w-full"
                disabled={processingPayment || initializePaymentMutation.isPending || !helcimScriptLoaded}
                data-testid="button-submit-payment"
              >
                {processingPayment || initializePaymentMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    {processingPayment ? "Processing..." : "Preparing payment..."}
                  </>
                ) : (
                  <>
                    <CreditCard className="h-4 w-4 mr-2" />
                    Pay ${(paymentInfo.amount / 100).toFixed(2)}
                  </>
                )}
              </Button>

              <p className="text-xs text-center text-muted-foreground">
                Your payment is processed securely through Helcim. Card information is never stored on our servers.
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

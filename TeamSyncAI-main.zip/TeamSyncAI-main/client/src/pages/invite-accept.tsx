import { useEffect, useState } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { CheckCircle2, FileText, AlertCircle, Loader2 } from "lucide-react";
import type { Invitation, Team, Role, TeamDocument } from "@shared/schema";

interface InvitationData {
  invitation: Invitation;
  team: Team;
  role: Role;
}

export default function InviteAccept() {
  const [, params] = useRoute("/invite/:token");
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { isAuthenticated, user } = useAuth();
  const [signedDocuments, setSignedDocuments] = useState<Set<string>>(new Set());
  const [acknowledgments, setAcknowledgments] = useState<Record<string, string>>({});

  const token = params?.token;

  // Store invitation token for post-registration redirect when page loads
  useEffect(() => {
    if (token && !isAuthenticated) {
      sessionStorage.setItem("pendingInvitationToken", token);
    }
  }, [token, isAuthenticated]);

  // Fetch invitation details
  const { data: invitationData, isLoading: isLoadingInvitation, error: invitationError } = useQuery<InvitationData>({
    queryKey: [`/api/invitations/token/${token}`],
    enabled: !!token,
  });

  // Fetch team documents
  const { data: documents = [] } = useQuery<TeamDocument[]>({
    queryKey: [`/api/teams/${invitationData?.team?.id}/documents`],
    enabled: !!invitationData?.team?.id,
  });

  // Accept invitation mutation
  const acceptMutation = useMutation({
    mutationFn: async () => {
      // First, sign all required documents
      for (const doc of documents.filter(d => d.requiresSignature)) {
        await apiRequest("POST", `/api/documents/${doc.id}/signatures`, {
          acknowledgmentText: acknowledgments[doc.id] || "I agree",
          invitationId: invitationData?.invitation.id,
        });
      }

      // Then accept the invitation
      return await apiRequest("POST", `/api/invitations/${token}/accept`, {});
    },
    onSuccess: () => {
      toast({
        title: "Invitation accepted!",
        description: `You've successfully joined ${invitationData?.team?.name}. Please complete your profile.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      navigate("/profile");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to accept invitation",
        variant: "destructive",
      });
    },
  });

  const handleDocumentToggle = (docId: string) => {
    setSignedDocuments(prev => {
      const newSet = new Set(prev);
      if (newSet.has(docId)) {
        newSet.delete(docId);
      } else {
        newSet.add(docId);
      }
      return newSet;
    });
  };

  const handleAcknowledgmentChange = (docId: string, value: string) => {
    setAcknowledgments(prev => ({
      ...prev,
      [docId]: value,
    }));
  };

  const allRequiredDocumentsSigned = documents
    .filter(d => d.requiresSignature)
    .every(d => signedDocuments.has(d.id) && acknowledgments[d.id]?.trim());

  const handleAccept = () => {
    if (!isAuthenticated) {
      // Redirect to login with return URL
      toast({
        title: "Login required",
        description: "Please log in to accept this invitation",
      });
      // Store the token in localStorage to resume after login
      localStorage.setItem("pendingInviteToken", token || "");
      window.location.href = "/";
      return;
    }

    if (!allRequiredDocumentsSigned) {
      toast({
        title: "Documents required",
        description: "Please review and sign all required documents",
        variant: "destructive",
      });
      return;
    }

    acceptMutation.mutate();
  };

  // Check for pending invitation after authentication
  useEffect(() => {
    if (isAuthenticated && token) {
      const pendingToken = localStorage.getItem("pendingInviteToken");
      if (pendingToken === token) {
        localStorage.removeItem("pendingInviteToken");
      }
    }
  }, [isAuthenticated, token]);

  if (isLoadingInvitation) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (invitationError || !invitationData) {
    return (
      <div className="flex items-center justify-center min-h-screen p-4">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-destructive" />
              Invalid Invitation
            </CardTitle>
            <CardDescription>
              This invitation link is invalid or has expired.
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={() => navigate("/")} variant="outline" data-testid="button-go-home">
              Go to Home
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  const { invitation, team, role } = invitationData;

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Invitation Header */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Team Invitation</CardTitle>
            <CardDescription>
              You've been invited to join {team.name}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Team:</span>
                <span className="font-medium">{team.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Role:</span>
                <span className="font-medium">{role.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Contact:</span>
                <span className="font-medium">{invitation.contactValue}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Documents Section */}
        {documents.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Required Documents
              </CardTitle>
              <CardDescription>
                Please review and sign the following documents before joining
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {documents.map((doc) => (
                <div key={doc.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium">{doc.title}</h4>
                      {doc.description && (
                        <p className="text-sm text-muted-foreground mt-1">{doc.description}</p>
                      )}
                    </div>
                    {doc.requiresSignature && (
                      <CheckCircle2
                        className={`h-5 w-5 ${signedDocuments.has(doc.id) ? "text-primary" : "text-muted-foreground"}`}
                      />
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(`/objects/${doc.fileUrl}`, "_blank")}
                      data-testid={`button-view-document-${doc.id}`}
                    >
                      View Document
                    </Button>
                  </div>

                  {doc.requiresSignature && (
                    <div className="space-y-3 pt-2 border-t">
                      <div className="space-y-2">
                        <Label htmlFor={`ack-${doc.id}`}>
                          Type your full name to acknowledge
                        </Label>
                        <Input
                          id={`ack-${doc.id}`}
                          placeholder="Your full name"
                          value={acknowledgments[doc.id] || ""}
                          onChange={(e) => handleAcknowledgmentChange(doc.id, e.target.value)}
                          data-testid={`input-acknowledgment-${doc.id}`}
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id={`sign-${doc.id}`}
                          checked={signedDocuments.has(doc.id)}
                          onCheckedChange={() => handleDocumentToggle(doc.id)}
                          data-testid={`checkbox-sign-${doc.id}`}
                        />
                        <label
                          htmlFor={`sign-${doc.id}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          I have read and agree to this document
                        </label>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Accept Button */}
        <Card>
          <CardFooter className="pt-6">
            <Button
              onClick={handleAccept}
              disabled={acceptMutation.isPending || (documents.some(d => d.requiresSignature) && !allRequiredDocumentsSigned)}
              className="w-full"
              size="lg"
              data-testid="button-accept-invitation"
            >
              {acceptMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Accepting...
                </>
              ) : (
                `Accept Invitation ${!isAuthenticated ? "(Login Required)" : ""}`
              )}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}

/// <reference types="@types/google.maps" />
import { useEffect, useRef, useState, useCallback } from "react";
import { Input } from "@/components/ui/input";
import { MapPin, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

declare global {
  interface Window {
    google: typeof google;
    initGoogleMaps?: () => void;
  }
}

interface GooglePlacesAutocompleteProps {
  value: string;
  onChange: (value: string) => void;
  onPlaceSelect?: (place: google.maps.places.PlaceResult) => void;
  placeholder?: string;
  className?: string;
  "data-testid"?: string;
  previousLocations?: string[];
}

let googleMapsLoaded = false;
let googleMapsLoading = false;
const loadCallbacks: { resolve: () => void; reject: (err: Error) => void }[] = [];

function loadGoogleMapsScript(): Promise<void> {
  return new Promise((resolve, reject) => {
    if (googleMapsLoaded && window.google?.maps?.places) {
      resolve();
      return;
    }

    if (googleMapsLoading) {
      loadCallbacks.push({ resolve, reject });
      return;
    }

    const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
    if (!apiKey) {
      console.warn("Google Maps API key not found");
      reject(new Error("Google Maps API key not configured"));
      return;
    }

    googleMapsLoading = true;

    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places&callback=initGoogleMaps`;
    script.async = true;
    script.defer = true;

    window.initGoogleMaps = () => {
      googleMapsLoaded = true;
      googleMapsLoading = false;
      resolve();
      loadCallbacks.forEach(cb => cb.resolve());
      loadCallbacks.length = 0;
    };

    script.onerror = () => {
      googleMapsLoading = false;
      const error = new Error("Failed to load Google Maps script");
      reject(error);
      loadCallbacks.forEach(cb => cb.reject(error));
      loadCallbacks.length = 0;
    };

    document.head.appendChild(script);
  });
}

export function GooglePlacesAutocomplete({
  value,
  onChange,
  onPlaceSelect,
  placeholder = "Search for a location...",
  className,
  "data-testid": dataTestId,
  previousLocations = [],
}: GooglePlacesAutocompleteProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const autocompleteRef = useRef<google.maps.places.Autocomplete | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isGoogleAvailable, setIsGoogleAvailable] = useState(false);
  const [showPreviousLocations, setShowPreviousLocations] = useState(false);

  const filteredPreviousLocations = previousLocations.filter(
    loc => loc.toLowerCase().includes(value.toLowerCase())
  );

  const initAutocomplete = useCallback(() => {
    if (!inputRef.current || !window.google?.maps?.places) return;

    autocompleteRef.current = new window.google.maps.places.Autocomplete(
      inputRef.current,
      {
        types: ["establishment", "geocode"],
        fields: ["formatted_address", "name", "geometry", "place_id"],
      }
    );

    autocompleteRef.current.addListener("place_changed", () => {
      const place = autocompleteRef.current?.getPlace();
      if (place) {
        const displayValue = place.name && place.formatted_address
          ? `${place.name}, ${place.formatted_address}`
          : place.formatted_address || place.name || "";
        
        onChange(displayValue);
        onPlaceSelect?.(place);
        setShowPreviousLocations(false);
      }
    });
  }, [onChange, onPlaceSelect]);

  useEffect(() => {
    loadGoogleMapsScript()
      .then(() => {
        setIsGoogleAvailable(true);
        setIsLoading(false);
      })
      .catch(() => {
        setIsGoogleAvailable(false);
        setIsLoading(false);
      });
  }, []);

  useEffect(() => {
    if (isGoogleAvailable && inputRef.current) {
      initAutocomplete();
    }

    return () => {
      if (autocompleteRef.current) {
        window.google?.maps?.event?.clearInstanceListeners(autocompleteRef.current);
      }
    };
  }, [isGoogleAvailable, initAutocomplete]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange(e.target.value);
    setShowPreviousLocations(true);
  };

  const handleSelectPreviousLocation = (loc: string) => {
    onChange(loc);
    setShowPreviousLocations(false);
  };

  return (
    <div className="relative">
      <div className="relative">
        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          ref={inputRef}
          type="text"
          value={value}
          onChange={handleInputChange}
          onFocus={() => setShowPreviousLocations(true)}
          onBlur={() => setTimeout(() => setShowPreviousLocations(false), 200)}
          placeholder={placeholder}
          className={cn("pl-10 pr-10", className)}
          data-testid={dataTestId}
        />
        {isLoading && (
          <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
        )}
      </div>

      {showPreviousLocations && filteredPreviousLocations.length > 0 && !value && (
        <div className="absolute z-50 mt-1 w-full rounded-md border bg-popover p-1 shadow-md">
          <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground">
            Previously used locations
          </div>
          {filteredPreviousLocations.slice(0, 5).map((loc, index) => (
            <button
              key={loc}
              type="button"
              className="w-full rounded-sm px-2 py-1.5 text-left text-sm hover-elevate"
              onClick={() => handleSelectPreviousLocation(loc)}
              data-testid={`previous-location-${index}`}
            >
              {loc}
            </button>
          ))}
        </div>
      )}

      {!isGoogleAvailable && !isLoading && (
        <p className="mt-1 text-xs text-muted-foreground">
          Type any address or location name
        </p>
      )}
    </div>
  );
}

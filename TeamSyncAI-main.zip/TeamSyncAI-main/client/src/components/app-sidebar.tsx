import { Calendar, Users, MessageSquare, MessagesSquare, Settings, LayoutDashboard, LogOut, Shield, CreditCard, CheckSquare, UserCircle, Bell, FileText } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/useAuth";
import { usePermissions } from "@/hooks/usePermissions";
import { useAppName } from "@/hooks/useAppName";
import { useTestView } from "@/contexts/TestViewContext";
import type { Team } from "@shared/schema";

const baseMenuItems = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
    testId: "link-dashboard",
    requiresPermission: null,
  },
  {
    title: "Tasks",
    url: "/tasks",
    icon: CheckSquare,
    testId: "link-tasks",
    requiresPermission: null,
    showBadge: true,
  },
  {
    title: "Teams",
    url: "/teams",
    icon: Users,
    testId: "link-teams",
    requiresPermission: "canViewPlayers" as const,
  },
  {
    title: "Schedule",
    url: "/events",
    icon: Calendar,
    testId: "link-schedule",
    requiresPermission: "canViewEvents" as const,
  },
  {
    title: "Campaigns",
    url: "/campaigns",
    icon: MessageSquare,
    testId: "link-campaigns",
    requiresPermission: "canManageCampaigns" as const,
  },
  {
    title: "Membership",
    url: "/membership",
    icon: CreditCard,
    testId: "link-membership",
    requiresPermission: "canViewMembership" as const,
  },
  {
    title: "Settings",
    url: "/settings",
    icon: Settings,
    testId: "link-settings",
    requiresPermission: "canManageSettings" as const,
  },
];

function AdminNotificationsMenuItem() {
  const [location] = useLocation();
  
  const { data: unreadCountData } = useQuery<{ count: number }>({
    queryKey: ["/api/admin/notifications/unread-count"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const unreadCount = unreadCountData?.count || 0;

  return (
    <SidebarMenuItem>
      <SidebarMenuButton asChild isActive={location === "/admin/notifications"}>
        <Link href="/admin/notifications" data-testid="link-admin-notifications">
          <Bell className="h-4 w-4" />
          <span>Notifications</span>
          {unreadCount > 0 && (
            <Badge variant="destructive" className="ml-auto" data-testid="badge-notifications-count">
              {unreadCount}
            </Badge>
          )}
        </Link>
      </SidebarMenuButton>
    </SidebarMenuItem>
  );
}

function TeamNotificationsMenuItem() {
  const [location] = useLocation();
  
  const { data: unreadCountData } = useQuery<{ count: number }>({
    queryKey: ["/api/team-notifications/unread-count"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const unreadCount = unreadCountData?.count || 0;

  return (
    <SidebarMenuItem>
      <SidebarMenuButton asChild isActive={location === "/notifications"}>
        <Link href="/notifications" data-testid="link-team-notifications">
          <Bell className="h-4 w-4" />
          <span>Notifications</span>
          {unreadCount > 0 && (
            <Badge variant="destructive" className="ml-auto" data-testid="badge-team-notifications-count">
              {unreadCount}
            </Badge>
          )}
        </Link>
      </SidebarMenuButton>
    </SidebarMenuItem>
  );
}

export function AppSidebar() {
  const [location] = useLocation();
  const { user } = useAuth();
  const { isTestViewActive, testViewMode } = useTestView();
  const appName = useAppName();

  const queryKey = isTestViewActive && testViewMode 
    ? `/api/teams?testViewMode=${testViewMode}`
    : "/api/teams";
    
  const { data: teams = [] } = useQuery<Team[]>({
    queryKey: [queryKey],
  });

  const { data: tasksSummary } = useQuery<{ documentsPending: number; eventsPending: number; total: number }>({
    queryKey: ["/api/tasks/summary"],
    refetchInterval: 60000,
  });

  const team = teams[0];
  const permissions = usePermissions(team?.id);

  const menuItems = baseMenuItems.filter((item) => {
    if (!item.requiresPermission) return true;
    return permissions[item.requiresPermission];
  });

  const handleLogout = async () => {
    try {
      await fetch("/api/logout", {
        method: "POST",
        credentials: "include",
      });
      window.location.href = "/";
    } catch (error) {
      console.error("Logout error:", error);
      window.location.href = "/";
    }
  };

  const getUserInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user?.email) {
      return user.email[0].toUpperCase();
    }
    return "U";
  };

  return (
    <Sidebar>
      <SidebarHeader className="border-b p-4">
        <div className="flex items-center gap-2">
          {team?.logoUrl || user?.organizationLogoUrl ? (
            <img
              src={team?.logoUrl || user?.organizationLogoUrl || ""}
              alt={team?.logoUrl ? `${team.name} logo` : "Organization logo"}
              className="h-8 w-8 rounded-md object-cover"
              data-testid="img-sidebar-logo"
            />
          ) : (
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <span className="text-lg font-semibold">T</span>
            </div>
          )}
          <span className="text-lg font-semibold">{team?.instanceName || appName}</span>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={location === item.url}>
                    <Link href={item.url} data-testid={item.testId}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                      {item.showBadge && tasksSummary && tasksSummary.total > 0 && (
                        <Badge variant="destructive" className="ml-auto" data-testid="badge-tasks-count">
                          {tasksSummary.total}
                        </Badge>
                      )}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
              {team?.messageBoardEnabled && (
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={location === `/teams/${team.id}/message-board`}>
                    <Link href={`/teams/${team.id}/message-board`} data-testid="link-message-board">
                      <MessagesSquare className="h-4 w-4" />
                      <span>Message Board</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
              {(permissions.canManageAttendance || permissions.canManageCampaigns) && (
                <TeamNotificationsMenuItem />
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        {user?.isGlobalAdmin && !isTestViewActive && (
          <SidebarGroup>
            <SidebarGroupLabel>Admin</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={location === "/admin"}>
                    <Link href="/admin" data-testid="link-admin-settings">
                      <Shield className="h-4 w-4" />
                      <span>Admin Settings</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={location === "/admin/users"}>
                    <Link href="/admin/users" data-testid="link-admin-users">
                      <Users className="h-4 w-4" />
                      <span>User Management</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={location === "/admin/marketing"}>
                    <Link href="/admin/marketing" data-testid="link-admin-marketing">
                      <FileText className="h-4 w-4" />
                      <span>Marketing Content</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <AdminNotificationsMenuItem />
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>
      <SidebarFooter className="border-t p-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Theme</span>
          <ThemeToggle />
        </div>
        <div className="flex items-center gap-3">
          <Link href="/profile" className="flex items-center gap-3 flex-1 min-w-0 hover-elevate rounded-md p-2 -m-2" data-testid="link-profile">
            <Avatar className="h-8 w-8">
              <AvatarImage src={user?.profileImageUrl || undefined} alt={user?.email || "User"} />
              <AvatarFallback>{getUserInitials()}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">
                {user?.firstName && user?.lastName
                  ? `${user.firstName} ${user.lastName}`
                  : user?.email || "User"}
              </div>
              {user?.email && (user?.firstName || user?.lastName) && (
                <div className="text-xs text-muted-foreground truncate">{user.email}</div>
              )}
            </div>
          </Link>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleLogout}
            data-testid="button-logout"
            title="Log out"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}

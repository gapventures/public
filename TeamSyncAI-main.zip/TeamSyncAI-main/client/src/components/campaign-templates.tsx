import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plus, Trash2, Edit, Clock, MessageSquare, ChevronDown, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { CampaignTemplate, TemplateReminder } from "@shared/schema";

interface CampaignTemplatesProps {
  teamId: string;
}

export function CampaignTemplates({ teamId }: CampaignTemplatesProps) {
  const { toast } = useToast();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [expandedTemplates, setExpandedTemplates] = useState<Set<string>>(new Set());
  const [templateForm, setTemplateForm] = useState({
    name: "",
    description: "",
  });
  const [reminderForm, setReminderForm] = useState({
    intervalHours: "24",
    messageTemplate: "",
  });
  const [editingReminder, setEditingReminder] = useState<TemplateReminder | null>(null);
  const [addingReminderTo, setAddingReminderTo] = useState<string | null>(null);

  const { data: templates = [], isLoading } = useQuery<CampaignTemplate[]>({
    queryKey: ["/api/teams", teamId, "campaign-templates"],
  });

  const createTemplateMutation = useMutation({
    mutationFn: async (data: { name: string; description?: string }) => {
      return await apiRequest("POST", `/api/teams/${teamId}/campaign-templates`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "campaign-templates"] });
      setIsCreateDialogOpen(false);
      setTemplateForm({ name: "", description: "" });
      toast({
        title: "Template created",
        description: "Campaign template has been created successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create template. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteTemplateMutation = useMutation({
    mutationFn: async (templateId: string) => {
      return await apiRequest("DELETE", `/api/campaign-templates/${templateId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "campaign-templates"] });
      toast({
        title: "Template deleted",
        description: "Campaign template has been deleted successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete template. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createReminderMutation = useMutation({
    mutationFn: async ({ templateId, data }: { templateId: string; data: any }) => {
      return await apiRequest("POST", `/api/campaign-templates/${templateId}/reminders`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "campaign-templates"] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaign-templates"] });
      setAddingReminderTo(null);
      setReminderForm({ intervalHours: "24", messageTemplate: "" });
      toast({
        title: "Reminder added",
        description: "Reminder has been added to the template.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add reminder. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateReminderMutation = useMutation({
    mutationFn: async ({ reminderId, templateId, data }: { reminderId: string; templateId: string; data: any }) => {
      return await apiRequest("PATCH", `/api/template-reminders/${reminderId}`, data);
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "campaign-templates"] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaign-templates"] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaign-templates", variables.templateId, "reminders"] });
      setEditingReminder(null);
      setReminderForm({ intervalHours: "24", messageTemplate: "" });
      toast({
        title: "Reminder updated",
        description: "Reminder has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update reminder. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteReminderMutation = useMutation({
    mutationFn: async (reminderId: string) => {
      return await apiRequest("DELETE", `/api/template-reminders/${reminderId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "campaign-templates"] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaign-templates"] });
      toast({
        title: "Reminder deleted",
        description: "Reminder has been removed from the template.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete reminder. Please try again.",
        variant: "destructive",
      });
    },
  });

  const toggleTemplate = (templateId: string) => {
    const newExpanded = new Set(expandedTemplates);
    if (newExpanded.has(templateId)) {
      newExpanded.delete(templateId);
      if (editingReminder && editingReminder.templateId === templateId) {
        setEditingReminder(null);
        setReminderForm({ intervalHours: "24", messageTemplate: "" });
      }
      if (addingReminderTo === templateId) {
        setAddingReminderTo(null);
        setReminderForm({ intervalHours: "24", messageTemplate: "" });
      }
    } else {
      newExpanded.add(templateId);
    }
    setExpandedTemplates(newExpanded);
  };

  const handleCreateTemplate = () => {
    if (!templateForm.name.trim()) {
      toast({
        title: "Error",
        description: "Please enter a template name.",
        variant: "destructive",
      });
      return;
    }
    createTemplateMutation.mutate(templateForm);
  };

  const handleAddReminder = (templateId: string) => {
    if (!reminderForm.messageTemplate.trim()) {
      toast({
        title: "Error",
        description: "Please enter a message template.",
        variant: "destructive",
      });
      return;
    }
    createReminderMutation.mutate({
      templateId,
      data: {
        intervalHours: parseInt(reminderForm.intervalHours),
        messageTemplate: reminderForm.messageTemplate,
      },
    });
  };

  const handleStartEditReminder = (reminder: TemplateReminder, templateId: string) => {
    setEditingReminder(reminder);
    setReminderForm({
      intervalHours: String(reminder.intervalHours),
      messageTemplate: reminder.messageTemplate,
    });
    setAddingReminderTo(null);
  };

  const handleUpdateReminder = (templateId: string) => {
    if (!editingReminder) return;
    
    if (!reminderForm.messageTemplate.trim()) {
      toast({
        title: "Error",
        description: "Please enter a message template.",
        variant: "destructive",
      });
      return;
    }
    
    updateReminderMutation.mutate({
      reminderId: editingReminder.id,
      templateId,
      data: {
        intervalHours: parseInt(reminderForm.intervalHours),
        messageTemplate: reminderForm.messageTemplate,
      },
    });
  };

  const handleCancelEdit = () => {
    setEditingReminder(null);
    setReminderForm({ intervalHours: "24", messageTemplate: "" });
  };

  const getIntervalLabel = (hours: number) => {
    if (hours === 1) return "1 hour before";
    if (hours === 2) return "2 hours before";
    if (hours === 4) return "4 hours before";
    if (hours === 12) return "12 hours before";
    if (hours === 24) return "1 day before";
    if (hours === 48) return "2 days before";
    if (hours === 72) return "3 days before";
    if (hours === 168) return "1 week before";
    return `${hours} hours before`;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Campaign Templates</CardTitle>
          <CardDescription>Loading templates...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Campaign Templates</CardTitle>
            <CardDescription>
              Create reusable reminder templates that can be quickly applied to events
            </CardDescription>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-create-template">
                <Plus className="h-4 w-4 mr-2" />
                New Template
              </Button>
            </DialogTrigger>
            <DialogContent data-testid="dialog-create-template">
              <DialogHeader>
                <DialogTitle>Create Campaign Template</DialogTitle>
                <DialogDescription>
                  Create a reusable template with pre-configured reminder schedules
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="template-name">Template Name</Label>
                  <Input
                    id="template-name"
                    placeholder="e.g., Standard Game Reminders"
                    value={templateForm.name}
                    onChange={(e) => setTemplateForm({ ...templateForm, name: e.target.value })}
                    data-testid="input-template-name"
                  />
                </div>
                <div>
                  <Label htmlFor="template-description">Description (Optional)</Label>
                  <Textarea
                    id="template-description"
                    placeholder="Describe when to use this template..."
                    value={templateForm.description}
                    onChange={(e) => setTemplateForm({ ...templateForm, description: e.target.value })}
                    data-testid="input-template-description"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  onClick={handleCreateTemplate}
                  disabled={createTemplateMutation.isPending}
                  data-testid="button-submit-template"
                >
                  {createTemplateMutation.isPending ? "Creating..." : "Create Template"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {templates.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 border rounded-md bg-muted/20">
            <MessageSquare className="h-12 w-12 text-muted-foreground mb-3" />
            <p className="text-sm text-muted-foreground mb-4">No templates yet</p>
            <Button
              onClick={() => setIsCreateDialogOpen(true)}
              size="sm"
              data-testid="button-create-first-template"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Template
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {templates.map((template) => (
              <TemplateCard
                key={template.id}
                template={template}
                teamId={teamId}
                expanded={expandedTemplates.has(template.id)}
                onToggle={() => toggleTemplate(template.id)}
                onDelete={() => deleteTemplateMutation.mutate(template.id)}
                addingReminder={addingReminderTo === template.id}
                onStartAddReminder={() => {
                  setEditingReminder(null);
                  setAddingReminderTo(template.id);
                  setReminderForm({ intervalHours: "24", messageTemplate: "" });
                }}
                onCancelAddReminder={() => {
                  setAddingReminderTo(null);
                  setReminderForm({ intervalHours: "24", messageTemplate: "" });
                }}
                reminderForm={reminderForm}
                setReminderForm={setReminderForm}
                onAddReminder={() => handleAddReminder(template.id)}
                onDeleteReminder={(reminderId) => deleteReminderMutation.mutate(reminderId)}
                getIntervalLabel={getIntervalLabel}
                isCreatingReminder={createReminderMutation.isPending}
                editingReminder={editingReminder}
                onStartEditReminder={(reminder, templateId) => {
                  setAddingReminderTo(null);
                  handleStartEditReminder(reminder, templateId);
                }}
                onUpdateReminder={handleUpdateReminder}
                onCancelEdit={handleCancelEdit}
                isUpdatingReminder={updateReminderMutation.isPending}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

interface TemplateCardProps {
  template: CampaignTemplate;
  teamId: string;
  expanded: boolean;
  onToggle: () => void;
  onDelete: () => void;
  addingReminder: boolean;
  onStartAddReminder: () => void;
  onCancelAddReminder: () => void;
  reminderForm: { intervalHours: string; messageTemplate: string };
  editingReminder: TemplateReminder | null;
  onStartEditReminder: (reminder: TemplateReminder, templateId: string) => void;
  onUpdateReminder: (templateId: string) => void;
  onCancelEdit: () => void;
  isUpdatingReminder: boolean;
  setReminderForm: (form: { intervalHours: string; messageTemplate: string }) => void;
  onAddReminder: () => void;
  onDeleteReminder: (reminderId: string) => void;
  getIntervalLabel: (hours: number) => string;
  isCreatingReminder: boolean;
}

function TemplateCard({
  template,
  teamId,
  expanded,
  onToggle,
  onDelete,
  addingReminder,
  onStartAddReminder,
  onCancelAddReminder,
  reminderForm,
  setReminderForm,
  onAddReminder,
  onDeleteReminder,
  getIntervalLabel,
  isCreatingReminder,
  editingReminder,
  onStartEditReminder,
  onUpdateReminder,
  onCancelEdit,
  isUpdatingReminder,
}: TemplateCardProps) {
  const { data: reminders = [] } = useQuery<TemplateReminder[]>({
    queryKey: ["/api/campaign-templates", template.id, "reminders"],
    enabled: expanded,
  });

  return (
    <div className="border rounded-md" data-testid={`template-${template.id}`}>
      <div className="flex items-center justify-between p-4">
        <button
          onClick={onToggle}
          className="flex items-center gap-3 flex-1 text-left hover-elevate active-elevate-2 rounded-md -m-2 p-2"
          data-testid={`button-toggle-template-${template.id}`}
        >
          {expanded ? (
            <ChevronDown className="h-5 w-5 text-muted-foreground" />
          ) : (
            <ChevronRight className="h-5 w-5 text-muted-foreground" />
          )}
          <div className="flex-1">
            <div className="font-medium">{template.name}</div>
            {template.description && (
              <div className="text-sm text-muted-foreground">{template.description}</div>
            )}
          </div>
        </button>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="ghost" size="icon" data-testid={`button-delete-template-${template.id}`}>
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Template?</AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently delete the template "{template.name}" and all its reminder configurations.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={onDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      {expanded && (
        <div className="border-t px-4 py-3 space-y-3 bg-muted/20">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium">Reminder Schedule</Label>
            {!addingReminder && (
              <Button
                onClick={onStartAddReminder}
                size="sm"
                variant="outline"
                data-testid={`button-add-reminder-${template.id}`}
              >
                <Plus className="h-3 w-3 mr-1" />
                Add Reminder
              </Button>
            )}
          </div>

          {reminders.length === 0 && !addingReminder && (
            <p className="text-sm text-muted-foreground">
              No reminders configured. Add reminders to set up the schedule for this template.
            </p>
          )}

          {reminders.map((reminder) => (
            editingReminder?.id === reminder.id ? (
              <div key={reminder.id} className="p-3 rounded-md border bg-card space-y-3">
                <div>
                  <Label className="text-sm">When to Send</Label>
                  <Select
                    value={reminderForm.intervalHours}
                    onValueChange={(value) => setReminderForm({ ...reminderForm, intervalHours: value })}
                  >
                    <SelectTrigger className="mt-1" data-testid="select-edit-reminder-interval">
                      <SelectValue placeholder="Select interval" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 hour before</SelectItem>
                      <SelectItem value="2">2 hours before</SelectItem>
                      <SelectItem value="4">4 hours before</SelectItem>
                      <SelectItem value="12">12 hours before</SelectItem>
                      <SelectItem value="24">24 hours (1 day) before</SelectItem>
                      <SelectItem value="48">48 hours (2 days) before</SelectItem>
                      <SelectItem value="72">72 hours (3 days) before</SelectItem>
                      <SelectItem value="168">1 week before</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-sm">Message Template</Label>
                  <Textarea
                    placeholder="Hi [Player Name], reminder about [Event Type] on [Date] at [Time]..."
                    value={reminderForm.messageTemplate}
                    onChange={(e) => setReminderForm({ ...reminderForm, messageTemplate: e.target.value })}
                    className="mt-1"
                    data-testid="input-edit-reminder-message"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Use variables: [Player Name], [Event Type], [Date], [Time], [Location]
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => onUpdateReminder(template.id)}
                    size="sm"
                    disabled={isUpdatingReminder}
                    data-testid="button-update-reminder"
                  >
                    {isUpdatingReminder ? "Updating..." : "Update Reminder"}
                  </Button>
                  <Button
                    onClick={onCancelEdit}
                    size="sm"
                    variant="outline"
                    data-testid="button-cancel-edit-reminder"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div
                key={reminder.id}
                className="flex items-start justify-between gap-3 p-3 rounded-md border bg-card"
                data-testid={`reminder-${reminder.id}`}
              >
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">
                      {getIntervalLabel(reminder.intervalHours)}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">{reminder.messageTemplate}</p>
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onStartEditReminder(reminder, template.id)}
                    data-testid={`button-edit-reminder-${reminder.id}`}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onDeleteReminder(reminder.id)}
                    data-testid={`button-delete-reminder-${reminder.id}`}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            )
          ))}

          {addingReminder && (
            <div className="p-3 rounded-md border bg-card space-y-3">
              <div>
                <Label className="text-sm">When to Send</Label>
                <Select
                  value={reminderForm.intervalHours}
                  onValueChange={(value) => setReminderForm({ ...reminderForm, intervalHours: value })}
                >
                  <SelectTrigger className="mt-1" data-testid="select-reminder-interval">
                    <SelectValue placeholder="Select interval" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 hour before</SelectItem>
                    <SelectItem value="2">2 hours before</SelectItem>
                    <SelectItem value="4">4 hours before</SelectItem>
                    <SelectItem value="12">12 hours before</SelectItem>
                    <SelectItem value="24">24 hours (1 day) before</SelectItem>
                    <SelectItem value="48">48 hours (2 days) before</SelectItem>
                    <SelectItem value="72">72 hours (3 days) before</SelectItem>
                    <SelectItem value="168">1 week before</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm">Message Template</Label>
                <Textarea
                  placeholder="Hi [Player Name], reminder about [Event Type] on [Date] at [Time]..."
                  value={reminderForm.messageTemplate}
                  onChange={(e) => setReminderForm({ ...reminderForm, messageTemplate: e.target.value })}
                  className="mt-1"
                  data-testid="input-reminder-message"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Use variables: [Player Name], [Event Type], [Date], [Time], [Location]
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={onAddReminder}
                  size="sm"
                  disabled={isCreatingReminder}
                  data-testid="button-save-reminder"
                >
                  {isCreatingReminder ? "Adding..." : "Add Reminder"}
                </Button>
                <Button
                  onClick={onCancelAddReminder}
                  size="sm"
                  variant="outline"
                  data-testid="button-cancel-reminder"
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

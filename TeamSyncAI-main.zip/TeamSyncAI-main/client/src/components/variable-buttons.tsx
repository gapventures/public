import { Badge } from "@/components/ui/badge";

const VARIABLES = [
  { label: "First Name", value: "{firstName}" },
  { label: "Player Name", value: "{playerName}" },
  { label: "Team Name", value: "{teamName}" },
  { label: "Coach Name", value: "{coachName}" },
  { label: "Event Type", value: "{eventType}" },
  { label: "Event Title", value: "{eventTitle}" },
  { label: "Date", value: "{date}" },
  { label: "Time", value: "{time}" },
  { label: "Location", value: "{location}" },
  { label: "Opponent", value: "{opponent}" },
  { label: "Home/Away", value: "{homeAway}" },
  { label: "Field Type", value: "{fieldType}" },
  { label: "Cleats", value: "{cleats}" },
  { label: "Jersey", value: "{jersey}" },
  { label: "Arrival Time", value: "{arrivalTime}" },
];

interface VariableButtonsProps {
  onInsert: (variable: string) => void;
}

export function VariableButtons({ onInsert }: VariableButtonsProps) {
  return (
    <div className="flex flex-wrap gap-2">
      <span className="text-xs text-muted-foreground self-center">Quick insert:</span>
      {VARIABLES.map((variable) => (
        <Badge
          key={variable.value}
          variant="outline"
          className="cursor-pointer hover-elevate active-elevate-2"
          onClick={() => onInsert(variable.value)}
          data-testid={`variable-${variable.value.toLowerCase().replace(/[[\] ]/g, '-')}`}
        >
          {variable.label}
        </Badge>
      ))}
    </div>
  );
}

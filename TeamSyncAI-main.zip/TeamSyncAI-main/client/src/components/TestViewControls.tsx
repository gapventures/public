import { useTestView, TestViewMode } from '@/contexts/TestViewContext';
import { useAuth } from '@/hooks/useAuth';
import { Eye, EyeOff } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export function TestViewControls() {
  const { user } = useAuth();
  const { testViewMode, setTestViewMode, isTestViewActive } = useTestView();

  if (!user?.isGlobalAdmin) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50" data-testid="test-view-controls">
      <Card className="p-3 shadow-lg border-primary/20">
        <div className="flex items-center gap-2">
          <Eye className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium">Test View:</span>
          <Select
            value={testViewMode}
            onValueChange={(value) => setTestViewMode(value as TestViewMode)}
          >
            <SelectTrigger 
              className="w-[180px] h-8" 
              data-testid="select-test-view-mode"
            >
              <SelectValue placeholder="Select view..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="off" data-testid="option-test-view-off">
                Off (Admin View)
              </SelectItem>
              <SelectItem value="team_owner" data-testid="option-test-view-owner">
                Team Owner
              </SelectItem>
              <SelectItem value="coach" data-testid="option-test-view-coach">
                Coach
              </SelectItem>
              <SelectItem value="assistant_coach" data-testid="option-test-view-assistant">
                Assistant Coach
              </SelectItem>
              <SelectItem value="player" data-testid="option-test-view-player">
                Player
              </SelectItem>
              <SelectItem value="viewer" data-testid="option-test-view-viewer">
                Viewer
              </SelectItem>
            </SelectContent>
          </Select>
          {isTestViewActive && (
            <Button
              size="icon"
              variant="ghost"
              onClick={() => setTestViewMode('off')}
              data-testid="button-exit-test-view"
              className="h-8 w-8"
            >
              <EyeOff className="h-4 w-4" />
            </Button>
          )}
        </div>
      </Card>
    </div>
  );
}

export function TestViewBanner() {
  const { testViewMode, isTestViewActive } = useTestView();

  if (!isTestViewActive) {
    return null;
  }

  const modeLabels: Record<TestViewMode, string> = {
    off: '',
    team_owner: 'Team Owner',
    coach: 'Coach',
    assistant_coach: 'Assistant Coach',
    player: 'Player',
    viewer: 'Viewer',
  };

  return (
    <div 
      className="bg-primary text-primary-foreground py-2 px-4 text-center text-sm font-medium"
      data-testid="test-view-banner"
    >
      <Eye className="inline-block h-4 w-4 mr-2" />
      Viewing as: {modeLabels[testViewMode]}
    </div>
  );
}

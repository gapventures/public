import { Link } from "wouter";
import { useAppName } from "@/hooks/useAppName";

export function MarketingFooter() {
  const appName = useAppName();
  
  return (
    <footer className="border-t py-6">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground" data-testid="text-footer-copyright">
            &copy; 2025 {appName}. Built for coaches, by coaches.
          </p>
          <nav className="flex items-center gap-4" data-testid="nav-footer-links">
            <Link 
              href="/privacy" 
              className="text-sm text-muted-foreground hover:text-foreground hover-elevate rounded-md px-2 py-1"
              data-testid="link-privacy-policy"
            >
              Privacy Policy
            </Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}

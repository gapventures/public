import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Smartphone, Plus, Clock, CheckCircle2, XCircle, Send, Download, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Team } from "@shared/schema";

interface TeamSMSPhoneNumberProps {
  teamId: string;
  team: Team;
  canManage: boolean;
}

export function TeamSMSPhoneNumber({ teamId, team, canManage }: TeamSMSPhoneNumberProps) {
  const [isPhoneProvisionDialogOpen, setIsPhoneProvisionDialogOpen] = useState(false);
  const [isPhoneReleaseDialogOpen, setIsPhoneReleaseDialogOpen] = useState(false);
  const [areaCode, setAreaCode] = useState("");
  const { toast } = useToast();
  
  // Check if phone provisioning is enabled (disabled during A2P registration)
  const isProvisioningEnabled = import.meta.env.VITE_ENABLE_PHONE_PROVISIONING === 'true';

  const { data: messageStats } = useQuery<{
    outboundCount: number;
    inboundCount: number;
    optOutCount: number;
    totalMessages: number;
  }>({
    queryKey: [`/api/teams/${teamId}/message-stats`],
    enabled: canManage && !!team.twilioPhoneNumber,
  });

  const { data: messageLogs = [] } = useQuery<any[]>({
    queryKey: [`/api/teams/${teamId}/message-logs`],
    enabled: canManage && !!team.twilioPhoneNumber,
  });

  const provisionPhoneMutation = useMutation({
    mutationFn: async (areaCodeParam?: string) => {
      const response = await apiRequest("POST", `/api/teams/${teamId}/provision-phone`, { areaCode: areaCodeParam });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `Failed to provision phone number (${response.status})`);
      }
      return await response.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId] });
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      setIsPhoneProvisionDialogOpen(false);
      setAreaCode("");
      toast({
        title: "Phone number provisioned",
        description: `Your team now has a dedicated phone number: ${data.phoneNumber}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Provisioning failed",
        description: error.message || "Failed to provision phone number. Please try again.",
        variant: "destructive",
      });
    },
  });

  const releasePhoneMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("DELETE", `/api/teams/${teamId}/phone-number`, {});
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `Failed to release phone number (${response.status})`);
      }
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId] });
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      setIsPhoneReleaseDialogOpen(false);
      toast({
        title: "Phone number released",
        description: "The team phone number has been released successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Release failed",
        description: error.message || "Failed to release phone number. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (!canManage) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle>SMS Phone Number</CardTitle>
        <CardDescription>
          {isProvisioningEnabled 
            ? "Manage your team's dedicated phone number for TCPA-compliant SMS messaging"
            : "Your team is using a shared phone number for SMS messaging"}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Smartphone className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium">
                {team.twilioPhoneNumber || "+1 (855) 677-3180"}
              </span>
            </div>
            <p className="text-sm text-muted-foreground">
              {!isProvisioningEnabled
                ? "Shared number - All teams use this number for SMS"
                : team.phoneNumberStatus === 'active' && team.twilioPhoneNumber
                ? "Active - All SMS messages will use this number"
                : "Using shared number - Provision a dedicated number for TCPA compliance"}
            </p>
          </div>
          {!isProvisioningEnabled ? (
            <Badge variant="secondary" data-testid="badge-phone-status">Shared</Badge>
          ) : team.phoneNumberStatus === 'active' && team.twilioPhoneNumber ? (
            <Badge variant="default" data-testid="badge-phone-status">Active</Badge>
          ) : (
            <Badge variant="secondary" data-testid="badge-phone-status">Shared</Badge>
          )}
        </div>

        {messageStats && team.twilioPhoneNumber && (
          <>
            <div className="grid grid-cols-2 gap-4 p-4 bg-muted/50 rounded-md">
              <div>
                <p className="text-sm text-muted-foreground">Messages Sent</p>
                <p className="text-2xl font-semibold" data-testid="text-messages-sent">{messageStats.outboundCount}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Responses</p>
                <p className="text-2xl font-semibold" data-testid="text-messages-received">{messageStats.inboundCount}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Messages</p>
                <p className="text-2xl font-semibold" data-testid="text-total-messages">{messageStats.totalMessages}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Opt-Outs</p>
                <p className="text-2xl font-semibold" data-testid="text-opt-outs">{messageStats.optOutCount}</p>
              </div>
            </div>

            {messageLogs.length > 0 && (
              <Collapsible>
                <CollapsibleTrigger asChild>
                  <Button variant="outline" className="w-full" data-testid="button-toggle-message-logs">
                    <Clock className="h-4 w-4 mr-2" />
                    View Recent Messages ({messageLogs.length})
                    <ChevronDown className="h-4 w-4 ml-auto" />
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-2 mt-2">
                  <div className="max-h-96 overflow-y-auto space-y-2">
                    {messageLogs.map((log: any) => (
                      <div key={log.id} className="p-3 bg-card border rounded-md" data-testid={`message-log-${log.id}`}>
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="flex items-center gap-2">
                            {log.direction === 'outbound' ? (
                              <Send className="h-4 w-4 text-blue-500" />
                            ) : (
                              <Download className="h-4 w-4 text-green-500" />
                            )}
                            <span className="text-sm font-medium">
                              {log.direction === 'outbound' ? 'Sent' : 'Received'}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            {log.status === 'delivered' && <CheckCircle2 className="h-4 w-4 text-green-500" />}
                            {log.status === 'failed' && <XCircle className="h-4 w-4 text-red-500" />}
                            {log.status === 'sent' && <Clock className="h-4 w-4 text-blue-500" />}
                            <span className="text-xs text-muted-foreground">
                              {new Date(log.createdAt).toLocaleString()}
                            </span>
                          </div>
                        </div>
                        <p className="text-sm mb-2">{log.body}</p>
                        <div className="flex gap-2 text-xs text-muted-foreground">
                          <span>{log.fromPhone} → {log.toPhone}</span>
                          {log.status && (
                            <Badge variant="outline" className="text-xs">
                              {log.status}
                            </Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            )}
          </>
        )}

        {isProvisioningEnabled && (
          <div className="flex gap-2">
            {!team.twilioPhoneNumber || team.phoneNumberStatus !== 'active' ? (
              <Dialog open={isPhoneProvisionDialogOpen} onOpenChange={setIsPhoneProvisionDialogOpen}>
                <DialogTrigger asChild>
                  <Button data-testid="button-provision-phone">
                    <Plus className="h-4 w-4 mr-2" />
                    Provision Phone Number
                  </Button>
                </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Provision Phone Number</DialogTitle>
                  <DialogDescription>
                    Get a dedicated Twilio phone number for your team. This ensures TCPA compliance and proper message attribution.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label htmlFor="area-code">Area Code (Optional)</Label>
                    <Input
                      id="area-code"
                      placeholder="e.g., 555"
                      value={areaCode}
                      onChange={(e) => setAreaCode(e.target.value)}
                      className="mt-2"
                      maxLength={3}
                      data-testid="input-area-code"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Leave blank to get any available number
                    </p>
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsPhoneProvisionDialogOpen(false);
                      setAreaCode("");
                    }}
                    data-testid="button-cancel-provision"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => provisionPhoneMutation.mutate(areaCode || undefined)}
                    disabled={provisionPhoneMutation.isPending}
                    data-testid="button-confirm-provision"
                  >
                    {provisionPhoneMutation.isPending ? "Provisioning..." : "Provision Number"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          ) : (
            <AlertDialog open={isPhoneReleaseDialogOpen} onOpenChange={setIsPhoneReleaseDialogOpen}>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" data-testid="button-release-phone">
                  Release Phone Number
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Release Phone Number</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to release {team.twilioPhoneNumber}? This will return the number to Twilio's pool and your team will use the shared fallback number.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel data-testid="button-cancel-release">Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => releasePhoneMutation.mutate()}
                    disabled={releasePhoneMutation.isPending}
                    data-testid="button-confirm-release"
                  >
                    {releasePhoneMutation.isPending ? "Releasing..." : "Release Number"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

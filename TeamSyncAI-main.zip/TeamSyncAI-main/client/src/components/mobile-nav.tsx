import { Calendar, Users, MessagesSquare, Settings, LayoutDashboard, Shield } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { usePermissions } from "@/hooks/usePermissions";
import { useAuth } from "@/hooks/useAuth";
import { useTestView } from "@/contexts/TestViewContext";
import type { Team } from "@shared/schema";

const baseNavItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard, testId: "link-mobile-dashboard", requiresPermission: null },
  { title: "Teams", url: "/teams", icon: Users, testId: "link-mobile-teams", requiresPermission: "canViewPlayers" as const },
  { title: "Schedule", url: "/events", icon: Calendar, testId: "link-mobile-schedule", requiresPermission: "canViewEvents" as const },
  { title: "Settings", url: "/settings", icon: Settings, testId: "link-mobile-settings", requiresPermission: "canManageSettings" as const },
];

export function MobileNav() {
  const [location] = useLocation();
  const { user } = useAuth();
  const { isTestViewActive, testViewMode } = useTestView();

  const queryKey = isTestViewActive && testViewMode 
    ? `/api/teams?testViewMode=${testViewMode}`
    : "/api/teams";
    
  const { data: teams = [] } = useQuery<Team[]>({
    queryKey: [queryKey],
  });

  const team = teams[0];
  const permissions = usePermissions(team?.id);

  const navItems = baseNavItems.filter((item) => {
    if (!item.requiresPermission) return true;
    return permissions[item.requiresPermission];
  });

  const allNavItems = [
    ...navItems,
    ...(team?.messageBoardEnabled
      ? [
          {
            title: "Messages",
            url: `/teams/${team.id}/message-board`,
            icon: MessagesSquare,
            testId: "link-mobile-message-board",
          },
        ]
      : []),
    ...(user?.isGlobalAdmin && !isTestViewActive
      ? [
          {
            title: "Admin",
            url: "/admin",
            icon: Shield,
            testId: "link-mobile-admin-settings",
          },
        ]
      : []),
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 border-t bg-background md:hidden">
      <nav className="flex items-center justify-around py-2">
        {allNavItems.map((item) => {
          const isActive = location === item.url;
          return (
            <Link key={item.title} href={item.url} data-testid={item.testId}>
              <div className="flex flex-col items-center gap-1 px-3 py-1 hover-elevate active-elevate-2 rounded-md">
                <item.icon
                  className={`h-5 w-5 ${
                    isActive ? "text-primary" : "text-muted-foreground"
                  }`}
                />
                <span
                  className={`text-xs ${
                    isActive ? "text-foreground font-medium" : "text-muted-foreground"
                  }`}
                >
                  {item.title}
                </span>
              </div>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

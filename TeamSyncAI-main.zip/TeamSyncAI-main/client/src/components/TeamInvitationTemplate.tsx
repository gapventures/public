import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Mail, MessageSquare, Info, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Team } from "@shared/schema";

interface TeamInvitationTemplateProps {
  teamId: string;
  team: Team;
  canManage: boolean;
}

const DEFAULT_TEMPLATE = "You've been invited to join {teamName} as {roleName}! Accept your invitation here: {inviteUrl}";

const AVAILABLE_VARIABLES = [
  { variable: "{teamName}", description: "Your team's name" },
  { variable: "{roleName}", description: "Role being assigned (e.g., Player, Coach)" },
  { variable: "{coachName}", description: "Name of the coach sending the invitation" },
  { variable: "{playerName}", description: "Name of the player being invited" },
  { variable: "{inviteUrl}", description: "The invitation link (required)" },
];

export function TeamInvitationTemplate({ teamId, team, canManage }: TeamInvitationTemplateProps) {
  const [template, setTemplate] = useState(team.invitationMessageTemplate || "");
  const [isDirty, setIsDirty] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setTemplate(team.invitationMessageTemplate || "");
    setIsDirty(false);
  }, [team.invitationMessageTemplate]);

  const updateTemplateMutation = useMutation({
    mutationFn: async (newTemplate: string | null) => {
      const response = await apiRequest("PATCH", `/api/teams/${teamId}/invitation-template`, { 
        invitationMessageTemplate: newTemplate 
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `Failed to update invitation template (${response.status})`);
      }
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId] });
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      setIsDirty(false);
      toast({
        title: "Template saved",
        description: "Your custom invitation message has been saved.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to save template",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    const trimmedTemplate = template.trim();
    if (trimmedTemplate && !trimmedTemplate.includes("{inviteUrl}")) {
      toast({
        title: "Missing invite link",
        description: "Your template must include {inviteUrl} so players can accept the invitation.",
        variant: "destructive",
      });
      return;
    }
    updateTemplateMutation.mutate(trimmedTemplate || null);
  };

  const handleReset = () => {
    setTemplate("");
    setIsDirty(true);
  };

  const handleTemplateChange = (value: string) => {
    setTemplate(value);
    setIsDirty(value !== (team.invitationMessageTemplate || ""));
  };

  const insertVariable = (variable: string) => {
    setTemplate((prev) => prev + variable);
    setIsDirty(true);
  };

  const previewMessage = () => {
    const t = template || DEFAULT_TEMPLATE;
    return t
      .replace(/\{teamName\}/g, team.name)
      .replace(/\{roleName\}/g, "Player")
      .replace(/\{coachName\}/g, "Coach Smith")
      .replace(/\{playerName\}/g, "John")
      .replace(/\{inviteUrl\}/g, "https://app.example.com/invite/abc123");
  };

  if (!canManage) return null;

  return (
    <Card data-testid="card-invitation-template">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5" />
          Invitation Message
        </CardTitle>
        <CardDescription>
          Customize the SMS message sent when inviting players to your team
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="invitation-template">Message Template</Label>
          <Textarea
            id="invitation-template"
            placeholder={DEFAULT_TEMPLATE}
            value={template}
            onChange={(e) => handleTemplateChange(e.target.value)}
            rows={4}
            className="font-mono text-sm"
            data-testid="textarea-invitation-template"
          />
          <div className="flex items-start gap-2 text-xs text-muted-foreground">
            <Info className="h-3 w-3 mt-0.5 shrink-0" />
            <span>Leave empty to use the default message. Template must include {"{inviteUrl}"} for the invitation link.</span>
          </div>
        </div>

        <div className="space-y-2">
          <Label>Available Variables</Label>
          <div className="flex flex-wrap gap-2">
            {AVAILABLE_VARIABLES.map(({ variable, description }) => (
              <Badge
                key={variable}
                variant="outline"
                className="cursor-pointer hover-elevate"
                onClick={() => insertVariable(variable)}
                title={description}
                data-testid={`badge-variable-${variable.replace(/[{}]/g, "")}`}
              >
                {variable}
              </Badge>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <Label>Preview</Label>
          <div className="p-3 bg-muted rounded-md text-sm">
            {previewMessage()}
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button
            onClick={handleSave}
            disabled={!isDirty || updateTemplateMutation.isPending}
            data-testid="button-save-template"
          >
            {updateTemplateMutation.isPending ? "Saving..." : "Save Template"}
          </Button>
          {team.invitationMessageTemplate && (
            <Button
              variant="outline"
              onClick={handleReset}
              disabled={updateTemplateMutation.isPending}
              data-testid="button-reset-template"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset to Default
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

import { useQuery } from "@tanstack/react-query";
import { DollarSign, Smartphone, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface TeamUsageBillingProps {
  teamId: string;
  canManage: boolean;
}

export function TeamUsageBilling({ teamId, canManage }: TeamUsageBillingProps) {
  const { data: usageSummary } = useQuery<{
    sms: { quantity: number; baseCost: number; markupCost: number; totalCost: number };
    phoneNumber: { quantity: number; baseCost: number; markupCost: number; totalCost: number };
    grandTotal: number;
  }>({
    queryKey: [`/api/teams/${teamId}/usage-summary`],
    enabled: canManage,
  });

  const { data: usageHistory = [] } = useQuery<Array<{
    id: string;
    teamId: string;
    usageType: 'sms' | 'phone_number';
    quantity: number;
    baseCost: number;
    markupCost: number;
    totalCost: number;
    metadata: any;
    createdAt: string;
  }>>({
    queryKey: [`/api/teams/${teamId}/usage`],
    enabled: canManage,
  });

  if (!canManage) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Usage & Billing</CardTitle>
        <CardDescription>
          Track SMS usage, phone number rentals, and estimated costs
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {usageSummary && usageSummary.sms && usageSummary.phoneNumber ? (
          <>
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-medium mb-3">SMS Messages (This Month)</h4>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Count</p>
                    <p className="text-xl font-semibold" data-testid="text-sms-count">
                      {usageSummary.sms.quantity}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Base Cost</p>
                    <p className="text-xl font-semibold" data-testid="text-sms-base-cost">
                      ${parseFloat(usageSummary.sms.baseCost as any).toFixed(4)}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Markup</p>
                    <p className="text-xl font-semibold" data-testid="text-sms-markup-cost">
                      ${parseFloat(usageSummary.sms.markupCost as any).toFixed(4)}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Total</p>
                    <p className="text-xl font-semibold" data-testid="text-sms-total-cost">
                      ${parseFloat(usageSummary.sms.totalCost as any).toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>

              {usageSummary.phoneNumber.quantity > 0 && (
                <div>
                  <h4 className="text-sm font-medium mb-3">Phone Number Rental (This Month)</h4>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Count</p>
                      <p className="text-xl font-semibold" data-testid="text-phone-count">
                        {usageSummary.phoneNumber.quantity}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Base Cost</p>
                      <p className="text-xl font-semibold" data-testid="text-phone-base-cost">
                        ${parseFloat(usageSummary.phoneNumber.baseCost as any).toFixed(2)}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Markup</p>
                      <p className="text-xl font-semibold" data-testid="text-phone-markup-cost">
                        ${parseFloat(usageSummary.phoneNumber.markupCost as any).toFixed(2)}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Total</p>
                      <p className="text-xl font-semibold" data-testid="text-phone-total-cost">
                        ${parseFloat(usageSummary.phoneNumber.totalCost as any).toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 bg-muted/50 rounded-md">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Cost (This Month)</p>
                  <p className="text-3xl font-bold" data-testid="text-total-cost">
                    ${parseFloat(usageSummary.grandTotal as any).toFixed(2)}
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-muted-foreground" />
              </div>
            </div>

            {usageHistory.length > 0 && (() => {
              const smsHistory = usageHistory.filter(u => u.usageType === 'sms');
              const usageByDate = smsHistory.reduce((acc, usage) => {
                const date = new Date(usage.createdAt).toLocaleDateString();
                if (!acc[date]) {
                  acc[date] = { date, messages: 0, cost: 0 };
                }
                acc[date].messages += usage.quantity;
                acc[date].cost += parseFloat(usage.totalCost as any);
                return acc;
              }, {} as Record<string, { date: string; messages: number; cost: number }>);

              const chartData = Object.values(usageByDate).slice(-30);

              return chartData.length > 0 ? (
                <div>
                  <h4 className="text-sm font-medium mb-3">SMS Usage History (Last 30 Days)</h4>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis 
                          dataKey="date" 
                          className="text-xs" 
                          tick={{ fontSize: 10 }}
                          angle={-45}
                          textAnchor="end"
                          height={60}
                        />
                        <YAxis className="text-xs" tick={{ fontSize: 10 }} />
                        <Tooltip 
                          contentStyle={{ fontSize: '12px' }}
                          formatter={(value: any, name: string) => {
                            if (name === 'cost') return [`$${Number(value).toFixed(2)}`, 'Cost'];
                            return [value, 'Messages'];
                          }}
                        />
                        <Bar dataKey="messages" fill="hsl(var(--primary))" name="Messages" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              ) : null;
            })()}

            {usageHistory.length > 0 && (() => {
              const smsWithCampaigns = usageHistory.filter(u => 
                u.usageType === 'sms' && u.metadata?.campaignId
              );

              const campaignUsage = smsWithCampaigns.reduce((acc, usage) => {
                const campaignId = usage.metadata.campaignId;
                if (!acc[campaignId]) {
                  acc[campaignId] = { count: 0, cost: 0 };
                }
                acc[campaignId].count += usage.quantity;
                acc[campaignId].cost += parseFloat(usage.totalCost as any);
                return acc;
              }, {} as Record<string, { count: number; cost: number }>);

              const hasCampaignData = Object.keys(campaignUsage).length > 0;

              return hasCampaignData ? (
                <div>
                  <h4 className="text-sm font-medium mb-3">Breakdown by Campaign</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {Object.entries(campaignUsage).map(([campaignId, data]) => (
                      <div key={campaignId} className="p-3 border rounded-md" data-testid={`campaign-usage-${campaignId}`}>
                        <p className="text-xs text-muted-foreground mb-1">Campaign {campaignId.substring(0, 8)}</p>
                        <div className="flex justify-between items-baseline">
                          <p className="text-sm font-semibold">{data.count} messages</p>
                          <p className="text-sm font-semibold">${data.cost.toFixed(2)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : null;
            })()}

            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="h-3 w-3" />
              <span>
                Usage tracked for current billing month. Costs include base Twilio rates plus admin-configured markup.
              </span>
            </div>
          </>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <Smartphone className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No usage data available for this month</p>
            <p className="text-xs mt-2">Send your first SMS to see usage tracking</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

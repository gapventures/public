import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Smartphone, UserPlus, X, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface ImportedContact {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  email?: string;
}

interface ImportContactsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  teamId: string;
}

export function ImportContactsDialog({ open, onOpenChange, teamId }: ImportContactsDialogProps) {
  const [supportsContactPicker, setSupportsContactPicker] = useState(false);
  const [contacts, setContacts] = useState<ImportedContact[]>([]);
  const [isPickingContacts, setIsPickingContacts] = useState(false);
  const [manualForm, setManualForm] = useState({ firstName: "", lastName: "", phone: "", email: "" });
  const { toast } = useToast();

  useEffect(() => {
    const hasContactPicker = 'contacts' in navigator && 'ContactsManager' in window;
    setSupportsContactPicker(hasContactPicker);
  }, []);

  const handlePickContacts = async () => {
    if (!('contacts' in navigator)) {
      toast({
        title: "Not supported",
        description: "Contact picker is not available in this browser",
        variant: "destructive",
      });
      return;
    }

    setIsPickingContacts(true);
    try {
      const props = ['name', 'tel', 'email'];
      const opts = { multiple: true };
      
      // @ts-expect-error - Contact Picker API types may not be available
      const selectedContacts = await navigator.contacts.select(props, opts);
      
      const importedContacts: ImportedContact[] = selectedContacts.map((contact: any, index: number) => {
        const fullName = contact.name?.[0] || "";
        const nameParts = fullName.trim().split(/\s+/);
        const firstName = nameParts[0] || "";
        const lastName = nameParts.slice(1).join(" ") || "";
        
        return {
          id: `contact-${Date.now()}-${index}`,
          firstName,
          lastName,
          phone: contact.tel?.[0] || "",
          email: contact.email?.[0] || "",
        };
      });

      // Filter out contacts without required fields (name AND phone)
      const validContacts = importedContacts.filter(c => {
        const hasName = c.firstName && c.firstName.trim() !== "";
        const hasPhone = c.phone && c.phone.trim() !== "";
        return hasName && hasPhone;
      });
      
      const invalidCount = importedContacts.length - validContacts.length;
      
      if (validContacts.length === 0) {
        toast({
          title: "No valid contacts",
          description: "Selected contacts must have both a name and phone number",
          variant: "destructive",
        });
        return;
      }

      setContacts(validContacts);
      
      if (invalidCount > 0) {
        toast({
          title: "Contacts imported with warnings",
          description: `${validContacts.length} contact${validContacts.length !== 1 ? 's' : ''} imported. ${invalidCount} skipped (missing name or phone).`,
        });
      } else {
        toast({
          title: "Contacts imported",
          description: `${validContacts.length} contact${validContacts.length !== 1 ? 's' : ''} ready to add`,
        });
      }
    } catch (error: any) {
      if (error.name === 'AbortError') {
        // User cancelled - this is normal, no toast needed
      } else {
        console.error('Contact picker error:', error);
        toast({
          title: "Import failed",
          description: "Could not import contacts. Please try again.",
          variant: "destructive",
        });
      }
    } finally {
      setIsPickingContacts(false);
    }
  };

  const handleAddManualContact = () => {
    if (!manualForm.firstName || !manualForm.phone) {
      toast({
        title: "Missing information",
        description: "First name and phone number are required",
        variant: "destructive",
      });
      return;
    }

    const newContact: ImportedContact = {
      id: `manual-${Date.now()}`,
      firstName: manualForm.firstName.trim(),
      lastName: manualForm.lastName.trim(),
      phone: manualForm.phone.trim(),
      email: manualForm.email.trim() || undefined,
    };

    setContacts([...contacts, newContact]);
    setManualForm({ firstName: "", lastName: "", phone: "", email: "" });
    
    toast({
      title: "Contact added",
      description: `${newContact.firstName} ${newContact.lastName} added to import list`,
    });
  };

  const handleRemoveContact = (id: string) => {
    setContacts(contacts.filter(c => c.id !== id));
  };

  const bulkCreateMutation = useMutation({
    mutationFn: async () => {
      // Prepare player data - teamId comes from route params, not payload
      const playersData = contacts.map(contact => ({
        firstName: contact.firstName,
        lastName: contact.lastName,
        phone: contact.phone,
        email: contact.email || undefined,
        // roleId can be omitted - backend will handle missing role gracefully
      }));

      const response = await apiRequest("POST", `/api/teams/${teamId}/players/bulk`, {
        players: playersData,
      });
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", teamId, "players"] });
      
      const created = data.created || 0;
      const errors = data.errors || [];
      
      if (errors.length === 0) {
        toast({
          title: "Players added",
          description: `Successfully added ${created} player${created !== 1 ? 's' : ''} to the team. Use "Send Invitations" button to notify them.`,
        });
      } else {
        toast({
          title: "Partially completed",
          description: `Added ${created} player${created !== 1 ? 's' : ''}, ${errors.length} failed. Check console for details.`,
          variant: "destructive",
        });
        console.error("Import errors:", errors);
      }
      
      setContacts([]);
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Import failed",
        description: error.message || "Could not add players. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleImport = () => {
    if (contacts.length === 0) {
      toast({
        title: "No contacts",
        description: "Please add at least one contact to import",
        variant: "destructive",
      });
      return;
    }
    
    // Final validation - ensure all contacts have required fields
    const invalidContacts = contacts.filter(c => !c.firstName.trim() || !c.phone.trim());
    if (invalidContacts.length > 0) {
      toast({
        title: "Invalid contacts",
        description: `${invalidContacts.length} contact${invalidContacts.length !== 1 ? 's' : ''} missing required information. Please remove or fix them.`,
        variant: "destructive",
      });
      return;
    }
    
    bulkCreateMutation.mutate();
  };

  const handleDialogClose = (newOpen: boolean) => {
    if (!bulkCreateMutation.isPending) {
      if (!newOpen) {
        setContacts([]);
        setManualForm({ firstName: "", lastName: "", phone: "", email: "" });
      }
      onOpenChange(newOpen);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleDialogClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Import Contacts</DialogTitle>
          <DialogDescription>
            {supportsContactPicker 
              ? "Select contacts from your device or add them manually"
              : "Add players manually - one at a time"}
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-6 py-4">
          {/* Contact Picker Button */}
          {supportsContactPicker && (
            <div className="space-y-2">
              <Button
                onClick={handlePickContacts}
                disabled={isPickingContacts || bulkCreateMutation.isPending}
                className="w-full"
                data-testid="button-pick-contacts"
              >
                {isPickingContacts ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Opening contacts...
                  </>
                ) : (
                  <>
                    <Smartphone className="h-4 w-4 mr-2" />
                    Select from Contacts
                  </>
                )}
              </Button>
              <p className="text-sm text-muted-foreground text-center">
                Tap to select multiple contacts from your device
              </p>
            </div>
          )}

          {/* Manual Add Form */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="text-sm font-medium flex items-center gap-2">
              <UserPlus className="h-4 w-4" />
              Add Manually
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">First Name *</Label>
                <Input
                  id="firstName"
                  value={manualForm.firstName}
                  onChange={(e) => setManualForm({ ...manualForm, firstName: e.target.value })}
                  placeholder="John"
                  disabled={bulkCreateMutation.isPending}
                  data-testid="input-firstName"
                />
              </div>
              <div>
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  value={manualForm.lastName}
                  onChange={(e) => setManualForm({ ...manualForm, lastName: e.target.value })}
                  placeholder="Doe"
                  disabled={bulkCreateMutation.isPending}
                  data-testid="input-lastName"
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={manualForm.phone}
                  onChange={(e) => setManualForm({ ...manualForm, phone: e.target.value })}
                  placeholder="+1 555-0100"
                  disabled={bulkCreateMutation.isPending}
                  data-testid="input-phone"
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={manualForm.email}
                  onChange={(e) => setManualForm({ ...manualForm, email: e.target.value })}
                  placeholder="john@example.com"
                  disabled={bulkCreateMutation.isPending}
                  data-testid="input-email"
                />
              </div>
            </div>
            <Button
              onClick={handleAddManualContact}
              disabled={bulkCreateMutation.isPending}
              variant="outline"
              className="w-full"
              data-testid="button-add-manual"
            >
              <UserPlus className="h-4 w-4 mr-2" />
              Add to Import List
            </Button>
          </div>

          {/* Contacts List */}
          {contacts.length > 0 && (
            <div className="space-y-3 border-t pt-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium">
                  Contacts to Import ({contacts.length})
                </h3>
                <Badge variant="secondary">{contacts.length} player{contacts.length !== 1 ? 's' : ''}</Badge>
              </div>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {contacts.map((contact) => (
                  <div
                    key={contact.id}
                    className="flex items-center justify-between p-3 rounded-md border bg-card"
                    data-testid={`contact-${contact.id}`}
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">
                        {contact.firstName} {contact.lastName}
                      </p>
                      <p className="text-sm text-muted-foreground truncate">{contact.phone}</p>
                      {contact.email && (
                        <p className="text-xs text-muted-foreground truncate">{contact.email}</p>
                      )}
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => handleRemoveContact(contact.id)}
                      disabled={bulkCreateMutation.isPending}
                      data-testid={`button-remove-${contact.id}`}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => handleDialogClose(false)}
            disabled={bulkCreateMutation.isPending}
            data-testid="button-cancel"
          >
            Cancel
          </Button>
          <Button
            onClick={handleImport}
            disabled={contacts.length === 0 || bulkCreateMutation.isPending}
            data-testid="button-import"
          >
            {bulkCreateMutation.isPending ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Importing...
              </>
            ) : (
              `Import ${contacts.length} Contact${contacts.length !== 1 ? 's' : ''}`
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Modern file uploader using UploadThing
import { UploadButton } from "@/utils/uploadthing";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Loader2 } from "lucide-react";

interface UploadThingUploaderProps {
  endpoint: "logoUploader" | "documentUploader" | "messageImageUploader";
  onComplete?: (url: string) => void;
  onError?: (error: Error) => void;
  buttonText?: string;
  buttonClassName?: string;
  disabled?: boolean;
}

export function UploadThingUploader({
  endpoint,
  onComplete,
  onError,
  buttonText = "Upload File",
  buttonClassName,
  disabled = false,
}: UploadThingUploaderProps) {
  const [isUploading, setIsUploading] = useState(false);

  return (
    <div>
      <UploadButton
        endpoint={endpoint}
        onClientUploadComplete={(res) => {
          setIsUploading(false);
          console.log("[UploadThing] onClientUploadComplete called with:", res);
          if (res && res.length > 0) {
            const fileUrl = res[0].url;
            console.log("[UploadThing] Upload complete, file URL:", fileUrl);
            onComplete?.(fileUrl);
          }
        }}
        onUploadError={(error: Error) => {
          setIsUploading(false);
          console.error("[UploadThing] Upload error:", error);
          onError?.(error);
        }}
        onUploadBegin={(fileName) => {
          console.log("[UploadThing] Upload started for file:", fileName);
          setIsUploading(true);
        }}
        appearance={{
          button: buttonClassName || "bg-primary text-primary-foreground hover:bg-primary/90 ut-uploading:cursor-not-allowed ut-uploading:bg-primary/50",
          allowedContent: "text-xs text-muted-foreground",
        }}
        content={{
          button: isUploading ? (
            <span className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              Uploading...
            </span>
          ) : (
            buttonText
          ),
        }}
        disabled={disabled || isUploading}
      />
    </div>
  );
}

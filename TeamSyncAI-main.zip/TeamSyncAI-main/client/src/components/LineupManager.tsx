import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, Loader2, Lock } from "lucide-react";
import type { Event, Player, Lineup } from "@shared/schema";
import { useTierAccess } from "@/hooks/useTierAccess";
import { useAuth } from "@/hooks/useAuth";
import { usePermissions } from "@/hooks/usePermissions";

interface LineupManagerProps {
  event: Event;
  teamId: string;
}

export function LineupManager({ event, teamId }: LineupManagerProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const { tier: tierData, isLoading: tierLoading } = useTierAccess();
  const { permissions, isLoading: permissionsLoading } = usePermissions(teamId);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showSizeDialog, setShowSizeDialog] = useState(false);
  const [lineupSize, setLineupSize] = useState("9");

  // Check if user has permission to manage lineups (requires canManageEvents)
  const canManageLineups = permissions?.canManageEvents || false;

  // Check if user has access to lineup feature (tier-based)
  const hasLineupAccess = user?.isGlobalAdmin || 
    (tierData && (tierData.isOnTrial() || tierData.hasFeature('lineup_management')));

  const { data: lineup, isLoading: lineupLoading } = useQuery<Lineup>({
    queryKey: [`/api/lineups/${event.id}`],
    enabled: event.sport === 'Baseball' || event.sport === 'Softball',
  });

  const { data: players = [] } = useQuery<Player[]>({
    queryKey: ["/api/teams", teamId, "players"],
  });

  const generateLineupMutation = useMutation({
    mutationFn: async (size: number) => {
      const response = await fetch(`/api/lineups/${event.id}/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ lineupSize: size }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to generate lineup");
      }
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/lineups/${event.id}`] });
      setShowSizeDialog(false);
      toast({
        title: "Lineup generated",
        description: "AI has created an optimal lineup based on attendance and player preferences",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Generation failed",
        description: error.message || "Failed to generate lineup",
        variant: "destructive",
      });
    },
  });

  const handleOpenDialog = () => {
    setShowSizeDialog(true);
  };

  const handleGenerateLineup = async () => {
    const size = parseInt(lineupSize);
    if (isNaN(size) || size < 1) {
      toast({
        title: "Invalid lineup size",
        description: "Please enter a valid number of players (1 or more)",
        variant: "destructive",
      });
      return;
    }
    setIsGenerating(true);
    try {
      await generateLineupMutation.mutateAsync(size);
    } finally {
      setIsGenerating(false);
    }
  };

  if (event.sport !== 'Baseball' && event.sport !== 'Softball') {
    return null;
  }

  if (tierLoading || lineupLoading || permissionsLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        </CardContent>
      </Card>
    );
  }

  // Show upgrade message if user has management permission but lacks tier access
  if (canManageLineups && !hasLineupAccess) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-5 w-5" />
            Lineup Management
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="text-center space-y-3">
            <p className="text-muted-foreground">
              AI-powered lineup generation is available with Coach or Pro membership.
            </p>
            <Button variant="outline" asChild>
              <a href="/membership" data-testid="button-upgrade-membership">
                View Membership Options
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getPlayerName = (playerId: string) => {
    const player = players.find(p => p.id === playerId);
    return player ? `${player.firstName} ${player.lastName}` : 'Unknown Player';
  };

  const getPlayerJersey = (playerId: string) => {
    const player = players.find(p => p.id === playerId);
    return player?.jerseyNumber || '';
  };

  const battingOrder = lineup?.battingOrder ? (lineup.battingOrder as any[]) : [];
  const pitchingRotation = lineup?.pitchingRotation ? (lineup.pitchingRotation as any[]) : [];
  const reserves = lineup?.reserves ? (lineup.reserves as any[]) : [];

  // Determine if user can manage lineups (both permission and tier access required)
  const canFullyManageLineups = canManageLineups && hasLineupAccess;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Game Lineup</h3>
        {canFullyManageLineups && (
          <Button
            onClick={handleOpenDialog}
            disabled={isGenerating}
            variant="outline"
            data-testid="button-generate-lineup"
          >
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Generate with AI
              </>
            )}
          </Button>
        )}
      </div>

      {!lineup ? (
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground mb-4">
              {canFullyManageLineups 
                ? "No lineup created yet. Generate one using AI or create manually."
                : "No lineup has been created for this game yet."}
            </p>
            {canFullyManageLineups && (
              <Button onClick={handleOpenDialog} disabled={isGenerating}>
                <Sparkles className="mr-2 h-4 w-4" />
                Generate Lineup
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Batting Order */}
          <Card className="md:col-span-2">
            <CardHeader className="bg-green-600 text-white">
              <CardTitle className="text-center">Batting Order</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <table className="w-full">
                <thead className="border-b">
                  <tr>
                    <th className="text-left p-2 w-12">#</th>
                    <th className="text-left p-2">Position</th>
                    <th className="text-left p-2">Player</th>
                    <th className="text-center p-2 w-16">Jersey</th>
                  </tr>
                </thead>
                <tbody>
                  {battingOrder.map((slot: any, idx: number) => (
                    <tr key={idx} className="border-b hover-elevate" data-testid={`batting-slot-${idx + 1}`}>
                      <td className="p-2 font-semibold">{slot.battingSlot}</td>
                      <td className="p-2 font-medium">{slot.position}</td>
                      <td className="p-2">{slot.playerName || getPlayerName(slot.playerId)}</td>
                      <td className="p-2 text-center">{getPlayerJersey(slot.playerId)}</td>
                    </tr>
                  ))}
                  {battingOrder.length === 0 && (
                    <tr>
                      <td colSpan={4} className="p-4 text-center text-muted-foreground">
                        No batting order set
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </CardContent>
          </Card>

          {/* Pitching & Game Info */}
          <div className="space-y-4">
            {/* Pitching Rotation */}
            <Card>
              <CardHeader className="bg-green-600 text-white">
                <CardTitle className="text-center">Pitching</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <table className="w-full">
                  <thead className="border-b">
                    <tr>
                      <th className="text-left p-2">Role</th>
                      <th className="text-left p-2">Player</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pitchingRotation.map((slot: any, idx: number) => (
                      <tr key={idx} className="border-b hover-elevate" data-testid={`pitching-slot-${idx + 1}`}>
                        <td className="p-2 font-semibold">{idx === 0 ? 'SP' : 'RP'}</td>
                        <td className="p-2">{slot.playerName || getPlayerName(slot.playerId)}</td>
                      </tr>
                    ))}
                    {pitchingRotation.length === 0 && (
                      <tr>
                        <td colSpan={2} className="p-4 text-center text-muted-foreground">
                          No pitchers assigned
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </CardContent>
            </Card>

            {/* Game Info */}
            <Card>
              <CardHeader className="bg-green-600 text-white">
                <CardTitle className="text-center">Game Info</CardTitle>
              </CardHeader>
              <CardContent className="p-3 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">Opponent:</span>
                  <span>{event.opponent || 'TBD'}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="font-medium">Field:</span>
                  <span>{event.location}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="font-medium">Time:</span>
                  <span>{new Date(event.datetime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                {event.jersey && (
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Jersey:</span>
                    <span>{event.jersey}</span>
                  </div>
                )}
                {event.homeAway && (
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Home/Away:</span>
                    <span className="capitalize">{event.homeAway}</span>
                  </div>
                )}
                {event.fieldType && (
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Field Type:</span>
                    <span className="capitalize">{event.fieldType}</span>
                  </div>
                )}
                {event.cleatsAllowed && (
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Cleats:</span>
                    <span className="capitalize">{event.cleatsAllowed}</span>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Reserves */}
          {reserves.length > 0 && (
            <Card className="md:col-span-3">
              <CardHeader className="bg-green-600 text-white">
                <CardTitle className="text-center">Reserves</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 p-3">
                  {reserves.map((reserve: any, idx: number) => (
                    <div key={idx} className="p-2 border rounded hover-elevate" data-testid={`reserve-${idx + 1}`}>
                      <span className="text-sm font-medium">{reserve.playerName || getPlayerName(reserve.playerId)}</span>
                      {getPlayerJersey(reserve.playerId) && (
                        <span className="text-xs text-muted-foreground ml-2">#{getPlayerJersey(reserve.playerId)}</span>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Lineup Size Dialog */}
      <Dialog open={showSizeDialog} onOpenChange={setShowSizeDialog}>
        <DialogContent data-testid="dialog-lineup-size">
          <DialogHeader>
            <DialogTitle>Generate Lineup</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="lineup-size">How many players in the batting order?</Label>
              <Input
                id="lineup-size"
                type="number"
                min="1"
                placeholder="e.g. 9, 10, 11..."
                value={lineupSize}
                onChange={(e) => setLineupSize(e.target.value)}
                data-testid="input-lineup-size"
              />
              <p className="text-xs text-muted-foreground">
                Enter the number of players you want in the batting lineup for this game
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowSizeDialog(false)}
              data-testid="button-cancel-lineup"
            >
              Cancel
            </Button>
            <Button
              onClick={handleGenerateLineup}
              disabled={isGenerating}
              data-testid="button-confirm-generate"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Generate
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { createContext, useContext, useState, ReactNode } from 'react';

export type TestViewMode = 
  | 'off'
  | 'team_owner'
  | 'coach'
  | 'assistant_coach'
  | 'player'
  | 'viewer';

interface TestViewContextType {
  testViewMode: TestViewMode;
  setTestViewMode: (mode: TestViewMode) => void;
  isTestViewActive: boolean;
}

const TestViewContext = createContext<TestViewContextType | undefined>(undefined);

export function TestViewProvider({ children }: { children: ReactNode }) {
  const [testViewMode, setTestViewMode] = useState<TestViewMode>('off');

  return (
    <TestViewContext.Provider
      value={{
        testViewMode,
        setTestViewMode,
        isTestViewActive: testViewMode !== 'off',
      }}
    >
      {children}
    </TestViewContext.Provider>
  );
}

export function useTestView() {
  const context = useContext(TestViewContext);
  if (context === undefined) {
    throw new Error('useTestView must be used within a TestViewProvider');
  }
  return context;
}

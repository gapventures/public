import { useQuery } from "@tanstack/react-query";
import type { AppSettings } from "@shared/schema";

export function useAppName() {
  const { data: appSettings } = useQuery<AppSettings>({
    queryKey: ["/api/app-settings"],
  });

  return appSettings?.applicationName || "TeamSyncAI";
}

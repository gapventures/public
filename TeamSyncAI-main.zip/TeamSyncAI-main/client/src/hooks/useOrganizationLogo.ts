import { useQuery } from "@tanstack/react-query";
import type { LandingPageContent } from "@shared/schema";

export function useOrganizationLogo() {
  const { data: landingContent } = useQuery<LandingPageContent>({
    queryKey: ["/api/landing-page"],
    staleTime: 5 * 60 * 1000,
  });

  return landingContent?.logoUrl || null;
}

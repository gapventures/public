import { useQuery } from "@tanstack/react-query";
import { useAuth } from "./useAuth";
import type { MembershipTier, TierLimit, TierFeature } from "@shared/schema";

type TierWithDetails = MembershipTier & { limits: TierLimit[]; features: TierFeature[] };

export function useTierAccess() {
  const { user: currentUser } = useAuth();
  const { data: tier, isLoading } = useQuery<TierWithDetails>({
    queryKey: ["/api/user/membership-tier"],
    retry: false,
  });

  const isOnTrial = (): boolean => {
    if (!currentUser || !currentUser.trialStartDate || !currentUser.trialEndDate) return false;
    const now = new Date();
    return new Date(currentUser.trialStartDate) <= now && new Date(currentUser.trialEndDate) >= now;
  };

  const user = tier ? {
    tier,
    isOnTrial,
    hasFeature: (featureKey: string): boolean => {
      if (!tier) return false;
      const feature = tier.features.find(f => f.featureKey === featureKey);
      return feature ? feature.enabled : false;
    },
    getLimit: (limitKey: string): number | null => {
      if (!tier) return null;
      const limit = tier.limits.find(l => l.limitKey === limitKey);
      return limit ? limit.limitValue : null;
    },
    canExceedLimit: (limitKey: string, currentCount: number): boolean => {
      if (!tier) return true;
      const limit = tier.limits.find(l => l.limitKey === limitKey);
      if (!limit) return true;
      return currentCount < limit.limitValue;
    },
    hasUnlimitedAccess: (): boolean => {
      return tier.monthlyPrice === 0 && tier.limits.length === 0;
    },
  } : null;

  return {
    tier: user,
    isLoading,
    hasTier: !!tier,
  };
}

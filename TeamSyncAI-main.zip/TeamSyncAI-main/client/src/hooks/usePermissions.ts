import { useQuery } from "@tanstack/react-query";
import { useAuth } from "./useAuth";
import type { Role, Player, Team } from "@shared/schema";
import { useTestView } from "@/contexts/TestViewContext";

interface UserPermissions {
  isTeamOwner: boolean;
  isGlobalAdmin: boolean;
  role: Role | null;
  player: Player | null;
  canViewEvents: boolean;
  canManageEvents: boolean;
  canViewPlayers: boolean;
  canManagePlayers: boolean;
  canSendReminders: boolean;
  canManageCampaigns: boolean;
  canViewResponses: boolean;
  canManageAttendance: boolean;
  canManageSettings: boolean;
  canManageRoles: boolean;
  canViewMembership: boolean;
  isLoading: boolean;
}

export function usePermissions(teamId?: string): UserPermissions {
  const { user } = useAuth();
  const { testViewMode, isTestViewActive } = useTestView();

  const { data: team } = useQuery<Team>({
    queryKey: ["/api/teams", teamId],
    enabled: !!teamId,
  });

  const { data: players = [] } = useQuery<Player[]>({
    queryKey: ["/api/teams", teamId, "players"],
    enabled: !!teamId,
  });

  const { data: roles = [] } = useQuery<Role[]>({
    queryKey: ["/api/teams", teamId, "roles"],
    enabled: !!teamId,
  });

  const isLoading = !user || (!!teamId && (!team || !players || !roles));

  // Global admins have full permissions everywhere (unless in test view mode)
  if (user && user.isGlobalAdmin && !isTestViewActive) {
    return {
      isTeamOwner: true,
      isGlobalAdmin: true,
      role: null,
      player: null,
      canViewEvents: true,
      canManageEvents: true,
      canViewPlayers: true,
      canManagePlayers: true,
      canSendReminders: true,
      canManageCampaigns: true,
      canViewResponses: true,
      canManageAttendance: true,
      canManageSettings: true,
      canManageRoles: true,
      canViewMembership: true,
      isLoading: false,
    };
  }

  // Test view mode override for global admins
  if (user && user.isGlobalAdmin && isTestViewActive) {
    switch (testViewMode) {
      case 'team_owner':
        return {
          isTeamOwner: true,
          isGlobalAdmin: false,
          role: null,
          player: null,
          canViewEvents: true,
          canManageEvents: true,
          canViewPlayers: true,
          canManagePlayers: true,
          canSendReminders: true,
          canManageCampaigns: true,
          canViewResponses: true,
          canManageAttendance: true,
          canManageSettings: true,
          canManageRoles: true,
          canViewMembership: true,
          isLoading: false,
        };
      case 'coach':
        return {
          isTeamOwner: false,
          isGlobalAdmin: false,
          role: null,
          player: null,
          canViewEvents: true,
          canManageEvents: true,
          canViewPlayers: true,
          canManagePlayers: true,
          canSendReminders: true,
          canManageCampaigns: true,
          canViewResponses: true,
          canManageAttendance: true,
          canManageSettings: false,
          canManageRoles: false,
          canViewMembership: true,
          isLoading: false,
        };
      case 'assistant_coach':
        return {
          isTeamOwner: false,
          isGlobalAdmin: false,
          role: null,
          player: null,
          canViewEvents: true,
          canManageEvents: true,
          canViewPlayers: true,
          canManagePlayers: false,
          canSendReminders: true,
          canManageCampaigns: false,
          canViewResponses: true,
          canManageAttendance: true,
          canManageSettings: false,
          canManageRoles: false,
          canViewMembership: false,
          isLoading: false,
        };
      case 'player':
        return {
          isTeamOwner: false,
          isGlobalAdmin: false,
          role: null,
          player: null,
          canViewEvents: true,
          canManageEvents: false,
          canViewPlayers: true,
          canManagePlayers: false,
          canSendReminders: false,
          canManageCampaigns: false,
          canViewResponses: true,
          canManageAttendance: false,
          canManageSettings: false,
          canManageRoles: false,
          canViewMembership: false,
          isLoading: false,
        };
      case 'viewer':
        return {
          isTeamOwner: false,
          isGlobalAdmin: false,
          role: null,
          player: null,
          canViewEvents: true,
          canManageEvents: false,
          canViewPlayers: true,
          canManagePlayers: false,
          canSendReminders: false,
          canManageCampaigns: false,
          canViewResponses: true,
          canManageAttendance: false,
          canManageSettings: false,
          canManageRoles: false,
          canViewMembership: false,
          isLoading: false,
        };
      default:
        break;
    }
  }

  if (!user || !teamId || !team) {
    return {
      isTeamOwner: false,
      isGlobalAdmin: false,
      role: null,
      player: null,
      canViewEvents: false,
      canManageEvents: false,
      canViewPlayers: false,
      canManagePlayers: false,
      canSendReminders: false,
      canManageCampaigns: false,
      canViewResponses: false,
      canManageAttendance: false,
      canManageSettings: false,
      canManageRoles: false,
      canViewMembership: false,
      isLoading,
    };
  }

  const isTeamOwner = team.userId === user.id;

  if (isTeamOwner) {
    return {
      isTeamOwner: true,
      isGlobalAdmin: false,
      role: null,
      player: null,
      canViewEvents: true,
      canManageEvents: true,
      canViewPlayers: true,
      canManagePlayers: true,
      canSendReminders: true,
      canManageCampaigns: true,
      canViewResponses: true,
      canManageAttendance: true,
      canManageSettings: true,
      canManageRoles: true,
      canViewMembership: true,
      isLoading: false,
    };
  }

  const player = players.find(
    (p) => p.email?.toLowerCase() === user.email?.toLowerCase()
  );

  const role = player?.roleId
    ? roles.find((r) => r.id === player.roleId) || null
    : null;

  if (!player || !role) {
    return {
      isTeamOwner: false,
      isGlobalAdmin: false,
      role: null,
      player: null,
      canViewEvents: true,
      canManageEvents: false,
      canViewPlayers: true,
      canManagePlayers: false,
      canSendReminders: false,
      canManageCampaigns: false,
      canViewResponses: true,
      canManageAttendance: false,
      canManageSettings: false,
      canManageRoles: false,
      canViewMembership: false,
      isLoading: false,
    };
  }

  return {
    isTeamOwner: false,
    isGlobalAdmin: false,
    role,
    player,
    canViewEvents: role.canViewEvents,
    canManageEvents: role.canManageEvents,
    canViewPlayers: role.canViewPlayers,
    canManagePlayers: role.canManagePlayers,
    canSendReminders: role.canSendReminders,
    canManageCampaigns: role.canManageCampaigns,
    canViewResponses: role.canViewResponses,
    canManageAttendance: role.canManageAttendance,
    canManageSettings: role.canManageSettings,
    canManageRoles: role.canManageRoles,
    canViewMembership: role.canViewMembership || false,
    isLoading: false,
  };
}

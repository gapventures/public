import { useQuery } from "@tanstack/react-query";
import type { AppSettings } from "@shared/schema";
import { AVAILABLE_SPORTS } from "@shared/schema";

export function useAvailableSports() {
  const { data: appSettings, isLoading } = useQuery<AppSettings>({
    queryKey: ["/api/app-settings"],
  });

  const availableSports = appSettings?.availableSports ?? [...AVAILABLE_SPORTS];
  
  return { availableSports, isLoading };
}

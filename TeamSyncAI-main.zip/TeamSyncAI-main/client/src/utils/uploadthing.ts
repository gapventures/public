// UploadThing React components with type safety
import { generateUploadButton, generateUploadDropzone } from "@uploadthing/react";
import type { OurFileRouter } from "../../../server/uploadthing";

// Configure UploadThing components with our backend URL
const config = {
  url: "/api/uploadthing",
};

export const UploadButton = generateUploadButton<OurFileRouter>(config);
export const UploadDropzone = generateUploadDropzone<OurFileRouter>(config);

# SMS Provider Abstraction Guide

## Overview

TeamSyncAI now supports multiple SMS providers through a clean abstraction layer. This allows you to easily switch between providers like Twilio, Plivo, and others without changing your application code.

## Current Providers

### Twilio (Default)
- **Cost**: ~$0.0079 per SMS
- **Setup**: Already configured
- **Pros**: Established, reliable, excellent documentation
- **Cons**: More expensive at scale, complex pricing

### Plivo (Alternative - Ready to Use)
- **Cost**: ~$0.0055 per SMS (30-40% cheaper than Twilio)
- **Setup**: Requires Plivo account
- **Pros**: Lower cost, simple pricing, 99.99% SLA
- **Cons**: Not currently installed (package needs to be added)

## How to Switch Providers

### Option 1: Switch to Plivo

1. **Install Plivo package**:
   ```bash
   npm install plivo
   ```

2. **Get Plivo credentials**:
   - Sign up at https://www.plivo.com
   - Get your Auth ID and Auth Token from the dashboard
   - Purchase a phone number

3. **Set environment variables**:
   ```bash
   PLIVO_AUTH_ID=your_auth_id
   PLIVO_AUTH_TOKEN=your_auth_token
   PLIVO_PHONE_NUMBER=your_plivo_number
   SMS_PROVIDER=plivo
   ```

4. **Restart the application** - The system will automatically use Plivo

### Option 2: Continue with Twilio (No Changes Needed)

The system defaults to Twilio if `SMS_PROVIDER` is not set or set to `twilio`.

## Architecture

### Provider Interface (`server/sms/provider.ts`)

All SMS providers must implement the `ISMSProvider` interface:

```typescript
interface ISMSProvider {
  name: string;
  sendSMS(params: SendSMSParams): Promise<SMSMessage>;
  searchAvailablePhoneNumbers(params: SearchPhoneNumbersParams): Promise<AvailablePhoneNumber[]>;
  purchasePhoneNumber(params: PurchasePhoneNumberParams): Promise<PhoneNumber>;
  releasePhoneNumber(sid: string): Promise<void>;
  listPhoneNumbers(): Promise<PhoneNumber[]>;
  getDefaultPhoneNumber(): Promise<string>;
  getSMSCost(): Promise<number>;
}
```

### Provider Factory (`server/sms/factory.ts`)

The factory selects the appropriate provider based on the `SMS_PROVIDER` environment variable:

```typescript
import { getSMSProvider } from './sms/factory';

const provider = getSMSProvider(); // Returns configured provider
await provider.sendSMS({ to, from, body });
```

### Implementations

- **TwilioProvider** (`server/sms/twilioProvider.ts`): Wraps Twilio SDK
- **PlivoProvider** (`server/sms/plivoProvider.ts`): Wraps Plivo SDK (example)

## Adding a New Provider

To add support for another SMS provider (e.g., Vonage, Bandwidth):

1. **Create a new provider class**:
   ```typescript
   // server/sms/vonageProvider.ts
   import type { ISMSProvider } from './provider';
   
   export class VonageProvider implements ISMSProvider {
     name = 'vonage';
     
     async sendSMS(params) {
       // Implement using Vonage SDK
     }
     
     // Implement other required methods...
   }
   ```

2. **Register in factory**:
   ```typescript
   // server/sms/factory.ts
   import { VonageProvider } from './vonageProvider';
   
   switch (providerName.toLowerCase()) {
     case 'vonage':
       providerInstance = new VonageProvider();
       break;
     // ... other providers
   }
   ```

3. **Set environment variable**:
   ```bash
   SMS_PROVIDER=vonage
   VONAGE_API_KEY=your_key
   VONAGE_API_SECRET=your_secret
   ```

## Cost Comparison

| Provider | Cost per SMS | Setup Complexity | Notes |
|----------|--------------|------------------|-------|
| Twilio   | $0.0079     | Easy (default)   | Well documented, established |
| Plivo    | $0.0055     | Easy            | 30% cheaper, simple pricing |
| Vonage   | Per-second billing | Medium | Good for longer messages |
| Telnyx   | Varies      | Medium          | Own network infrastructure |

## Migration Checklist

Before switching providers in production:

- [ ] Test SMS sending with new provider in development
- [ ] Verify phone number provisioning works
- [ ] Test opt-out handling
- [ ] Verify message logging
- [ ] Test campaign reminders
- [ ] Check usage tracking and billing
- [ ] Update monitoring/alerting if needed
- [ ] Plan for DNS/webhook URL updates if required

## Provider-Specific Notes

### Twilio
- Supports Replit connector integration
- Automatic fallback to environment variables
- Trial accounts require phone verification

### Plivo
- Requires manual package installation (`npm install plivo`)
- Simple auth with Auth ID and Token
- Different API structure but same interface

## Troubleshooting

### Provider not switching
- Verify `SMS_PROVIDER` environment variable is set correctly
- Restart the application after changing environment variables
- Check logs for `[SMS] Using {provider} provider` message

### Phone number provisioning fails
- Ensure provider credentials are valid
- Check account balance
- Verify account is not in trial mode (may require verification)
- Try different area codes if specific area is unavailable

### SMS not sending
- Check provider dashboard for delivery status
- Verify phone numbers are in E.164 format
- Ensure account has sufficient balance
- Check for opt-out status in database

## Environment Variables Reference

### Twilio
```bash
TWILIO_ACCOUNT_SID=ACxxxx
TWILIO_AUTH_TOKEN=your_token
TWILIO_PHONE_NUMBER=+1234567890
SMS_PROVIDER=twilio  # or omit (default)
```

### Plivo
```bash
PLIVO_AUTH_ID=MAxxxx
PLIVO_AUTH_TOKEN=your_token
PLIVO_PHONE_NUMBER=+1234567890
SMS_PROVIDER=plivo
```

## Future Enhancements

Potential improvements to the provider system:

1. **Multi-provider failover**: Automatically switch providers if one fails
2. **Load balancing**: Distribute SMS across multiple providers
3. **Cost optimization**: Route messages based on destination pricing
4. **A/B testing**: Compare delivery rates across providers
5. **Provider-specific features**: Expose advanced features when available

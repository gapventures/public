# TeamSyncAI SMS Guide

## Overview

TeamSyncAI automates team communication via text messages (SMS). Players receive event reminders and can respond directly via text to confirm attendance. The system tracks all responses and updates attendance automatically.

---

## For Coaches & Team Managers

### Sending Event Reminders

1. **Navigate to your event** in the Events page
2. **Click "Send Reminder"** button
3. **Choose reminder timing**:
   - Before event (e.g., 24 hours before, 2 hours before)
   - Custom time
4. **Review recipients** - All players with valid phone numbers will receive the message
5. **Send** - Players receive the reminder immediately

### Sending Campaigns

Campaigns let you send custom messages to your team (not tied to a specific event):

1. **Go to Campaigns** page
2. **Create New Campaign**
3. **Write your message** - Can include team announcements, schedule changes, etc.
4. **Select recipients**:
   - All players
   - By reliability score (target unreliable players for extra reminders)
   - Custom selection
5. **Send now or schedule** for later

### Viewing Responses

**In Event Page:**
- See real-time RSVP status for each player
- Green (YES), Red (NO), Yellow (MAYBE)
- View player notes/reasons for their response

**In Settings > Phone Numbers:**
- Total messages sent/received
- Message logs with full conversation history
- Opt-out tracking

---

## For Players & Parents

### Receiving Messages

All SMS messages come from: **+1 (855) 677-3180**

Example reminder message:
```
[Team Name] Game Reminder
📅 Saturday, Nov 23 at 3:00 PM
📍 Lincoln Field

Reply:
1 for YES
2 for NO
3 for MAYBE
```

### Responding to Reminders

#### Option 1: Simple Numeric Response
Just reply with a number:
- **Text "1"** → You're attending (YES)
- **Text "2"** → You can't make it (NO)
- **Text "3"** → You're unsure (MAYBE)

#### Option 2: Natural Language
You can also reply in your own words:
- "Yeah I'll be there" → YES
- "Can't make it, stuck at work" → NO
- "I might be 15 mins late" → MAYBE
- "Sorry coach, have a family thing" → NO

The system uses AI to understand your message and update your status automatically.

### Changing Your Response

Changed your mind? **Just text again!**

**Example:**
1. Monday: Text "2" (can't make it)
2. Wednesday: Text "1" (plans changed, I can come!)
3. Your status is now YES ✅

You can change your response as many times as needed before the event. The system always uses your most recent reply.

### Adding a Note

Want to explain your response? Just include it:
- "1 - Will be there but might be 10 mins late"
- "2 - Family emergency, sorry coach"
- "3 - Depends on if I finish work early"

Coaches will see your note along with your response.

---

## Opt-Out / Opt-In (TCPA Compliance)

### To Stop Receiving Messages

Text any of these keywords to **+1 (855) 677-3180**:
- STOP
- STOPALL
- UNSUBSCRIBE
- CANCEL
- END
- QUIT

You'll receive a confirmation: *"You have been unsubscribed from [Team Name] SMS messages. Reply START to resubscribe."*

### To Start Receiving Messages Again

Text any of these keywords:
- START
- UNSTOP
- YES

You'll receive a confirmation: *"You have been resubscribed to [Team Name] SMS messages."*

**Note:** Each team has separate opt-out status. If you're on multiple teams, you can opt out of one without affecting the others.

---

## How the System Works

### Message Routing (Beta Launch)

**Currently:** All teams share **+1 (855) 677-3180**
- The system tracks which team each player belongs to
- When you reply, it automatically knows your team context
- Responses are linked to the correct upcoming event

**After A2P Approval:** Teams can provision dedicated numbers
- Each team gets their own number
- Better delivery rates and TCPA compliance

### Smart Event Matching

When you reply to a reminder:
1. System identifies you by your phone number
2. Finds your team
3. Matches your response to the **next upcoming event**
4. Updates your RSVP status instantly

### Response Tracking

Your responses are logged and tracked:
- **RSVP History**: Coaches can see all your responses
- **Reliability Score**: System tracks if you honor commitments
  - Show up when you say YES: Score goes up ⬆️
  - No-show after saying YES: Score goes down ⬇️
  - Show up after saying NO/MAYBE: Small bonus ✨
- **Better Reminders**: Unreliable players get extra reminders automatically

---

## Message Costs & Billing

### How Billing Works
- **Pay-per-message**: Only pay for messages you send
- **Current Rate**: $0.0079 per SMS segment
- **Track Usage**: View costs in Settings > Billing

### Message Segments
- Most messages = 1 segment (160 characters)
- Longer messages = multiple segments
- Emojis count as more characters

### Cost Examples
- Simple reminder to 15 players = 15 × $0.0079 = **$0.12**
- Campaign to 50 players = 50 × $0.0079 = **$0.40**

---

## Best Practices

### For Coaches

**Timing:**
- Send reminders 24-48 hours before events
- Send follow-up 2-4 hours before for stragglers
- Avoid late-night messages (respect player time zones)

**Message Content:**
- Keep it clear and concise
- Include: Date, time, location
- Add any special instructions (bring equipment, arrive early, etc.)

**Response Management:**
- Check RSVPs regularly
- Follow up with MAYBE responses
- Thank players for reliable attendance

### For Players

**Quick Responses:**
- Reply within 24 hours if possible
- Coaches need accurate headcounts for planning

**Update Changes:**
- Text immediately if your plans change
- Coaches appreciate timely updates

**Honoring Commitments:**
- If you say YES, try your best to attend
- Your reliability score affects reminder frequency

---

## Troubleshooting

### Not Receiving Messages?

1. **Check opt-out status**: Text "START" to resubscribe
2. **Verify phone number**: Make sure coach has your correct number
3. **Check carrier**: Some carriers block short codes/shared numbers

### Messages Going to Wrong Team?

- This shouldn't happen - contact your coach to verify your phone number is correct in the roster

### Response Not Updating?

1. **Check you replied to the right number**: +1 (855) 677-3180
2. **Wait a few seconds**: Updates are usually instant but may take up to 30 seconds
3. **Reply again**: The system processes the most recent message

### Getting Messages from Old Team?

- Text "STOP" to opt out of that team's messages
- Each team has separate opt-out tracking

---

## Privacy & Data

### What We Track
- Phone numbers (for sending/receiving messages)
- Message content and timestamps
- RSVP responses and notes
- Opt-out preferences

### What We Don't Share
- Your phone number is never shared with other teams
- Messages are only visible to your team's coaches
- Opt-out status is private

### Data Retention
- Message logs kept for audit/compliance purposes
- You can request deletion by contacting your coach or admin

---

## Support

### For Players
Contact your team coach or manager with questions

### For Coaches
- View documentation in the app
- Contact TeamSyncAI support for technical issues
- Check Settings > Phone Numbers for message logs and diagnostics

---

**Last Updated:** November 2024  
**Version:** Beta (Shared Number)

# TeamSyncAI Testing Guide

## Overview

This testing infrastructure helps you validate all critical functionality before going live with real users, real SMS costs, and real payments. The goal is to catch bugs early and avoid costly mistakes in production.

## Testing Strategy

### 1. **Unit Tests (Jest)** - Fast, Isolated Logic Testing
**Purpose**: Test individual functions without external dependencies  
**Coverage**:
- SMS template variable replacement
- Opt-out enforcement (TCPA compliance)
- Usage tracking cost calculations
- Provider abstraction layer
- Phone number normalization

**How to Run**:
```bash
# All commands require NODE_OPTIONS='--experimental-vm-modules' flag
# Add --testPathIgnorePatterns=plivo to skip Plivo tests (no plivo package needed)
NODE_OPTIONS='--experimental-vm-modules' npx jest --testPathIgnorePatterns=plivo      # Run tests
NODE_OPTIONS='--experimental-vm-modules' npx jest --watch --testPathIgnorePatterns=plivo    # Watch mode
NODE_OPTIONS='--experimental-vm-modules' npx jest --coverage --testPathIgnorePatterns=plivo  # Coverage
```

### 2. **Integration Tests (Supertest + Jest)** - API Route Testing
**Purpose**: Test Express routes with mocked external services  
**Coverage** (Coming next):
- Campaign creation and sending
- Payment request workflows
- Phone number provisioning
- Webhook handlers (Helcim, SMS)

### 3. **End-to-End Tests (Playwright)** - Full User Journey Testing
**Purpose**: Test complete workflows in the browser  
**Use existing `run_test` tool for**:
- Coach creates campaign and sends SMS
- Parent RSVP and payment checkout
- Phone number provisioning UI

---

## Current Test Coverage

### ✅ Implemented Unit Tests

#### **SMS Template Variables** (`server/__tests__/twilio.test.ts`)
Tests the critical `replaceTemplateVariables` function:
- Player name, first name, team variables
- Event-specific variables (date, time, location)
- Multiple variable replacement
- Optional/missing variable handling
- Legacy bracket format backward compatibility
- Special characters in values

**Why Critical**: Incorrect variable replacement could send confusing or wrong information to parents/players.

#### **Opt-Out Handling** (`server/__tests__/optOut.test.ts`)
**⚠️ CRITICAL FOR TCPA COMPLIANCE**

Tests that SMS are NOT sent to opted-out users:
- Blocks SMS to opted-out numbers
- Allows SMS to non-opted-out numbers
- Checks opt-out before every send
- Team-specific opt-outs (can be opted out of one team but not another)

**Why Critical**: Sending SMS to opted-out users violates TCPA and can result in $500-$1500 fines per message.

#### **Usage Tracking & Billing** (`server/__tests__/usageTracking.test.ts`)
**⚠️ CRITICAL FOR REVENUE**

Tests accurate cost calculations:
- Fixed markup calculation
- Percentage markup calculation
- Zero costs when pricing missing
- Message metadata tracking
- Logging even if usage tracking fails

**Why Critical**: Incorrect billing means you lose money or overcharge customers.

#### **Provider Abstraction** (`server/__tests__/sms/`)
Tests the multi-provider SMS system:
- Twilio provider metadata
- Plivo provider metadata and cost comparison
- Factory pattern provider selection
- Provider caching and reset

**Why Critical**: Ensures you can switch SMS providers without breaking functionality.

---

## Test Scenarios Covered

### High-Risk Scenarios (Currently Tested)

| Scenario | Test Coverage | Risk Level | Impact if Broken |
|----------|---------------|------------|------------------|
| Opted-out user receives SMS | ✅ Tested | **CRITICAL** | Legal liability ($500-$1500/msg) |
| Incorrect usage costs | ✅ Tested | **HIGH** | Revenue loss or overcharging |
| Template variables fail | ✅ Tested | **HIGH** | Confusing/wrong messages to users |
| Provider switch breaks SMS | ✅ Tested | **HIGH** | No SMS can be sent |
| Team-specific opt-outs | ✅ Tested | **MEDIUM** | Privacy/compliance issues |

### Medium-Risk Scenarios (Need Testing Next)

| Scenario | Test Coverage | Risk Level | Impact if Broken |
|----------|---------------|------------|------------------|
| Phone provisioning fails | ❌ Not tested | **MEDIUM** | Teams can't get dedicated numbers |
| Campaign scheduling errors | ❌ Not tested | **MEDIUM** | Reminders sent at wrong times |
| Payment capture fails | ❌ Not tested | **HIGH** | Money not collected |
| Duplicate reminder sends | ❌ Not tested | **MEDIUM** | Annoying users, wasted money |
| Invalid phone numbers | ❌ Not tested | **LOW** | SMS delivery failures |

---

## Running Tests

### Quick Start

**Important**: All test commands must include the `NODE_OPTIONS='--experimental-vm-modules'` flag because this project uses ES modules.

```bash
# Run all tests (requires Plivo package: npm install plivo)
NODE_OPTIONS='--experimental-vm-modules' npx jest

# Run tests without Plivo (recommended for quick testing)
NODE_OPTIONS='--experimental-vm-modules' npx jest --testPathIgnorePatterns=plivo

# Watch mode (auto-reruns on file changes)  
NODE_OPTIONS='--experimental-vm-modules' npx jest --watch --testPathIgnorePatterns=plivo

# Generate coverage report
NODE_OPTIONS='--experimental-vm-modules' npx jest --coverage --testPathIgnorePatterns=plivo

# Run specific test file
NODE_OPTIONS='--experimental-vm-modules' npx jest twilio.test

# Run tests matching pattern
NODE_OPTIONS='--experimental-vm-modules' npx jest --testNamePattern="opt-out"
```

**Note**: Plivo tests require the `plivo` package to be installed. If you see TypeScript errors about missing 'plivo' module, either:
- Install it: `npm install plivo`
- Or skip Plivo tests: add `--testPathIgnorePatterns=plivo` to your jest command

**Pro tip**: Create a shell alias to make this easier:
```bash
alias jest-test="NODE_OPTIONS='--experimental-vm-modules' npx jest --testPathIgnorePatterns=plivo"
# Then run: jest-test --watch
```

### Interpreting Results

**✅ PASS** - All tests passed
```
PASS  server/__tests__/twilio.test.ts
  SMS Template Variables
    ✓ replaces player name (3 ms)
    ✓ replaces multiple variables (2 ms)
```

**❌ FAIL** - Tests failed (fix before deploying!)
```
FAIL  server/__tests__/optOut.test.ts
  ● Opt-Out Handling › should NOT send to opted-out user
    
    expect(result).toBeNull()
    Expected: null
    Received: "mock-sid-123"
```

**Coverage Report** - Shows what code is tested
```
-------------------|---------|----------|---------|---------|
File               | % Stmts | % Branch | % Funcs | % Lines |
-------------------|---------|----------|---------|---------|
twilio.ts          |   85.42  |    78.57 |   88.89 |   84.78 |
-------------------|---------|----------|---------|---------|
```

Goal: **80%+ coverage** on critical modules.

---

## Pre-Launch Testing Checklist

### Phase 1: Unit Tests (Current)
- [x] SMS template variable replacement
- [x] Opt-out enforcement
- [x] Usage tracking calculations
- [x] Provider abstraction
- [ ] Phone number normalization edge cases
- [ ] Reliability score filtering
- [ ] Campaign template merging

### Phase 2: Integration Tests (Next)
- [ ] POST /api/campaigns - Create campaign
- [ ] POST /api/campaigns/:id/send - Send campaign with opt-out checks
- [ ] POST /api/teams/:id/provision-phone - Phone provisioning
- [ ] POST /api/payments - Payment request creation
- [ ] POST /api/sms/webhook - Incoming SMS handling
- [ ] POST /api/helcim/webhook - Payment status updates

### Phase 3: End-to-End Tests (Browser)
- [ ] Coach login → create team → provision phone number
- [ ] Coach create campaign → send to players
- [ ] Player/parent receives SMS → clicks opt-out
- [ ] Coach sends payment request → parent pays
- [ ] Campaign scheduled reminders fire on time

### Phase 4: Manual Testing
- [ ] Test with real Twilio number (small batch, <10 SMS)
- [ ] Test Helcim payment flow in test mode
- [ ] Verify opt-out actually prevents future SMS
- [ ] Check usage tracking shows correct costs
- [ ] Test switching to Plivo in staging environment
- [ ] Verify scheduled reminders fire correctly

---

## Mocking External Services

### SMS Providers (Twilio/Plivo)
**Mock Location**: `server/__tests__/mocks/smsProvider.mock.ts`

Prevents real SMS from being sent during tests:
```typescript
const mockProvider = new MockSMSProvider();
mockProvider.sendSMSResult = { sid: 'test-123', status: 'sent' };
```

**Benefits**:
- No SMS costs during testing
- Fast test execution
- Predictable responses
- Can test error scenarios

### Database (Storage Layer)
**Mock Location**: `server/__tests__/mocks/storage.mock.ts`

Prevents real database writes:
```typescript
const mockStorage = createMockStorage();
mockStorage.isOptedOut.mockResolvedValue(true);
```

**Benefits**:
- Tests don't modify real data
- Fast, in-memory execution
- Easy to set up test scenarios

---

## Best Practices

### 1. **Test Names Should Be Clear**
```typescript
// ✅ Good
it('should NOT send SMS to opted-out user')

// ❌ Bad
it('works correctly')
```

### 2. **Test One Thing Per Test**
```typescript
// ✅ Good - focused on one scenario
it('calculates percentage markup correctly', () => {
  // ... test percentage calculation
});

it('calculates fixed markup correctly', () => {
  // ... test fixed calculation
});

// ❌ Bad - tests too many things
it('calculates costs', () => {
  // ... tests percentage, fixed, and zero costs
});
```

### 3. **Use Descriptive Assertions**
```typescript
// ✅ Good - clear expectation
expect(mockProvider.sendSMSCalls).toHaveLength(0);

// ❌ Bad - unclear what's being tested
expect(result).toBeTruthy();
```

### 4. **Clean Up After Tests**
```typescript
beforeEach(() => {
  jest.clearAllMocks();
  mockProvider.reset();
});
```

---

## Common Issues

### Issue: "Cannot find module"
**Solution**: Ensure Jest is configured with correct module mappings
```javascript
// jest.config.js
moduleNameMapper: {
  '^@shared/(.*)$': '<rootDir>/shared/$1',
}
```

### Issue: "ReferenceError: jest is not defined"
**Solution**: Add `@types/jest` to devDependencies
```bash
npm install --save-dev @types/jest
```

### Issue: Tests hang and don't finish
**Solution**: Ensure all async operations are awaited
```typescript
// ✅ Good
await sendSMS('+1234567890', 'Test');

// ❌ Bad - missing await
sendSMS('+1234567890', 'Test');
```

---

## Next Steps

1. **Run existing tests**: `NODE_OPTIONS='--experimental-vm-modules' npx jest` to see current coverage
2. **Add integration tests**: Test API routes with supertest
3. **Add e2e tests**: Use Playwright for full user journeys
4. **Increase coverage**: Aim for 80%+ on critical modules
5. **Test in staging**: Run against real services in test mode
6. **Monitor in production**: Set up error tracking (Sentry, etc.)

---

## Resources

- **Jest Documentation**: https://jestjs.io/docs/getting-started
- **Supertest**: https://github.com/visionmedia/supertest
- **Testing Best Practices**: https://github.com/goldbergyoni/javascript-testing-best-practices

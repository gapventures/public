# Pre-Launch Testing Checklist

## Overview
This checklist helps ensure TeamSyncAI is ready for production deployment with real users, real SMS costs, and real payments. Complete each section before going live.

---

## Phase 1: Automated Testing ✅

### Unit Tests (Jest)
Run: `NODE_OPTIONS='--experimental-vm-modules' npx jest`

**Setup**: Tests are already configured. Just run the command above.

- [ ] **SMS Template Variables** - All merge variables work correctly
  - `NODE_OPTIONS='--experimental-vm-modules' npx jest twilio.test`
  - Verify: All 11 test cases pass
  
- [ ] **Opt-Out Handling (TCPA Compliance)** ⚠️ CRITICAL
  - `NODE_OPTIONS='--experimental-vm-modules' npx jest optOut.test`
  - Verify: Opted-out users NEVER receive SMS
  - Verify: Team-specific opt-outs work correctly
  
- [ ] **Usage Tracking & Billing** ⚠️ CRITICAL
  - `NODE_OPTIONS='--experimental-vm-modules' npx jest usageTracking.test`
  - Verify: Cost calculations are accurate
  - Verify: Fixed and percentage markups work
  
- [ ] **Provider Abstraction**
  - `NODE_OPTIONS='--experimental-vm-modules' npx jest factory.test`
  - Verify: Can switch between Twilio and Plivo
  - Verify: Provider caching works

**Acceptance Criteria**: All tests pass with 0 failures

---

## Phase 2: Integration Testing (API Routes)

### Critical Endpoints to Test

#### SMS & Campaigns
- [ ] **POST /api/campaigns** - Create campaign
  - Test: Valid campaign creation
  - Test: Event-based vs standalone campaigns
  - Test: Template variable validation
  
- [ ] **POST /api/campaigns/:id/send** - Send campaign
  - Test: Respects opt-outs
  - Test: Uses correct phone number (team-specific or default)
  - Test: Logs messages correctly
  - Test: Tracks usage costs
  
- [ ] **POST /api/sms/webhook** - Incoming SMS
  - Test: Handles STOP/UNSUBSCRIBE opt-outs
  - Test: Logs inbound messages
  - Test: Handles invalid signatures

#### Phone Number Management
- [ ] **POST /api/teams/:id/provision-phone** - Provision number
  - Test: Successfully provisions number
  - Test: Handles no available numbers
  - Test: Updates team status correctly
  
- [ ] **DELETE /api/teams/:id/phone-number** - Release number
  - Test: Releases number from provider
  - Test: Updates team records

#### Payments
- [ ] **POST /api/payments** - Create payment request
  - Test: Generates Helcim checkout
  - Test: Tracks request in database
  
- [ ] **POST /api/helcim/webhook** - Payment status updates
  - Test: Marks payments as paid
  - Test: Handles declined cards
  - Test: Validates webhook signatures

**Acceptance Criteria**: All endpoints return correct status codes and create expected side effects

---

## Phase 3: End-to-End Testing (Playwright)

### Critical User Journeys

#### Coach Workflow
- [ ] **Team Setup**
  1. Coach signs up / logs in
  2. Creates team
  3. Provisions dedicated phone number
  4. Verifies number appears in settings
  
- [ ] **Player Management**
  1. Add players via CSV import
  2. Invite players via SMS
  3. Verify players appear in roster
  
- [ ] **Campaign Creation & Sending**
  1. Create event-based campaign
  2. Configure 3 reminders (3 days, 1 day, 2 hours before)
  3. Target specific reliability score
  4. Send immediate test message
  5. Verify message logs show delivery

#### Parent/Player Workflow
- [ ] **RSVP Handling**
  1. Receive SMS with event details
  2. Reply with attendance status
  3. Verify response logged
  
- [ ] **Opt-Out**
  1. Reply with "STOP"
  2. Verify opt-out recorded
  3. Verify no future messages received
  4. Test opt-in again
  
- [ ] **Payment Flow**
  1. Receive payment request SMS
  2. Click link to Helcim checkout
  3. Complete payment (test mode)
  4. Verify payment marked as paid
  5. Verify confirmation message

**Acceptance Criteria**: All journeys complete successfully in test environment

---

## Phase 4: Provider Testing

### Twilio Testing (Current Default)
- [ ] **Send test SMS** (≤ 10 messages)
  - To: Your own phone number
  - Verify: Message received
  - Verify: Correct from number
  - Verify: Message logs updated
  - Verify: Usage tracking shows costs
  
- [ ] **Provision phone number** (staging only)
  - Provision test number
  - Send SMS from that number
  - Release number after testing
  
- [ ] **Webhook testing**
  - Reply to test SMS
  - Verify inbound message logged
  - Reply with "STOP"
  - Verify opt-out recorded

### Plivo Testing (Before Switching)
Only test if planning to switch providers before launch:

- [ ] **Install Plivo SDK**
  - `npm install plivo`
  
- [ ] **Configure Plivo credentials**
  ```bash
  PLIVO_AUTH_ID=your_auth_id
  PLIVO_AUTH_TOKEN=your_token
  PLIVO_PHONE_NUMBER=+1xxxxxxxxxx
  SMS_PROVIDER=plivo
  ```
  
- [ ] **Send test SMS via Plivo**
  - Restart app
  - Send test message
  - Verify logs show "Using plivo provider"
  - Verify message delivered
  - Verify costs tracked correctly

**Acceptance Criteria**: Both providers can send SMS and handle responses correctly

---

## Phase 5: Campaign Scheduling Testing

### Scheduled Reminders
- [ ] **Create campaign with future reminders**
  1. Create event 1 week from now
  2. Set reminders: 3 days, 1 day, 2 hours before
  3. Wait for first reminder time
  4. Verify reminder sent at correct time
  
- [ ] **Duplicate send prevention**
  1. Create two campaigns for same event
  2. Verify players don't get duplicate messages
  
- [ ] **Timezone handling**
  1. Set event in different timezone
  2. Verify reminders sent in event's local time

### Cron Job Validation
- [ ] **Manual trigger test**
  - Trigger reminder check manually
  - Verify due reminders sent
  - Verify no duplicate sends
  
- [ ] **Production cron validation**
  - Monitor logs for cron execution
  - Verify runs every minute
  - Check for errors in logs

**Acceptance Criteria**: Reminders send at correct times with no duplicates

---

## Phase 6: Payment System Testing

### Helcim Integration
- [ ] **Test mode configuration**
  - Verify using test API keys
  - Verify test mode banner appears
  
- [ ] **Payment request creation**
  1. Create payment request
  2. Verify Helcim checkout link generated
  3. Verify request tracked in database
  
- [ ] **Payment capture**
  1. Complete payment with test card: `4242 4242 4242 4242`
  2. Verify webhook received
  3. Verify payment status updated to "paid"
  4. Verify confirmation sent to payer
  
- [ ] **Declined payment handling**
  1. Use test card for decline: `4000 0000 0000 0002`
  2. Verify payment marked as "failed"
  3. Verify coach notified
  
- [ ] **Refund testing**
  1. Refund a test payment
  2. Verify status updated
  3. Verify ledger shows refund

**Acceptance Criteria**: All payment flows work correctly in test mode

---

## Phase 7: Security & Compliance

### TCPA Compliance
- [ ] Opt-out enforcement tested (Phase 1)
- [ ] STOP keywords working (STOP, UNSUBSCRIBE, QUIT, CANCEL, END)
- [ ] Opt-in required before first message
- [ ] Team-specific opt-outs working
- [ ] Opt-out confirmation sent immediately

### Data Protection
- [ ] Passwords hashed (bcrypt)
- [ ] Session secrets configured
- [ ] API keys in environment variables (not committed to code)
- [ ] Helcim webhook signature validation
- [ ] SMS provider credentials secured

### Multi-Tenant Isolation
- [ ] Users can only see their own teams
- [ ] Team owners can only manage their teams
- [ ] Usage tracking isolated by team
- [ ] Payment requests scoped to team

**Acceptance Criteria**: All security checks pass

---

## Phase 8: Performance & Monitoring

### Load Testing
- [ ] **Bulk SMS sending**
  - Send campaign to 100+ players
  - Monitor success/failure rates
  - Check for rate limit issues
  
- [ ] **Concurrent operations**
  - Multiple coaches creating campaigns simultaneously
  - No database conflicts or race conditions

### Error Handling
- [ ] **Provider failures**
  - Simulate Twilio/Plivo downtime
  - Verify graceful error messages
  - Verify errors logged
  
- [ ] **Database failures**
  - Simulate connection loss
  - Verify app doesn't crash
  - Verify retry logic works

### Logging & Monitoring
- [ ] SMS send/receive logs complete
- [ ] Payment webhook logs complete
- [ ] Error logs capture stack traces
- [ ] Sensitive data (API keys, passwords) not logged

**Acceptance Criteria**: App handles errors gracefully and logs useful debugging info

---

## Phase 9: Pre-Production Deployment

### Staging Environment
- [ ] Deploy to staging environment
- [ ] Run all automated tests against staging
- [ ] Complete manual testing checklist
- [ ] Test with real (small batch) SMS
- [ ] Verify database migrations work

### Environment Configuration
- [ ] All required environment variables set
- [ ] Production API keys configured
- [ ] SESSION_SECRET set to secure random value
- [ ] Database connection string correct
- [ ] SMS provider credentials correct
- [ ] Helcim production keys configured

### Data Migration
- [ ] Test data seeded (if needed)
- [ ] Production roles created (Coach, Player, etc.)
- [ ] Usage pricing configured
- [ ] Payment providers configured

**Acceptance Criteria**: Staging environment mirrors production setup

---

## Phase 10: Production Deployment

### Pre-Launch
- [ ] All previous phases complete
- [ ] Final security audit passed
- [ ] Performance benchmarks met
- [ ] Error monitoring configured (Sentry, etc.)
- [ ] Backup strategy in place

### Launch Day
- [ ] Deploy to production
- [ ] Run smoke tests
- [ ] Monitor error logs
- [ ] Watch for webhook delivery issues
- [ ] Check SMS delivery rates

### Post-Launch Monitoring (First 24 Hours)
- [ ] Monitor SMS usage and costs
- [ ] Check payment processing success rate
- [ ] Review error logs every 2 hours
- [ ] Verify scheduled reminders firing
- [ ] Monitor database performance

**Acceptance Criteria**: Production app stable with no critical errors

---

## Critical Metrics to Track

### SMS Metrics
- Total messages sent
- Delivery success rate (target: >98%)
- Opt-out rate (target: <2%)
- Cost per message
- Average send time

### Payment Metrics
- Payment success rate (target: >95%)
- Average transaction value
- Refund rate (target: <3%)
- Webhook delivery success (target: 100%)

### System Health
- API response times (target: <500ms)
- Database query performance
- Error rate (target: <0.1%)
- Uptime (target: 99.9%)

---

## Rollback Plan

If critical issues discovered:

1. **Immediate**: Disable SMS sending (set SMS_PROVIDER to mock)
2. **Within 1 hour**: Fix and deploy patch
3. **If unfixable**: Rollback to previous version
4. **Communication**: Notify affected users within 2 hours

---

## Sign-Off

Before launching to production, the following must be verified:

- [ ] All automated tests passing
- [ ] All integration tests passing
- [ ] All e2e tests passing
- [ ] Security audit complete
- [ ] Opt-out compliance verified
- [ ] Billing accuracy verified
- [ ] Staging deployment successful
- [ ] Team trained on monitoring procedures

**Signed off by**: ________________  
**Date**: ________________

---

**REMEMBER**: It's better to delay launch than to deploy with critical bugs. Take your time validating everything!

/**
 * Payment Authorization Helpers
 * 
 * Reusable utilities for enforcing team and player access control
 * in payment routes.
 */

import { db } from '../db';
import { teams, players, teamMembers } from '../../shared/schema';
import { eq, and, or, isNotNull } from 'drizzle-orm';

/**
 * Assert user has access to a team with optional permission requirement
 * 
 * Access is granted if user is:
 * - Global admin
 * - Team owner
 * - Player on team with required permission (if specified)
 * 
 * @throws 404 if team not found
 * @throws 403 if user not authorized
 */
export async function ensureTeamAccess(
  userId: string,
  userEmail: string | null | undefined,
  teamId: string,
  isGlobalAdmin: boolean,
  requiredPermission?: 'canViewPlayers' | 'canManagePlayers'
): Promise<{ teamId: string; userId: string }> {
  // Fetch team once
  const [team] = await db
    .select()
    .from(teams)
    .where(eq(teams.id, teamId))
    .limit(1);

  if (!team) {
    throw { code: 'TEAM_NOT_FOUND', status: 404, message: 'Team not found' };
  }

  // Global admin has access to all teams
  if (isGlobalAdmin) {
    return { teamId: team.id, userId: team.userId };
  }

  // Team owner has access
  if (team.userId === userId) {
    return { teamId: team.id, userId: team.userId };
  }

  // Check if user is on team via teamMembers table (primary)
  const normalizedEmail = userEmail?.toLowerCase();
  
  // Build WHERE conditions: match by userId OR email
  const memberMatchConditions = [];
  if (userId) {
    memberMatchConditions.push(eq(teamMembers.userId, userId));
  }
  if (normalizedEmail) {
    memberMatchConditions.push(eq(teamMembers.email, normalizedEmail));
  }

  let teamMember = null;
  if (memberMatchConditions.length > 0) {
    [teamMember] = await db
      .select()
      .from(teamMembers)
      .where(
        and(
          eq(teamMembers.teamId, teamId),
          eq(teamMembers.status, 'active'),
          or(...memberMatchConditions)
        )
      )
      .limit(1);
  }

  // Fallback: Check players table for backwards compatibility
  if (!teamMember) {
    const playerMatchConditions = [];
    if (userId) {
      playerMatchConditions.push(eq(players.userId, userId));
    }
    if (normalizedEmail) {
      playerMatchConditions.push(eq(players.email, normalizedEmail));
    }

    if (playerMatchConditions.length > 0) {
      const [playerRecord] = await db
        .select()
        .from(players)
        .where(
          and(
            eq(players.teamId, teamId),
            or(...playerMatchConditions)
          )
        )
        .limit(1);

      if (!playerRecord) {
        // User is not on team
        throw { 
          code: 'FORBIDDEN', 
          status: 403, 
          message: 'Not authorized to access this team' 
        };
      }
    } else {
      // No valid identifiers
      throw { 
        code: 'FORBIDDEN', 
        status: 403, 
        message: 'Not authorized to access this team' 
      };
    }
  }

  // If a specific permission is required, check using getUserPermissions
  // getUserPermissions checks teamMembers first, then falls back to players
  if (requiredPermission) {
    const { getUserPermissions } = await import('../permissions');
    const permissions = await getUserPermissions(userId, teamId);
    
    if (!permissions || !permissions[requiredPermission]) {
      throw {
        code: 'FORBIDDEN',
        status: 403,
        message: `Requires ${requiredPermission} permission`
      };
    }
  }

  // User has access (either no permission required, or permission granted)
  return { teamId: team.id, userId: team.userId };
}

/**
 * Assert user has access to pay for a specific player
 * 
 * Access is granted if:
 * - Player record is linked to user's userId
 * - Player email matches user email
 * - User has canManagePlayers permission (coach/manager)
 * - User is global admin
 * 
 * @throws 404 if player not found or not on team
 * @throws 403 if user not authorized
 */
export async function ensurePlayerPaymentAccess(
  userId: string,
  userEmail: string | null | undefined,
  playerId: string,
  teamId: string,
  isGlobalAdmin: boolean,
  hasCoachPermission: boolean
): Promise<{ id: string; teamId: string; userId: string | null; email: string | null }> {
  // Verify player exists and belongs to team
  const [player] = await db
    .select()
    .from(players)
    .where(
      and(
        eq(players.id, playerId),
        eq(players.teamId, teamId)
      )
    )
    .limit(1);

  if (!player) {
    throw {
      code: 'PLAYER_NOT_FOUND',
      status: 404,
      message: 'Player not found or not on this team'
    };
  }

  // Global admin can pay for anyone
  if (isGlobalAdmin) {
    return player;
  }

  // Coaches/managers can pay for team players
  if (hasCoachPermission) {
    return player;
  }

  // User owns this player record
  if (player.userId === userId) {
    return player;
  }

  // Email match (guardian/parent case)
  // Guard against null/undefined userEmail
  const normalizedUserEmail = userEmail?.toLowerCase();
  const normalizedPlayerEmail = player.email?.toLowerCase();
  
  if (normalizedUserEmail && normalizedPlayerEmail && normalizedUserEmail === normalizedPlayerEmail) {
    return player;
  }

  // TODO: Add guardian model for explicit parent-child relationships
  // For now, we require userId match, email match, or coach permission

  // No access
  throw {
    code: 'FORBIDDEN',
    status: 403,
    message: 'Not authorized to initiate payment for this player'
  };
}

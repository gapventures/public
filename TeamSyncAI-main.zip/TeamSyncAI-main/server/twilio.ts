import { getSMSProvider } from './sms/factory';
import twilio from 'twilio';

export async function getTwilioClient() {
  const { TwilioProvider } = await import('./sms/twilioProvider');
  const provider = getSMSProvider();
  
  if (!(provider instanceof TwilioProvider)) {
    throw new Error('getTwilioClient can only be called when using Twilio provider');
  }
  
  return (provider as any).getClient();
}

export async function getTwilioFromPhoneNumber() {
  const provider = getSMSProvider();
  return provider.getDefaultPhoneNumber();
}

export interface SendSMSOptions {
  teamId?: string;
  eventId?: string;
  playerId?: string;
  campaignId?: string;
}

// Send SMS with template variable replacement and message logging
export async function sendSMS(
  to: string, 
  message: string, 
  options: SendSMSOptions = {}
): Promise<string | null> {
  try {
    const { normalizePhoneForTwilio } = await import("@shared/phoneUtils");
    const { storage } = await import("./storage");
    const provider = getSMSProvider();
    
    // Normalize phone number to E.164 format
    const normalizedPhone = normalizePhoneForTwilio(to);
    
    if (!normalizedPhone) {
      throw new Error(`Invalid phone number: ${to}`);
    }

    // Check opt-out status if teamId is provided
    if (options.teamId) {
      const isOptedOut = await storage.isOptedOut(options.teamId, normalizedPhone);
      if (isOptedOut) {
        console.log(`SMS not sent to ${normalizedPhone} - user has opted out for team ${options.teamId}`);
        return null;
      }
    }
    
    let fromPhone: string;

    // Use team-specific phone number if available, otherwise use default
    if (options.teamId) {
      const team = await storage.getTeam(options.teamId);
      if (team?.twilioPhoneNumber && team.phoneNumberStatus === 'active') {
        fromPhone = team.twilioPhoneNumber;
      } else {
        fromPhone = await provider.getDefaultPhoneNumber();
      }
    } else {
      fromPhone = await provider.getDefaultPhoneNumber();
    }
    
    const smsMessage = await provider.sendSMS({
      to: normalizedPhone,
      from: fromPhone,
      body: message,
    });

    // Log the outbound message
    if (options.teamId) {
      await storage.createMessageLog({
        messageSid: smsMessage.sid,
        teamId: options.teamId,
        eventId: options.eventId || null,
        playerId: options.playerId || null,
        campaignId: options.campaignId || null,
        direction: 'outbound',
        fromPhone: fromPhone,
        toPhone: normalizedPhone,
        body: message,
        status: smsMessage.status,
        errorCode: smsMessage.errorCode,
        errorMessage: smsMessage.errorMessage,
      });

      // Track SMS usage for billing (always track, even if pricing is missing)
      try {
        const usagePricing = await storage.getUsagePricing();
        
        // Calculate costs based on pricing config, or default to zero
        // Note: PostgreSQL numeric columns return as strings to preserve precision
        let baseCost = "0";
        let markupCost = "0";
        let totalCost = "0";
        
        if (usagePricing) {
          const baseCostNum = parseFloat(usagePricing.smsBaseCost as string) || 0;
          let markupCostNum = 0;
          
          if (usagePricing.smsMarkupType === 'percentage') {
            const markupValue = parseFloat(usagePricing.smsMarkupValue as string) || 0;
            markupCostNum = baseCostNum * (markupValue / 100);
          } else {
            markupCostNum = parseFloat(usagePricing.smsMarkupValue as string) || 0;
          }
          
          const totalCostNum = baseCostNum + markupCostNum;
          
          // Convert back to strings with fixed precision for storage
          baseCost = baseCostNum.toFixed(4);
          markupCost = markupCostNum.toFixed(4);
          totalCost = totalCostNum.toFixed(4);
        }

        // Always create usage tracking record, even with zero costs
        await storage.createUsageTracking({
          teamId: options.teamId,
          usageType: 'sms',
          quantity: 1,
          baseCost: baseCost,
          markupCost: markupCost,
          totalCost: totalCost,
          metadata: {
            messageSid: smsMessage.sid,
            eventId: options.eventId,
            playerId: options.playerId,
            campaignId: options.campaignId,
            toPhone: normalizedPhone,
          },
        });
      } catch (error) {
        console.error('Failed to track SMS usage:', error);
        // Don't fail the SMS send if usage tracking fails
      }
    }
    
    console.log(`SMS sent to ${to} (normalized: ${normalizedPhone}) from ${fromPhone} via ${provider.name} - SID: ${smsMessage.sid}`);
    return smsMessage.sid;
  } catch (error) {
    console.error(`Failed to send SMS to ${to}:`, error);
    throw error;
  }
}

// Replace template variables in message
export function replaceTemplateVariables(
  template: string,
  variables: {
    playerName?: string;
    firstName?: string;
    teamName?: string;
    coachName?: string;
    eventType?: string;
    eventTitle?: string;
    date?: string;
    eventDate?: string;
    time?: string;
    eventTime?: string;
    location?: string;
    opponent?: string;
    homeAway?: string;
    fieldType?: string;
    cleats?: string;
    jersey?: string;
    arrivalTime?: string;
  }
): string {
  let message = template;
  
  // Support old [Bracket] format for backwards compatibility
  if (variables.playerName) message = message.replace(/\[Player Name\]/g, variables.playerName);
  if (variables.eventType) message = message.replace(/\[Event Type\]/g, variables.eventType);
  if (variables.date) message = message.replace(/\[Date\]/g, variables.date);
  if (variables.time) message = message.replace(/\[Time\]/g, variables.time);
  if (variables.location) message = message.replace(/\[Location\]/g, variables.location);
  if (variables.opponent) message = message.replace(/\[Opponent\]/g, variables.opponent || "");
  if (variables.homeAway) message = message.replace(/\[Home\/Away\]/g, variables.homeAway || "");
  if (variables.fieldType) message = message.replace(/\[Field Type\]/g, variables.fieldType || "");
  if (variables.cleats) message = message.replace(/\[Cleats\]/g, variables.cleats || "");
  if (variables.jersey) message = message.replace(/\[Jersey\]/g, variables.jersey || "");
  if (variables.arrivalTime) message = message.replace(/\[Arrival Time\]/g, variables.arrivalTime || "");
  
  // Support new {curlyBrace} format
  if (variables.playerName !== undefined) message = message.replace(/\{playerName\}/g, variables.playerName);
  if (variables.firstName !== undefined) message = message.replace(/\{firstName\}/g, variables.firstName);
  if (variables.teamName !== undefined) message = message.replace(/\{teamName\}/g, variables.teamName);
  if (variables.coachName !== undefined) message = message.replace(/\{coachName\}/g, variables.coachName);
  if (variables.eventType !== undefined) message = message.replace(/\{eventType\}/g, variables.eventType);
  if (variables.eventTitle !== undefined) message = message.replace(/\{eventTitle\}/g, variables.eventTitle);
  if (variables.date !== undefined) message = message.replace(/\{date\}/g, variables.date);
  if (variables.eventDate !== undefined) message = message.replace(/\{eventDate\}/g, variables.eventDate);
  if (variables.time !== undefined) message = message.replace(/\{time\}/g, variables.time);
  if (variables.eventTime !== undefined) message = message.replace(/\{eventTime\}/g, variables.eventTime);
  if (variables.location !== undefined) message = message.replace(/\{location\}/g, variables.location);
  if (variables.opponent !== undefined) message = message.replace(/\{opponent\}/g, variables.opponent || "");
  if (variables.homeAway !== undefined) message = message.replace(/\{homeAway\}/g, variables.homeAway || "");
  if (variables.fieldType !== undefined) message = message.replace(/\{fieldType\}/g, variables.fieldType || "");
  if (variables.cleats !== undefined) message = message.replace(/\{cleats\}/g, variables.cleats || "");
  if (variables.jersey !== undefined) message = message.replace(/\{jersey\}/g, variables.jersey || "");
  if (variables.arrivalTime !== undefined) message = message.replace(/\{arrivalTime\}/g, variables.arrivalTime || "");
  
  return message;
}

// Default invitation message template
export const DEFAULT_INVITATION_TEMPLATE = "You've been invited to join {teamName} as {roleName}! Accept your invitation here: {inviteUrl}";

// Replace invitation template variables
export function replaceInvitationVariables(
  template: string,
  variables: {
    teamName: string;
    roleName: string;
    coachName?: string;
    playerName?: string;
    inviteUrl: string;
  }
): string {
  let message = template;
  
  message = message.replace(/\{teamName\}/g, variables.teamName);
  message = message.replace(/\{roleName\}/g, variables.roleName);
  message = message.replace(/\{inviteUrl\}/g, variables.inviteUrl);
  
  if (variables.coachName !== undefined) {
    message = message.replace(/\{coachName\}/g, variables.coachName);
  }
  if (variables.playerName !== undefined) {
    message = message.replace(/\{playerName\}/g, variables.playerName);
  }
  
  return message;
}

export interface InvitationSMSOptions {
  customTemplate?: string;
  coachName?: string;
  playerName?: string;
  teamId?: string;
}

// Send team invitation via SMS
export async function sendInvitationSMS(
  to: string,
  teamName: string,
  roleName: string,
  token: string,
  options: InvitationSMSOptions = {}
): Promise<void> {
  // Construct base URL based on deployment environment
  // Priority: APP_DOMAIN (custom domain) > REPLIT_DOMAINS > RENDER_EXTERNAL_URL > localhost
  const baseUrl = process.env.APP_DOMAIN
    ? process.env.APP_DOMAIN
    : process.env.REPLIT_DOMAINS 
    ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}`
    : process.env.RENDER_EXTERNAL_URL
    ? process.env.RENDER_EXTERNAL_URL
    : 'https://localhost:5000';
  
  const inviteUrl = `${baseUrl}/invite/${token}`;
  
  // Use custom template if provided, otherwise use default
  const template = options.customTemplate || DEFAULT_INVITATION_TEMPLATE;
  
  const message = replaceInvitationVariables(template, {
    teamName,
    roleName,
    coachName: options.coachName,
    playerName: options.playerName,
    inviteUrl,
  });
  
  await sendSMS(to, message, { teamId: options.teamId });
}

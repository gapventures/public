import { storage } from "./storage";

export async function seedDefaultTiers() {
  const existingTiers = await storage.getMembershipTiers();
  
  if (existingTiers.length > 0) {
    console.log("Tiers already exist, skipping seed");
    return;
  }

  console.log("Seeding default membership tiers...");

  const freeTier = await storage.createMembershipTier({
    name: "Free",
    description: "Perfect for trying out TeamSyncAI with a single team",
    monthlyPrice: 0,
    trialPeriodDays: 0,
    isActive: true,
    isDefault: true,
    displayOrder: 1,
  });

  await storage.setTierLimit({
    tierId: freeTier.id,
    limitKey: "max_teams",
    limitValue: 1,
  });

  await storage.setTierLimit({
    tierId: freeTier.id,
    limitKey: "max_players_per_team",
    limitValue: 15,
  });

  await storage.setTierLimit({
    tierId: freeTier.id,
    limitKey: "max_events_per_month",
    limitValue: 10,
  });

  await storage.setTierFeature({
    tierId: freeTier.id,
    featureKey: "sms_reminders",
    enabled: true,
  });

  await storage.setTierFeature({
    tierId: freeTier.id,
    featureKey: "message_board",
    enabled: false,
  });

  await storage.setTierFeature({
    tierId: freeTier.id,
    featureKey: "campaign_templates",
    enabled: false,
  });

  await storage.setTierFeature({
    tierId: freeTier.id,
    featureKey: "calendar_subscriptions",
    enabled: true,
  });

  const coachTier = await storage.createMembershipTier({
    name: "Coach",
    description: "For coaches managing multiple teams with advanced features",
    monthlyPrice: 1999,
    trialPeriodDays: 14,
    isActive: true,
    isDefault: false,
    displayOrder: 2,
  });

  await storage.setTierLimit({
    tierId: coachTier.id,
    limitKey: "max_teams",
    limitValue: 5,
  });

  await storage.setTierLimit({
    tierId: coachTier.id,
    limitKey: "max_players_per_team",
    limitValue: 30,
  });

  await storage.setTierLimit({
    tierId: coachTier.id,
    limitKey: "max_events_per_month",
    limitValue: 50,
  });

  await storage.setTierFeature({
    tierId: coachTier.id,
    featureKey: "sms_reminders",
    enabled: true,
  });

  await storage.setTierFeature({
    tierId: coachTier.id,
    featureKey: "message_board",
    enabled: true,
  });

  await storage.setTierFeature({
    tierId: coachTier.id,
    featureKey: "campaign_templates",
    enabled: true,
  });

  await storage.setTierFeature({
    tierId: coachTier.id,
    featureKey: "calendar_subscriptions",
    enabled: true,
  });

  await storage.setTierFeature({
    tierId: coachTier.id,
    featureKey: "csv_bulk_upload",
    enabled: true,
  });

  await storage.setTierFeature({
    tierId: coachTier.id,
    featureKey: "lineup_management",
    enabled: true,
  });

  const proTier = await storage.createMembershipTier({
    name: "Pro",
    description: "For organizations managing large programs with unlimited access",
    monthlyPrice: 4999,
    trialPeriodDays: 14,
    isActive: true,
    isDefault: false,
    displayOrder: 3,
  });

  await storage.setTierLimit({
    tierId: proTier.id,
    limitKey: "max_teams",
    limitValue: 999,
  });

  await storage.setTierLimit({
    tierId: proTier.id,
    limitKey: "max_players_per_team",
    limitValue: 100,
  });

  await storage.setTierLimit({
    tierId: proTier.id,
    limitKey: "max_events_per_month",
    limitValue: 999,
  });

  await storage.setTierFeature({
    tierId: proTier.id,
    featureKey: "sms_reminders",
    enabled: true,
  });

  await storage.setTierFeature({
    tierId: proTier.id,
    featureKey: "message_board",
    enabled: true,
  });

  await storage.setTierFeature({
    tierId: proTier.id,
    featureKey: "campaign_templates",
    enabled: true,
  });

  await storage.setTierFeature({
    tierId: proTier.id,
    featureKey: "calendar_subscriptions",
    enabled: true,
  });

  await storage.setTierFeature({
    tierId: proTier.id,
    featureKey: "csv_bulk_upload",
    enabled: true,
  });

  await storage.setTierFeature({
    tierId: proTier.id,
    featureKey: "priority_support",
    enabled: true,
  });

  await storage.setTierFeature({
    tierId: proTier.id,
    featureKey: "advanced_analytics",
    enabled: true,
  });

  await storage.setTierFeature({
    tierId: proTier.id,
    featureKey: "lineup_management",
    enabled: true,
  });

  console.log("Default tiers seeded successfully!");
}

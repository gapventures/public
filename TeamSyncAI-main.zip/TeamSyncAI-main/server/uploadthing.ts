// UploadThing configuration for Express
import { createUploadthing, type FileRouter } from "uploadthing/express";
import type { Request } from "express";

const f = createUploadthing({
  errorFormatter: (err) => {
    console.error("[UploadThing] Error:", err.message, err.cause);
    return {
      message: err.message,
    };
  },
});

// Extend Express Request to include session user
interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    firstName?: string;
    lastName?: string;
  };
}

// FileRouter for handling uploads with authentication
export const uploadRouter = {
  // Logo uploader (team and organization logos)
  logoUploader: f({
    image: {
      maxFileSize: "4MB",
      maxFileCount: 1,
    },
  })
    .middleware(async ({ req }) => {
      const authReq = req as AuthenticatedRequest;
      
      // Require authentication
      if (!authReq.user) {
        throw new Error("Unauthorized - Please log in to upload files");
      }

      console.log("[UploadThing] Logo upload initiated by user:", authReq.user.email);

      // Pass user context to onUploadComplete
      return { 
        userId: authReq.user.id,
        userEmail: authReq.user.email,
      };
    })
    .onUploadComplete(async ({ metadata, file }) => {
      console.log("[UploadThing] Logo upload completed for user:", metadata.userEmail);
      console.log("[UploadThing] File URL:", file.ufsUrl);
      
      return { url: file.ufsUrl };
    }),

  // Message image uploader (for message board)
  messageImageUploader: f({
    image: {
      maxFileSize: "4MB",
      maxFileCount: 1,
    },
  })
    .middleware(async ({ req }) => {
      const authReq = req as AuthenticatedRequest;
      
      // Require authentication
      if (!authReq.user) {
        throw new Error("Unauthorized - Please log in to upload images");
      }

      console.log("[UploadThing] Message image upload initiated by user:", authReq.user.email);

      return { 
        userId: authReq.user.id,
        userEmail: authReq.user.email,
      };
    })
    .onUploadComplete(async ({ metadata, file }) => {
      console.log("[UploadThing] Message image upload completed for user:", metadata.userEmail);
      console.log("[UploadThing] File URL:", file.ufsUrl);
      
      return { url: file.ufsUrl };
    }),

  // Document uploader (waivers, forms, etc.)
  documentUploader: f({
    "application/pdf": {
      maxFileSize: "8MB",
      maxFileCount: 1,
    },
    "application/msword": {
      maxFileSize: "8MB",
      maxFileCount: 1,
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
      maxFileSize: "8MB",
      maxFileCount: 1,
    },
    image: {
      maxFileSize: "8MB",
      maxFileCount: 1,
    },
  })
    .middleware(async ({ req }) => {
      const authReq = req as AuthenticatedRequest;
      
      // Require authentication
      if (!authReq.user) {
        throw new Error("Unauthorized - Please log in to upload documents");
      }

      console.log("[UploadThing] Document upload initiated by user:", authReq.user.email);

      return { 
        userId: authReq.user.id,
        userEmail: authReq.user.email,
      };
    })
    .onUploadComplete(async ({ metadata, file }) => {
      console.log("[UploadThing] Document upload completed for user:", metadata.userEmail);
      console.log("[UploadThing] File URL:", file.ufsUrl);
      
      return { url: file.ufsUrl };
    }),
} satisfies FileRouter;

export type OurFileRouter = typeof uploadRouter;

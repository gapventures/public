import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { startReminderScheduler, startNotificationScheduler } from "./scheduler";
import { storage } from "./storage";
import { seedPaymentProviders } from "./seedPaymentProviders";
import { db } from "./db";
import { users } from "@shared/schema";
import { eq } from "drizzle-orm";

const app = express();

declare module 'http' {
  interface IncomingMessage {
    rawBody: unknown
  }
}
app.use(express.json({
  verify: (req, _res, buf) => {
    req.rawBody = buf;
  }
}));
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

// Initialize default roles for existing teams
async function initializeDefaultRoles() {
  try {
    log("Checking for teams without default roles...");
    const teams = await storage.getTeams();
    
    const defaultRoleNames = ["Coach", "Assistant Coach", "Player", "Non-Player"];
    
    for (const team of teams) {
      const roles = await storage.getRoles(team.id);
      const roleNames = roles.map(r => r.name);
      
      // Check if team is missing any default roles
      const missingDefaultRoles = defaultRoleNames.filter(name => !roleNames.includes(name));
      
      if (missingDefaultRoles.length > 0) {
        log(`Team "${team.name}" is missing default roles: ${missingDefaultRoles.join(", ")}`);
        
        // Create only the missing default roles individually
        const defaultRoleConfigs = [
          {
            name: "Coach",
            description: "Full access to all team management features",
            canViewEvents: true,
            canManageEvents: true,
            canViewPlayers: true,
            canManagePlayers: true,
            canSendReminders: true,
            canManageCampaigns: true,
            canViewResponses: true,
            canManageAttendance: true,
            canManageSettings: true,
            canManageRoles: true,
            canViewMembership: true,
            isDefault: true,
          },
          {
            name: "Assistant Coach",
            description: "Can manage most aspects except settings and roles",
            canViewEvents: true,
            canManageEvents: true,
            canViewPlayers: true,
            canManagePlayers: true,
            canSendReminders: true,
            canManageCampaigns: true,
            canViewResponses: true,
            canManageAttendance: true,
            canManageSettings: false,
            canManageRoles: false,
            canViewMembership: false,
            isDefault: true,
          },
          {
            name: "Player",
            description: "Standard player with view-only access",
            canViewEvents: true,
            canManageEvents: false,
            canViewPlayers: true,
            canManagePlayers: false,
            canSendReminders: false,
            canManageCampaigns: false,
            canViewResponses: true,
            canManageAttendance: false,
            canManageSettings: false,
            canManageRoles: false,
            canViewMembership: false,
            isDefault: true,
          },
          {
            name: "Non-Player",
            description: "Team staff or supporter with view-only access",
            canViewEvents: true,
            canManageEvents: false,
            canViewPlayers: true,
            canManagePlayers: false,
            canSendReminders: false,
            canManageCampaigns: false,
            canViewResponses: true,
            canManageAttendance: false,
            canManageSettings: false,
            canManageRoles: false,
            canViewMembership: false,
            isDefault: true,
          },
        ];
        
        // Create only missing default roles
        for (const roleConfig of defaultRoleConfigs) {
          if (missingDefaultRoles.includes(roleConfig.name)) {
            await storage.createRole({ ...roleConfig, teamId: team.id });
            log(`Created default role "${roleConfig.name}" for team "${team.name}"`);
          }
        }
      }
    }
    
    log("Default roles initialization complete");
  } catch (error) {
    console.error("Error initializing default roles:", error);
  }
}

async function migrateCanViewMembershipPermission() {
  try {
    log("Migrating canViewMembership permission for existing Coach roles...");
    const teams = await storage.getTeams();
    
    for (const team of teams) {
      const roles = await storage.getRoles(team.id);
      const coachRole = roles.find(r => r.name === "Coach");
      
      if (coachRole && coachRole.canViewMembership !== true) {
        await storage.updateRole(coachRole.id, { canViewMembership: true });
        log(`Updated Coach role for team "${team.name}" to have canViewMembership = true`);
      }
    }
    
    log("canViewMembership migration complete");
  } catch (error) {
    console.error("Error migrating canViewMembership permission:", error);
  }
}

(async () => {
  const server = await registerRoutes(app);

  // Initialize default roles for existing teams
  await initializeDefaultRoles();
  
  // Migrate existing Coach roles to have canViewMembership
  await migrateCanViewMembershipPermission();
  
  // Seed payment providers if not already present
  try {
    console.log("[STARTUP] Seeding payment providers...");
    await seedPaymentProviders();
    console.log("[STARTUP] Payment providers seed complete");
  } catch (error) {
    console.error("[STARTUP] Error seeding payment providers:", error);
    console.error("[STARTUP] Stack trace:", error instanceof Error ? error.stack : 'No stack trace');
  }

  // Seed usage pricing if not already present
  try {
    console.log("[STARTUP] Seeding usage pricing...");
    const existingPricing = await storage.getUsagePricing();
    if (!existingPricing) {
      await storage.updateUsagePricing({
        smsBaseCost: "0.0079",
        smsMarkupType: 'percentage',
        smsMarkupValue: "50",
        phoneNumberBaseCost: "2.00",
        phoneNumberMarkupType: 'percentage',
        phoneNumberMarkupValue: "25",
      });
      console.log("[STARTUP] Usage pricing initialized with defaults");
    } else {
      console.log("[STARTUP] Usage pricing already configured");
    }
  } catch (error) {
    console.error("[STARTUP] Error seeding usage pricing:", error);
  }

  // Promote designated global admins
  try {
    console.log("[STARTUP] Checking for designated global admins...");
    const adminEmails = ['matt@team-sync-ai.com'];
    
    for (const email of adminEmails) {
      const [existingUser] = await db.select().from(users).where(eq(users.email, email));
      
      if (existingUser && !existingUser.isGlobalAdmin) {
        await storage.upsertUser({
          ...existingUser,
          isGlobalAdmin: true,
        });
        console.log(`[STARTUP] Promoted ${email} to global admin`);
      } else if (existingUser && existingUser.isGlobalAdmin) {
        console.log(`[STARTUP] ${email} is already a global admin`);
      }
    }
  } catch (error) {
    console.error("[STARTUP] Error promoting global admins:", error);
  }

  // Start automated reminder scheduler
  startReminderScheduler();
  
  // Start automated notification update scheduler
  startNotificationScheduler();

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || '5000', 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();

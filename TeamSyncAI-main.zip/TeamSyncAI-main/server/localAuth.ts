import { Express } from "express";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import session from "express-session";
import connectPg from "connect-pg-simple";
import bcrypt from "bcrypt";
import { db } from "./db";
import { users } from "@shared/schema";
import { eq, and } from "drizzle-orm";
import { sendSMS } from "./twilio";
import { storage } from "./storage";
import { normalizePhoneForTwilio } from "@shared/phoneUtils";

const SALT_ROUNDS = 10;
const RESET_TOKEN_EXPIRY_MINUTES = 15;

// Session configuration
export function getSession() {
  // Validate required environment variables
  if (!process.env.SESSION_SECRET) {
    throw new Error('SESSION_SECRET environment variable is required');
  }
  
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL environment variable is required');
  }
  
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  
  // Log session store initialization (hide password from URL)
  const dbUrl = process.env.DATABASE_URL;
  const sanitizedUrl = dbUrl.replace(/:\/\/([^:]+):([^@]+)@/, '://***:***@');
  console.log(`[AUTH] Initializing session store with database: ${sanitizedUrl}`);
  
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: true,
    ttl: sessionTtl,
    tableName: "sessions",
  });
  
  // Listen for session store errors
  sessionStore.on('error', (error) => {
    console.error('[AUTH] Session store error:', error);
  });
  
  const isProduction = process.env.NODE_ENV === "production";
  
  console.log(`[AUTH] Session configuration: production=${isProduction}, proxy=${isProduction}`);
  
  return session({
    secret: process.env.SESSION_SECRET,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    proxy: isProduction, // Trust X-Forwarded-Proto header from reverse proxy (Render, Heroku, etc.)
    cookie: {
      httpOnly: true,
      secure: isProduction,
      maxAge: sessionTtl,
      sameSite: 'lax',
    },
  });
}

// Hash password using bcrypt
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

// Compare password with hash
export async function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// Create a new user with hashed password
export async function createUser(
  email: string,
  password: string,
  firstName: string,
  lastName: string,
  smsConsentGranted: boolean = false,
  accountType: "coach" | "parent" | "player" = "coach",
  phone?: string
) {
  const hashedPassword = await hashPassword(password);
  
  // Normalize phone number to E.164 format for SMS delivery
  const normalizedPhone = phone ? normalizePhoneForTwilio(phone) : null;
  
  const [user] = await db.insert(users).values({
    email,
    password: hashedPassword,
    firstName,
    lastName,
    smsConsentGranted,
    accountType,
    phone: normalizedPhone || null,
  }).returning();
  
  return user;
}

// Find user by email
export async function findUserByEmail(email: string) {
  const [user] = await db.select().from(users).where(eq(users.email, email));
  return user;
}

// Verify user credentials
export async function verifyUser(email: string, password: string) {
  try {
    console.log(`[AUTH] Looking up user by email: ${email}`);
    const user = await findUserByEmail(email);
    
    if (!user || !user.password) {
      console.log(`[AUTH] User not found or has no password: ${email}`);
      return null;
    }
    
    console.log(`[AUTH] User found, verifying password for: ${email}`);
    const isValid = await comparePassword(password, user.password);
    
    if (!isValid) {
      console.log(`[AUTH] Invalid password for: ${email}`);
      return null;
    }
    
    console.log(`[AUTH] Password verified successfully for: ${email}`);
    return user;
  } catch (error) {
    console.error(`[AUTH] Error in verifyUser for ${email}:`, error);
    // Log full error details
    if (error instanceof Error) {
      console.error(`[AUTH] Error name: ${error.name}, message: ${error.message}`);
      console.error(`[AUTH] Error stack:`, error.stack);
    }
    throw error;
  }
}

// Generate a random 6-digit code
function generateResetCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Generate reset token and expiration
export async function generatePasswordResetToken(email: string): Promise<{ token: string; user: any; phone: string } | null> {
  const user = await findUserByEmail(email);
  
  if (!user) {
    return null;
  }
  
  // Get phone number from user record or lookup from player
  let phone = user.phone;
  
  if (!phone) {
    // Try to find phone from player record (players are matched by email)
    const { players } = await import("@shared/schema");
    const [player] = await db.select().from(players).where(eq(players.email, email));
    
    if (player && player.phone) {
      phone = player.phone;
      // Optionally update user's phone number for future use
      await db.update(users).set({ phone: player.phone }).where(eq(users.id, user.id));
    }
  }
  
  if (!phone) {
    return null; // No phone number found
  }
  
  const resetToken = generateResetCode();
  const resetTokenExpires = new Date(Date.now() + RESET_TOKEN_EXPIRY_MINUTES * 60 * 1000);
  
  // Update user with reset token
  const [updatedUser] = await db
    .update(users)
    .set({
      resetToken,
      resetTokenExpires,
    })
    .where(eq(users.email, email))
    .returning();
  
  return { token: resetToken, user: updatedUser, phone };
}

// Verify reset token and update password
export async function resetPasswordWithToken(token: string, newPassword: string): Promise<boolean> {
  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.resetToken, token));
  
  if (!user) {
    return false;
  }
  
  // Check if token has expired
  if (!user.resetTokenExpires || user.resetTokenExpires < new Date()) {
    return false;
  }
  
  // Hash new password
  const hashedPassword = await hashPassword(newPassword);
  
  // Update password and clear reset token
  await db
    .update(users)
    .set({
      password: hashedPassword,
      resetToken: null,
      resetTokenExpires: null,
    })
    .where(eq(users.id, user.id));
  
  return true;
}

// Setup local authentication
export async function setupAuth(app: Express) {
  // Note: trust proxy is set in routes.ts before this function is called
  app.use(getSession());
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure passport-local strategy
  passport.use(
    new LocalStrategy(
      {
        usernameField: "email",
        passwordField: "password",
      },
      async (email, password, done) => {
        try {
          console.log(`Login attempt for email: ${email}`);
          const user = await verifyUser(email, password);
          
          if (!user) {
            console.log(`Login failed: Invalid credentials for ${email}`);
            return done(null, false, { message: "Invalid email or password" });
          }
          
          console.log(`Login successful for ${email}`);
          return done(null, user);
        } catch (error) {
          console.error(`Login error for ${email}:`, error);
          return done(error);
        }
      }
    )
  );

  // Serialize user to session
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  // Deserialize user from session
  passport.deserializeUser(async (id: string, done) => {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, id));
      
      // If user not found (e.g., deleted account or stale session), clear the session
      if (!user) {
        console.log(`[Auth] User ${id} not found in database, clearing session`);
        return done(null, false);
      }
      
      done(null, user);
    } catch (error) {
      console.error(`[Auth] Error deserializing user ${id}:`, error);
      done(error);
    }
  });

  // Register route
  app.post("/api/register", async (req, res) => {
    try {
      const { 
        email, 
        password, 
        firstName, 
        lastName, 
        phone,
        smsConsentGranted, 
        accountType = "coach",
        playerDetails,
        joinCode
      } = req.body;

      // Validate input - check each required field
      const missingFields = [];
      if (!firstName) missingFields.push("First Name");
      if (!lastName) missingFields.push("Last Name");
      if (!phone) missingFields.push("Phone Number");
      if (!email) missingFields.push("Email");
      if (!password) missingFields.push("Password");
      
      if (missingFields.length > 0) {
        return res.status(400).json({ 
          message: `Please fill in: ${missingFields.join(", ")}` 
        });
      }

      // Validate SMS consent (required for TCPA compliance) - must be strictly boolean true
      if (smsConsentGranted !== true) {
        return res.status(400).json({ message: "You must agree to receive SMS messages to continue" });
      }

      // Validate parent accounts have player details with required fields
      if (accountType === "parent") {
        if (!playerDetails || !playerDetails.firstName || playerDetails.firstName.trim() === "" ||
            !playerDetails.lastName || playerDetails.lastName.trim() === "" ||
            !playerDetails.phone || playerDetails.phone.trim() === "") {
          return res.status(400).json({ message: "Player first name, last name, and phone number are required for parent accounts" });
        }
      }

      // Check if user already exists
      const existingUser = await findUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }

      // Create user with SMS consent and account type
      const user = await createUser(email, password, firstName, lastName, smsConsentGranted, accountType, phone);

      // Handle parent accounts
      if (accountType === "parent" && playerDetails) {
        try {
          if (joinCode) {
            // Join code registration - create pending join request
            const { teams, pendingParentJoins } = await import("@shared/schema");
            
            // Validate join code
            const [team] = await db
              .select()
              .from(teams)
              .where(
                and(
                  eq(teams.joinCode, joinCode.toUpperCase()),
                  eq(teams.joinCodeEnabled, true)
                )
              )
              .limit(1);

            if (!team) {
              return res.status(400).json({ message: "Invalid or disabled join code" });
            }

            if (team.joinCodeExpiry && new Date(team.joinCodeExpiry) < new Date()) {
              return res.status(400).json({ message: "This join code has expired" });
            }

            // Create pending join request
            await db.insert(pendingParentJoins).values({
              teamId: team.id,
              parentUserId: user.id,
              parentEmail: email,
              parentPhone: phone,
              parentFirstName: firstName,
              parentLastName: lastName,
              playerFirstName: playerDetails.firstName,
              playerLastName: playerDetails.lastName,
              playerPhone: playerDetails.phone,
              playerEmail: playerDetails.email || null,
              playerDateOfBirth: playerDetails.dateOfBirth || null,
              joinCode: joinCode.toUpperCase(),
              status: "pending",
            });
            
            console.log(`Created pending join request for parent ${user.email} to team ${team.name}`);
          } else {
            // No join code - parent account created without team/player
            // They will receive an invitation from a coach
            console.log(`Parent account created for ${user.email} without join code - awaiting coach invitation`);
          }
        } catch (playerError) {
          console.error("Error creating player record for parent:", playerError);
          // Continue - parent can manually add player later
        }
      } else if (accountType === "coach") {
        // Link coach user to any existing player records with matching email
        try {
          const { players } = await import("@shared/schema");
          
          // Get all players and filter by case-insensitive email match
          // This is safe and works with legacy mixed-case emails
          const allPlayers = await db.select().from(players);
          const matchingPlayers = allPlayers.filter(
            (p: any) => p.email && p.email.toLowerCase() === email.toLowerCase()
          );
          
          if (matchingPlayers.length > 0) {
            // Link all matching player records to this user
            for (const player of matchingPlayers) {
              await db
                .update(players)
                .set({ userId: user.id })
                .where(eq(players.id, player.id));
            }
            
            console.log(`Linked ${matchingPlayers.length} player record(s) to user ${user.email}`);
          }
        } catch (linkError) {
          console.error("Error linking user to player records:", linkError);
          // Continue even if linking fails
        }

        // Coaches can create teams manually from the dashboard
      }

      // Log the user in
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Registration successful but login failed" });
        }
        res.json({ 
          id: user.id, 
          email: user.email, 
          firstName: user.firstName, 
          lastName: user.lastName 
        });
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // Login route
  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        console.error("Passport authentication error:", err);
        return res.status(500).json({ message: "Login failed" });
      }
      
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid credentials" });
      }
      
      req.login(user, (loginErr) => {
        if (loginErr) {
          console.error("Session login error:", loginErr);
          return res.status(500).json({ message: "Login failed" });
        }
        
        res.json({ 
          id: user.id, 
          email: user.email, 
          firstName: user.firstName, 
          lastName: user.lastName 
        });
      });
    })(req, res, next);
  });

  // Logout route
  app.post("/api/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  // Current user route
  app.get("/api/user", (req, res) => {
    if (req.isAuthenticated()) {
      const user = req.user as any;
      res.json({ 
        id: user.id, 
        email: user.email, 
        firstName: user.firstName, 
        lastName: user.lastName,
        isGlobalAdmin: user.isGlobalAdmin,
      });
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });

  // Request password reset
  app.post("/api/password-reset/request", async (req, res) => {
    try {
      const { email } = req.body;

      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }

      const result = await generatePasswordResetToken(email);

      if (!result) {
        // Don't reveal if user exists or doesn't have a phone number
        return res.json({ message: "If a matching account was found, a reset code has been sent." });
      }

      // Send SMS with reset code (skip in development for testing)
      const isDevelopment = process.env.NODE_ENV === "development";
      
      if (isDevelopment) {
        // In development, log the code instead of sending SMS
        console.log(`[DEV MODE] Password reset code for ${email}: ${result.token}`);
        res.json({ message: "Reset code sent to your phone number" });
      } else {
        // In production, send actual SMS
        try {
          const message = `Your TeamSyncAI password reset code is: ${result.token}. This code expires in ${RESET_TOKEN_EXPIRY_MINUTES} minutes.`;
          await sendSMS(result.phone, message);
          
          res.json({ message: "Reset code sent to your phone number" });
        } catch (smsError) {
          console.error("Failed to send SMS:", smsError);
          // Clear the reset token if SMS failed
          await db.update(users).set({ resetToken: null, resetTokenExpires: null }).where(eq(users.email, email));
          res.status(500).json({ message: "Failed to send reset code. Please try again." });
        }
      }
    } catch (error) {
      console.error("Password reset request error:", error);
      res.status(500).json({ message: "Failed to process request" });
    }
  });

  // Verify reset code and update password
  app.post("/api/password-reset/verify", async (req, res) => {
    try {
      const { code, newPassword } = req.body;

      if (!code || !newPassword) {
        return res.status(400).json({ message: "Code and new password are required" });
      }

      if (newPassword.length < 6) {
        return res.status(400).json({ message: "Password must be at least 6 characters" });
      }

      const success = await resetPasswordWithToken(code, newPassword);

      if (!success) {
        return res.status(400).json({ message: "Invalid or expired reset code" });
      }

      res.json({ message: "Password reset successful" });
    } catch (error) {
      console.error("Password reset verify error:", error);
      res.status(500).json({ message: "Failed to reset password" });
    }
  });
}

import { db } from "./db";
import { paymentProviders } from "@shared/schema";
import { eq } from "drizzle-orm";

export async function seedPaymentProviders() {
  // Check if Helcim credentials are available
  const helcimApiKey = process.env.HELCIM_API_KEY;
  const helcimWebhookSecret = process.env.HELCIM_WEBHOOK_SECRET;

  console.log("[SEED DEBUG] Environment variables check:");
  console.log(`  - HELCIM_API_KEY: ${helcimApiKey ? 'SET (length: ' + helcimApiKey.length + ')' : 'NOT SET'}`);
  console.log(`  - HELCIM_WEBHOOK_SECRET: ${helcimWebhookSecret ? 'SET (length: ' + helcimWebhookSecret.length + ')' : 'NOT SET'}`);

  if (!helcimApiKey) {
    console.warn("⚠️  HELCIM_API_KEY not set - Payment provider will be disabled");
  }
  
  if (!helcimWebhookSecret) {
    console.warn("⚠️  HELCIM_WEBHOOK_SECRET not set - Webhook verification will fail");
  }

  // Check if Helcim provider exists
  console.log("[SEED DEBUG] Querying database for existing Helcim provider...");
  let existingHelcim;
  try {
    const results = await db
      .select()
      .from(paymentProviders)
      .where(eq(paymentProviders.name, "Helcim"))
      .limit(1);
    existingHelcim = results[0];
    console.log(`[SEED DEBUG] Query successful. Found ${results.length} existing provider(s)`);
  } catch (error) {
    console.error("[SEED DEBUG] Database query failed:", error);
    throw error;
  }

  if (existingHelcim) {
    console.log("[SEED DEBUG] Found existing Helcim provider:");
    console.log(`  - ID: ${existingHelcim.id}`);
    console.log(`  - Current apiKey: ${existingHelcim.apiKey ? 'SET (length: ' + existingHelcim.apiKey.length + ')' : 'NULL'}`);
    console.log(`  - Current webhookSecret: ${existingHelcim.webhookSecret ? 'SET (length: ' + existingHelcim.webhookSecret.length + ')' : 'NULL'}`);
    console.log(`  - Is Enabled: ${existingHelcim.isEnabled}`);

    // Update existing provider if credentials have changed or were missing
    const needsUpdate = 
      existingHelcim.apiKey !== helcimApiKey ||
      existingHelcim.webhookSecret !== helcimWebhookSecret;

    console.log(`[SEED DEBUG] Needs update: ${needsUpdate}`);

    if (needsUpdate && (helcimApiKey || helcimWebhookSecret)) {
      console.log("Updating Helcim payment provider credentials...");
      
      try {
        const updateResult = await db
          .update(paymentProviders)
          .set({
            apiKey: helcimApiKey || null,
            webhookSecret: helcimWebhookSecret || null,
            isEnabled: !!(helcimApiKey && helcimWebhookSecret),
            updatedAt: new Date(),
          })
          .where(eq(paymentProviders.id, existingHelcim.id))
          .returning();

        console.log(`[SEED DEBUG] Update returned ${updateResult.length} rows`);
        if (updateResult.length > 0) {
          console.log(`[SEED DEBUG] Returned row - apiKey: ${updateResult[0].apiKey ? 'SET' : 'NULL'}, webhookSecret: ${updateResult[0].webhookSecret ? 'SET' : 'NULL'}`);
        }

        console.log(`✓ Helcim credentials updated (${helcimApiKey && helcimWebhookSecret ? 'enabled' : 'partially configured'})`);
        
        // Verify the update worked
        const [updated] = await db
          .select()
          .from(paymentProviders)
          .where(eq(paymentProviders.id, existingHelcim.id))
          .limit(1);
        
        console.log("[SEED DEBUG] After update verification:");
        console.log(`  - Updated apiKey: ${updated.apiKey ? 'SET (length: ' + updated.apiKey.length + ')' : 'NULL'}`);
        console.log(`  - Updated webhookSecret: ${updated.webhookSecret ? 'SET (length: ' + updated.webhookSecret.length + ')' : 'NULL'}`);
        console.log(`  - Updated isEnabled: ${updated.isEnabled}`);
      } catch (error) {
        console.error("[SEED ERROR] Failed to update payment provider:");
        console.error(error);
      }
    } else {
      console.log("Payment providers already configured, no updates needed");
    }
    return;
  }

  // Create new Helcim provider if it doesn't exist
  console.log("Seeding Helcim payment provider...");

  try {
    await db.insert(paymentProviders).values({
      name: "Helcim",
      displayName: "Helcim",
      isEnabled: !!(helcimApiKey && helcimWebhookSecret),
      apiKey: helcimApiKey || null,
      webhookSecret: helcimWebhookSecret || null,
      config: JSON.stringify({
        apiEndpoint: "https://api.helcim.com/v2",
        checkoutEndpoint: "https://secure.myhelcim.com/checkout",
      }),
    });

    console.log(`✓ Helcim payment provider created (${helcimApiKey && helcimWebhookSecret ? 'enabled' : 'disabled - missing credentials'})`);
  } catch (error) {
    console.error("[SEED ERROR] Failed to create payment provider:");
    console.error(error);
    throw error;
  }
}

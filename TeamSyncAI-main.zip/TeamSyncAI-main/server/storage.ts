// Referenced from javascript_database blueprint integration
import { db } from "./db";
import { eq, desc, gte, lte, and, or, inArray, isNull, sql } from "drizzle-orm";
import { normalizePhoneForTwilio } from "@shared/phoneUtils";
import {
  users, type User, type UpsertUser,
  teams, type Team, type InsertTeam,
  roles, type Role, type InsertRole,
  players, type Player, type InsertPlayer,
  events, type Event, type InsertEvent,
  campaigns, type Campaign, type InsertCampaign,
  reminders, type Reminder, type InsertReminder,
  reminderSends, type ReminderSend, type InsertReminderSend,
  responses, type Response, type InsertResponse,
  attendance, type Attendance, type InsertAttendance,
  reliabilityHistory, type ReliabilityHistory, type InsertReliabilityHistory,
  notificationSettings, type NotificationSettings, type InsertNotificationSettings,
  notificationSends, type NotificationSend, type InsertNotificationSend,
  campaignTemplates, type CampaignTemplate, type InsertCampaignTemplate,
  templateReminders, type TemplateReminder, type InsertTemplateReminder,
  customFields, type CustomField, type InsertCustomField,
  eventTemplates, type EventTemplate, type InsertEventTemplate,
  messages, type Message, type InsertMessage,
  messageReactions, type MessageReaction, type InsertMessageReaction,
  appSettings, type AppSettings, type InsertAppSettings,
  landingPageContent, type LandingPageContent, type InsertLandingPageContent,
  marketingPageContent, type MarketingPageContent, type MarketingPageContentData,
  type AboutPageContent, type FeaturesPageContent, type PricingPageContent, type ContactPageContent,
  aboutPageContentSchema, featuresPageContentSchema, pricingPageContentSchema, contactPageContentSchema,
  DEFAULT_ABOUT_CONTENT, DEFAULT_FEATURES_CONTENT, DEFAULT_PRICING_CONTENT, DEFAULT_CONTACT_CONTENT,
  membershipTiers, type MembershipTier, type InsertMembershipTier,
  tierLimits, type TierLimit, type InsertTierLimit,
  tierFeatures, type TierFeature, type InsertTierFeature,
  invitations, type Invitation, type InsertInvitation,
  teamDocuments, type TeamDocument, type InsertTeamDocument,
  documentSignatures, type DocumentSignature, type InsertDocumentSignature,
  lineups, type Lineup, type InsertLineup,
  teamPaymentRequests,
  messageLogs, type MessageLog, type InsertMessageLog,
  smsOptOuts, type SmsOptOut, type InsertSmsOptOut,
  usagePricing, type UsagePricing, type InsertUsagePricing,
  usageTracking, type UsageTracking, type InsertUsageTracking,
  adminNotifications, type AdminNotification, type InsertAdminNotification,
  teamNotifications, type TeamNotification, type InsertTeamNotification,
} from "@shared/schema";

export interface IStorage {
  // Users (for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  deleteUser(id: string): Promise<void>;

  // Teams
  getTeams(): Promise<Team[]>;
  getTeamsForUser(userId: string): Promise<Team[]>;
  getTeam(id: string): Promise<Team | undefined>;
  createTeam(team: InsertTeam): Promise<Team>;
  updateTeam(id: string, data: Partial<InsertTeam>): Promise<Team | undefined>;
  deleteTeam(id: string): Promise<void>;

  // Roles
  getRoles(teamId: string): Promise<Role[]>;
  getRole(id: string): Promise<Role | undefined>;
  createRole(role: InsertRole): Promise<Role>;
  updateRole(id: string, data: Partial<InsertRole>): Promise<Role | undefined>;
  deleteRole(id: string): Promise<void>;
  createDefaultRoles(teamId: string): Promise<Role[]>;

  // Players
  getPlayers(teamId: string): Promise<Player[]>;
  getPlayer(id: string): Promise<Player | undefined>;
  getPlayerByUser(teamId: string, userId: string): Promise<Player | undefined>;
  findPlayerByContact(teamId: string, contactValue: string, contactType?: "email" | "phone"): Promise<Player | undefined>;
  createPlayer(player: InsertPlayer): Promise<Player>;
  updatePlayer(id: string, data: Partial<InsertPlayer>): Promise<Player | undefined>;
  deletePlayer(id: string): Promise<void>;

  // Events
  getEvents(teamId?: string): Promise<Event[]>;
  getEventsWithStats(teamId?: string): Promise<Array<Event & { stats: { yes: number; no: number; maybe: number; pending: number } }>>;
  getUpcomingEvents(limit?: number): Promise<Event[]>;
  getEventsWithoutCampaigns(teamId: string): Promise<Event[]>;
  getEvent(id: string): Promise<Event | undefined>;
  getPaymentRequest(id: string): Promise<typeof teamPaymentRequests.$inferSelect | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: string, data: Partial<InsertEvent>): Promise<Event | undefined>;
  deleteEvent(id: string): Promise<void>;

  // Campaigns
  getCampaign(eventId: string): Promise<Campaign | undefined>;
  getCampaignById(id: string): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaign(id: string, data: Partial<InsertCampaign>): Promise<Campaign | undefined>;
  deleteCampaign(id: string): Promise<void>;
  getAllCampaigns(): Promise<Array<Campaign & { event: Event; reminders: Reminder[] }>>;

  // Reminders
  getReminders(campaignId: string): Promise<Reminder[]>;
  createReminder(reminder: InsertReminder): Promise<Reminder>;
  updateReminder(id: string, data: Partial<InsertReminder>): Promise<Reminder | undefined>;
  deleteReminder(id: string): Promise<void>;
  getDueReminders(): Promise<Array<Reminder & { campaign: Campaign; event: Event | null }>>;

  // Reminder Sends
  getReminderSends(reminderId: string): Promise<ReminderSend[]>;
  createReminderSend(send: InsertReminderSend): Promise<ReminderSend>;
  wasReminderSent(reminderId: string, playerId: string): Promise<boolean>;

  // Responses
  getResponses(eventId: string): Promise<Response[]>;
  getResponse(eventId: string, playerId: string): Promise<Response | undefined>;
  createResponse(response: InsertResponse): Promise<Response>;
  updateResponse(id: string, data: Partial<InsertResponse>): Promise<Response | undefined>;

  // Attendance
  getAttendance(eventId: string): Promise<Attendance[]>;
  createAttendance(att: InsertAttendance): Promise<Attendance>;

  // Reliability History
  createReliabilityHistory(history: InsertReliabilityHistory): Promise<ReliabilityHistory>;
  getPlayerHistory(playerId: string): Promise<ReliabilityHistory[]>;

  // Notification Settings
  getNotificationSettings(teamId: string): Promise<NotificationSettings | undefined>;
  createNotificationSettings(settings: InsertNotificationSettings): Promise<NotificationSettings>;
  updateNotificationSettings(teamId: string, data: Partial<InsertNotificationSettings>): Promise<NotificationSettings | undefined>;
  getAllEnabledNotificationSettings(): Promise<NotificationSettings[]>;
  
  // Notification Sends
  wasNotificationSent(notificationSettingsId: string, eventId: string): Promise<boolean>;
  createNotificationSend(send: InsertNotificationSend): Promise<NotificationSend>;

  // Campaign Templates
  getCampaignTemplates(teamId: string): Promise<CampaignTemplate[]>;
  getGlobalCampaignTemplates(): Promise<CampaignTemplate[]>;
  getCampaignTemplate(id: string): Promise<CampaignTemplate | undefined>;
  createCampaignTemplate(template: InsertCampaignTemplate): Promise<CampaignTemplate>;
  updateCampaignTemplate(id: string, data: Partial<InsertCampaignTemplate>): Promise<CampaignTemplate | undefined>;
  deleteCampaignTemplate(id: string): Promise<void>;

  // Template Reminders
  getTemplateReminders(templateId: string): Promise<TemplateReminder[]>;
  createTemplateReminder(reminder: InsertTemplateReminder): Promise<TemplateReminder>;
  updateTemplateReminder(id: string, data: Partial<InsertTemplateReminder>): Promise<TemplateReminder | undefined>;
  deleteTemplateReminder(id: string): Promise<void>;

  // Admin Notifications
  getAdminNotifications(): Promise<AdminNotification[]>;
  getUnreadAdminNotificationsCount(): Promise<number>;
  createAdminNotification(notification: InsertAdminNotification): Promise<AdminNotification>;
  markAdminNotificationAsRead(id: string): Promise<AdminNotification | undefined>;
  markAllAdminNotificationsAsRead(): Promise<void>;

  // Event Templates
  getEventTemplates(): Promise<EventTemplate[]>;
  getEventTemplatesBySport(sport: string): Promise<EventTemplate[]>;
  getEventTemplate(id: string): Promise<EventTemplate | undefined>;
  createEventTemplate(template: InsertEventTemplate): Promise<EventTemplate>;
  updateEventTemplate(id: string, data: Partial<InsertEventTemplate>): Promise<EventTemplate | undefined>;
  deleteEventTemplate(id: string): Promise<void>;

  // Custom Fields
  getCustomFields(): Promise<CustomField[]>;
  getCustomField(id: string): Promise<CustomField | undefined>;
  createCustomField(field: InsertCustomField): Promise<CustomField>;
  updateCustomField(id: string, data: Partial<InsertCustomField>): Promise<CustomField | undefined>;
  deleteCustomField(id: string): Promise<void>;

  // Messages
  getMessages(teamId: string): Promise<Array<Message & { user: User; reactions: Array<MessageReaction & { user: User }> }>>;
  getMessage(id: string): Promise<Message | undefined>;
  createMessage(message: InsertMessage): Promise<Message>;
  updateMessage(id: string, data: Partial<InsertMessage>): Promise<Message | undefined>;
  deleteMessage(id: string): Promise<void>;
  pinMessage(id: string, isPinned: boolean): Promise<Message | undefined>;

  // App Settings
  getAppSettings(): Promise<AppSettings>;
  updateAppSettings(data: Partial<InsertAppSettings>): Promise<AppSettings>;

  // Landing Page Content
  getLandingPageContent(): Promise<LandingPageContent>;
  updateLandingPageContent(data: Partial<InsertLandingPageContent>): Promise<LandingPageContent>;

  // Marketing Page Content
  getMarketingPageContent(page: "about" | "features" | "pricing" | "contact"): Promise<MarketingPageContentData>;
  updateMarketingPageContent(page: "about" | "features" | "pricing" | "contact", content: MarketingPageContentData): Promise<MarketingPageContentData>;

  // Message Reactions
  getMessageReactions(messageId: string): Promise<MessageReaction[]>;
  createMessageReaction(reaction: InsertMessageReaction): Promise<MessageReaction>;
  deleteMessageReaction(messageId: string, userId: string, emoji: string): Promise<void>;
  getUserReaction(messageId: string, userId: string, emoji: string): Promise<MessageReaction | undefined>;

  // Membership Tiers
  getMembershipTiers(): Promise<Array<MembershipTier & { limits: TierLimit[]; features: TierFeature[] }>>;
  getMembershipTier(id: string): Promise<MembershipTier & { limits: TierLimit[]; features: TierFeature[] } | undefined>;
  createMembershipTier(tier: InsertMembershipTier): Promise<MembershipTier>;
  updateMembershipTier(id: string, data: Partial<InsertMembershipTier>): Promise<MembershipTier | undefined>;
  deleteMembershipTier(id: string): Promise<void>;

  // Tier Limits
  getTierLimits(tierId: string): Promise<TierLimit[]>;
  setTierLimit(limit: InsertTierLimit): Promise<TierLimit>;
  deleteTierLimit(tierId: string, limitKey: string): Promise<void>;

  // Tier Features
  getTierFeatures(tierId: string): Promise<TierFeature[]>;
  setTierFeature(feature: InsertTierFeature): Promise<TierFeature>;
  deleteTierFeature(tierId: string, featureKey: string): Promise<void>;

  // User Membership Management
  getAllUsers(): Promise<User[]>;
  assignTierToUser(userId: string, tierId: string, startTrial: boolean): Promise<User | undefined>;
  getUserMembershipTier(userId: string): Promise<MembershipTier & { limits: TierLimit[]; features: TierFeature[] } | undefined>;

  // Invitations
  getInvitations(teamId: string): Promise<Invitation[]>;
  getInvitation(id: string): Promise<Invitation | undefined>;
  getInvitationByToken(token: string): Promise<Invitation | undefined>;
  createInvitation(invitation: InsertInvitation): Promise<Invitation>;
  updateInvitation(id: string, data: Partial<InsertInvitation>): Promise<Invitation | undefined>;
  cancelInvitation(id: string): Promise<Invitation | undefined>;
  getPendingInvitation(teamId: string, contactValue: string): Promise<Invitation | undefined>;

  // Team Documents
  getTeamDocuments(teamId: string): Promise<TeamDocument[]>;
  getActiveTeamDocuments(teamId: string): Promise<TeamDocument[]>;
  getTeamDocument(id: string): Promise<TeamDocument | undefined>;
  createTeamDocument(document: InsertTeamDocument): Promise<TeamDocument>;
  updateTeamDocument(id: string, data: Partial<InsertTeamDocument>): Promise<TeamDocument | undefined>;
  archiveTeamDocument(id: string): Promise<TeamDocument | undefined>;

  // Document Signatures
  getDocumentSignatures(documentId: string): Promise<DocumentSignature[]>;
  getUserSignatures(userId: string, teamId: string): Promise<DocumentSignature[]>;
  createDocumentSignature(signature: InsertDocumentSignature): Promise<DocumentSignature>;
  hasUserSignedDocument(userId: string, documentId: string): Promise<boolean>;

  // Tasks
  getPendingDocuments(userId: string): Promise<Array<TeamDocument & { team: Team }>>;
  getPendingRsvps(userId: string): Promise<Array<Event & { team: Team }>>;
  getTasksSummary(userId: string): Promise<{ documentsPending: number; eventsPending: number; total: number }>;

  // Lineups (Baseball/Softball)
  getLineup(eventId: string): Promise<Lineup | undefined>;
  createLineup(lineup: InsertLineup): Promise<Lineup>;
  updateLineup(eventId: string, data: Partial<InsertLineup>): Promise<Lineup | undefined>;
  deleteLineup(eventId: string): Promise<void>;

  // Message Logs
  createMessageLog(log: InsertMessageLog): Promise<MessageLog>;
  getMessageLog(id: string): Promise<MessageLog | undefined>;
  getMessageLogBySid(messageSid: string): Promise<MessageLog | undefined>;
  getTeamMessageLogs(teamId: string, limit?: number): Promise<MessageLog[]>;
  updateMessageLog(id: string, data: Partial<InsertMessageLog>): Promise<MessageLog | undefined>;

  // SMS Opt-Outs
  createOptOut(optOut: InsertSmsOptOut): Promise<SmsOptOut>;
  getOptOut(teamId: string, phoneNumber: string): Promise<SmsOptOut | undefined>;
  isOptedOut(teamId: string, phoneNumber: string): Promise<boolean>;
  optBackIn(teamId: string, phoneNumber: string): Promise<SmsOptOut | undefined>;

  // Usage Pricing
  getUsagePricing(): Promise<UsagePricing | undefined>;
  updateUsagePricing(data: Partial<InsertUsagePricing>): Promise<UsagePricing>;

  // Usage Tracking
  createUsageTracking(usage: InsertUsageTracking): Promise<UsageTracking>;
  getTeamUsage(teamId: string, startDate?: Date, endDate?: Date): Promise<UsageTracking[]>;
  getTeamUsageSummary(teamId: string, startDate: Date, endDate: Date): Promise<{
    totalSms: number;
    totalCost: number;
    smsCost: number;
    phoneNumberCost: number;
  }>;

  // Team Notifications (Coach notifications for RSVP responses, etc.)
  createTeamNotification(notification: InsertTeamNotification): Promise<TeamNotification>;
  getTeamNotifications(userId: string, teamId?: string): Promise<TeamNotification[]>;
  getUnreadTeamNotificationsCount(userId: string): Promise<number>;
  markTeamNotificationAsRead(id: string): Promise<TeamNotification | undefined>;
  markAllTeamNotificationsAsRead(userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Users (for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    // Normalize phone number to E.164 format for SMS delivery
    const normalizedData = {
      ...userData,
      phone: userData.phone ? normalizePhoneForTwilio(userData.phone) : userData.phone,
    };
    
    const [user] = await db
      .insert(users)
      .values(normalizedData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...normalizedData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async deleteUser(id: string): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  // Teams
  async getTeams(): Promise<Team[]> {
    return await db.select().from(teams).orderBy(desc(teams.createdAt));
  }

  async getTeamsForUser(userId: string): Promise<Team[]> {
    const user = await this.getUser(userId);
    if (!user) {
      return [];
    }

    // If user is global admin, return all teams
    if (user.isGlobalAdmin) {
      return await this.getTeams();
    }

    // Get teams where user is the owner
    const ownedTeams = await db
      .select()
      .from(teams)
      .where(eq(teams.userId, userId))
      .orderBy(desc(teams.createdAt));

    // Get teams where user has a player record (via case-insensitive email match)
    let teamsWithRole: Team[] = [];
    if (user.email) {
      const userPlayers = await db
        .select()
        .from(players)
        .where(sql`LOWER(${players.email}) = LOWER(${user.email})`);
      
      const teamIdsWithRole = userPlayers.map((p: any) => p.teamId);
      
      if (teamIdsWithRole.length > 0) {
        teamsWithRole = await db
          .select()
          .from(teams)
          .where(inArray(teams.id, teamIdsWithRole))
          .orderBy(desc(teams.createdAt));
      }
    }

    // Combine and deduplicate teams
    const allTeams = [...ownedTeams, ...teamsWithRole];
    const uniqueTeams = Array.from(
      new Map(allTeams.map((team) => [team.id, team])).values()
    );

    return uniqueTeams;
  }

  async getTeam(id: string): Promise<Team | undefined> {
    const [team] = await db.select().from(teams).where(eq(teams.id, id));
    return team || undefined;
  }

  async createTeam(team: InsertTeam): Promise<Team> {
    const [newTeam] = await db.insert(teams).values(team).returning();
    // Automatically create default roles for the new team
    await this.createDefaultRoles(newTeam.id);
    return newTeam;
  }

  async updateTeam(id: string, data: Partial<InsertTeam>): Promise<Team | undefined> {
    const [updated] = await db
      .update(teams)
      .set(data)
      .where(eq(teams.id, id))
      .returning();
    return updated;
  }

  async deleteTeam(id: string): Promise<void> {
    await db.delete(teams).where(eq(teams.id, id));
  }

  // Roles
  async getRoles(teamId: string): Promise<Role[]> {
    return await db.select().from(roles).where(eq(roles.teamId, teamId)).orderBy(roles.name);
  }

  async getRole(id: string): Promise<Role | undefined> {
    const [role] = await db.select().from(roles).where(eq(roles.id, id));
    return role || undefined;
  }

  async createRole(role: InsertRole): Promise<Role> {
    const [newRole] = await db.insert(roles).values(role).returning();
    return newRole;
  }

  async updateRole(id: string, data: Partial<InsertRole>): Promise<Role | undefined> {
    const [updated] = await db.update(roles).set(data).where(eq(roles.id, id)).returning();
    return updated || undefined;
  }

  async deleteRole(id: string): Promise<void> {
    await db.delete(roles).where(eq(roles.id, id));
  }

  async createDefaultRoles(teamId: string): Promise<Role[]> {
    const defaultRoles: InsertRole[] = [
      {
        teamId,
        name: "Coach",
        description: "Full access to all team management features",
        canViewEvents: true,
        canManageEvents: true,
        canViewPlayers: true,
        canManagePlayers: true,
        canSendReminders: true,
        canManageCampaigns: true,
        canViewResponses: true,
        canManageAttendance: true,
        canManageSettings: true,
        canManageRoles: true,
        canViewMembership: true,
        isDefault: true,
      },
      {
        teamId,
        name: "Assistant Coach",
        description: "Can manage most aspects except settings and roles",
        canViewEvents: true,
        canManageEvents: true,
        canViewPlayers: true,
        canManagePlayers: true,
        canSendReminders: true,
        canManageCampaigns: true,
        canViewResponses: true,
        canManageAttendance: true,
        canManageSettings: false,
        canManageRoles: false,
        canViewMembership: false,
        isDefault: true,
      },
      {
        teamId,
        name: "Player",
        description: "Standard player with view-only access",
        canViewEvents: true,
        canManageEvents: false,
        canViewPlayers: true,
        canManagePlayers: false,
        canSendReminders: false,
        canManageCampaigns: false,
        canViewResponses: true,
        canManageAttendance: false,
        canManageSettings: false,
        canManageRoles: false,
        canViewMembership: false,
        isDefault: true,
      },
      {
        teamId,
        name: "Non-Player",
        description: "Team staff or supporter with view-only access",
        canViewEvents: true,
        canManageEvents: false,
        canViewPlayers: true,
        canManagePlayers: false,
        canSendReminders: false,
        canManageCampaigns: false,
        canViewResponses: true,
        canManageAttendance: false,
        canManageSettings: false,
        canManageRoles: false,
        canViewMembership: false,
        isDefault: true,
      },
    ];

    const createdRoles: Role[] = [];
    for (const role of defaultRoles) {
      const created = await this.createRole(role);
      createdRoles.push(created);
    }
    return createdRoles;
  }

  // Players
  async getPlayers(teamId: string): Promise<Player[]> {
    return await db.select().from(players).where(eq(players.teamId, teamId)).orderBy(players.firstName, players.lastName);
  }

  async getPlayer(id: string): Promise<Player | undefined> {
    const [player] = await db.select().from(players).where(eq(players.id, id));
    return player || undefined;
  }

  async getPlayerByUser(teamId: string, userId: string): Promise<Player | undefined> {
    const [player] = await db
      .select()
      .from(players)
      .where(
        and(
          eq(players.teamId, teamId),
          eq(players.userId, userId)
        )
      );
    return player || undefined;
  }

  async findPlayerByContact(teamId: string, contactValue: string, contactType?: "email" | "phone"): Promise<Player | undefined> {
    // Normalize contact value for matching
    const normalizedContact = contactValue.toLowerCase().trim();
    
    // Determine if this is email or phone
    // Use explicit contactType if provided, otherwise detect via @ symbol
    const isEmail = contactType ? contactType === "email" : normalizedContact.includes('@');
    
    if (isEmail) {
      // EMAIL MATCHING: Case-insensitive email comparison
      const [player] = await db
        .select()
        .from(players)
        .where(
          and(
            eq(players.teamId, teamId),
            sql`LOWER(${players.email}) = ${normalizedContact}`
          )
        );
      return player || undefined;
    } else {
      // PHONE MATCHING: Strip all non-digits and normalize to include country code
      const digitsOnly = contactValue.replace(/\D/g, '');
      
      // Require minimum 10 digits for valid phone number (prevent matching on purely numeric usernames)
      if (digitsOnly.length < 10) {
        return undefined;
      }
      
      // Normalize to include country code (assume US/Canada if 10 digits)
      const canonicalDigits = digitsOnly.length === 10 
        ? '1' + digitsOnly  // Add country code to 10-digit US numbers
        : digitsOnly;
      
      // Search for players where phone digits match
      // This handles ALL formats: "+15551234567", "15551234567", "(555) 123-4567", "555-123-4567", etc.
      const allPlayers = await db
        .select()
        .from(players)
        .where(eq(players.teamId, teamId));
      
      // Find player by matching canonical digit versions
      const player = allPlayers.find((p: any) => {
        if (p.phone) {
          const playerDigits = p.phone.replace(/\D/g, '');
          
          // Skip empty phone numbers
          if (playerDigits.length < 10) {
            return false;
          }
          
          // Normalize player's phone to canonical form
          const playerCanonical = playerDigits.length === 10
            ? '1' + playerDigits
            : playerDigits;
          // Match if canonical forms are identical
          return playerCanonical === canonicalDigits;
        }
        return false;
      });
      
      return player;
    }
  }

  async createPlayer(player: InsertPlayer): Promise<Player> {
    // Import phone normalization utility
    const { normalizePhoneForTwilio } = await import("@shared/phoneUtils");
    
    // Normalize email to lowercase and phone to E.164 format for consistent matching
    const normalizedPlayer = {
      ...player,
      email: player.email ? player.email.toLowerCase() : player.email,
      phone: player.phone ? normalizePhoneForTwilio(player.phone) : player.phone,
    };
    const [newPlayer] = await db.insert(players).values(normalizedPlayer).returning();
    return newPlayer;
  }

  async updatePlayer(id: string, data: Partial<InsertPlayer>): Promise<Player | undefined> {
    // Import phone normalization utility
    const { normalizePhoneForTwilio } = await import("@shared/phoneUtils");
    
    // Normalize email and phone when updating
    const normalizedData = {
      ...data,
      email: data.email ? data.email.toLowerCase() : data.email,
      phone: data.phone ? normalizePhoneForTwilio(data.phone) : data.phone,
    };
    const [updated] = await db.update(players).set(normalizedData).where(eq(players.id, id)).returning();
    return updated || undefined;
  }

  async deletePlayer(id: string): Promise<void> {
    await db.delete(players).where(eq(players.id, id));
  }

  // Events
  async getEvents(teamId?: string): Promise<Event[]> {
    if (teamId) {
      return await db.select().from(events).where(eq(events.teamId, teamId)).orderBy(desc(events.datetime));
    }
    return await db.select().from(events).orderBy(desc(events.datetime));
  }

  async getEventsWithStats(teamId?: string): Promise<Array<Event & { stats: { yes: number; no: number; maybe: number; pending: number } }>> {
    // Fetch events
    const eventList = await this.getEvents(teamId);
    
    if (eventList.length === 0) {
      return [];
    }

    // Get all unique team IDs from events
    const teamIds = Array.from(new Set(eventList.map(e => e.teamId)));
    
    // Get all event IDs
    const eventIds = eventList.map(e => e.id);
    
    // Fetch all players for these teams in ONE query using IN clause
    const allPlayers = await db
      .select()
      .from(players)
      .where(inArray(players.teamId, teamIds));
    
    // Fetch all responses for these events in ONE query using IN clause
    const allResponsesForEvents = await db
      .select()
      .from(responses)
      .where(inArray(responses.eventId, eventIds));
    
    // Calculate stats for each event
    return eventList.map(event => {
      const eventResponses = allResponsesForEvents.filter((r: any) => r.eventId === event.id);
      const teamPlayers = allPlayers.filter((p: any) => p.teamId === event.teamId);
      
      // Create a set of player IDs who have responded
      const respondedPlayerIds = new Set(eventResponses.map((r: any) => r.playerId));
      
      // Count responses by status
      const yes = eventResponses.filter((r: any) => r.status === "yes").length;
      const no = eventResponses.filter((r: any) => r.status === "no").length;
      const maybe = eventResponses.filter((r: any) => r.status === "maybe").length;
      const pendingResponses = eventResponses.filter((r: any) => r.status === "pending").length;
      
      // Count players who haven't responded at all
      const noResponse = teamPlayers.filter((p: any) => !respondedPlayerIds.has(p.id)).length;
      
      // Total pending = players with "pending" status + players with no response
      const pending = pendingResponses + noResponse;
      
      return {
        ...event,
        stats: { yes, no, maybe, pending }
      };
    });
  }

  async getUpcomingEvents(limit: number = 30): Promise<Event[]> {
    const now = new Date();
    const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    
    return await db
      .select()
      .from(events)
      .where(and(gte(events.datetime, now), lte(events.datetime, thirtyDaysFromNow)))
      .orderBy(events.datetime)
      .limit(limit);
  }

  async getEventsWithoutCampaigns(teamId: string): Promise<Event[]> {
    const allEvents = await db
      .select()
      .from(events)
      .where(eq(events.teamId, teamId))
      .orderBy(desc(events.datetime));
    
    const allCampaigns = await db
      .select()
      .from(campaigns);
    
    const eventIdsWithCampaigns = new Set(allCampaigns.map((c: any) => c.eventId));
    
    return allEvents.filter((event: any) => !eventIdsWithCampaigns.has(event.id));
  }

  async getEvent(id: string): Promise<Event | undefined> {
    const [event] = await db.select().from(events).where(eq(events.id, id));
    return event || undefined;
  }

  async getPaymentRequest(id: string): Promise<typeof teamPaymentRequests.$inferSelect | undefined> {
    const [paymentRequest] = await db.select().from(teamPaymentRequests).where(eq(teamPaymentRequests.id, id));
    return paymentRequest || undefined;
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const [newEvent] = await db.insert(events).values(event).returning();
    return newEvent;
  }

  async updateEvent(id: string, data: Partial<InsertEvent>): Promise<Event | undefined> {
    // Get current event to increment sequence
    const currentEvent = await this.getEvent(id);
    if (!currentEvent) return undefined;

    // Increment sequence number and update timestamp for calendar sync
    const updateData = {
      ...data,
      sequence: currentEvent.sequence + 1,
      updatedAt: new Date(),
    };

    const [updated] = await db.update(events).set(updateData).where(eq(events.id, id)).returning();
    return updated || undefined;
  }

  async deleteEvent(id: string): Promise<void> {
    await db.delete(events).where(eq(events.id, id));
  }

  // Campaigns
  async getCampaign(eventId: string): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.eventId, eventId));
    return campaign || undefined;
  }

  async createCampaign(campaign: InsertCampaign): Promise<Campaign> {
    const [newCampaign] = await db.insert(campaigns).values(campaign).returning();
    return newCampaign;
  }

  async updateCampaign(id: string, data: Partial<InsertCampaign>): Promise<Campaign | undefined> {
    const [updated] = await db.update(campaigns).set(data).where(eq(campaigns.id, id)).returning();
    return updated || undefined;
  }

  async getCampaignById(id: string): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return campaign || undefined;
  }

  async deleteCampaign(id: string): Promise<void> {
    // First delete all associated reminders
    await db.delete(reminders).where(eq(reminders.campaignId, id));
    // Then delete the campaign
    await db.delete(campaigns).where(eq(campaigns.id, id));
  }

  async getAllCampaigns(): Promise<Array<Campaign & { event: Event; reminders: Reminder[] }>> {
    const allCampaigns = await db
      .select()
      .from(campaigns)
      .innerJoin(events, eq(campaigns.eventId, events.id))
      .orderBy(desc(events.datetime));

    const result = [];
    for (const { campaigns: campaign, events: event } of allCampaigns) {
      const remindersList = await this.getReminders(campaign.id);
      result.push({
        ...campaign,
        event,
        reminders: remindersList
      });
    }

    return result;
  }

  // Reminders
  async getReminders(campaignId: string): Promise<Reminder[]> {
    return await db.select().from(reminders).where(eq(reminders.campaignId, campaignId));
  }

  async createReminder(reminder: InsertReminder): Promise<Reminder> {
    const [newReminder] = await db.insert(reminders).values(reminder).returning();
    return newReminder;
  }

  async updateReminder(id: string, data: Partial<InsertReminder>): Promise<Reminder | undefined> {
    const [updated] = await db
      .update(reminders)
      .set(data)
      .where(eq(reminders.id, id))
      .returning();
    return updated;
  }

  async deleteReminder(id: string): Promise<void> {
    await db.delete(reminders).where(eq(reminders.id, id));
  }

  async getDueReminders(): Promise<Array<Reminder & { campaign: Campaign; event: Event | null }>> {
    const now = new Date();
    
    // Get all active campaigns with their events (left join to include campaigns without events)
    const activeCampaigns = await db
      .select()
      .from(campaigns)
      .leftJoin(events, eq(campaigns.eventId, events.id))
      .where(eq(campaigns.isActive, true));

    // For each campaign, get reminders and check if they're due
    const dueReminders: Array<Reminder & { campaign: Campaign; event: Event | null }> = [];
    
    for (const { campaigns: campaign, events: event } of activeCampaigns) {
      const campaignReminders = await this.getReminders(campaign.id);
      
      for (const reminder of campaignReminders) {
        // For event-based campaigns, check if reminder is due based on event time
        if (event) {
          const eventTime = new Date(event.datetime);
          const reminderTime = new Date(eventTime.getTime() - reminder.intervalHours * 60 * 60 * 1000);
          
          // Check if reminder is due (within the last hour and not in the future)
          const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);
          if (reminderTime <= now && reminderTime >= oneHourAgo) {
            dueReminders.push({ ...reminder, campaign, event });
          }
        }
        // For standalone campaigns, reminders are not time-based (skip for now)
        // Future: Could add absolute timestamp field for standalone campaigns
      }
    }
    
    return dueReminders;
  }

  // Reminder Sends
  async getReminderSends(reminderId: string): Promise<ReminderSend[]> {
    return await db.select().from(reminderSends).where(eq(reminderSends.reminderId, reminderId));
  }

  async createReminderSend(send: InsertReminderSend): Promise<ReminderSend> {
    const [newSend] = await db.insert(reminderSends).values(send).returning();
    return newSend;
  }

  async wasReminderSent(reminderId: string, playerId: string): Promise<boolean> {
    const [send] = await db
      .select()
      .from(reminderSends)
      .where(and(eq(reminderSends.reminderId, reminderId), eq(reminderSends.playerId, playerId)))
      .limit(1);
    return !!send;
  }

  // Responses
  async getResponses(eventId: string): Promise<Response[]> {
    return await db.select().from(responses).where(eq(responses.eventId, eventId)).orderBy(desc(responses.createdAt));
  }

  async getResponse(eventId: string, playerId: string): Promise<Response | undefined> {
    const [response] = await db
      .select()
      .from(responses)
      .where(and(eq(responses.eventId, eventId), eq(responses.playerId, playerId)));
    return response || undefined;
  }

  async createResponse(response: InsertResponse): Promise<Response> {
    const [newResponse] = await db.insert(responses).values(response).returning();
    return newResponse;
  }

  async updateResponse(id: string, data: Partial<InsertResponse>): Promise<Response | undefined> {
    const [updated] = await db
      .update(responses)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(responses.id, id))
      .returning();
    return updated || undefined;
  }

  // Attendance
  async getAttendance(eventId: string): Promise<Attendance[]> {
    return await db.select().from(attendance).where(eq(attendance.eventId, eventId));
  }

  async createAttendance(att: InsertAttendance): Promise<Attendance> {
    const [newAtt] = await db.insert(attendance).values(att).returning();
    return newAtt;
  }

  // Reliability History
  async createReliabilityHistory(history: InsertReliabilityHistory): Promise<ReliabilityHistory> {
    const [newHistory] = await db.insert(reliabilityHistory).values(history).returning();
    return newHistory;
  }

  async getPlayerHistory(playerId: string): Promise<ReliabilityHistory[]> {
    return await db
      .select()
      .from(reliabilityHistory)
      .where(eq(reliabilityHistory.playerId, playerId))
      .orderBy(desc(reliabilityHistory.createdAt));
  }

  // Notification Settings
  async getNotificationSettings(teamId: string): Promise<NotificationSettings | undefined> {
    const [settings] = await db
      .select()
      .from(notificationSettings)
      .where(eq(notificationSettings.teamId, teamId));
    return settings || undefined;
  }

  async createNotificationSettings(settings: InsertNotificationSettings): Promise<NotificationSettings> {
    const [newSettings] = await db.insert(notificationSettings).values(settings).returning();
    return newSettings;
  }

  async updateNotificationSettings(teamId: string, data: Partial<InsertNotificationSettings>): Promise<NotificationSettings | undefined> {
    const [updated] = await db
      .update(notificationSettings)
      .set(data)
      .where(eq(notificationSettings.teamId, teamId))
      .returning();
    return updated || undefined;
  }

  async getAllEnabledNotificationSettings(): Promise<NotificationSettings[]> {
    return await db
      .select()
      .from(notificationSettings)
      .where(eq(notificationSettings.enabled, true));
  }

  async wasNotificationSent(notificationSettingsId: string, eventId: string): Promise<boolean> {
    const [send] = await db
      .select()
      .from(notificationSends)
      .where(
        and(
          eq(notificationSends.notificationSettingsId, notificationSettingsId),
          eq(notificationSends.eventId, eventId)
        )
      );
    return !!send;
  }

  async createNotificationSend(send: InsertNotificationSend): Promise<NotificationSend> {
    const [newSend] = await db.insert(notificationSends).values(send).returning();
    return newSend;
  }

  // Campaign Templates
  async getCampaignTemplates(teamId: string): Promise<CampaignTemplate[]> {
    return await db
      .select()
      .from(campaignTemplates)
      .where(eq(campaignTemplates.teamId, teamId))
      .orderBy(desc(campaignTemplates.createdAt));
  }

  async getGlobalCampaignTemplates(): Promise<CampaignTemplate[]> {
    return await db
      .select()
      .from(campaignTemplates)
      .where(isNull(campaignTemplates.teamId))
      .orderBy(desc(campaignTemplates.createdAt));
  }

  async getCampaignTemplate(id: string): Promise<CampaignTemplate | undefined> {
    const [template] = await db
      .select()
      .from(campaignTemplates)
      .where(eq(campaignTemplates.id, id));
    return template || undefined;
  }

  async createCampaignTemplate(template: InsertCampaignTemplate): Promise<CampaignTemplate> {
    const [newTemplate] = await db.insert(campaignTemplates).values(template).returning();
    return newTemplate;
  }

  async updateCampaignTemplate(id: string, data: Partial<InsertCampaignTemplate>): Promise<CampaignTemplate | undefined> {
    const [updated] = await db
      .update(campaignTemplates)
      .set(data)
      .where(eq(campaignTemplates.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteCampaignTemplate(id: string): Promise<void> {
    // First delete all associated template reminders
    await db.delete(templateReminders).where(eq(templateReminders.templateId, id));
    // Then delete the template
    await db.delete(campaignTemplates).where(eq(campaignTemplates.id, id));
  }

  // Event Templates
  async getEventTemplates(): Promise<EventTemplate[]> {
    return await db
      .select()
      .from(eventTemplates)
      .orderBy(eventTemplates.sport, eventTemplates.name);
  }

  async getEventTemplatesBySport(sport: string): Promise<EventTemplate[]> {
    return await db
      .select()
      .from(eventTemplates)
      .where(eq(eventTemplates.sport, sport))
      .orderBy(eventTemplates.name);
  }

  async getEventTemplate(id: string): Promise<EventTemplate | undefined> {
    const [template] = await db
      .select()
      .from(eventTemplates)
      .where(eq(eventTemplates.id, id))
      .limit(1);
    return template;
  }

  async createEventTemplate(template: InsertEventTemplate): Promise<EventTemplate> {
    const [newTemplate] = await db.insert(eventTemplates).values(template).returning();
    return newTemplate;
  }

  async updateEventTemplate(id: string, data: Partial<InsertEventTemplate>): Promise<EventTemplate | undefined> {
    const [updated] = await db
      .update(eventTemplates)
      .set(data)
      .where(eq(eventTemplates.id, id))
      .returning();
    return updated;
  }

  async deleteEventTemplate(id: string): Promise<void> {
    await db.delete(eventTemplates).where(eq(eventTemplates.id, id));
  }

  // Custom Fields
  async getCustomFields(): Promise<CustomField[]> {
    return await db
      .select()
      .from(customFields)
      .orderBy(customFields.name);
  }

  async getCustomField(id: string): Promise<CustomField | undefined> {
    const result = await db
      .select()
      .from(customFields)
      .where(eq(customFields.id, id))
      .limit(1);
    return result[0];
  }

  async createCustomField(field: InsertCustomField): Promise<CustomField> {
    const result = await db.insert(customFields).values(field).returning();
    return result[0];
  }

  async updateCustomField(id: string, data: Partial<InsertCustomField>): Promise<CustomField | undefined> {
    const result = await db
      .update(customFields)
      .set(data)
      .where(eq(customFields.id, id))
      .returning();
    return result[0];
  }

  async deleteCustomField(id: string): Promise<void> {
    await db.delete(customFields).where(eq(customFields.id, id));
  }

  // Template Reminders
  async getTemplateReminders(templateId: string): Promise<TemplateReminder[]> {
    return await db
      .select()
      .from(templateReminders)
      .where(eq(templateReminders.templateId, templateId))
      .orderBy(desc(templateReminders.intervalHours));
  }

  async createTemplateReminder(reminder: InsertTemplateReminder): Promise<TemplateReminder> {
    const [newReminder] = await db.insert(templateReminders).values(reminder).returning();
    return newReminder;
  }

  async updateTemplateReminder(id: string, data: Partial<InsertTemplateReminder>): Promise<TemplateReminder | undefined> {
    const [updated] = await db
      .update(templateReminders)
      .set(data)
      .where(eq(templateReminders.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteTemplateReminder(id: string): Promise<void> {
    await db.delete(templateReminders).where(eq(templateReminders.id, id));
  }

  // Admin Notifications
  async getAdminNotifications(): Promise<AdminNotification[]> {
    return await db
      .select()
      .from(adminNotifications)
      .orderBy(desc(adminNotifications.createdAt));
  }

  async getUnreadAdminNotificationsCount(): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(adminNotifications)
      .where(eq(adminNotifications.isRead, false));
    return result[0]?.count || 0;
  }

  async createAdminNotification(notification: InsertAdminNotification): Promise<AdminNotification> {
    const [newNotification] = await db.insert(adminNotifications).values(notification).returning();
    return newNotification;
  }

  async markAdminNotificationAsRead(id: string): Promise<AdminNotification | undefined> {
    const [updated] = await db
      .update(adminNotifications)
      .set({ isRead: true, readAt: new Date() })
      .where(eq(adminNotifications.id, id))
      .returning();
    return updated || undefined;
  }

  async markAllAdminNotificationsAsRead(): Promise<void> {
    await db
      .update(adminNotifications)
      .set({ isRead: true, readAt: new Date() })
      .where(eq(adminNotifications.isRead, false));
  }

  // Messages
  async getMessages(teamId: string): Promise<Array<Message & { user: User; reactions: Array<MessageReaction & { user: User }> }>> {
    const result = await db
      .select({
        message: messages,
        user: users,
      })
      .from(messages)
      .leftJoin(users, eq(messages.userId, users.id))
      .where(eq(messages.teamId, teamId))
      .orderBy(desc(messages.isPinned), desc(messages.createdAt));

    const messagesWithReactions = await Promise.all(
      result.map(async (row: any) => {
        const reactions = await db
          .select({
            reaction: messageReactions,
            user: users,
          })
          .from(messageReactions)
          .leftJoin(users, eq(messageReactions.userId, users.id))
          .where(eq(messageReactions.messageId, row.message.id));

        return {
          ...row.message,
          user: row.user!,
          reactions: reactions.map((r: any) => ({ ...r.reaction, user: r.user! })),
        };
      })
    );

    return messagesWithReactions;
  }

  async getMessage(id: string): Promise<Message | undefined> {
    const [message] = await db
      .select()
      .from(messages)
      .where(eq(messages.id, id));
    return message || undefined;
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  async updateMessage(id: string, data: Partial<InsertMessage>): Promise<Message | undefined> {
    const [updated] = await db
      .update(messages)
      .set(data)
      .where(eq(messages.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteMessage(id: string): Promise<void> {
    await db.delete(messages).where(eq(messages.id, id));
  }

  async pinMessage(id: string, isPinned: boolean): Promise<Message | undefined> {
    const [updated] = await db
      .update(messages)
      .set({ isPinned })
      .where(eq(messages.id, id))
      .returning();
    return updated || undefined;
  }

  // Message Reactions
  async getMessageReactions(messageId: string): Promise<MessageReaction[]> {
    return await db
      .select()
      .from(messageReactions)
      .where(eq(messageReactions.messageId, messageId));
  }

  async createMessageReaction(reaction: InsertMessageReaction): Promise<MessageReaction> {
    const [newReaction] = await db.insert(messageReactions).values(reaction).returning();
    return newReaction;
  }

  async deleteMessageReaction(messageId: string, userId: string, emoji: string): Promise<void> {
    await db
      .delete(messageReactions)
      .where(
        and(
          eq(messageReactions.messageId, messageId),
          eq(messageReactions.userId, userId),
          eq(messageReactions.emoji, emoji)
        )
      );
  }

  async getUserReaction(messageId: string, userId: string, emoji: string): Promise<MessageReaction | undefined> {
    const [reaction] = await db
      .select()
      .from(messageReactions)
      .where(
        and(
          eq(messageReactions.messageId, messageId),
          eq(messageReactions.userId, userId),
          eq(messageReactions.emoji, emoji)
        )
      );
    return reaction || undefined;
  }

  // App Settings
  async getAppSettings(): Promise<AppSettings> {
    const [settings] = await db.select().from(appSettings);
    
    if (!settings) {
      const [newSettings] = await db
        .insert(appSettings)
        .values({ applicationName: "TeamSyncAI" })
        .returning();
      return newSettings;
    }
    
    return settings;
  }

  async updateAppSettings(data: Partial<InsertAppSettings>): Promise<AppSettings> {
    const existingSettings = await this.getAppSettings();
    
    const [updated] = await db
      .update(appSettings)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(appSettings.id, existingSettings.id))
      .returning();
    
    return updated;
  }

  // Landing Page Content
  async getLandingPageContent(): Promise<LandingPageContent> {
    const [content] = await db.select().from(landingPageContent);
    
    if (!content) {
      // Seed with default content including 6 feature cards
      const defaultFeatures = [
        {
          icon: "MessageSquare" as const,
          title: "Smart SMS Reminders",
          description: "Automatically send customizable SMS reminders to your team. AI parses natural language responses to track who's coming.",
        },
        {
          icon: "Calendar" as const,
          title: "Event Management",
          description: "Create games and practices with all the details. Track attendance, location, and game-specific information in one place.",
        },
        {
          icon: "TrendingUp" as const,
          title: "Reliability Tracking",
          description: "Monitor player reliability over time. Automatically score players based on their attendance history.",
        },
        {
          icon: "Bell" as const,
          title: "Automated Updates",
          description: "Send scheduled team updates to specific roles. Daily, weekly, or before events — you choose when your team gets notified.",
        },
        {
          icon: "Zap" as const,
          title: "Campaign Templates",
          description: "Save time with reusable reminder templates. Create once, apply to any event with a single click.",
        },
        {
          icon: "Users" as const,
          title: "Role-Based Access",
          description: "Control who can manage events, players, and settings. Create custom roles with specific permissions.",
        },
      ];
      
      const [newContent] = await db
        .insert(landingPageContent)
        .values({
          heroTitle: "Your AI-Powered Assistant Manager",
          heroSubtitle: "Automate team management for amateur sports teams. Save hours every week with intelligent SMS reminders, attendance tracking, and player reliability monitoring.",
          heroCta: "Get Started",
          features: defaultFeatures,
          ctaHeading: "Ready to simplify your team management?",
          ctaDescription: "Join coaches who are already saving time and staying organized with {appName}.",
          ctaButton: "Start Now",
          footerText: "&copy; 2025 {appName}. Built for coaches, by coaches.",
        })
        .returning();
      return newContent;
    }
    
    return content;
  }

  async updateLandingPageContent(data: Partial<InsertLandingPageContent>): Promise<LandingPageContent> {
    const existingContent = await this.getLandingPageContent();
    
    const [updated] = await db
      .update(landingPageContent)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(landingPageContent.id, existingContent.id))
      .returning();
    
    return updated;
  }

  // Marketing Page Content
  async getMarketingPageContent(page: "about" | "features" | "pricing" | "contact"): Promise<MarketingPageContentData> {
    const [content] = await db
      .select()
      .from(marketingPageContent)
      .where(eq(marketingPageContent.page, page));
    
    if (!content) {
      // Return default content based on page type
      let defaultContent: MarketingPageContentData;
      
      switch (page) {
        case "about":
          defaultContent = DEFAULT_ABOUT_CONTENT;
          break;
        case "features":
          defaultContent = DEFAULT_FEATURES_CONTENT;
          break;
        case "pricing":
          defaultContent = DEFAULT_PRICING_CONTENT;
          break;
        case "contact":
          defaultContent = DEFAULT_CONTACT_CONTENT;
          break;
      }
      
      // Seed the database with default content
      await db
        .insert(marketingPageContent)
        .values({
          page,
          content: defaultContent,
        });
      
      return defaultContent;
    }
    
    return content.content as MarketingPageContentData;
  }

  async updateMarketingPageContent(page: "about" | "features" | "pricing" | "contact", content: MarketingPageContentData): Promise<MarketingPageContentData> {
    // Validate content based on page type
    let validatedContent: MarketingPageContentData;
    
    switch (page) {
      case "about":
        validatedContent = aboutPageContentSchema.parse(content);
        break;
      case "features":
        validatedContent = featuresPageContentSchema.parse(content);
        break;
      case "pricing":
        validatedContent = pricingPageContentSchema.parse(content);
        break;
      case "contact":
        validatedContent = contactPageContentSchema.parse(content);
        break;
    }
    
    // Ensure the row exists first
    await this.getMarketingPageContent(page);
    
    await db
      .update(marketingPageContent)
      .set({ content: validatedContent, updatedAt: new Date() })
      .where(eq(marketingPageContent.page, page));
    
    return validatedContent;
  }

  // Membership Tiers
  async getMembershipTiers(): Promise<Array<MembershipTier & { limits: TierLimit[]; features: TierFeature[] }>> {
    const tiers = await db.select().from(membershipTiers).orderBy(membershipTiers.displayOrder, membershipTiers.name);
    
    const tiersWithDetails = await Promise.all(
      tiers.map(async (tier: any) => {
        const limits = await this.getTierLimits(tier.id);
        const features = await this.getTierFeatures(tier.id);
        return { ...tier, limits, features };
      })
    );
    
    return tiersWithDetails;
  }

  async getMembershipTier(id: string): Promise<MembershipTier & { limits: TierLimit[]; features: TierFeature[] } | undefined> {
    const [tier] = await db.select().from(membershipTiers).where(eq(membershipTiers.id, id));
    if (!tier) return undefined;
    
    const limits = await this.getTierLimits(id);
    const features = await this.getTierFeatures(id);
    
    return { ...tier, limits, features };
  }

  async createMembershipTier(tier: InsertMembershipTier): Promise<MembershipTier> {
    if (tier.isDefault) {
      await db
        .update(membershipTiers)
        .set({ isDefault: false })
        .where(eq(membershipTiers.isDefault, true));
    }
    
    const [newTier] = await db.insert(membershipTiers).values(tier).returning();
    return newTier;
  }

  async updateMembershipTier(id: string, data: Partial<InsertMembershipTier>): Promise<MembershipTier | undefined> {
    if (data.isDefault === true) {
      await db
        .update(membershipTiers)
        .set({ isDefault: false })
        .where(eq(membershipTiers.isDefault, true));
    }
    
    const [updated] = await db
      .update(membershipTiers)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(membershipTiers.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteMembershipTier(id: string): Promise<void> {
    await db.delete(membershipTiers).where(eq(membershipTiers.id, id));
  }

  // Tier Limits
  async getTierLimits(tierId: string): Promise<TierLimit[]> {
    return await db.select().from(tierLimits).where(eq(tierLimits.tierId, tierId));
  }

  async setTierLimit(limit: InsertTierLimit): Promise<TierLimit> {
    // Upsert: update if exists, insert if not
    const existing = await db
      .select()
      .from(tierLimits)
      .where(and(eq(tierLimits.tierId, limit.tierId), eq(tierLimits.limitKey, limit.limitKey)))
      .limit(1);

    if (existing.length > 0) {
      const [updated] = await db
        .update(tierLimits)
        .set({ limitValue: limit.limitValue })
        .where(eq(tierLimits.id, existing[0].id))
        .returning();
      return updated;
    } else {
      const [newLimit] = await db.insert(tierLimits).values(limit).returning();
      return newLimit;
    }
  }

  async deleteTierLimit(tierId: string, limitKey: string): Promise<void> {
    await db
      .delete(tierLimits)
      .where(and(eq(tierLimits.tierId, tierId), eq(tierLimits.limitKey, limitKey)));
  }

  // Tier Features
  async getTierFeatures(tierId: string): Promise<TierFeature[]> {
    return await db.select().from(tierFeatures).where(eq(tierFeatures.tierId, tierId));
  }

  async setTierFeature(feature: InsertTierFeature): Promise<TierFeature> {
    // Upsert: update if exists, insert if not
    const existing = await db
      .select()
      .from(tierFeatures)
      .where(and(eq(tierFeatures.tierId, feature.tierId), eq(tierFeatures.featureKey, feature.featureKey)))
      .limit(1);

    if (existing.length > 0) {
      const [updated] = await db
        .update(tierFeatures)
        .set({ enabled: feature.enabled })
        .where(eq(tierFeatures.id, existing[0].id))
        .returning();
      return updated;
    } else {
      const [newFeature] = await db.insert(tierFeatures).values(feature).returning();
      return newFeature;
    }
  }

  async deleteTierFeature(tierId: string, featureKey: string): Promise<void> {
    await db
      .delete(tierFeatures)
      .where(and(eq(tierFeatures.tierId, tierId), eq(tierFeatures.featureKey, featureKey)));
  }

  // User Membership Management
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(users.email);
  }

  async assignTierToUser(userId: string, tierId: string, startTrial: boolean): Promise<User | undefined> {
    const tier = await db.select().from(membershipTiers).where(eq(membershipTiers.id, tierId)).limit(1);
    if (tier.length === 0) return undefined;

    const updateData: Partial<UpsertUser> = {
      membershipTierId: tierId,
      updatedAt: new Date(),
    };

    if (startTrial && tier[0].trialPeriodDays > 0) {
      const now = new Date();
      const trialEnd = new Date(now);
      trialEnd.setDate(trialEnd.getDate() + tier[0].trialPeriodDays);
      
      updateData.trialStartDate = now;
      updateData.trialEndDate = trialEnd;
    } else {
      updateData.trialStartDate = null;
      updateData.trialEndDate = null;
    }

    const [updated] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, userId))
      .returning();
    
    return updated || undefined;
  }

  async getUserMembershipTier(userId: string): Promise<MembershipTier & { limits: TierLimit[]; features: TierFeature[] } | undefined> {
    const user = await this.getUser(userId);
    if (!user || !user.membershipTierId) return undefined;
    
    return await this.getMembershipTier(user.membershipTierId);
  }

  // Invitations
  async getInvitations(teamId: string): Promise<Invitation[]> {
    return await db
      .select()
      .from(invitations)
      .where(eq(invitations.teamId, teamId))
      .orderBy(desc(invitations.createdAt));
  }

  async getInvitation(id: string): Promise<Invitation | undefined> {
    const [invitation] = await db
      .select()
      .from(invitations)
      .where(eq(invitations.id, id));
    return invitation || undefined;
  }

  async getInvitationByToken(token: string): Promise<Invitation | undefined> {
    const [invitation] = await db
      .select()
      .from(invitations)
      .where(eq(invitations.token, token));
    return invitation || undefined;
  }

  async createInvitation(invitation: InsertInvitation): Promise<Invitation> {
    const [created] = await db
      .insert(invitations)
      .values(invitation)
      .returning();
    return created;
  }

  async updateInvitation(id: string, data: Partial<InsertInvitation>): Promise<Invitation | undefined> {
    const [updated] = await db
      .update(invitations)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(invitations.id, id))
      .returning();
    return updated || undefined;
  }

  async cancelInvitation(id: string): Promise<Invitation | undefined> {
    return await this.updateInvitation(id, { status: "cancelled" });
  }

  async getPendingInvitation(teamId: string, contactValue: string): Promise<Invitation | undefined> {
    const [invitation] = await db
      .select()
      .from(invitations)
      .where(
        and(
          eq(invitations.teamId, teamId),
          eq(invitations.contactValue, contactValue),
          eq(invitations.status, "pending")
        )
      )
      .limit(1);
    return invitation || undefined;
  }

  // Team Documents
  async getTeamDocuments(teamId: string): Promise<TeamDocument[]> {
    return await db
      .select()
      .from(teamDocuments)
      .where(eq(teamDocuments.teamId, teamId))
      .orderBy(desc(teamDocuments.createdAt));
  }

  async getActiveTeamDocuments(teamId: string): Promise<TeamDocument[]> {
    return await db
      .select()
      .from(teamDocuments)
      .where(
        and(
          eq(teamDocuments.teamId, teamId),
          isNull(teamDocuments.archivedAt)
        )
      )
      .orderBy(desc(teamDocuments.activeFrom));
  }

  async getTeamDocument(id: string): Promise<TeamDocument | undefined> {
    const [document] = await db
      .select()
      .from(teamDocuments)
      .where(eq(teamDocuments.id, id));
    return document || undefined;
  }

  async createTeamDocument(document: InsertTeamDocument): Promise<TeamDocument> {
    const [created] = await db
      .insert(teamDocuments)
      .values(document)
      .returning();
    return created;
  }

  async updateTeamDocument(id: string, data: Partial<InsertTeamDocument>): Promise<TeamDocument | undefined> {
    const [updated] = await db
      .update(teamDocuments)
      .set(data)
      .where(eq(teamDocuments.id, id))
      .returning();
    return updated || undefined;
  }

  async archiveTeamDocument(id: string): Promise<TeamDocument | undefined> {
    return await this.updateTeamDocument(id, { archivedAt: new Date() });
  }

  // Document Signatures
  async getDocumentSignatures(documentId: string): Promise<DocumentSignature[]> {
    return await db
      .select()
      .from(documentSignatures)
      .where(eq(documentSignatures.documentId, documentId))
      .orderBy(desc(documentSignatures.signedAt));
  }

  async getUserSignatures(userId: string, teamId: string): Promise<DocumentSignature[]> {
    const teamDocs = await this.getActiveTeamDocuments(teamId);
    const docIds = teamDocs.map(doc => doc.id);
    
    if (docIds.length === 0) return [];
    
    return await db
      .select()
      .from(documentSignatures)
      .where(
        and(
          eq(documentSignatures.userId, userId),
          inArray(documentSignatures.documentId, docIds)
        )
      );
  }

  async createDocumentSignature(signature: InsertDocumentSignature): Promise<DocumentSignature> {
    const [created] = await db
      .insert(documentSignatures)
      .values(signature)
      .returning();
    return created;
  }

  async hasUserSignedDocument(userId: string, documentId: string): Promise<boolean> {
    const [signature] = await db
      .select()
      .from(documentSignatures)
      .where(
        and(
          eq(documentSignatures.userId, userId),
          eq(documentSignatures.documentId, documentId)
        )
      )
      .limit(1);
    return !!signature;
  }

  // Tasks
  async getPendingDocuments(userId: string): Promise<Array<TeamDocument & { team: Team }>> {
    // Get user's email to match with player records
    const user = await this.getUser(userId);
    if (!user || !user.email) return [];

    // Get all teams the user belongs to (matching by email)
    const userPlayers = await db
      .select()
      .from(players)
      .where(eq(players.email, user.email));
    
    const teamIds = userPlayers.map((p: any) => p.teamId);
    if (teamIds.length === 0) return [];

    // Get all active documents for those teams
    const allDocs = await db
      .select()
      .from(teamDocuments)
      .where(
        and(
          inArray(teamDocuments.teamId, teamIds),
          isNull(teamDocuments.archivedAt),
          eq(teamDocuments.requiresSignature, true)
        )
      );

    // Filter out documents the user has already signed
    const pendingDocs = [];
    for (const doc of allDocs) {
      const hasSigned = await this.hasUserSignedDocument(userId, doc.id);
      if (!hasSigned) {
        const [team] = await db.select().from(teams).where(eq(teams.id, doc.teamId));
        if (team) {
          pendingDocs.push({ ...doc, team });
        }
      }
    }

    return pendingDocs;
  }

  async getPendingRsvps(userId: string): Promise<Array<Event & { team: Team }>> {
    // Get user's email to match with player records
    const user = await this.getUser(userId);
    if (!user || !user.email) return [];

    // Get all teams the user belongs to (matching by email)
    const userPlayers = await db
      .select()
      .from(players)
      .where(eq(players.email, user.email));
    
    const teamIds = userPlayers.map((p: any) => p.teamId);
    if (teamIds.length === 0) return [];

    // Get upcoming events for those teams
    const now = new Date();
    const upcomingEvents = await db
      .select()
      .from(events)
      .where(
        and(
          inArray(events.teamId, teamIds),
          gte(events.datetime, now)
        )
      )
      .orderBy(events.datetime);

    // Get player IDs for this user across all teams
    const playerIds = userPlayers.map((p: any) => p.id);

    // Filter events where user hasn't responded
    const pendingEvents = [];
    for (const event of upcomingEvents) {
      // Find the player record for this team
      const playerForTeam = userPlayers.find((p: any) => p.teamId === event.teamId);
      if (!playerForTeam) continue;

      // Check if user has response record for this event
      const [existingResponse] = await db
        .select()
        .from(responses)
        .where(
          and(
            eq(responses.eventId, event.id),
            eq(responses.playerId, playerForTeam.id)
          )
        )
        .limit(1);

      if (!existingResponse) {
        const [team] = await db.select().from(teams).where(eq(teams.id, event.teamId));
        if (team) {
          pendingEvents.push({ ...event, team });
        }
      }
    }

    return pendingEvents;
  }

  async getTasksSummary(userId: string): Promise<{ documentsPending: number; eventsPending: number; total: number }> {
    const [docs, rsvps] = await Promise.all([
      this.getPendingDocuments(userId),
      this.getPendingRsvps(userId)
    ]);

    return {
      documentsPending: docs.length,
      eventsPending: rsvps.length,
      total: docs.length + rsvps.length
    };
  }

  // Lineups (Baseball/Softball)
  async getLineup(eventId: string): Promise<Lineup | undefined> {
    const [lineup] = await db
      .select()
      .from(lineups)
      .where(eq(lineups.eventId, eventId));
    return lineup || undefined;
  }

  async createLineup(lineupData: InsertLineup): Promise<Lineup> {
    const [lineup] = await db
      .insert(lineups)
      .values(lineupData)
      .onConflictDoUpdate({
        target: lineups.eventId,
        set: {
          ...lineupData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return lineup;
  }

  async updateLineup(eventId: string, data: Partial<InsertLineup>): Promise<Lineup | undefined> {
    const [lineup] = await db
      .update(lineups)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(lineups.eventId, eventId))
      .returning();
    return lineup || undefined;
  }

  async deleteLineup(eventId: string): Promise<void> {
    await db.delete(lineups).where(eq(lineups.eventId, eventId));
  }

  // Message Logs
  async createMessageLog(log: InsertMessageLog): Promise<MessageLog> {
    const [messageLog] = await db.insert(messageLogs).values(log).returning();
    return messageLog;
  }

  async getMessageLog(id: string): Promise<MessageLog | undefined> {
    const [log] = await db.select().from(messageLogs).where(eq(messageLogs.id, id));
    return log || undefined;
  }

  async getMessageLogBySid(messageSid: string): Promise<MessageLog | undefined> {
    const [log] = await db.select().from(messageLogs).where(eq(messageLogs.messageSid, messageSid));
    return log || undefined;
  }

  async getTeamMessageLogs(teamId: string, limit: number = 100): Promise<MessageLog[]> {
    return await db
      .select()
      .from(messageLogs)
      .where(eq(messageLogs.teamId, teamId))
      .orderBy(desc(messageLogs.createdAt))
      .limit(limit);
  }

  async updateMessageLog(id: string, data: Partial<InsertMessageLog>): Promise<MessageLog | undefined> {
    const [updated] = await db
      .update(messageLogs)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(messageLogs.id, id))
      .returning();
    return updated || undefined;
  }

  // SMS Opt-Outs
  async createOptOut(optOut: InsertSmsOptOut): Promise<SmsOptOut> {
    // Import phone normalization utility
    const { normalizePhoneForTwilio } = await import("@shared/phoneUtils");
    
    // Normalize phone number to E.164 format for consistent matching
    const normalizedPhone = normalizePhoneForTwilio(optOut.phoneNumber);
    
    // Check if opt-out already exists (idempotent)
    const existing = await this.getOptOut(optOut.teamId, normalizedPhone);
    if (existing) {
      // Update existing opt-out to ensure isOptedOut is true
      const [updated] = await db
        .update(smsOptOuts)
        .set({ isOptedOut: true, optedOutAt: new Date() })
        .where(eq(smsOptOuts.id, existing.id))
        .returning();
      return updated;
    }
    
    // Create new opt-out with normalized phone
    const [created] = await db
      .insert(smsOptOuts)
      .values({
        ...optOut,
        phoneNumber: normalizedPhone,
      })
      .returning();
    return created;
  }

  async getOptOut(teamId: string, phoneNumber: string): Promise<SmsOptOut | undefined> {
    const [optOut] = await db
      .select()
      .from(smsOptOuts)
      .where(and(eq(smsOptOuts.teamId, teamId), eq(smsOptOuts.phoneNumber, phoneNumber)));
    return optOut || undefined;
  }

  async isOptedOut(teamId: string, phoneNumber: string): Promise<boolean> {
    // Import phone normalization utility
    const { normalizePhoneForTwilio } = await import("@shared/phoneUtils");
    
    // Normalize phone number to E.164 format before checking
    const normalizedPhone = normalizePhoneForTwilio(phoneNumber);
    
    const optOut = await this.getOptOut(teamId, normalizedPhone);
    return optOut?.isOptedOut ?? false;
  }

  async optBackIn(teamId: string, phoneNumber: string): Promise<SmsOptOut | undefined> {
    const [updated] = await db
      .update(smsOptOuts)
      .set({
        isOptedOut: false,
        optedBackInAt: new Date(),
      })
      .where(and(eq(smsOptOuts.teamId, teamId), eq(smsOptOuts.phoneNumber, phoneNumber)))
      .returning();
    return updated || undefined;
  }

  // Usage Pricing
  async getUsagePricing(): Promise<UsagePricing | undefined> {
    const [pricing] = await db.select().from(usagePricing).limit(1);
    return pricing || undefined;
  }

  async updateUsagePricing(data: Partial<InsertUsagePricing>): Promise<UsagePricing> {
    const existing = await this.getUsagePricing();
    
    if (existing) {
      const [updated] = await db
        .update(usagePricing)
        .set({ ...data, updatedAt: new Date() })
        .where(eq(usagePricing.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(usagePricing).values(data).returning();
      return created;
    }
  }

  // Usage Tracking
  async createUsageTracking(usage: InsertUsageTracking): Promise<UsageTracking> {
    const [created] = await db.insert(usageTracking).values(usage).returning();
    return created;
  }

  async getTeamUsage(teamId: string, startDate?: Date, endDate?: Date): Promise<UsageTracking[]> {
    let query = db.select().from(usageTracking).where(eq(usageTracking.teamId, teamId));
    
    if (startDate && endDate) {
      query = query.where(
        and(
          eq(usageTracking.teamId, teamId),
          gte(usageTracking.createdAt, startDate),
          lte(usageTracking.createdAt, endDate)
        )
      );
    }
    
    return await query.orderBy(desc(usageTracking.createdAt));
  }

  async getTeamUsageSummary(teamId: string, startDate: Date, endDate: Date): Promise<{
    totalSms: number;
    totalCost: number;
    smsCost: number;
    phoneNumberCost: number;
  }> {
    const usage = await this.getTeamUsage(teamId, startDate, endDate);
    
    const smsUsage = usage.filter(u => u.usageType === 'sms');
    const phoneNumberUsage = usage.filter(u => u.usageType === 'phone_number');
    
    const totalSms = smsUsage.reduce((sum, u) => sum + u.quantity, 0);
    // Parse numeric strings (PostgreSQL numeric columns return as strings)
    const smsCost = smsUsage.reduce((sum, u) => sum + parseFloat(u.totalCost as string), 0);
    const phoneNumberCost = phoneNumberUsage.reduce((sum, u) => sum + parseFloat(u.totalCost as string), 0);
    
    return {
      totalSms,
      totalCost: smsCost + phoneNumberCost,
      smsCost,
      phoneNumberCost,
    };
  }

  // Team Notifications (Coach notifications for RSVP responses, etc.)
  async createTeamNotification(notificationData: InsertTeamNotification): Promise<TeamNotification> {
    const [notification] = await db.insert(teamNotifications).values(notificationData).returning();
    return notification;
  }

  async getTeamNotifications(userId: string, teamId?: string): Promise<TeamNotification[]> {
    let query = db.select().from(teamNotifications).where(eq(teamNotifications.userId, userId));
    
    if (teamId) {
      query = query.where(
        and(
          eq(teamNotifications.userId, userId),
          eq(teamNotifications.teamId, teamId)
        )
      );
    }
    
    return await query.orderBy(desc(teamNotifications.createdAt));
  }

  async getUnreadTeamNotificationsCount(userId: string): Promise<number> {
    const notifications = await db
      .select()
      .from(teamNotifications)
      .where(
        and(
          eq(teamNotifications.userId, userId),
          eq(teamNotifications.isRead, false)
        )
      );
    return notifications.length;
  }

  async markTeamNotificationAsRead(id: string): Promise<TeamNotification | undefined> {
    const [updated] = await db
      .update(teamNotifications)
      .set({ isRead: true, readAt: new Date() })
      .where(eq(teamNotifications.id, id))
      .returning();
    return updated || undefined;
  }

  async markAllTeamNotificationsAsRead(userId: string): Promise<void> {
    await db
      .update(teamNotifications)
      .set({ isRead: true, readAt: new Date() })
      .where(
        and(
          eq(teamNotifications.userId, userId),
          eq(teamNotifications.isRead, false)
        )
      );
  }
}

export const storage = new DatabaseStorage();

import cron from "node-cron";
import { storage } from "./storage";
import { sendSMS, replaceTemplateVariables } from "./twilio";

// Run every minute to check for due reminders
export function startReminderScheduler() {
  console.log("Starting reminder scheduler (runs every minute)...");
  
  cron.schedule("* * * * *", async () => {
    try {
      await processDueReminders();
    } catch (error) {
      console.error("Error in reminder scheduler:", error);
    }
  });
}

// Run every 5 minutes to check for notification updates
export function startNotificationScheduler() {
  console.log("Starting notification update scheduler (runs every 5 minutes)...");
  
  cron.schedule("*/5 * * * *", async () => {
    try {
      await processNotificationUpdates();
    } catch (error) {
      console.error("Error in notification scheduler:", error);
    }
  });
}

async function processDueReminders() {
  const dueReminders = await storage.getDueReminders();
  
  if (dueReminders.length === 0) {
    return;
  }

  console.log(`Found ${dueReminders.length} due reminders to process`);

  for (const reminder of dueReminders) {
    try {
      const { campaign, event } = reminder;
      
      // Get team data for teamName and coachName variables
      const team = await storage.getTeam(campaign.teamId);
      if (!team) {
        console.error(`Team ${campaign.teamId} not found for campaign ${campaign.id}`);
        continue;
      }

      // Get coach name (team owner)
      let coachName = 'Coach';
      if (team.userId) {
        const coachUser = await storage.getUser(team.userId);
        if (coachUser && (coachUser.firstName || coachUser.lastName)) {
          coachName = `${coachUser.firstName || ''} ${coachUser.lastName || ''}`.trim();
        }
      }
      
      // Get all players for this team
      const allPlayers = await storage.getPlayers(campaign.teamId);
      
      // Filter players based on targeting rules
      let targetPlayers = allPlayers;
      
      // Apply reliability score filter if specified (using new range-based system)
      if (reminder.minReliability !== null || reminder.maxReliability !== null) {
        const minScore = reminder.minReliability ?? 0;
        const maxScore = reminder.maxReliability ?? 5;
        targetPlayers = targetPlayers.filter((p) => {
          // Default to 0 for players without a reliability score (new players, etc.)
          const playerScore = p.reliabilityScore ?? 0;
          return playerScore >= minScore && playerScore <= maxScore;
        });
      } 
      // Fallback to old threshold-based filter for backwards compatibility
      else if (reminder.targetReliabilityThreshold !== null) {
        targetPlayers = targetPlayers.filter((p) => {
          const playerScore = p.reliabilityScore ?? 0;
          return playerScore <= reminder.targetReliabilityThreshold!;
        });
      }

      // Apply status filter if specified (only for event-based campaigns)
      if (reminder.targetStatusFilter && event) {
        const responses = await storage.getResponses(event.id);
        const responseMap = new Map(responses.map((r) => [r.playerId, r]));
        
        targetPlayers = targetPlayers.filter((p) => {
          const response = responseMap.get(p.id);
          if (!response) return reminder.targetStatusFilter === "pending";
          return response.status === reminder.targetStatusFilter;
        });
      }

      const eventOrStandalone = event ? `event ${event.id}` : 'standalone campaign';
      console.log(`Sending reminder to ${targetPlayers.length} players for ${eventOrStandalone}`);

      // Send SMS to each target player
      for (const player of targetPlayers) {
        // Check if we've already sent this specific reminder to this player
        const alreadySent = await storage.wasReminderSent(reminder.id, player.id);
        if (alreadySent) {
          console.log(`Reminder ${reminder.id} already sent to player ${player.id}, skipping`);
          continue;
        }

        // Build variables object (always include player and team variables)
        // Handle null/undefined names gracefully with fallbacks
        const variables: any = {
          playerName: `${player.firstName || ''} ${player.lastName || ''}`.trim() || 'Player',
          firstName: player.firstName || 'Player',
          teamName: team.name,
          coachName: coachName,
        };

        // Add event-specific variables if this is an event-based campaign
        if (event) {
          const eventDate = new Date(event.datetime);
          variables.eventType = event.type;
          variables.eventTitle = event.title;
          variables.date = eventDate.toLocaleDateString();
          variables.eventDate = eventDate.toLocaleDateString();
          variables.time = eventDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          variables.eventTime = eventDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          variables.location = event.location;
          variables.opponent = event.opponent || undefined;
          variables.homeAway = event.homeAway || undefined;
          variables.fieldType = event.fieldType || undefined;
          variables.cleats = event.cleatsAllowed || undefined;
          variables.jersey = event.jersey || undefined;
          variables.arrivalTime = event.arrivalTime || undefined;
        }

        // Personalize message
        const personalizedMessage = replaceTemplateVariables(reminder.messageTemplate, variables);

        // Send SMS with team context for proper phone number and logging
        await sendSMS(player.phone, personalizedMessage, {
          teamId: campaign.teamId,
          eventId: event?.id,
          playerId: player.id,
          campaignId: reminder.campaignId,
        });
        
        // Record that we sent this reminder
        await storage.createReminderSend({
          reminderId: reminder.id,
          playerId: player.id,
        });
        
        console.log(`Sent reminder to ${player.firstName} ${player.lastName} (${player.phone})`);
      }
    } catch (error) {
      console.error(`Error processing reminder ${reminder.id}:`, error);
    }
  }
}

async function processNotificationUpdates() {
  const enabledSettings = await storage.getAllEnabledNotificationSettings();
  
  if (enabledSettings.length === 0) {
    return;
  }

  console.log(`Checking ${enabledSettings.length} notification settings for updates`);

  for (const settings of enabledSettings) {
    try {
      // For before_event cadence, check each event separately
      if (settings.cadence === "before_event") {
        await processBeforeEventNotifications(settings);
        continue;
      }

      // Check if it's time to send based on cadence and last sent time
      if (!shouldSendNotification(settings)) {
        continue;
      }

      const team = await storage.getTeam(settings.teamId);
      if (!team) continue;

      // Get all players with the specified roles
      const allPlayers = await storage.getPlayers(settings.teamId);
      const targetPlayers = allPlayers.filter(p => 
        p.roleId && settings.roleIds.includes(p.roleId)
      );

      if (targetPlayers.length === 0) {
        console.log(`No players found with roles ${settings.roleIds.join(', ')} for team ${team.name}`);
        continue;
      }

      // Compose the update message
      const message = await composeUpdateMessage(settings, team);

      console.log(`Sending update to ${targetPlayers.length} players for team ${team.name}`);

      // Send to each player
      for (const player of targetPlayers) {
        try {
          await sendSMS(player.phone, message, {
            teamId: settings.teamId,
            playerId: player.id,
          });
          console.log(`Sent update to ${player.firstName} ${player.lastName} (${player.phone})`);
        } catch (error) {
          console.error(`Failed to send update to ${player.firstName} ${player.lastName}:`, error);
        }
      }

      // Update last sent timestamp
      await storage.updateNotificationSettings(settings.teamId, {
        lastSentAt: new Date(),
      });

      console.log(`Completed notification update for team ${team.name}`);
    } catch (error) {
      console.error(`Error processing notification for team ${settings.teamId}:`, error);
    }
  }
}

async function processBeforeEventNotifications(settings: any) {
  const team = await storage.getTeam(settings.teamId);
  if (!team) return;

  // Get all upcoming events
  const events = await storage.getEvents(settings.teamId);
  const now = new Date();
  const futureEvents = events.filter(e => new Date(e.datetime) >= now);

  if (futureEvents.length === 0) {
    return;
  }

  const eventTimingHours = settings.eventTimingHours || 24;
  const targetTimeMs = eventTimingHours * 60 * 60 * 1000;
  const toleranceMs = 15 * 60 * 1000; // 15-minute tolerance for 5-minute cron

  // Find events that are approximately eventTimingHours away
  const eventsToNotify = futureEvents.filter(event => {
    const eventTime = new Date(event.datetime).getTime();
    const timeUntilEvent = eventTime - now.getTime();
    
    // Check if event is within our target window
    return Math.abs(timeUntilEvent - targetTimeMs) <= toleranceMs;
  });

  if (eventsToNotify.length === 0) {
    return;
  }

  console.log(`Found ${eventsToNotify.length} events to notify about for team ${team.name}`);

  // Get all players with the specified roles
  const allPlayers = await storage.getPlayers(settings.teamId);
  const targetPlayers = allPlayers.filter(p => 
    p.roleId && settings.roleIds.includes(p.roleId)
  );

  if (targetPlayers.length === 0) {
    console.log(`No players found with roles ${settings.roleIds.join(', ')} for team ${team.name}`);
    return;
  }

  // Send notification for each event
  for (const event of eventsToNotify) {
    // Check if we already sent a notification for this event
    const alreadySent = await storage.wasNotificationSent(settings.id, event.id);
    if (alreadySent) {
      console.log(`Already sent notification for event ${event.title}, skipping`);
      continue;
    }

    const message = await composeUpdateMessage(settings, team);
    
    console.log(`Sending before-event update for ${event.title} to ${targetPlayers.length} players`);

    // Send to each player
    for (const player of targetPlayers) {
      try {
        await sendSMS(player.phone, message, {
          teamId: settings.teamId,
          eventId: event.id,
          playerId: player.id,
        });
        console.log(`Sent before-event update to ${player.firstName} ${player.lastName} (${player.phone})`);
      } catch (error) {
        console.error(`Failed to send update to ${player.firstName} ${player.lastName}:`, error);
      }
    }

    // Record that we sent this notification for this event
    await storage.createNotificationSend({
      notificationSettingsId: settings.id,
      eventId: event.id,
    });
  }

  // Update last sent timestamp
  await storage.updateNotificationSettings(settings.teamId, {
    lastSentAt: new Date(),
  });
}

function shouldSendNotification(settings: any): boolean {
  const now = new Date();
  const lastSent = settings.lastSentAt ? new Date(settings.lastSentAt) : null;

  // If never sent, send now
  if (!lastSent) return true;

  // Check based on cadence
  switch (settings.cadence) {
    case "daily": {
      // Send if last sent was more than 23 hours ago and current time matches timeOfDay
      const hoursSinceLastSent = (now.getTime() - lastSent.getTime()) / (1000 * 60 * 60);
      if (hoursSinceLastSent < 23) return false;
      
      const [targetHour, targetMinute] = (settings.timeOfDay || "09:00").split(':').map(Number);
      const currentHour = now.getHours();
      const currentMinute = now.getMinutes();
      
      // Check if we're within a 5-minute window of the target time
      // This accounts for the cron running every 5 minutes
      const targetTimeMinutes = targetHour * 60 + targetMinute;
      const currentTimeMinutes = currentHour * 60 + currentMinute;
      const timeDiff = Math.abs(currentTimeMinutes - targetTimeMinutes);
      
      return timeDiff <= 5;
    }

    case "weekly": {
      // Send if last sent was more than 6 days ago and it's the right day of week
      const daysSinceLastSent = (now.getTime() - lastSent.getTime()) / (1000 * 60 * 60 * 24);
      if (daysSinceLastSent < 6) return false;
      
      const targetDayOfWeek = settings.dayOfWeek || 1; // Default to Monday
      if (now.getDay() !== targetDayOfWeek) return false;
      
      // Also check time of day for weekly
      const [weeklyTargetHour, weeklyTargetMinute] = (settings.timeOfDay || "09:00").split(':').map(Number);
      const weeklyCurrentHour = now.getHours();
      const weeklyCurrentMinute = now.getMinutes();
      
      const weeklyTargetTimeMinutes = weeklyTargetHour * 60 + weeklyTargetMinute;
      const weeklyCurrentTimeMinutes = weeklyCurrentHour * 60 + weeklyCurrentMinute;
      const weeklyTimeDiff = Math.abs(weeklyCurrentTimeMinutes - weeklyTargetTimeMinutes);
      
      return weeklyTimeDiff <= 5;
    }

    case "before_event":
      // Handled separately in processBeforeEventNotifications
      return false;

    default:
      return false;
  }
}

async function composeUpdateMessage(settings: any, team: any): Promise<string> {
  let message = `Team Update - ${team.name}\n\n`;

  // Get upcoming events (next 7 days)
  if (settings.includeUpcomingEvents) {
    const events = await storage.getEvents(settings.teamId);
    const now = new Date();
    const next7Days = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    
    const upcomingEvents = events.filter(e => {
      const eventDate = new Date(e.datetime);
      return eventDate >= now && eventDate <= next7Days;
    });

    if (upcomingEvents.length > 0) {
      message += `📅 Upcoming Events (${upcomingEvents.length}):\n`;
      upcomingEvents.slice(0, 3).forEach(e => {
        const eventDate = new Date(e.datetime);
        message += `• ${e.title || e.type} - ${eventDate.toLocaleDateString()} at ${eventDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}\n`;
      });
      if (upcomingEvents.length > 3) {
        message += `  ...and ${upcomingEvents.length - 3} more\n`;
      }
      message += '\n';
    }
  }

  // Get recent responses (last 24 hours)
  if (settings.includeRecentResponses) {
    const events = await storage.getEvents(settings.teamId);
    const last24Hours = new Date(Date.now() - 24 * 60 * 60 * 1000);
    
    let recentResponseCount = 0;
    for (const event of events) {
      const responses = await storage.getResponses(event.id);
      const recentResponses = responses.filter(r => {
        const responseDate = new Date(r.createdAt);
        return responseDate >= last24Hours;
      });
      recentResponseCount += recentResponses.length;
    }

    if (recentResponseCount > 0) {
      message += `💬 Recent Responses: ${recentResponseCount} in last 24h\n\n`;
    }
  }

  // Get attendance stats for next event
  if (settings.includeAttendanceStats) {
    const events = await storage.getEvents(settings.teamId);
    const now = new Date();
    const futureEvents = events.filter(e => new Date(e.datetime) >= now);
    futureEvents.sort((a, b) => new Date(a.datetime).getTime() - new Date(b.datetime).getTime());

    if (futureEvents.length > 0) {
      const nextEvent = futureEvents[0];
      const responses = await storage.getResponses(nextEvent.id);
      const players = await storage.getPlayers(settings.teamId);
      
      const yesCount = responses.filter(r => r.status === 'yes').length;
      const noCount = responses.filter(r => r.status === 'no').length;
      const maybeCount = responses.filter(r => r.status === 'maybe').length;
      const pendingCount = players.length - responses.length;

      message += `📊 Next Event Status:\n`;
      message += `✅ Confirmed: ${yesCount}\n`;
      message += `❌ Declined: ${noCount}\n`;
      message += `❓ Maybe: ${maybeCount}\n`;
      if (pendingCount > 0) {
        message += `⏳ Pending: ${pendingCount}\n`;
      }
      message += '\n';
    }
  }

  // Get pending responses count
  if (settings.includePendingResponses) {
    const events = await storage.getEvents(settings.teamId);
    const now = new Date();
    const futureEvents = events.filter(e => new Date(e.datetime) >= now);
    
    let totalPending = 0;
    for (const event of futureEvents) {
      const responses = await storage.getResponses(event.id);
      const players = await storage.getPlayers(settings.teamId);
      totalPending += players.length - responses.length;
    }

    if (totalPending > 0) {
      message += `⚠️ ${totalPending} players haven't responded to upcoming events\n\n`;
    }
  }

  message += `---\nTeamSyncAI`;

  return message;
}

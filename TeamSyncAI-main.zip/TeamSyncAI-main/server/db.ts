// Database configuration with dual-mode support:
// - Development (Replit): Uses @neondatabase/serverless with WebSocket
// - Production (Render): Uses node-postgres for standard PostgreSQL connection

import * as schema from "@shared/schema";
import { Pool as NeonPool, neonConfig } from '@neondatabase/serverless';
import { drizzle as neonDrizzle } from 'drizzle-orm/neon-serverless';
import { Pool as PgPool } from 'pg';
import { drizzle as pgDrizzle } from 'drizzle-orm/node-postgres';
import ws from 'ws';

const isProduction = process.env.NODE_ENV === 'production';

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

let pool: any;
let db: any;

// Production: Use standard node-postgres driver for traditional servers (Render, etc.)
if (isProduction) {
  console.log('[DB] Initializing with node-postgres (production mode)');
  
  pool = new PgPool({ 
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.DATABASE_URL.includes('sslmode=require') ? { rejectUnauthorized: false } : false
  });
  
  db = pgDrizzle({ client: pool, schema });
  
} else {
  // Development: Use Neon serverless driver with WebSocket (for Replit)
  console.log('[DB] Initializing with @neondatabase/serverless (development mode)');
  
  neonConfig.webSocketConstructor = ws;
  
  pool = new NeonPool({ connectionString: process.env.DATABASE_URL });
  db = neonDrizzle({ client: pool, schema });
}

/**
 * Close database connection pool
 * Should be called during application shutdown or test teardown
 */
export async function closeDatabase() {
  if (pool && typeof pool.end === 'function') {
    await pool.end();
    console.log('[DB] Connection pool closed');
  }
}

export { pool, db };

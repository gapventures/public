import { GoogleGenAI } from "@google/genai";
import { storage } from "./storage";
import type { Player, Event, Response, Attendance } from "@shared/schema";
import type { LineupData } from "@shared/schema";
import { lineupDataSchema } from "@shared/schema";

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.error("GEMINI_API_KEY environment variable not set");
}

const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export interface LineupGenerationInput {
  event: Event;
  players: Player[];
  attendance: Array<Response | Attendance>;
  lineupSize?: number;
}

export async function generateOptimalLineup(input: LineupGenerationInput): Promise<LineupData> {
  if (!ai) {
    throw new Error("Gemini AI is not configured. Please set GEMINI_API_KEY environment variable.");
  }

  const { event, players, attendance, lineupSize = 9 } = input;

  const attendingPlayerIds = attendance
    .filter(a => ('status' in a && a.status === 'yes') || ('attended' in a && a.attended))
    .map(a => a.playerId);

  const attendingPlayers = players.filter(p => attendingPlayerIds.includes(p.id));

  if (attendingPlayers.length === 0) {
    return {
      battingOrder: [],
      pitchingRotation: [],
      reserves: [],
    };
  }

  const playersWithPreferences = attendingPlayers.map(p => ({
    id: p.id,
    name: `${p.firstName} ${p.lastName}`,
    position: p.position || 'Unknown',
    jerseyNumber: p.jerseyNumber,
    preferredBattingOrder: p.preferredBattingOrder,
    preferredPitchingOrder: p.preferredPitchingOrder,
    reliabilityScore: p.reliabilityScore,
  }));

  const prompt = `You are an expert baseball/softball coach helping generate an optimal lineup.

Event Details:
- Sport: ${event.sport}
- Type: ${event.type}
- Opponent: ${event.opponent || 'N/A'}
- Required Lineup Size: ${lineupSize} players

Available Players (${playersWithPreferences.length}):
${playersWithPreferences.map((p, idx) => 
  `${idx + 1}. ${p.name} (#${p.jerseyNumber || '??'}) - Position: ${p.position}
     - Preferred Batting Order: ${p.preferredBattingOrder || 'Not set'}
     - Preferred Pitching Order: ${p.preferredPitchingOrder || 'Not set'}
     - Reliability Score: ${p.reliabilityScore}/5`
).join('\n')}

Instructions:
1. Create a batting order (1-${lineupSize} positions) prioritizing:
   - Players' preferred batting order when available
   - Reliability scores (higher is better)
   - Traditional baseball lineup strategy (best hitters in key spots)
   
2. Assign defensive positions to the ${lineupSize} starters. Use standard positions: P, C, 1B, 2B, 3B, SS, LF, CF, RF
   - For lineups larger than 9, assign positions creatively or use "DH" (designated hitter) for additional players

3. Create a pitching rotation (SP for starter, then RPs for relievers) from players with pitching preferences:
   - ONLY include players with preferredPitchingOrder of 1 or higher (0 means does not pitch)
   - 1 = Starting pitcher (SP), 2-4 = Relief pitchers (RP)

4. Place remaining players in reserves

Return ONLY valid JSON in this exact format (no markdown, no explanation):
{
  "battingOrder": [
    {"playerId": "player-id", "position": "CF", "battingSlot": 1, "playerName": "Player Name"},
    ...${lineupSize} slots total
  ],
  "pitchingRotation": [
    {"playerId": "player-id", "pitchingSlot": 1, "playerName": "Player Name"},
    ...at least 1, up to 4-5 pitchers
  ],
  "reserves": [
    {"playerId": "player-id", "playerName": "Player Name"},
    ...remaining players
  ]
}`;

  try {
    const result = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    const responseText = result.response.text() || "";
    
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("Invalid response format from AI");
    }

    const parsedData = JSON.parse(jsonMatch[0]);
    
    const validatedLineup = lineupDataSchema.parse(parsedData);
    
    return validatedLineup;
  } catch (error) {
    console.error("Error generating lineup with Gemini:", error);
    
    return generateFallbackLineup(playersWithPreferences, lineupSize);
  }
}

function generateFallbackLineup(
  players: Array<{
    id: string;
    name: string;
    position: string;
    preferredBattingOrder?: number | null;
    preferredPitchingOrder?: number | null;
  }>,
  lineupSize: number = 9
): LineupData {
  const sortedByBatting = [...players].sort((a, b) => {
    if (a.preferredBattingOrder && b.preferredBattingOrder) {
      return a.preferredBattingOrder - b.preferredBattingOrder;
    }
    if (a.preferredBattingOrder) return -1;
    if (b.preferredBattingOrder) return 1;
    return 0;
  });

  const battingOrder = sortedByBatting.slice(0, lineupSize).map((p, idx) => ({
    playerId: p.id,
    position: p.position || 'LF',
    battingSlot: idx + 1,
    playerName: p.name,
  }));

  const pitchers = players.filter(p => p.preferredPitchingOrder && p.preferredPitchingOrder > 0).sort((a, b) => 
    (a.preferredPitchingOrder || 99) - (b.preferredPitchingOrder || 99)
  );

  const pitchingRotation = pitchers.slice(0, 4).map((p, idx) => ({
    playerId: p.id,
    pitchingSlot: idx + 1,
    playerName: p.name,
  }));

  const starterIds = new Set(battingOrder.map(b => b.playerId));
  const pitcherIds = new Set(pitchingRotation.map(p => p.playerId));
  
  const reserves = players
    .filter(p => !starterIds.has(p.id) || pitcherIds.has(p.id))
    .map(p => ({
      playerId: p.id,
      playerName: p.name,
    }));

  return {
    battingOrder,
    pitchingRotation,
    reserves,
  };
}

// Referenced from javascript_gemini blueprint integration
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface PlayerResponseParsed {
  status: "yes" | "no" | "maybe";
  note: string;
}

export async function parsePlayerResponse(text: string): Promise<PlayerResponseParsed> {
  try {
    // Check for simple numeric responses first
    const trimmed = text.trim();
    if (trimmed === "1") {
      return { status: "yes", note: "Confirmed" };
    } else if (trimmed === "2") {
      return { status: "no", note: "Declined" };
    } else if (trimmed === "3") {
      return { status: "maybe", note: "Maybe" };
    }

    // Use AI for natural language parsing
    const systemPrompt = `You are an AI assistant helping to parse player responses to sports event invitations.
Analyze the text and determine:
1. The player's availability status: "yes" (they can attend), "no" (they cannot attend), or "maybe" (uncertain)
2. Extract a brief note explaining their response (if provided)

Respond with JSON in this format:
{"status": "yes"|"no"|"maybe", "note": "brief explanation"}

Examples:
"Yeah I'll be there" -> {"status": "yes", "note": "Confirmed"}
"Can't make it, stuck at work" -> {"status": "no", "note": "Stuck at work"}
"I might be 15 mins late" -> {"status": "maybe", "note": "Might be 15 mins late"}
"Sorry coach, have a family thing" -> {"status": "no", "note": "Family commitment"}`;

    const result = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            status: { 
              type: "string",
              enum: ["yes", "no", "maybe"]
            },
            note: { type: "string" },
          },
          required: ["status", "note"],
        },
      },
      contents: [
        {
          role: "user",
          parts: [{ text }],
        },
      ],
    });

    const rawJson = result.response.text() || "";
    console.log(`Gemini AI parsed response: ${rawJson}`);

    if (!rawJson || rawJson.trim() === "") {
      throw new Error("Empty response from Gemini AI");
    }

    // Defensive JSON parsing with validation
    const data = JSON.parse(rawJson);
    
    // Validate the response structure
    if (!data.status || !["yes", "no", "maybe"].includes(data.status)) {
      throw new Error(`Invalid status in AI response: ${data.status}`);
    }
    
    if (typeof data.note !== "string") {
      throw new Error(`Invalid note in AI response: ${data.note}`);
    }

    return {
      status: data.status as "yes" | "no" | "maybe",
      note: data.note,
    };
  } catch (error) {
    console.error(`Failed to parse player response with AI: ${error}`);
    // Fallback to "maybe" if AI fails
    return {
      status: "maybe",
      note: text.substring(0, 100), // Include original text as note
    };
  }
}

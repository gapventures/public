import { Router } from 'express';
import { db } from '../db';
import { users } from '@shared/schema';
import { eq } from 'drizzle-orm';
import { PaymentProviderFactory } from '../services/payments/PaymentProviderFactory';

const router = Router();

// Cancel user's subscription
router.post('/cancel', async (req: any, res) => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    // Get user's current subscription
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (!user.helcimSubscriptionId) {
      return res.status(400).json({ error: 'No active subscription found' });
    }

    // Get Helcim provider
    const provider = await PaymentProviderFactory.getProvider('helcim');

    // Cancel subscription with Helcim
    await provider.cancelSubscription({
      subscriptionId: user.helcimSubscriptionId,
      userId,
    });

    // Update user record with soft delete
    await db.update(users)
      .set({
        subscriptionStatus: 'canceled',
        subscriptionCancelledAt: new Date(),
      })
      .where(eq(users.id, userId));

    res.json({ success: true, message: 'Subscription canceled successfully' });
  } catch (error) {
    console.error('Subscription cancellation error:', error);
    res.status(500).json({ error: 'Failed to cancel subscription' });
  }
});

export default router;

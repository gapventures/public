import { Router } from 'express';
import { z } from 'zod';
import { PaymentService } from '../../services/PaymentService';
import { isAuthenticated } from '../../routes';
import { db } from '../../db';
import { membershipTiers } from '../../../shared/schema';
import { eq } from 'drizzle-orm';

const router = Router();

// Zod DTOs for validation
const CreateSubscriptionDto = z.object({
  tierId: z.string().uuid(),
  billingInterval: z.enum(['monthly', 'yearly']),
  providerName: z.string().optional(),
});

/**
 * POST /api/subscriptions
 * Create a new subscription
 * 
 * Returns 202 with checkout URL for hosted payment flow
 */
router.post('/', isAuthenticated, async (req: any, res) => {
  try {
    const validation = CreateSubscriptionDto.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Invalid request data',
          details: validation.error.errors,
        },
      });
    }

    const { tierId, billingInterval, providerName } = validation.data;
    const userId = req.user.id;

    // Get tier details to calculate amount
    const [tier] = await db
      .select()
      .from(membershipTiers)
      .where(eq(membershipTiers.id, tierId))
      .limit(1);

    if (!tier) {
      return res.status(404).json({
        error: {
          code: 'TIER_NOT_FOUND',
          message: 'Membership tier not found',
        },
      });
    }

    // Calculate amount in cents
    const amount = billingInterval === 'yearly' && tier.annualPrice
      ? tier.annualPrice * 100
      : tier.monthlyPrice * 100;

    // Create subscription
    const result = await PaymentService.createSubscription({
      userId,
      tierId,
      amount,
      billingInterval,
      providerName,
    });

    // Return 202 Accepted with checkout URL
    res.status(202).json({
      transactionId: result.transactionId,
      checkoutUrl: result.checkoutUrl,
      status: result.status,
    });
  } catch (error) {
    console.error('Error creating subscription:', error);
    
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    
    // Check for provider-specific errors
    if (errorMessage.includes('not configured') || errorMessage.includes('not enabled')) {
      return res.status(402).json({
        error: {
          code: 'PAYMENT_REQUIRED',
          message: errorMessage,
        },
      });
    }

    res.status(500).json({
      error: {
        code: 'SUBSCRIPTION_CREATE_FAILED',
        message: 'Failed to create subscription',
        providerMessage: errorMessage,
      },
    });
  }
});

/**
 * GET /api/subscriptions/current
 * Get current user's active subscription
 */
router.get('/current', isAuthenticated, async (req: any, res) => {
  try {
    const userId = req.user.id;
    const history = await PaymentService.getSubscriptionHistory(userId);
    
    // Find most recent active subscription
    const activeSubscription = history.find((t: any) => t.status === 'completed' || t.status === 'pending');
    
    res.json(activeSubscription || null);
  } catch (error) {
    console.error('Error fetching current subscription:', error);
    res.status(500).json({
      error: {
        code: 'SUBSCRIPTION_FETCH_FAILED',
        message: 'Failed to fetch subscription',
      },
    });
  }
});

/**
 * GET /api/subscriptions/history
 * Get all subscription payment history for current user
 */
router.get('/history', isAuthenticated, async (req: any, res) => {
  try {
    const userId = req.user.id;
    const history = await PaymentService.getSubscriptionHistory(userId);
    
    res.json(history);
  } catch (error) {
    console.error('Error fetching subscription history:', error);
    res.status(500).json({
      error: {
        code: 'HISTORY_FETCH_FAILED',
        message: 'Failed to fetch subscription history',
      },
    });
  }
});

/**
 * DELETE /api/subscriptions/:id
 * Cancel a subscription
 */
router.delete('/:id', isAuthenticated, async (req: any, res) => {
  try {
    const userId = req.user.id;
    const subscriptionId = req.params.id;

    await PaymentService.cancelSubscription({
      userId,
      subscriptionId,
    });

    res.json({ message: 'Subscription cancelled successfully' });
  } catch (error) {
    console.error('Error cancelling subscription:', error);
    
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    
    if (errorMessage.includes('not found') || errorMessage.includes('unauthorized')) {
      return res.status(404).json({
        error: {
          code: 'SUBSCRIPTION_NOT_FOUND',
          message: errorMessage,
        },
      });
    }

    res.status(500).json({
      error: {
        code: 'SUBSCRIPTION_CANCEL_FAILED',
        message: 'Failed to cancel subscription',
        providerMessage: errorMessage,
      },
    });
  }
});

export default router;

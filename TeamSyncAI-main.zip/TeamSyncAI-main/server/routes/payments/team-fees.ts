import { Router } from 'express';
import { z } from 'zod';
import { PaymentService } from '../../services/PaymentService';
import { isAuthenticated } from '../../routes';
import { requirePermission } from '../../permissions';
import { db } from '../../db';
import { teamPaymentRequests, teamPayments, players, teams } from '../../../shared/schema';
import { eq, and, desc } from 'drizzle-orm';
import { ensureTeamAccess, ensurePlayerPaymentAccess } from '../../auth/payment-authorization';

const router = Router();

// Zod DTOs for validation
const CreatePaymentRequestDto = z.object({
  title: z.string().min(1).max(200),
  description: z.string().optional(),
  amount: z.number().positive(), // Amount in dollars (will be converted to cents)
  dueDate: z.string().datetime().optional(),
  isRecurring: z.boolean().optional().default(false),
  recurringInterval: z.enum(['monthly', 'yearly']).optional(),
});

const InitiatePaymentDto = z.object({
  playerId: z.string().uuid(),
  providerName: z.string().optional(),
});

/**
 * POST /api/teams/:teamId/payment-requests
 * Create a new payment request (coach only)
 */
router.post('/:teamId/payment-requests', 
  isAuthenticated, 
  requirePermission('canManagePlayers'),
  async (req: any, res) => {
    try {
      const validation = CreatePaymentRequestDto.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid request data',
            details: validation.error.errors,
          },
        });
      }

      const { teamId } = req.params;
      const userId = req.user.id;
      const { title, description, amount, dueDate, isRecurring, recurringInterval } = validation.data;

      // Verify team exists
      const [team] = await db
        .select()
        .from(teams)
        .where(eq(teams.id, teamId))
        .limit(1);

      if (!team) {
        return res.status(404).json({
          error: {
            code: 'TEAM_NOT_FOUND',
            message: 'Team not found',
          },
        });
      }

      // Create payment request
      const [paymentRequest] = await db
        .insert(teamPaymentRequests)
        .values({
          teamId,
          createdByUserId: userId,
          title,
          description: description || null,
          amount: Math.round(amount * 100), // Convert dollars to cents
          currency: 'USD',
          dueDate: dueDate ? new Date(dueDate) : null,
          isRecurring: isRecurring || false,
          recurringInterval: isRecurring ? recurringInterval : null,
          status: 'active',
        })
        .returning();

      res.status(201).json(paymentRequest);
    } catch (error) {
      console.error('Error creating payment request:', error);
      res.status(500).json({
        error: {
          code: 'PAYMENT_REQUEST_CREATE_FAILED',
          message: 'Failed to create payment request',
        },
      });
    }
  }
);

/**
 * GET /api/teams/:teamId/payment-requests
 * List all payment requests for a team
 * 
 * Authorization: User must be a team member (owner, player, or have role)
 */
router.get('/:teamId/payment-requests',
  isAuthenticated,
  async (req: any, res) => {
    try {
      const { teamId } = req.params;
      const userId = req.user.id;
      const userEmail = req.user.email;
      const isGlobalAdmin = req.user.isGlobalAdmin || false;

      // Verify team access with canViewPlayers permission
      try {
        await ensureTeamAccess(userId, userEmail, teamId, isGlobalAdmin, 'canViewPlayers');
      } catch (authError: any) {
        return res.status(authError.status || 403).json({
          error: {
            code: authError.code || 'FORBIDDEN',
            message: authError.message || 'Not authorized',
          },
        });
      }

      const requests = await db
        .select()
        .from(teamPaymentRequests)
        .where(
          and(
            eq(teamPaymentRequests.teamId, teamId),
            eq(teamPaymentRequests.status, 'active')
          )
        )
        .orderBy(desc(teamPaymentRequests.createdAt));

      res.json(requests);
    } catch (error) {
      console.error('Error fetching payment requests:', error);
      res.status(500).json({
        error: {
          code: 'PAYMENT_REQUESTS_FETCH_FAILED',
          message: 'Failed to fetch payment requests',
        },
      });
    }
  }
);

/**
 * POST /api/payment-requests/:id/pay
 * Initiate payment for a payment request (player/guardian/coach)
 * 
 * Authorization: User must be the player owner, email match, or have canManagePlayers
 * Returns 202 with checkout URL
 */
router.post('/:id/pay',
  isAuthenticated,
  async (req: any, res) => {
    try {
      const validation = InitiatePaymentDto.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid request data',
            details: validation.error.errors,
          },
        });
      }

      const { id: paymentRequestId } = req.params;
      const { playerId, providerName } = validation.data;
      const userId = req.user.id;
      const userEmail = req.user.email;
      const isGlobalAdmin = req.user.isGlobalAdmin || false;

      // Get payment request
      const [paymentRequest] = await db
        .select()
        .from(teamPaymentRequests)
        .where(eq(teamPaymentRequests.id, paymentRequestId))
        .limit(1);

      if (!paymentRequest) {
        return res.status(404).json({
          error: {
            code: 'PAYMENT_REQUEST_NOT_FOUND',
            message: 'Payment request not found',
          },
        });
      }

      // Check if user has canManagePlayers permission for this team
      // Import getUserPermissions from permissions.ts
      const { getUserPermissions } = await import('../../permissions');
      const userPermissions = await getUserPermissions(userId, paymentRequest.teamId);
      const hasCoachPermission = userPermissions?.canManagePlayers || false;

      // Verify player authorization
      let player;
      try {
        player = await ensurePlayerPaymentAccess(
          userId,
          userEmail,
          playerId,
          paymentRequest.teamId,
          isGlobalAdmin,
          hasCoachPermission
        );
      } catch (authError: any) {
        return res.status(authError.status || 403).json({
          error: {
            code: authError.code || 'FORBIDDEN',
            message: authError.message || 'Not authorized',
          },
        });
      }

      // Check if already paid
      const [existingPayment] = await db
        .select()
        .from(teamPayments)
        .where(
          and(
            eq(teamPayments.paymentRequestId, paymentRequestId),
            eq(teamPayments.playerId, playerId),
            eq(teamPayments.status, 'completed')
          )
        )
        .limit(1);

      if (existingPayment) {
        return res.status(409).json({
          error: {
            code: 'ALREADY_PAID',
            message: 'This payment has already been completed',
          },
        });
      }

      // Process payment
      const result = await PaymentService.processPayment({
        userId,
        amount: paymentRequest.amount,
        description: paymentRequest.title,
        teamId: paymentRequest.teamId,
        paymentRequestId,
        playerId,
        providerName,
      });

      // Return 202 Accepted with checkout URL
      res.status(202).json({
        transactionId: result.transactionId,
        checkoutUrl: result.checkoutUrl,
        status: result.status,
      });
    } catch (error) {
      console.error('Error initiating payment:', error);
      
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      
      if (errorMessage.includes('not configured') || errorMessage.includes('not enabled')) {
        return res.status(402).json({
          error: {
            code: 'PAYMENT_REQUIRED',
            message: errorMessage,
          },
        });
      }

      if (errorMessage.includes('Payment already exists')) {
        return res.status(409).json({
          error: {
            code: 'DUPLICATE_PAYMENT',
            message: errorMessage,
          },
        });
      }

      res.status(500).json({
        error: {
          code: 'PAYMENT_INITIATE_FAILED',
          message: 'Failed to initiate payment',
          providerMessage: errorMessage,
        },
      });
    }
  }
);

/**
 * GET /api/payment-requests/:id/transactions
 * Get payment status for a payment request (for a specific player)
 */
router.get('/:id/transactions',
  isAuthenticated,
  async (req: any, res) => {
    try {
      const { id: paymentRequestId } = req.params;
      const { playerId } = req.query;

      if (!playerId) {
        return res.status(400).json({
          error: {
            code: 'VALIDATION_ERROR',
            message: 'playerId query parameter required',
          },
        });
      }

      const payments = await db
        .select({
          id: teamPayments.id,
          status: teamPayments.status,
          paidAt: teamPayments.paidAt,
          createdAt: teamPayments.createdAt,
          amount: teamPaymentRequests.amount,
          title: teamPaymentRequests.title,
        })
        .from(teamPayments)
        .innerJoin(teamPaymentRequests, eq(teamPayments.paymentRequestId, teamPaymentRequests.id))
        .where(
          and(
            eq(teamPayments.paymentRequestId, paymentRequestId),
            eq(teamPayments.playerId, playerId as string)
          )
        )
        .orderBy(desc(teamPayments.createdAt));

      res.json(payments);
    } catch (error) {
      console.error('Error fetching payment transactions:', error);
      res.status(500).json({
        error: {
          code: 'TRANSACTIONS_FETCH_FAILED',
          message: 'Failed to fetch payment transactions',
        },
      });
    }
  }
);

export default router;

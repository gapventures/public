/**
 * Guest Payment Routes
 * 
 * Handles tokenized payment links for parents/guardians to pay
 * without requiring login. Requires email verification against player email.
 */

import { Router } from 'express';
import { z } from 'zod';
import { PaymentTokenService } from '../../services/PaymentTokenService';
import { PaymentService } from '../../services/PaymentService';
import { isAuthenticated } from '../../routes';
import { requirePermission } from '../../permissions';
import { db } from '../../db';
import { players, teamPaymentRequests, teamPayments } from '../../../shared/schema';
import { eq, and } from 'drizzle-orm';
import twilio from 'twilio';

const router = Router();

// Validation schemas
const SendPaymentLinkDto = z.object({
  playerIds: z.array(z.string().uuid()).min(1).max(50), // Batch send to multiple players
  channel: z.enum(['sms', 'email']),
  customMessage: z.string().max(500).optional(),
});

const GuestPaymentDto = z.object({
  email: z.string().email(),
  providerName: z.string().optional(), // 'helcim', 'paypal', 'venmo'
});

/**
 * POST /api/payment-requests/:id/send-links
 * Generate tokenized payment links and send to players via SMS/email
 * 
 * Authorization: Requires canManagePlayers permission (coaches only)
 */
router.post('/:id/send-links',
  isAuthenticated,
  requirePermission('canManagePlayers'),
  async (req: any, res) => {
    try {
      const validation = SendPaymentLinkDto.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid request data',
            details: validation.error.errors,
          },
        });
      }

      const { id: paymentRequestId } = req.params;
      const { playerIds, channel, customMessage } = validation.data;
      const userId = req.user.id;

      // Verify payment request exists
      const [paymentRequest] = await db
        .select()
        .from(teamPaymentRequests)
        .where(eq(teamPaymentRequests.id, paymentRequestId))
        .limit(1);

      if (!paymentRequest) {
        return res.status(404).json({
          error: {
            code: 'PAYMENT_REQUEST_NOT_FOUND',
            message: 'Payment request not found',
          },
        });
      }

      // Fetch all players
      const allPlayers = await db
        .select()
        .from(players)
        .where(eq(players.teamId, paymentRequest.teamId));

      const playerMap = new Map(allPlayers.map((p: any) => [p.id, p]));
      const results: Array<{ playerId: string; success: boolean; error?: string }> = [];

      // Generate tokens and send for each player
      for (const playerId of playerIds) {
        const player = playerMap.get(playerId);
        
        if (!player) {
          results.push({
            playerId,
            success: false,
            error: 'Player not found',
          });
          continue;
        }

        // Generate token
        const rawToken = await PaymentTokenService.generateToken({
          paymentRequestId,
          playerId,
          channel,
          createdByUserId: userId,
          expiresInHours: 48,
        });

        // Build payment link URL
        const baseUrl = process.env.REPLIT_DOMAINS 
          ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}`
          : `http://localhost:5000`;
        const paymentLink = `${baseUrl}/api/payment-links/${rawToken}`;

        // Send based on channel
        if (channel === 'sms') {
          // Send SMS via Twilio
          if (!player.phoneNumber) {
            results.push({
              playerId,
              success: false,
              error: 'Player has no phone number',
            });
            continue;
          }

          try {
            const client = twilio(
              process.env.TWILIO_ACCOUNT_SID,
              process.env.TWILIO_AUTH_TOKEN
            );

            const amountDollars = (paymentRequest.amount / 100).toFixed(2);
            const message = customMessage || 
              `Payment request from your team: ${paymentRequest.title}. ` +
              `Amount: $${amountDollars}. ` +
              `Click here to pay: ${paymentLink}`;

            await client.messages.create({
              body: message,
              from: process.env.TWILIO_PHONE_NUMBER,
              to: player.phoneNumber,
            });

            results.push({ playerId, success: true });
          } catch (smsError) {
            console.error('Error sending SMS:', smsError);
            results.push({
              playerId,
              success: false,
              error: 'Failed to send SMS',
            });
          }
        } else {
          // Email channel - would integrate with email service
          // For now, just return the link
          results.push({
            playerId,
            success: true,
            // In a real implementation, send email here
          });
        }
      }

      res.json({
        sent: results.filter(r => r.success).length,
        failed: results.filter(r => !r.success).length,
        results,
      });
    } catch (error) {
      console.error('Error sending payment links:', error);
      res.status(500).json({
        error: {
          code: 'SEND_LINKS_FAILED',
          message: 'Failed to send payment links',
        },
      });
    }
  }
);

/**
 * GET /api/payment-links/:token
 * Validate token and retrieve payment information (before payment)
 * 
 * No authentication required - token validates access
 */
router.get('/:token',
  async (req, res) => {
    try {
      const { token } = req.params;

      const validation = await PaymentTokenService.validateToken(token);

      if (!validation.isValid) {
        return res.status(400).json({
          error: {
            code: 'INVALID_TOKEN',
            message: validation.error || 'Invalid payment link',
          },
        });
      }

      // Return payment context for UI display
      res.json({
        paymentRequestId: validation.token!.paymentRequestId,
        playerId: validation.token!.playerId,
        playerName: validation.token!.playerName,
        title: validation.token!.title,
        amount: validation.token!.amount,
        // Note: playerEmail is NOT returned for privacy
      });
    } catch (error) {
      console.error('Error validating payment link:', error);
      res.status(500).json({
        error: {
          code: 'VALIDATION_FAILED',
          message: 'Failed to validate payment link',
        },
      });
    }
  }
);

/**
 * POST /api/payment-links/:token/pay
 * Process guest payment with email verification
 * 
 * No authentication required - token + email verify access
 */
router.post('/:token/pay',
  async (req, res) => {
    try {
      const validation = GuestPaymentDto.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid request data',
            details: validation.error.errors,
          },
        });
      }

      const { token } = req.params;
      const { email, providerName } = validation.data;

      // Validate token
      const tokenValidation = await PaymentTokenService.validateToken(token);

      if (!tokenValidation.isValid) {
        return res.status(400).json({
          error: {
            code: 'INVALID_TOKEN',
            message: tokenValidation.error || 'Invalid or expired payment link',
          },
        });
      }

      const paymentContext = tokenValidation.token!;

      // Verify email matches player email (CRITICAL SECURITY CHECK)
      const emailMatches = await PaymentTokenService.verifyPlayerEmail(
        paymentContext.playerId,
        email
      );

      if (!emailMatches) {
        return res.status(403).json({
          error: {
            code: 'EMAIL_VERIFICATION_FAILED',
            message: 'The email address does not match our records. Please use the email address associated with this player.',
          },
        });
      }

      // Check if already paid
      const [existingPayment] = await db
        .select()
        .from(teamPayments)
        .where(
          and(
            eq(teamPayments.paymentRequestId, paymentContext.paymentRequestId),
            eq(teamPayments.playerId, paymentContext.playerId),
            eq(teamPayments.status, 'completed')
          )
        )
        .limit(1);

      if (existingPayment) {
        return res.status(409).json({
          error: {
            code: 'ALREADY_PAID',
            message: 'This payment has already been completed',
          },
        });
      }

      // Process guest payment
      const result = await PaymentService.processGuestPayment({
        amount: paymentContext.amount,
        description: paymentContext.title,
        paymentRequestId: paymentContext.paymentRequestId,
        playerId: paymentContext.playerId,
        payerEmail: email,
        providerName,
      });

      // Mark token as used
      await PaymentTokenService.markTokenUsed(paymentContext.id);

      // Return 202 Accepted with checkout URL
      res.status(202).json({
        transactionId: result.transactionId,
        checkoutUrl: result.checkoutUrl,
        status: result.status,
      });
    } catch (error) {
      console.error('Error processing guest payment:', error);
      
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      
      if (errorMessage.includes('not configured') || errorMessage.includes('not enabled')) {
        return res.status(402).json({
          error: {
            code: 'PAYMENT_REQUIRED',
            message: errorMessage,
          },
        });
      }

      if (errorMessage.includes('Payment already exists')) {
        return res.status(409).json({
          error: {
            code: 'DUPLICATE_PAYMENT',
            message: errorMessage,
          },
        });
      }

      res.status(500).json({
        error: {
          code: 'PAYMENT_FAILED',
          message: 'Failed to process payment',
        },
      });
    }
  }
);

export default router;

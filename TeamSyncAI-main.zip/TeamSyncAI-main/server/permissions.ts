import type { Request, Response, NextFunction } from "express";
import { storage } from "./storage";
import { db } from "./db";
import { teamMembers, roles, teamPaymentRequests } from "../shared/schema";
import { eq, and, or } from "drizzle-orm";

export type Permission =
  | "canViewEvents"
  | "canManageEvents"
  | "canViewPlayers"
  | "canManagePlayers"
  | "canSendReminders"
  | "canManageCampaigns"
  | "canViewResponses"
  | "canManageAttendance"
  | "canManageSettings"
  | "canManageRoles"
  | "canViewMembership";

export async function getUserPermissions(userId: string, teamId: string) {
  const user = await storage.getUser(userId);
  if (!user) {
    return null;
  }

  // Global admins have full permissions everywhere
  if (user.isGlobalAdmin) {
    return {
      isTeamOwner: true,
      isGlobalAdmin: true,
      canViewEvents: true,
      canManageEvents: true,
      canViewPlayers: true,
      canManagePlayers: true,
      canSendReminders: true,
      canManageCampaigns: true,
      canViewResponses: true,
      canManageAttendance: true,
      canManageSettings: true,
      canManageRoles: true,
      canViewMembership: true,
    };
  }

  const team = await storage.getTeam(teamId);
  if (!team) {
    return null;
  }

  if (team.userId === userId) {
    return {
      isTeamOwner: true,
      isGlobalAdmin: false,
      canViewEvents: true,
      canManageEvents: true,
      canViewPlayers: true,
      canManagePlayers: true,
      canSendReminders: true,
      canManageCampaigns: true,
      canViewResponses: true,
      canManageAttendance: true,
      canManageSettings: true,
      canManageRoles: true,
      canViewMembership: true,
    };
  }

  // NEW: Check teamMembers table first (staff members, coaches, etc.)
  const normalizedEmail = user.email?.toLowerCase();
  
  // Build WHERE conditions: match by userId OR email
  const memberMatchConditions = [];
  if (userId) {
    memberMatchConditions.push(eq(teamMembers.userId, userId));
  }
  if (normalizedEmail) {
    memberMatchConditions.push(eq(teamMembers.email, normalizedEmail));
  }
  
  // Try teamMembers lookup if we have identifiers
  let teamMember = null;
  if (memberMatchConditions.length > 0) {
    const [result] = await db
      .select({
        roleId: teamMembers.roleId,
        membershipType: teamMembers.membershipType,
        status: teamMembers.status,
      })
      .from(teamMembers)
      .where(
        and(
          eq(teamMembers.teamId, teamId),
          eq(teamMembers.status, 'active'),
          or(...memberMatchConditions)
        )
      )
      .limit(1);
    teamMember = result || null;
  }

  if (teamMember?.roleId) {
    // Team member with role - fetch role permissions
    const [role] = await db
      .select()
      .from(roles)
      .where(eq(roles.id, teamMember.roleId))
      .limit(1);

    if (role) {
      return {
        isTeamOwner: false,
        isGlobalAdmin: false,
        canViewEvents: role.canViewEvents,
        canManageEvents: role.canManageEvents,
        canViewPlayers: role.canViewPlayers,
        canManagePlayers: role.canManagePlayers,
        canSendReminders: role.canSendReminders,
        canManageCampaigns: role.canManageCampaigns,
        canViewResponses: role.canViewResponses,
        canManageAttendance: role.canManageAttendance,
        canManageSettings: role.canManageSettings,
        canManageRoles: role.canManageRoles,
        canViewMembership: role.canViewMembership,
      };
    }
  }

  if (teamMember) {
    // Team member without specific role - default permissions
    return {
      isTeamOwner: false,
      isGlobalAdmin: false,
      canViewEvents: true,
      canManageEvents: false,
      canViewPlayers: true,
      canManagePlayers: false,
      canSendReminders: false,
      canManageCampaigns: false,
      canViewResponses: true,
      canManageAttendance: false,
      canManageSettings: false,
      canManageRoles: false,
      canViewMembership: false,
    };
  }

  // FALLBACK: Check players table for backwards compatibility
  const players = await storage.getPlayers(teamId);

  // Match player by userId (primary) or email (fallback for legacy/guardian cases)
  const player = players.find(
    (p) => p.userId === userId || p.email?.toLowerCase() === normalizedEmail
  );

  if (!player?.roleId) {
    // Player without role or not found
    if (player) {
      // Player exists but no role - default player permissions
      return {
        isTeamOwner: false,
        isGlobalAdmin: false,
        canViewEvents: true,
        canManageEvents: false,
        canViewPlayers: true,
        canManagePlayers: false,
        canSendReminders: false,
        canManageCampaigns: false,
        canViewResponses: true,
        canManageAttendance: false,
        canManageSettings: false,
        canManageRoles: false,
        canViewMembership: false,
      };
    }
    // Not found in either table
    return null;
  }

  const role = await storage.getRole(player.roleId);
  if (!role) {
    return {
      isTeamOwner: false,
      isGlobalAdmin: false,
      canViewEvents: true,
      canManageEvents: false,
      canViewPlayers: true,
      canManagePlayers: false,
      canSendReminders: false,
      canManageCampaigns: false,
      canViewResponses: true,
      canManageAttendance: false,
      canManageSettings: false,
      canManageRoles: false,
      canViewMembership: false,
    };
  }

  return {
    isTeamOwner: false,
    isGlobalAdmin: false,
    canViewEvents: role.canViewEvents,
    canManageEvents: role.canManageEvents,
    canViewPlayers: role.canViewPlayers,
    canManagePlayers: role.canManagePlayers,
    canSendReminders: role.canSendReminders,
    canManageCampaigns: role.canManageCampaigns,
    canViewResponses: role.canViewResponses,
    canManageAttendance: role.canManageAttendance,
    canManageSettings: role.canManageSettings,
    canManageRoles: role.canManageRoles,
    canViewMembership: role.canViewMembership,
  };
}

export function requirePermission(...permissions: Permission[]) {
  return async (req: any, res: Response, next: NextFunction) => {
    try {
      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const teamId = req.params.id || req.params.teamId || req.body.teamId;
      if (!teamId) {
        return res.status(400).json({ message: "Team ID required" });
      }

      const userPermissions = await getUserPermissions(userId, teamId);
      if (!userPermissions) {
        return res.status(403).json({ message: "Forbidden" });
      }

      if (userPermissions.isTeamOwner) {
        return next();
      }

      const hasAllPermissions = permissions.every(
        (perm) => userPermissions[perm] === true
      );

      if (!hasAllPermissions) {
        return res.status(403).json({ message: "Forbidden: Insufficient permissions" });
      }

      next();
    } catch (error) {
      console.error("Permission check error:", error);
      res.status(500).json({ message: "Failed to check permissions" });
    }
  };
}

export function requirePermissionForEvent(permission: Permission) {
  return async (req: any, res: Response, next: NextFunction) => {
    try {
      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const eventId = req.params.id || req.params.eventId;
      if (!eventId) {
        return res.status(400).json({ message: "Event ID required" });
      }

      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      const userPermissions = await getUserPermissions(userId, event.teamId);
      if (!userPermissions) {
        return res.status(403).json({ message: "Forbidden" });
      }

      if (userPermissions.isTeamOwner || userPermissions[permission]) {
        return next();
      }

      res.status(403).json({ message: "Forbidden: Insufficient permissions" });
    } catch (error) {
      console.error("Permission check error:", error);
      res.status(500).json({ message: "Failed to check permissions" });
    }
  };
}

export function requirePermissionForPaymentRequest(permission: Permission) {
  return async (req: any, res: Response, next: NextFunction) => {
    try {
      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const paymentRequestId = req.params.id || req.params.paymentRequestId;
      if (!paymentRequestId) {
        return res.status(400).json({ message: "Payment Request ID required" });
      }

      // Fetch payment request to get its teamId
      const paymentRequest = await storage.getPaymentRequest(paymentRequestId);
      if (!paymentRequest) {
        return res.status(404).json({ message: "Payment request not found" });
      }

      const userPermissions = await getUserPermissions(userId, paymentRequest.teamId);
      if (!userPermissions) {
        return res.status(403).json({ message: "Forbidden" });
      }

      if (userPermissions.isTeamOwner || userPermissions[permission]) {
        return next();
      }

      res.status(403).json({ message: "Forbidden: Insufficient permissions" });
    } catch (error) {
      console.error("Permission check error:", error);
      res.status(500).json({ message: "Failed to check permissions" });
    }
  };
}

export function requireGlobalAdmin() {
  return async (req: any, res: Response, next: NextFunction) => {
    try {
      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = await storage.getUser(userId);
      if (!user || !user.isGlobalAdmin) {
        return res.status(403).json({ message: "Forbidden: Global admin access required" });
      }

      next();
    } catch (error) {
      console.error("Global admin check error:", error);
      res.status(500).json({ message: "Failed to check global admin status" });
    }
  };
}

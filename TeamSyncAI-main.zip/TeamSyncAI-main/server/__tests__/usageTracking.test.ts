/**
 * Critical Billing Tests
 * These tests ensure usage tracking and cost calculations are accurate
 */

import { jest } from '@jest/globals';
import { MockSMSProvider } from './mocks/smsProvider.mock';
import { createMockStorage } from './mocks/storage.mock';

// Create mock instances before mocking modules
const mockProviderInstance = new MockSMSProvider();
const mockStorageInstance = createMockStorage();

jest.mock('../sms/factory', () => ({
  getSMSProvider: jest.fn(() => mockProviderInstance),
}));

jest.mock('../storage', () => ({
  storage: mockStorageInstance,
}));

jest.mock('@shared/phoneUtils', () => ({
  normalizePhoneForTwilio: jest.fn((phone: string) => phone.startsWith('+') ? phone : `+1${phone}`),
}));

// Import after mocking
import { sendSMS } from '../twilio';

describe('Usage Tracking and Billing', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should create usage tracking record after sending SMS', async () => {
    await sendSMS('+1234567890', 'Test message', { teamId: 'team-123' });

    expect(mockStorageInstance.createUsageTracking).toHaveBeenCalledTimes(1);
    expect(mockStorageInstance.createUsageTracking).toHaveBeenCalledWith(
      expect.objectContaining({
        teamId: 'team-123',
        usageType: 'sms',
        quantity: 1,
      })
    );
  });

  it('should calculate costs correctly with fixed markup', async () => {
    mockStorageInstance.getUsagePricing.mockResolvedValue({
      smsBaseCost: '0.0079',
      smsMarkupType: 'fixed',
      smsMarkupValue: '0.0021',
    });

    await sendSMS('+1234567890', 'Test', { teamId: 'team-123' });

    expect(mockStorageInstance.createUsageTracking).toHaveBeenCalledWith(
      expect.objectContaining({
        baseCost: '0.0079',
        markupCost: '0.0021',
        totalCost: '0.0100', // 0.0079 + 0.0021
      })
    );
  });

  it('should calculate costs correctly with percentage markup', async () => {
    mockStorageInstance.getUsagePricing.mockResolvedValue({
      smsBaseCost: '0.0079',
      smsMarkupType: 'percentage',
      smsMarkupValue: '25', // 25% markup
    });

    await sendSMS('+1234567890', 'Test', { teamId: 'team-123' });

    const expectedMarkup = 0.0079 * 0.25; // 0.001975
    const expectedTotal = 0.0079 + expectedMarkup; // 0.009875

    expect(mockStorageInstance.createUsageTracking).toHaveBeenCalledWith(
      expect.objectContaining({
        baseCost: '0.0079',
        markupCost: expectedMarkup.toFixed(4),
        totalCost: expectedTotal.toFixed(4),
      })
    );
  });

  it('should track zero costs when pricing is missing', async () => {
    mockStorageInstance.getUsagePricing.mockResolvedValue(null);

    await sendSMS('+1234567890', 'Test', { teamId: 'team-123' });

    expect(mockStorageInstance.createUsageTracking).toHaveBeenCalledWith(
      expect.objectContaining({
        baseCost: '0',
        markupCost: '0',
        totalCost: '0',
      })
    );
  });

  it('should include message metadata in usage tracking', async () => {
    await sendSMS('+1234567890', 'Test', {
      teamId: 'team-123',
      eventId: 'event-456',
      playerId: 'player-789',
      campaignId: 'campaign-abc',
    });

    expect(mockStorageInstance.createUsageTracking).toHaveBeenCalledWith(
      expect.objectContaining({
        metadata: expect.objectContaining({
          messageSid: 'mock-sid-123',
          eventId: 'event-456',
          playerId: 'player-789',
          campaignId: 'campaign-abc',
          toPhone: '+1234567890',
        }),
      })
    );
  });

  it('should continue SMS send even if usage tracking fails', async () => {
    mockStorageInstance.createUsageTracking.mockRejectedValue(new Error('DB error'));

    const result = await sendSMS('+1234567890', 'Test', { teamId: 'team-123' });

    expect(result).toBe('mock-sid-123'); // SMS still sent
  });

  it('should create message log after sending SMS', async () => {
    await sendSMS('+1234567890', 'Test message', {
      teamId: 'team-123',
      eventId: 'event-456',
    });

    expect(mockStorageInstance.createMessageLog).toHaveBeenCalledWith(
      expect.objectContaining({
        messageSid: 'mock-sid-123',
        teamId: 'team-123',
        eventId: 'event-456',
        direction: 'outbound',
        toPhone: '+1234567890',
        body: 'Test message',
        status: 'sent',
      })
    );
  });
});

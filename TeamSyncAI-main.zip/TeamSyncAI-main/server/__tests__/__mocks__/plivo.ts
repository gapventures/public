// Mock Plivo module for testing without installing the actual package
export class Client {
  constructor(authId?: string, authToken?: string) {}
  
  async messages_create_powerpack() {
    return {
      messageUuid: 'mock-uuid-123'
    };
  }
}

export default Client;

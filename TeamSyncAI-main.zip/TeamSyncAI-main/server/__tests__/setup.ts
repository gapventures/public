// Jest setup file - executed before each test file
import { afterAll } from '@jest/globals';

process.env.NODE_ENV = 'test';

// Close database connection pool after all tests in this file complete
afterAll(async () => {
  const { closeDatabase } = await import('../db');
  await closeDatabase();
});

/**
 * Critical TCPA Compliance Tests
 * These tests ensure opt-out handling works correctly to avoid legal issues
 */

import { jest } from '@jest/globals';
import { MockSMSProvider } from './mocks/smsProvider.mock';
import { createMockStorage } from './mocks/storage.mock';

// Create mock instances before mocking modules
const mockProviderInstance = new MockSMSProvider();
const mockStorageInstance = createMockStorage();

// Mock the provider factory
jest.mock('../sms/factory', () => ({
  getSMSProvider: jest.fn(() => mockProviderInstance),
}));

// Mock the storage
jest.mock('../storage', () => ({
  storage: mockStorageInstance,
}));

// Mock phone utils
jest.mock('@shared/phoneUtils', () => ({
  normalizePhoneForTwilio: jest.fn((phone: string) => phone.startsWith('+') ? phone : `+1${phone}`),
}));

// Import after mocking so Jest uses mocked versions
import { sendSMS } from '../twilio';

describe('Opt-Out Handling (TCPA Compliance)', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockProviderInstance.reset();
  });

  it('should NOT send SMS to opted-out user', async () => {
    mockStorageInstance.isOptedOut.mockResolvedValue(true);

    const result = await sendSMS('+1234567890', 'Test message', {
      teamId: 'team-123',
    });

    expect(result).toBeNull();
    expect(mockProviderInstance.sendSMSCalls).toHaveLength(0);
    expect(mockStorageInstance.isOptedOut).toHaveBeenCalledWith('team-123', '+1234567890');
  });

  it('should send SMS to user who has NOT opted out', async () => {
    mockStorageInstance.isOptedOut.mockResolvedValue(false);

    const result = await sendSMS('+1234567890', 'Test message', {
      teamId: 'team-123',
    });

    expect(result).toBe('mock-sid-123');
    expect(mockProviderInstance.sendSMSCalls).toHaveLength(1);
    expect(mockProviderInstance.sendSMSCalls[0]).toMatchObject({
      to: '+1234567890',
      body: 'Test message',
    });
  });

  it('should check opt-out status before every send', async () => {
    mockStorageInstance.isOptedOut.mockResolvedValue(false);

    await sendSMS('+1111111111', 'Message 1', { teamId: 'team-123' });
    await sendSMS('+1222222222', 'Message 2', { teamId: 'team-123' });

    expect(mockStorageInstance.isOptedOut).toHaveBeenCalledTimes(2);
    expect(mockStorageInstance.isOptedOut).toHaveBeenNthCalledWith(1, 'team-123', '+1111111111');
    expect(mockStorageInstance.isOptedOut).toHaveBeenNthCalledWith(2, 'team-123', '+1222222222');
  });

  it('should NOT check opt-out when teamId is missing', async () => {
    await sendSMS('+1234567890', 'Test message'); // No teamId

    expect(mockStorageInstance.isOptedOut).not.toHaveBeenCalled();
    expect(mockProviderInstance.sendSMSCalls).toHaveLength(1);
  });

  it('should be team-specific (opted out of one team, not another)', async () => {
    mockStorageInstance.isOptedOut
      .mockResolvedValueOnce(true)   // Opted out of team-123
      .mockResolvedValueOnce(false); // NOT opted out of team-456

    const result1 = await sendSMS('+1234567890', 'Message 1', { teamId: 'team-123' });
    const result2 = await sendSMS('+1234567890', 'Message 2', { teamId: 'team-456' });

    expect(result1).toBeNull();
    expect(result2).toBe('mock-sid-123');
    expect(mockProviderInstance.sendSMSCalls).toHaveLength(1); // Only second message sent
  });
});

/**
 * Test Database Helper
 * 
 * Provides utilities for integration tests that need database access.
 * Uses the real DATABASE_URL but with proper cleanup to isolate tests.
 */

import { db } from '../../db';
import { 
  users, 
  teams, 
  players, 
  smsOptOuts,
  messageLogs,
  usageTracking,
  paymentRequestTokens,
  teamPaymentRequests,
  events
} from '../../../shared/schema';
import { eq } from 'drizzle-orm';

/**
 * Test data factory for creating test records
 */
export class TestDataFactory {
  /**
   * Create a test user
   */
  static async createUser(overrides: Partial<any> = {}) {
    const defaultUser = {
      email: `test-${Date.now()}@example.com`,
      password: 'hashed-password',
      accountType: 'coach' as const,
      firstName: 'Test',
      lastName: 'User',
    };

    const [user] = await db
      .insert(users)
      .values({ ...defaultUser, ...overrides })
      .returning();

    return user;
  }

  /**
   * Create a test team
   */
  static async createTeam(ownerId: string, overrides: Partial<any> = {}) {
    const defaultTeam = {
      name: `Test Team ${Date.now()}`,
      sport: 'Baseball' as const,
      ownerId,
      season: '2025',
    };

    const [team] = await db
      .insert(teams)
      .values({ ...defaultTeam, ...overrides })
      .returning();

    return team;
  }

  /**
   * Create a test player
   */
  static async createPlayer(teamId: string, overrides: Partial<any> = {}) {
    const defaultPlayer = {
      firstName: 'Test',
      lastName: 'Player',
      phone: `+1555${Math.floor(Math.random() * 10000000).toString().padStart(7, '0')}`,
      email: `player-${Date.now()}@example.com`,
      teamId,
    };

    const [player] = await db
      .insert(players)
      .values({ ...defaultPlayer, ...overrides })
      .returning();

    return player;
  }

  /**
   * Create a test event
   */
  static async createEvent(teamId: string, overrides: Partial<any> = {}) {
    const defaultEvent = {
      title: `Test Event ${Date.now()}`,
      teamId,
      date: new Date(),
      type: 'game' as const,
    };

    const [event] = await db
      .insert(events)
      .values({ ...defaultEvent, ...overrides })
      .returning();

    return event;
  }

  /**
   * Create a test payment request
   */
  static async createPaymentRequest(teamId: string, createdByUserId: string, overrides: Partial<any> = {}) {
    const defaultRequest = {
      teamId,
      title: `Test Payment ${Date.now()}`,
      amount: 5000, // $50.00
      createdByUserId,
    };

    const [request] = await db
      .insert(teamPaymentRequests)
      .values({ ...defaultRequest, ...overrides })
      .returning();

    return request;
  }

  /**
   * Mark player as opted out
   */
  static async createOptOut(teamId: string, phoneNumber: string) {
    const [optOut] = await db
      .insert(smsOptOuts)
      .values({
        teamId,
        phoneNumber,
        optedOutAt: new Date(),
        isOptedOut: true,
      })
      .returning();

    return optOut;
  }
}

/**
 * Cleanup helper for removing test data
 */
export class TestCleanup {
  private static recordsToDelete: Map<string, Set<string>> = new Map();

  /**
   * Track a record for cleanup
   */
  static track(table: string, id: string) {
    if (!this.recordsToDelete.has(table)) {
      this.recordsToDelete.set(table, new Set());
    }
    this.recordsToDelete.get(table)!.add(id);
  }

  /**
   * Clean up all tracked records
   */
  static async cleanup() {
    // Clean up in reverse order to handle foreign key constraints
    const cleanupOrder = [
      { name: 'paymentRequestTokens', table: paymentRequestTokens },
      { name: 'usageTracking', table: usageTracking },
      { name: 'messageLogs', table: messageLogs },
      { name: 'smsOptOuts', table: smsOptOuts },
      { name: 'teamPaymentRequests', table: teamPaymentRequests },
      { name: 'players', table: players },
      { name: 'events', table: events },
      { name: 'teams', table: teams },
      { name: 'users', table: users },
    ];

    for (const { name, table } of cleanupOrder) {
      const ids = this.recordsToDelete.get(name);
      if (ids && ids.size > 0) {
        try {
          await db.delete(table as any).where(eq((table as any).id, Array.from(ids)[0]));
        } catch (error) {
          console.error(`Failed to cleanup ${name}:`, error);
        }
      }
    }

    // Reset tracking
    this.recordsToDelete.clear();
  }

  /**
   * Clean up specific test data by ID
   */
  static async cleanupById(table: any, id: string) {
    try {
      await db.delete(table).where(eq(table.id, id));
    } catch (error) {
      console.error(`Failed to cleanup record:`, error);
    }
  }
}

/**
 * Setup and teardown helpers for integration tests
 */
export async function setupTest() {
  // Reset cleanup tracker
  TestCleanup['recordsToDelete'].clear();
}

export async function teardownTest() {
  await TestCleanup.cleanup();
}

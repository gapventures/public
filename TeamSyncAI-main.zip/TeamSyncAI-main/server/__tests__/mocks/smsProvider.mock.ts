import type { ISMSProvider, SMSMessage, PhoneNumber, AvailablePhoneNumber } from '../../sms/provider';

export class MockSMSProvider implements ISMSProvider {
  name = 'mock';
  
  sendSMSCalls: Array<{ to: string; from: string; body: string }> = [];
  sendSMSResult: SMSMessage = {
    sid: 'mock-sid-123',
    status: 'sent',
    errorCode: null,
    errorMessage: null,
  };
  
  searchResult: AvailablePhoneNumber[] = [
    {
      phoneNumber: '+1234567890',
      friendlyName: '+1 (234) 567-890',
      locality: 'Test City',
      region: 'TS',
    }
  ];
  
  purchaseResult: PhoneNumber = {
    phoneNumber: '+1234567890',
    friendlyName: 'Test Number',
    sid: 'PN-mock-sid',
  };
  
  listResult: PhoneNumber[] = [];
  defaultPhone = '+1999999999';
  smsCost = 0.0079;

  async sendSMS(params: { to: string; from: string; body: string }): Promise<SMSMessage> {
    this.sendSMSCalls.push(params);
    return this.sendSMSResult;
  }

  async searchAvailablePhoneNumbers(): Promise<AvailablePhoneNumber[]> {
    return this.searchResult;
  }

  async purchasePhoneNumber(): Promise<PhoneNumber> {
    return this.purchaseResult;
  }

  async releasePhoneNumber(): Promise<void> {
    return Promise.resolve();
  }

  async listPhoneNumbers(): Promise<PhoneNumber[]> {
    return this.listResult;
  }

  async getDefaultPhoneNumber(): Promise<string> {
    return this.defaultPhone;
  }

  async getSMSCost(): Promise<number> {
    return this.smsCost;
  }

  reset() {
    this.sendSMSCalls = [];
  }
}

import { jest } from '@jest/globals';

export function createMockStorage(): any {
  return {
    // @ts-expect-error - Mock function types
    isOptedOut: jest.fn().mockResolvedValue(false),
    // @ts-expect-error - Mock function types
    getTeam: jest.fn().mockResolvedValue({
      id: 'team-123',
      name: 'Test Team',
      twilioPhoneNumber: '+1234567890',
      phoneNumberStatus: 'active',
    }),
    // @ts-expect-error - Mock function types
    createMessageLog: jest.fn().mockResolvedValue(undefined),
    // @ts-expect-error - Mock function types
    createUsageTracking: jest.fn().mockResolvedValue(undefined),
    // @ts-expect-error - Mock function types
    getUsagePricing: jest.fn().mockResolvedValue({
      smsBaseCost: '0.0079',
      smsMarkupType: 'fixed',
      smsMarkupValue: '0.0001',
    }),
  };
}

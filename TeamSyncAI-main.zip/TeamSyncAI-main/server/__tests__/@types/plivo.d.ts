// Type declarations for plivo mock (for testing without installing actual package)
declare module 'plivo' {
  export class Client {
    constructor(authId?: string, authToken?: string);
    messages_create_powerpack(params: any): Promise<any>;
  }
  export default Client;
}

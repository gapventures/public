/**
 * Opt-Out Enforcement Integration Tests (TCPA Compliance)
 * 
 * CRITICAL: These tests validate TCPA compliance to avoid legal issues.
 * Tests run against real database and real opt-out checking logic.
 * 
 * TCPA Requirements:
 * - MUST check opt-out status before every SMS send
 * - MUST respect team-specific opt-outs
 * - MUST prevent sending to opted-out numbers
 * - MUST handle opt-out regardless of phone format
 */

import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import { TestDataFactory, setupTest, teardownTest } from '../helpers/testDb';
import { db } from '../../db';
import { storage } from '../../storage';

describe('Opt-Out Enforcement Integration Tests (TCPA Compliance)', () => {
  let testUser: any;
  let testTeam: any;
  let testPlayer: any;

  beforeEach(async () => {
    await setupTest();
    
    const uniqueId = Date.now() + Math.random();
    testUser = await TestDataFactory.createUser({
      email: `coach-${uniqueId}@test.com`,
      firstName: 'Coach',
      lastName: 'Test',
    });

    testTeam = await TestDataFactory.createTeam(testUser.id, {
      name: 'Test Team',
      twilioPhoneNumber: '+15551234567',
      phoneNumberStatus: 'active',
    });

    testPlayer = await TestDataFactory.createPlayer(testTeam.id, {
      firstName: 'John',
      lastName: 'Doe',
      phone: '+15559876543',
    });
  });

  afterEach(async () => {
    await teardownTest();
  });

  describe('storage.isOptedOut', () => {
    it('should return false when player has NOT opted out', async () => {
      const isOptedOut = await storage.isOptedOut(testTeam.id, testPlayer.phone);

      expect(isOptedOut).toBe(false);
    });

    it('should return true when player HAS opted out', async () => {
      // Create opt-out record
      await TestDataFactory.createOptOut(testTeam.id, testPlayer.phone);

      const isOptedOut = await storage.isOptedOut(testTeam.id, testPlayer.phone);

      expect(isOptedOut).toBe(true);
    });

    it('should be team-specific (opted out of one team, not another)', async () => {
      // Create second team
      const team2 = await TestDataFactory.createTeam(testUser.id, {
        name: 'Team 2',
      });

      // Opt out of team 1 only
      await TestDataFactory.createOptOut(testTeam.id, testPlayer.phone);

      const isOptedOutTeam1 = await storage.isOptedOut(testTeam.id, testPlayer.phone);
      const isOptedOutTeam2 = await storage.isOptedOut(team2.id, testPlayer.phone);

      expect(isOptedOutTeam1).toBe(true);
      expect(isOptedOutTeam2).toBe(false);
    });

    it('should handle phone number format variations', async () => {
      // Create opt-out with E.164 format
      await TestDataFactory.createOptOut(testTeam.id, '+15559876543');

      // Check with different formats (should all normalize to E.164)
      const checks = await Promise.all([
        storage.isOptedOut(testTeam.id, '+15559876543'),  // E.164
        storage.isOptedOut(testTeam.id, '15559876543'),   // Without +
        storage.isOptedOut(testTeam.id, '5559876543'),    // 10 digits
      ]);

      expect(checks.every(c => c === true)).toBe(true);
    });

    it('should return false for different phone number', async () => {
      await TestDataFactory.createOptOut(testTeam.id, '+15559876543');

      const isOptedOut = await storage.isOptedOut(testTeam.id, '+15551111111');

      expect(isOptedOut).toBe(false);
    });
  });

  describe('storage.createOptOut', () => {
    it('should create opt-out record', async () => {
      await storage.createOptOut({
        teamId: testTeam.id,
        phoneNumber: testPlayer.phone,
        playerId: testPlayer.id,
      });

      const isOptedOut = await storage.isOptedOut(testTeam.id, testPlayer.phone);

      expect(isOptedOut).toBe(true);
    });

    it('should normalize phone number to E.164', async () => {
      // Create with non-E.164 format
      await storage.createOptOut({
        teamId: testTeam.id,
        phoneNumber: '(555) 987-6543',
        playerId: testPlayer.id,
      });

      // Check with E.164 format
      const isOptedOut = await storage.isOptedOut(testTeam.id, '+15559876543');

      expect(isOptedOut).toBe(true);
    });

    it('should allow opt-out without player ID', async () => {
      // Unknown number opts out
      await storage.createOptOut({
        teamId: testTeam.id,
        phoneNumber: '+15551111111',
        playerId: null as any,
      });

      const isOptedOut = await storage.isOptedOut(testTeam.id, '+15551111111');

      expect(isOptedOut).toBe(true);
    });

    it('should be idempotent (multiple opt-outs for same number)', async () => {
      // First opt-out
      await storage.createOptOut({
        teamId: testTeam.id,
        phoneNumber: testPlayer.phone,
        playerId: testPlayer.id,
      });
      
      // Second opt-out (should not throw error)
      await storage.createOptOut({
        teamId: testTeam.id,
        phoneNumber: testPlayer.phone,
        playerId: testPlayer.id,
      });

      const isOptedOut = await storage.isOptedOut(testTeam.id, testPlayer.phone);

      expect(isOptedOut).toBe(true);
    });
  });

  describe('Opt-Out Security Requirements', () => {
    it('CRITICAL: Must prevent sending to opted-out number', async () => {
      // Create opt-out
      await storage.createOptOut({
        teamId: testTeam.id,
        phoneNumber: testPlayer.phone,
        playerId: testPlayer.id,
      });

      // Verify opt-out is enforced
      const isOptedOut = await storage.isOptedOut(testTeam.id, testPlayer.phone);

      expect(isOptedOut).toBe(true);
      
      // In production, sendSMS checks this before sending
      // This test validates the storage layer works correctly
    });

    it('CRITICAL: Must check opt-out for EVERY send attempt', async () => {
      // First check (not opted out)
      const check1 = await storage.isOptedOut(testTeam.id, testPlayer.phone);
      expect(check1).toBe(false);

      // Opt out
      await storage.createOptOut({
        teamId: testTeam.id,
        phoneNumber: testPlayer.phone,
        playerId: testPlayer.id,
      });

      // Second check (opted out)
      const check2 = await storage.isOptedOut(testTeam.id, testPlayer.phone);
      expect(check2).toBe(true);

      // This demonstrates the system always gets current opt-out status
    });

    it('CRITICAL: Must handle canonical phone matching', async () => {
      // User opts out with formatted number
      await storage.createOptOut({
        teamId: testTeam.id,
        phoneNumber: '(555) 987-6543',
        playerId: testPlayer.id,
      });

      // System checks with E.164 format
      const isOptedOut = await storage.isOptedOut(testTeam.id, '+15559876543');

      expect(isOptedOut).toBe(true);
      
      // This prevents opt-out bypass via different phone formats
    });

    it('CRITICAL: Team isolation prevents cross-team opt-out leakage', async () => {
      const team2 = await TestDataFactory.createTeam(testUser.id, {
        name: 'Team 2',
      });

      // Opt out of team 1
      await storage.createOptOut({
        teamId: testTeam.id,
        phoneNumber: testPlayer.phone,
        playerId: testPlayer.id,
      });

      // Verify team 2 can still send to same number
      const team2CanSend = !(await storage.isOptedOut(team2.id, testPlayer.phone));

      expect(team2CanSend).toBe(true);
      
      // This prevents one team's opt-outs from affecting another team
    });
  });

  describe('Edge Cases', () => {
    it('should handle null phone number gracefully', async () => {
      const isOptedOut = await storage.isOptedOut(testTeam.id, null as any);

      expect(isOptedOut).toBe(false);
    });

    it('should handle empty string phone number', async () => {
      const isOptedOut = await storage.isOptedOut(testTeam.id, '');

      expect(isOptedOut).toBe(false);
    });

    it('should handle invalid phone format', async () => {
      const isOptedOut = await storage.isOptedOut(testTeam.id, 'not-a-phone');

      expect(isOptedOut).toBe(false);
    });

    it('should handle non-existent team ID', async () => {
      const isOptedOut = await storage.isOptedOut('non-existent-team', testPlayer.phone);

      expect(isOptedOut).toBe(false);
    });
  });
});

/**
 * PaymentTokenService Integration Tests
 * 
 * CRITICAL: These tests validate payment link security and lifecycle.
 * Tests run against real database to ensure production code works correctly.
 * 
 * Security features tested:
 * - Token generation and SHA-256 hashing
 * - Expiration enforcement
 * - One-time use (mark as used)
 * - Email verification
 * - Token cleanup
 */

import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import { PaymentTokenService } from '../../services/PaymentTokenService';
import { TestDataFactory, setupTest, teardownTest } from '../helpers/testDb';
import { db } from '../../db';
import { paymentRequestTokens } from '../../../shared/schema';
import { eq } from 'drizzle-orm';

describe('PaymentTokenService Integration Tests', () => {
  let testUser: any;
  let testTeam: any;
  let testPlayer: any;
  let testPaymentRequest: any;

  beforeEach(async () => {
    await setupTest();
    
    // Create test data with unique identifiers
    const uniqueId = Date.now() + Math.random();
    testUser = await TestDataFactory.createUser({
      email: `coach-${uniqueId}@test.com`,
      firstName: 'Coach',
      lastName: 'Test',
    });

    testTeam = await TestDataFactory.createTeam(testUser.id, {
      name: 'Test Team',
    });

    testPlayer = await TestDataFactory.createPlayer(testTeam.id, {
      firstName: 'John',
      lastName: 'Doe',
      email: `player-${uniqueId}@test.com`,
      phone: `+1555${Math.floor(Math.random() * 10000000).toString().padStart(7, '0')}`,
    });

    testPaymentRequest = await TestDataFactory.createPaymentRequest(
      testTeam.id,
      testUser.id,
      {
        title: 'Team Fees',
        amount: 5000, // $50.00
      }
    );
  });

  afterEach(async () => {
    await teardownTest();
  });

  describe('generateToken', () => {
    it('should generate a secure token and hash it in database', async () => {
      const rawToken = await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'sms',
        createdByUserId: testUser.id,
        expiresInHours: 48,
      });

      // Raw token should be 64 characters (base64url from 32 bytes)
      expect(rawToken).toBeDefined();
      expect(rawToken.length).toBeGreaterThan(40);

      // Token should NOT be stored in plain text
      const tokens = await db
        .select()
        .from(paymentRequestTokens)
        .where(eq(paymentRequestTokens.paymentRequestId, testPaymentRequest.id));

      expect(tokens).toHaveLength(1);
      expect(tokens[0].tokenHash).not.toBe(rawToken);
      expect(tokens[0].tokenHash.length).toBe(64); // SHA-256 hex = 64 chars
    });

    it('should set correct expiration time', async () => {
      const rawToken = await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'sms',
        createdByUserId: testUser.id,
        expiresInHours: 24,
      });

      const tokens = await db
        .select()
        .from(paymentRequestTokens)
        .where(eq(paymentRequestTokens.paymentRequestId, testPaymentRequest.id));

      const expiresAt = tokens[0].expiresAt;
      const now = new Date();
      const expectedExpiry = new Date(now.getTime() + 24 * 60 * 60 * 1000);

      // Allow 1 minute variance
      const timeDiff = Math.abs(expiresAt.getTime() - expectedExpiry.getTime());
      expect(timeDiff).toBeLessThan(60 * 1000);
    });

    it('should store channel and creator info', async () => {
      await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'email',
        createdByUserId: testUser.id,
      });

      const tokens = await db
        .select()
        .from(paymentRequestTokens)
        .where(eq(paymentRequestTokens.paymentRequestId, testPaymentRequest.id));

      expect(tokens[0].channel).toBe('email');
      expect(tokens[0].createdByUserId).toBe(testUser.id);
      expect(tokens[0].playerId).toBe(testPlayer.id);
    });
  });

  describe('validateToken', () => {
    it('should validate a valid token and return payment context', async () => {
      const rawToken = await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'sms',
        createdByUserId: testUser.id,
      });

      const result = await PaymentTokenService.validateToken(rawToken);

      expect(result.isValid).toBe(true);
      expect(result.token).toBeDefined();
      expect(result.token!.paymentRequestId).toBe(testPaymentRequest.id);
      expect(result.token!.playerId).toBe(testPlayer.id);
      expect(result.token!.playerName).toBe('John Doe');
      expect(result.token!.playerEmail).toBe(testPlayer.email);
      expect(result.token!.amount).toBe(5000);
      expect(result.token!.title).toBe('Team Fees');
    });

    it('should reject invalid token', async () => {
      const result = await PaymentTokenService.validateToken('invalid-token-123');

      expect(result.isValid).toBe(false);
      expect(result.error).toBe('Invalid or expired payment link');
      expect(result.token).toBeUndefined();
    });

    it('should reject expired token', async () => {
      // Generate token that expires in the past
      const rawToken = await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'sms',
        createdByUserId: testUser.id,
        expiresInHours: -1, // Already expired
      });

      const result = await PaymentTokenService.validateToken(rawToken);

      expect(result.isValid).toBe(false);
      expect(result.error).toBe('This payment link has expired');
    });

    it('should reject already used token', async () => {
      const rawToken = await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'sms',
        createdByUserId: testUser.id,
      });

      // Validate once (should work)
      const firstResult = await PaymentTokenService.validateToken(rawToken);
      expect(firstResult.isValid).toBe(true);

      // Mark as used
      await PaymentTokenService.markTokenUsed(firstResult.token!.id);

      // Validate again (should fail)
      const secondResult = await PaymentTokenService.validateToken(rawToken);
      expect(secondResult.isValid).toBe(false);
      expect(secondResult.error).toBe('This payment link has already been used');
    });
  });

  describe('markTokenUsed', () => {
    it('should mark token as used and set usedAt timestamp', async () => {
      const rawToken = await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'sms',
        createdByUserId: testUser.id,
      });

      const validationResult = await PaymentTokenService.validateToken(rawToken);
      const tokenId = validationResult.token!.id;

      // Mark as used
      await PaymentTokenService.markTokenUsed(tokenId);

      // Check database
      const tokens = await db
        .select()
        .from(paymentRequestTokens)
        .where(eq(paymentRequestTokens.id, tokenId));

      expect(tokens[0].usedAt).toBeDefined();
      expect(tokens[0].usedAt).toBeInstanceOf(Date);
    });

    it('should prevent token reuse after marking as used', async () => {
      const rawToken = await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'sms',
        createdByUserId: testUser.id,
      });

      const firstValidation = await PaymentTokenService.validateToken(rawToken);
      await PaymentTokenService.markTokenUsed(firstValidation.token!.id);

      const secondValidation = await PaymentTokenService.validateToken(rawToken);
      expect(secondValidation.isValid).toBe(false);
      expect(secondValidation.error).toContain('already been used');
    });
  });

  describe('verifyPlayerEmail', () => {
    it('should verify matching email (case-insensitive)', async () => {
      const result = await PaymentTokenService.verifyPlayerEmail(
        testPlayer.id,
        testPlayer.email.toUpperCase() // Uppercase
      );

      expect(result).toBe(true);
    });

    it('should verify matching email with whitespace', async () => {
      const result = await PaymentTokenService.verifyPlayerEmail(
        testPlayer.id,
        `  ${testPlayer.email}  ` // Extra spaces
      );

      expect(result).toBe(true);
    });

    it('should reject non-matching email', async () => {
      const result = await PaymentTokenService.verifyPlayerEmail(
        testPlayer.id,
        'wrong@test.com'
      );

      expect(result).toBe(false);
    });

    it('should reject when player has no email', async () => {
      const playerWithoutEmail = await TestDataFactory.createPlayer(testTeam.id, {
        email: null,
      });

      const result = await PaymentTokenService.verifyPlayerEmail(
        playerWithoutEmail.id,
        'any@test.com'
      );

      expect(result).toBe(false);
    });
  });

  describe('cleanupExpiredTokens', () => {
    it('should delete tokens expired more than 7 days ago', async () => {
      // Create old expired token
      await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'sms',
        createdByUserId: testUser.id,
        expiresInHours: -200, // Expired 8+ days ago
      });

      const deletedCount = await PaymentTokenService.cleanupExpiredTokens();

      expect(deletedCount).toBe(1);

      const tokens = await db
        .select()
        .from(paymentRequestTokens)
        .where(eq(paymentRequestTokens.paymentRequestId, testPaymentRequest.id));

      expect(tokens).toHaveLength(0);
    });

    it('should NOT delete recently expired tokens', async () => {
      // Create recently expired token
      await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'sms',
        createdByUserId: testUser.id,
        expiresInHours: -24, // Expired 1 day ago
      });

      const deletedCount = await PaymentTokenService.cleanupExpiredTokens();

      expect(deletedCount).toBe(0);

      const tokens = await db
        .select()
        .from(paymentRequestTokens)
        .where(eq(paymentRequestTokens.paymentRequestId, testPaymentRequest.id));

      expect(tokens).toHaveLength(1);
    });
  });

  describe('revokeTokensForPaymentRequest', () => {
    it('should revoke all unused tokens for a payment request', async () => {
      // Create multiple tokens
      await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'sms',
        createdByUserId: testUser.id,
      });

      await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'email',
        createdByUserId: testUser.id,
      });

      const revokedCount = await PaymentTokenService.revokeTokensForPaymentRequest(
        testPaymentRequest.id
      );

      expect(revokedCount).toBe(2);

      // Check all tokens are marked as used
      const tokens = await db
        .select()
        .from(paymentRequestTokens)
        .where(eq(paymentRequestTokens.paymentRequestId, testPaymentRequest.id));

      expect(tokens).toHaveLength(2);
      expect(tokens.every((t: any) => t.usedAt !== null)).toBe(true);
    });

    it('should NOT revoke already used tokens', async () => {
      const token1 = await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'sms',
        createdByUserId: testUser.id,
      });

      // Mark first token as used
      const validation = await PaymentTokenService.validateToken(token1);
      await PaymentTokenService.markTokenUsed(validation.token!.id);

      // Create second token
      await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'email',
        createdByUserId: testUser.id,
      });

      const revokedCount = await PaymentTokenService.revokeTokensForPaymentRequest(
        testPaymentRequest.id
      );

      // Should only revoke the unused token
      expect(revokedCount).toBe(1);
    });
  });

  describe('getTokenStats', () => {
    it('should return accurate token statistics', async () => {
      // Create 3 tokens
      const token1 = await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'sms',
        createdByUserId: testUser.id,
      });

      await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'email',
        createdByUserId: testUser.id,
        expiresInHours: -1, // Expired
      });

      await PaymentTokenService.generateToken({
        paymentRequestId: testPaymentRequest.id,
        playerId: testPlayer.id,
        channel: 'sms',
        createdByUserId: testUser.id,
      });

      // Mark one as used
      const validation = await PaymentTokenService.validateToken(token1);
      await PaymentTokenService.markTokenUsed(validation.token!.id);

      const stats = await PaymentTokenService.getTokenStats(testPaymentRequest.id);

      expect(stats.total).toBe(3);
      expect(stats.used).toBe(1);
      expect(stats.expired).toBe(1);
      expect(stats.active).toBe(1);
      expect(stats.byChannel.sms).toBe(2);
      expect(stats.byChannel.email).toBe(1);
    });
  });
});

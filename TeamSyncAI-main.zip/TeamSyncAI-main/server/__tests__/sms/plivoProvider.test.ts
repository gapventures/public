import { PlivoProvider } from '../../sms/plivoProvider';

describe('PlivoProvider', () => {
  let provider: PlivoProvider;

  beforeEach(() => {
    provider = new PlivoProvider();
  });

  describe('provider metadata', () => {
    it('should have correct name', () => {
      expect(provider.name).toBe('plivo');
    });

    it('should return correct SMS cost (cheaper than Twilio)', async () => {
      const cost = await provider.getSMSCost();
      expect(cost).toBe(0.0055);
      expect(cost).toBeLessThan(0.0079); // Cheaper than Twilio
    });
  });

  describe('getClient', () => {
    it('should throw error when plivo not configured', async () => {
      // Clear environment variables
      const originalEnv = process.env;
      delete process.env.PLIVO_AUTH_ID;
      delete process.env.PLIVO_AUTH_TOKEN;
      delete process.env.PLIVO_PHONE_NUMBER;

      await expect(provider.getDefaultPhoneNumber()).rejects.toThrow(
        'Plivo not configured'
      );

      // Restore environment
      process.env = originalEnv;
    });
  });
});

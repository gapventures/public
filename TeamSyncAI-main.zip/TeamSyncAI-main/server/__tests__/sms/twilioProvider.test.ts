import { TwilioProvider } from '../../sms/twilioProvider';

describe('TwilioProvider', () => {
  let provider: TwilioProvider;

  beforeEach(() => {
    provider = new TwilioProvider();
  });

  describe('provider metadata', () => {
    it('should have correct name', () => {
      expect(provider.name).toBe('twilio');
    });

    it('should return correct SMS cost', async () => {
      const cost = await provider.getSMSCost();
      expect(cost).toBe(0.0079);
    });
  });

  // Note: getDefaultPhoneNumber() is tested in integration tests
  // where we can properly control environment variables
});

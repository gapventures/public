import { getSMSProvider, resetSMSProvider } from '../../sms/factory';
import { TwilioProvider } from '../../sms/twilioProvider';
import { PlivoProvider } from '../../sms/plivoProvider';

describe('SMS Provider Factory', () => {
  const originalEnv = process.env;

  beforeEach(() => {
    resetSMSProvider();
    process.env = { ...originalEnv };
  });

  afterAll(() => {
    process.env = originalEnv;
  });

  it('returns Twilio provider by default', () => {
    delete process.env.SMS_PROVIDER;
    const provider = getSMSProvider();
    expect(provider).toBeInstanceOf(TwilioProvider);
    expect(provider.name).toBe('twilio');
  });

  it('returns Twilio provider when explicitly set', () => {
    process.env.SMS_PROVIDER = 'twilio';
    const provider = getSMSProvider();
    expect(provider).toBeInstanceOf(TwilioProvider);
  });

  it('returns Plivo provider when SMS_PROVIDER=plivo', () => {
    process.env.SMS_PROVIDER = 'plivo';
    const provider = getSMSProvider();
    expect(provider).toBeInstanceOf(PlivoProvider);
    expect(provider.name).toBe('plivo');
  });

  it('is case-insensitive', () => {
    process.env.SMS_PROVIDER = 'PLIVO';
    const provider = getSMSProvider();
    expect(provider).toBeInstanceOf(PlivoProvider);
  });

  it('caches provider instance across calls', () => {
    const provider1 = getSMSProvider();
    const provider2 = getSMSProvider();
    expect(provider1).toBe(provider2);
  });

  it('can reset provider instance', () => {
    const provider1 = getSMSProvider();
    resetSMSProvider();
    const provider2 = getSMSProvider();
    expect(provider1).not.toBe(provider2);
  });
});

import { replaceTemplateVariables } from '../twilio';

describe('SMS Template Variables', () => {
  describe('replaceTemplateVariables', () => {
    it('replaces player name in curly brace format', () => {
      const template = 'Hi {playerName}, welcome to the team!';
      const result = replaceTemplateVariables(template, { playerName: 'John Smith' });
      expect(result).toBe('Hi John Smith, welcome to the team!');
    });

    it('replaces first name variable', () => {
      const template = 'Hey {firstName}!';
      const result = replaceTemplateVariables(template, { firstName: 'Sarah' });
      expect(result).toBe('Hey Sarah!');
    });

    it('replaces multiple variables in one template', () => {
      const template = '{playerName} has a {eventType} on {date} at {time}';
      const result = replaceTemplateVariables(template, {
        playerName: 'Alex Johnson',
        eventType: 'Practice',
        date: 'Monday, Jan 15',
        time: '6:00 PM'
      });
      expect(result).toBe('Alex Johnson has a Practice on Monday, Jan 15 at 6:00 PM');
    });

    it('replaces team-level variables', () => {
      const template = 'Hi {playerName}, {coachName} from {teamName} here!';
      const result = replaceTemplateVariables(template, {
        playerName: 'Mike',
        coachName: 'Coach Davis',
        teamName: 'Hawks'
      });
      expect(result).toBe('Hi Mike, Coach Davis from Hawks here!');
    });

    it('replaces event-specific variables', () => {
      const template = '{eventTitle} - {location}, bring {cleats} and {jersey}';
      const result = replaceTemplateVariables(template, {
        eventTitle: 'Championship Game',
        location: 'Main Field',
        cleats: 'turf shoes',
        jersey: 'home jersey'
      });
      expect(result).toBe('Championship Game - Main Field, bring turf shoes and home jersey');
    });

    it('handles optional variables by leaving empty string', () => {
      const template = 'Game vs {opponent} ({homeAway})';
      const result = replaceTemplateVariables(template, {
        opponent: 'Tigers',
        homeAway: ''
      });
      expect(result).toBe('Game vs Tigers ()');
    });

    it('leaves unreplaced variables as-is when no value provided', () => {
      const template = 'Hi {playerName}, see you at {location}';
      const result = replaceTemplateVariables(template, { playerName: 'Jordan' });
      expect(result).toBe('Hi Jordan, see you at {location}');
    });

    it('supports legacy bracket format for backward compatibility', () => {
      const template = '[Player Name] has a game on [Date] at [Time]';
      const result = replaceTemplateVariables(template, {
        playerName: 'Sam',
        date: 'Saturday',
        time: '10:00 AM'
      });
      expect(result).toBe('Sam has a game on Saturday at 10:00 AM');
    });

    it('handles empty template', () => {
      const result = replaceTemplateVariables('', { playerName: 'Test' });
      expect(result).toBe('');
    });

    it('handles template with no variables', () => {
      const template = 'This is a plain message';
      const result = replaceTemplateVariables(template, { playerName: 'Test' });
      expect(result).toBe('This is a plain message');
    });

    it('handles special characters in variable values', () => {
      const template = 'Player: {playerName}';
      const result = replaceTemplateVariables(template, {
        playerName: "O'Brien (Jr.)"
      });
      expect(result).toBe("Player: O'Brien (Jr.)");
    });
  });
});

import { describe, it, expect } from '@jest/globals';
import {
  formatPhoneForDisplay,
  normalizePhoneForTwilio,
  autoFormatPhoneInput,
  isValidPhoneNumber,
} from '../../shared/phoneUtils';

describe('Phone Utilities', () => {
  describe('formatPhoneForDisplay', () => {
    it('should format 10-digit US number', () => {
      expect(formatPhoneForDisplay('5551234567')).toBe('(555) 123-4567');
    });

    it('should format 11-digit number with country code', () => {
      expect(formatPhoneForDisplay('15551234567')).toBe('+1 (555) 123-4567');
    });

    it('should format messy input with dashes and parens', () => {
      expect(formatPhoneForDisplay('(555) 123-4567')).toBe('(555) 123-4567');
      expect(formatPhoneForDisplay('555-123-4567')).toBe('(555) 123-4567');
    });

    it('should handle null and undefined', () => {
      expect(formatPhoneForDisplay(null)).toBe('');
      expect(formatPhoneForDisplay(undefined)).toBe('');
      expect(formatPhoneForDisplay('')).toBe('');
    });

    it('should return original for non-standard formats', () => {
      const weird = '123';
      expect(formatPhoneForDisplay(weird)).toBe(weird);
    });
  });

  describe('normalizePhoneForTwilio (E.164)', () => {
    it('should normalize 10-digit US number to E.164', () => {
      expect(normalizePhoneForTwilio('5551234567')).toBe('+15551234567');
    });

    it('should normalize 11-digit number with country code', () => {
      expect(normalizePhoneForTwilio('15551234567')).toBe('+15551234567');
    });

    it('should normalize number with parentheses and dashes', () => {
      expect(normalizePhoneForTwilio('(555) 123-4567')).toBe('+15551234567');
      expect(normalizePhoneForTwilio('555-123-4567')).toBe('+15551234567');
    });

    it('should normalize number with spaces', () => {
      expect(normalizePhoneForTwilio('+1 555 123 4567')).toBe('+15551234567');
    });

    it('should preserve existing E.164 format', () => {
      expect(normalizePhoneForTwilio('+15551234567')).toBe('+15551234567');
    });

    it('should handle international numbers with +', () => {
      expect(normalizePhoneForTwilio('+44 20 1234 5678')).toBe('+442012345678');
      expect(normalizePhoneForTwilio('+61 2 1234 5678')).toBe('+61212345678');
    });

    it('should handle 011 international dialing prefix (US)', () => {
      expect(normalizePhoneForTwilio('011442012345678')).toBe('+442012345678');
    });

    it('should handle 00 international dialing prefix', () => {
      expect(normalizePhoneForTwilio('00442012345678')).toBe('+442012345678');
    });

    it('should handle null and undefined', () => {
      expect(normalizePhoneForTwilio(null)).toBe('');
      expect(normalizePhoneForTwilio(undefined)).toBe('');
      expect(normalizePhoneForTwilio('')).toBe('');
    });

    it('should detect non-US international numbers', () => {
      // UK: 44 (11 digits total)
      expect(normalizePhoneForTwilio('442012345678')).toBe('+442012345678');
      // Australia: 61 (11 digits)
      expect(normalizePhoneForTwilio('61212345678')).toBe('+61212345678');
    });

    it('should handle long international numbers', () => {
      // 12+ digit numbers should be treated as international
      expect(normalizePhoneForTwilio('123456789012')).toBe('+123456789012');
    });
  });

  describe('autoFormatPhoneInput', () => {
    it('should format as user types (progressive formatting)', () => {
      expect(autoFormatPhoneInput('')).toBe('');
      expect(autoFormatPhoneInput('5')).toBe('5');
      expect(autoFormatPhoneInput('55')).toBe('55');
      expect(autoFormatPhoneInput('555')).toBe('555');
      expect(autoFormatPhoneInput('5551')).toBe('(555) 1');
      expect(autoFormatPhoneInput('555123')).toBe('(555) 123');
      expect(autoFormatPhoneInput('5551234')).toBe('(555) 123-4');
      expect(autoFormatPhoneInput('5551234567')).toBe('(555) 123-4567');
    });

    it('should limit to 10 digits', () => {
      expect(autoFormatPhoneInput('55512345678999')).toBe('(555) 123-4567');
    });

    it('should strip non-digit characters before formatting', () => {
      expect(autoFormatPhoneInput('555-123-4567')).toBe('(555) 123-4567');
      expect(autoFormatPhoneInput('(555) 123-4567')).toBe('(555) 123-4567');
    });
  });

  describe('isValidPhoneNumber', () => {
    it('should validate 10-digit US numbers', () => {
      expect(isValidPhoneNumber('5551234567')).toBe(true);
      expect(isValidPhoneNumber('(555) 123-4567')).toBe(true);
      expect(isValidPhoneNumber('555-123-4567')).toBe(true);
    });

    it('should validate 11-digit numbers with country code', () => {
      expect(isValidPhoneNumber('15551234567')).toBe(true);
      expect(isValidPhoneNumber('+1 555 123 4567')).toBe(true);
    });

    it('should reject invalid numbers', () => {
      expect(isValidPhoneNumber('123')).toBe(false);
      expect(isValidPhoneNumber('555123')).toBe(false);
      expect(isValidPhoneNumber(null)).toBe(false);
      expect(isValidPhoneNumber(undefined)).toBe(false);
      expect(isValidPhoneNumber('')).toBe(false);
    });

    it('should reject non-US international numbers', () => {
      // This function only validates US numbers
      expect(isValidPhoneNumber('+442012345678')).toBe(false);
    });
  });
});

/**
 * Payment Token Service
 * 
 * Generates secure tokenized payment links for guest payments.
 * Tokens are hashed for security and have built-in expiry.
 */

import crypto from 'crypto';
import { db } from '../db';
import { paymentRequestTokens, teamPaymentRequests, players } from '../../shared/schema';
import { eq, and, isNull, lt, gt } from 'drizzle-orm';

export interface GenerateTokenParams {
  paymentRequestId: string;
  playerId: string;
  channel: 'sms' | 'email' | 'manual';
  createdByUserId: string;
  expiresInHours?: number; // Default 48 hours
}

export interface TokenValidationResult {
  isValid: boolean;
  token?: {
    id: string;
    paymentRequestId: string;
    playerId: string;
    playerEmail: string | null;
    playerName: string;
    amount: number; // in cents
    title: string;
  };
  error?: string;
}

export class PaymentTokenService {
  /**
   * Generate a secure random token (64 characters, URL-safe)
   */
  private static generateRawToken(): string {
    return crypto.randomBytes(32).toString('base64url');
  }

  /**
   * Hash a token for storage (SHA-256)
   */
  private static hashToken(token: string): string {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  /**
   * Generate a new payment token
   * 
   * @returns The raw token (only time it's available - must be sent immediately)
   */
  static async generateToken(params: GenerateTokenParams): Promise<string> {
    const {
      paymentRequestId,
      playerId,
      channel,
      createdByUserId,
      expiresInHours = 48,
    } = params;

    // Generate raw token
    const rawToken = this.generateRawToken();
    const tokenHash = this.hashToken(rawToken);

    // Calculate expiry
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + expiresInHours);

    // Store token hash in database
    await db.insert(paymentRequestTokens).values({
      tokenHash,
      paymentRequestId,
      playerId,
      channel,
      createdByUserId,
      expiresAt,
    });

    // Return raw token (caller must send via SMS/email immediately)
    return rawToken;
  }

  /**
   * Validate a token and retrieve payment context
   * 
   * Checks:
   * - Token exists in database
   * - Not expired
   * - Not already used
   * - Player and payment request still exist
   * 
   * @returns Validation result with payment context or error
   */
  static async validateToken(rawToken: string): Promise<TokenValidationResult> {
    try {
      const tokenHash = this.hashToken(rawToken);

      // Find token in database with JOIN to get payment request and player info
      const result = await db
        .select({
          token: paymentRequestTokens,
          paymentRequest: teamPaymentRequests,
          player: players,
        })
        .from(paymentRequestTokens)
        .innerJoin(
          teamPaymentRequests,
          eq(paymentRequestTokens.paymentRequestId, teamPaymentRequests.id)
        )
        .innerJoin(
          players,
          eq(paymentRequestTokens.playerId, players.id)
        )
        .where(eq(paymentRequestTokens.tokenHash, tokenHash))
        .limit(1);

      if (result.length === 0) {
        return {
          isValid: false,
          error: 'Invalid or expired payment link',
        };
      }

      const { token, paymentRequest, player } = result[0];

      // Check if token is expired
      if (new Date() > token.expiresAt) {
        return {
          isValid: false,
          error: 'This payment link has expired',
        };
      }

      // Check if token already used
      if (token.usedAt) {
        return {
          isValid: false,
          error: 'This payment link has already been used',
        };
      }

      // Token is valid - return payment context
      return {
        isValid: true,
        token: {
          id: token.id,
          paymentRequestId: token.paymentRequestId,
          playerId: token.playerId,
          playerEmail: player.email,
          playerName: `${player.firstName} ${player.lastName}`,
          amount: paymentRequest.amount,
          title: paymentRequest.title,
        },
      };
    } catch (error) {
      console.error('Error validating payment token:', error);
      return {
        isValid: false,
        error: 'Failed to validate payment link',
      };
    }
  }

  /**
   * Mark a token as used
   * 
   * Called after successful payment to prevent reuse
   */
  static async markTokenUsed(tokenId: string): Promise<void> {
    await db
      .update(paymentRequestTokens)
      .set({ usedAt: new Date() })
      .where(eq(paymentRequestTokens.id, tokenId));
  }

  /**
   * Verify email matches player for guest payment
   * 
   * @param playerId Player ID from token
   * @param providedEmail Email provided by payer (case-insensitive)
   * @returns True if email matches player email
   */
  static async verifyPlayerEmail(
    playerId: string,
    providedEmail: string
  ): Promise<boolean> {
    const [player] = await db
      .select({ email: players.email })
      .from(players)
      .where(eq(players.id, playerId))
      .limit(1);

    if (!player || !player.email) {
      return false;
    }

    // Case-insensitive comparison
    return player.email.toLowerCase() === providedEmail.trim().toLowerCase();
  }

  /**
   * Clean up expired tokens (can be run as cron job)
   * 
   * Deletes tokens that expired more than 7 days ago
   */
  static async cleanupExpiredTokens(): Promise<number> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - 7);

    const result = await db
      .delete(paymentRequestTokens)
      .where(lt(paymentRequestTokens.expiresAt, cutoffDate))
      .returning({ id: paymentRequestTokens.id });

    return result.length;
  }

  /**
   * Revoke all tokens for a payment request
   * 
   * Useful when a payment request is deleted or cancelled
   */
  static async revokeTokensForPaymentRequest(
    paymentRequestId: string
  ): Promise<number> {
    const result = await db
      .update(paymentRequestTokens)
      .set({ usedAt: new Date() }) // Mark as used to prevent future use
      .where(
        and(
          eq(paymentRequestTokens.paymentRequestId, paymentRequestId),
          isNull(paymentRequestTokens.usedAt)
        )
      )
      .returning({ id: paymentRequestTokens.id });

    return result.length;
  }

  /**
   * Get token statistics for a payment request
   * 
   * Useful for coaches to see how many payment links were sent/used
   */
  static async getTokenStats(paymentRequestId: string) {
    const tokens = await db
      .select({
        channel: paymentRequestTokens.channel,
        createdAt: paymentRequestTokens.createdAt,
        expiresAt: paymentRequestTokens.expiresAt,
        usedAt: paymentRequestTokens.usedAt,
      })
      .from(paymentRequestTokens)
      .where(eq(paymentRequestTokens.paymentRequestId, paymentRequestId));

    const now = new Date();

    return {
      total: tokens.length,
      used: tokens.filter((t: any) => t.usedAt).length,
      expired: tokens.filter((t: any) => !t.usedAt && t.expiresAt < now).length,
      active: tokens.filter((t: any) => !t.usedAt && t.expiresAt >= now).length,
      byChannel: {
        sms: tokens.filter((t: any) => t.channel === 'sms').length,
        email: tokens.filter((t: any) => t.channel === 'email').length,
        manual: tokens.filter((t: any) => t.channel === 'manual').length,
      },
    };
  }
}

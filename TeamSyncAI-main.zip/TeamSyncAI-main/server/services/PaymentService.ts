import { db } from '../db';
import {
  paymentProviders,
  paymentTransactions,
  subscriptionPayments,
  teamPaymentRequests,
  teamPayments,
  type InsertPaymentTransaction,
  type InsertSubscriptionPayment,
  type InsertTeamPayment,
  type PaymentTransaction,
} from '../../shared/schema';
import { eq, and, desc } from 'drizzle-orm';
import { PaymentProviderFactory } from './payments';
import type {
  CreateSubscriptionParams,
  ProcessPaymentParams,
  CreatePaymentLinkParams,
} from './payments/base';

/**
 * Payment Service
 * 
 * Encapsulates all payment-related business logic:
 * - Transaction logging
 * - Provider interaction
 * - Authorization checks
 * - Idempotency handling
 */
export class PaymentService {
  /**
   * Create a subscription for a user
   */
  static async createSubscription(params: {
    userId: string;
    tierId: string;
    amount: number;
    billingInterval: 'monthly' | 'yearly';
    providerName?: string;
  }) {
    const { userId, tierId, amount, billingInterval, providerName } = params;

    // Get payment provider (use specified or default)
    const provider = providerName
      ? await PaymentProviderFactory.getProvider(providerName)
      : await PaymentProviderFactory.getDefaultProvider();

    // Get provider config from database and verify it's enabled
    const [providerConfig] = await db
      .select()
      .from(paymentProviders)
      .where(eq(paymentProviders.name, provider.getProviderName()))
      .limit(1);

    if (!providerConfig) {
      throw new Error('Payment provider not found');
    }

    if (!providerConfig.isEnabled) {
      throw new Error('Payment provider is not enabled');
    }

    // Create subscription with provider
    const result = await provider.createSubscription({
      userId,
      tierId,
      amount,
      currency: 'USD',
      billingInterval,
    });

    // Log transaction as pending
    const [transaction] = await db.insert(paymentTransactions).values({
      providerId: providerConfig.id,
      providerTransactionId: result.subscriptionId,
      userId,
      amount,
      currency: 'USD',
      status: 'pending',
      type: 'subscription',
      description: `${billingInterval} subscription`,
      metadata: JSON.stringify({
        tierId,
        billingInterval,
        checkoutUrl: result.checkoutUrl,
      }),
    }).returning();

    // Create subscription payment record (will be updated when payment completes via webhook)
    const now = new Date();
    const billingPeriodStart = now;
    const billingPeriodEnd = new Date(now);
    if (billingInterval === 'monthly') {
      billingPeriodEnd.setMonth(billingPeriodEnd.getMonth() + 1);
    } else {
      billingPeriodEnd.setFullYear(billingPeriodEnd.getFullYear() + 1);
    }

    await db.insert(subscriptionPayments).values({
      transactionId: transaction.id,
      userId,
      tierId,
      billingPeriodStart,
      billingPeriodEnd,
    });

    return {
      transactionId: transaction.id,
      checkoutUrl: result.checkoutUrl,
      status: result.status,
    };
  }

  /**
   * Cancel a subscription
   */
  static async cancelSubscription(params: {
    userId: string;
    subscriptionId: string;
    providerName?: string;
  }) {
    const { userId, subscriptionId, providerName } = params;

    // Verify user owns this subscription
    const [transaction] = await db
      .select()
      .from(paymentTransactions)
      .where(
        and(
          eq(paymentTransactions.providerTransactionId, subscriptionId),
          eq(paymentTransactions.userId, userId),
          eq(paymentTransactions.type, 'subscription')
        )
      )
      .limit(1);

    if (!transaction) {
      throw new Error('Subscription not found or unauthorized');
    }

    // Get payment provider
    const provider = providerName
      ? await PaymentProviderFactory.getProvider(providerName)
      : await PaymentProviderFactory.getDefaultProvider();

    // Cancel with provider
    await provider.cancelSubscription({
      subscriptionId,
      userId,
    });

    // Update transaction status
    await db
      .update(paymentTransactions)
      .set({
        status: 'refunded', // Using refunded to indicate cancelled
        updatedAt: new Date(),
      })
      .where(eq(paymentTransactions.id, transaction.id));
  }

  /**
   * Process a one-time payment (team fees)
   */
  static async processPayment(params: {
    userId: string;
    amount: number;
    description: string;
    teamId?: string;
    paymentRequestId?: string;
    playerId?: string;
    providerName?: string;
  }) {
    const { userId, amount, description, teamId, paymentRequestId, playerId, providerName } = params;

    // IDEMPOTENCY: Check for duplicate payment for same player/request
    if (paymentRequestId && playerId) {
      const [existingPayment] = await db
        .select()
        .from(teamPayments)
        .where(
          and(
            eq(teamPayments.paymentRequestId, paymentRequestId),
            eq(teamPayments.playerId, playerId)
          )
        )
        .limit(1);

      // If completed or pending, don't allow duplicate
      if (existingPayment && (existingPayment.status === 'completed' || existingPayment.status === 'pending')) {
        throw new Error('Payment already exists for this player and request');
      }
    }

    // Get payment provider
    const provider = providerName
      ? await PaymentProviderFactory.getProvider(providerName)
      : await PaymentProviderFactory.getDefaultProvider();

    // Get provider config and verify it's enabled
    const [providerConfig] = await db
      .select()
      .from(paymentProviders)
      .where(eq(paymentProviders.name, provider.getProviderName()))
      .limit(1);

    if (!providerConfig) {
      throw new Error('Payment provider not found');
    }

    if (!providerConfig.isEnabled) {
      throw new Error('Payment provider is not enabled');
    }

    // Process payment
    const result = await provider.processPayment({
      userId,
      amount,
      currency: 'USD',
      description,
      teamId,
    });

    // Log transaction
    const [transaction] = await db.insert(paymentTransactions).values({
      providerId: providerConfig.id,
      providerTransactionId: result.transactionId,
      userId,
      teamId: teamId || null,
      amount,
      currency: 'USD',
      status: result.status === 'completed' ? 'completed' : 'pending',
      type: teamId ? 'team_payment' : 'one_time',
      description,
      metadata: JSON.stringify({
        paymentRequestId,
        playerId,
        checkoutUrl: result.checkoutUrl,
      }),
    }).returning();

    // If for a payment request, create team payment record
    if (paymentRequestId && playerId) {
      await db.insert(teamPayments).values({
        paymentRequestId,
        transactionId: transaction.id,
        playerId,
        userId,
        status: result.status === 'completed' ? 'completed' : 'pending',
        paidAt: result.status === 'completed' ? new Date() : null,
      });
    }

    return {
      transactionId: transaction.id,
      checkoutUrl: result.checkoutUrl,
      status: result.status,
    };
  }

  /**
   * Process a guest payment (no userId - uses email verification)
   */
  static async processGuestPayment(params: {
    amount: number;
    description: string;
    paymentRequestId: string;
    playerId: string;
    payerEmail: string;
    providerName?: string;
  }) {
    const { amount, description, paymentRequestId, playerId, payerEmail, providerName } = params;

    // IDEMPOTENCY: Check for duplicate payment for same player/request
    const [existingPayment] = await db
      .select()
      .from(teamPayments)
      .where(
        and(
          eq(teamPayments.paymentRequestId, paymentRequestId),
          eq(teamPayments.playerId, playerId)
        )
      )
      .limit(1);

    // If completed or pending, don't allow duplicate
    if (existingPayment && (existingPayment.status === 'completed' || existingPayment.status === 'pending')) {
      throw new Error('Payment already exists for this player and request');
    }

    // Get payment provider
    const provider = providerName
      ? await PaymentProviderFactory.getProvider(providerName)
      : await PaymentProviderFactory.getDefaultProvider();

    // Get provider config and verify it's enabled
    const [providerConfig] = await db
      .select()
      .from(paymentProviders)
      .where(eq(paymentProviders.name, provider.getProviderName()))
      .limit(1);

    if (!providerConfig) {
      throw new Error('Payment provider not found');
    }

    if (!providerConfig.isEnabled) {
      throw new Error('Payment provider is not enabled');
    }

    // Get team ID from payment request
    const [paymentRequest] = await db
      .select({ teamId: teamPaymentRequests.teamId })
      .from(teamPaymentRequests)
      .where(eq(teamPaymentRequests.id, paymentRequestId))
      .limit(1);

    if (!paymentRequest) {
      throw new Error('Payment request not found');
    }

    // Process payment (guest payment - no userId)
    const result = await provider.processPayment({
      userId: payerEmail, // Use email as identifier for guest payments
      amount,
      currency: 'USD',
      description,
      teamId: paymentRequest.teamId,
    });

    // Log transaction (userId is NULL for guest payments)
    const [transaction] = await db.insert(paymentTransactions).values({
      providerId: providerConfig.id,
      providerTransactionId: result.transactionId,
      userId: null, // Guest payment - no userId
      teamId: paymentRequest.teamId,
      amount,
      currency: 'USD',
      status: result.status === 'completed' ? 'completed' : 'pending',
      type: 'team_payment',
      description,
      metadata: JSON.stringify({
        paymentRequestId,
        playerId,
        payerEmail,
        checkoutUrl: result.checkoutUrl,
        guestPayment: true,
      }),
    }).returning();

    // Create team payment record
    await db.insert(teamPayments).values({
      paymentRequestId,
      transactionId: transaction.id,
      playerId,
      userId: null, // Guest payment
      payerEmail, // Store payer email for receipts/audit trail
      status: result.status === 'completed' ? 'completed' : 'pending',
      paidAt: result.status === 'completed' ? new Date() : null,
    });

    return {
      transactionId: transaction.id,
      checkoutUrl: result.checkoutUrl,
      status: result.status,
    };
  }

  /**
   * Create a payment link for coaches to share
   */
  static async createPaymentLink(params: {
    amount: number;
    description: string;
    teamId: string;
    createdByUserId: string;
    providerName?: string;
  }) {
    const { amount, description, teamId, createdByUserId, providerName } = params;

    // Get payment provider
    const provider = providerName
      ? await PaymentProviderFactory.getProvider(providerName)
      : await PaymentProviderFactory.getDefaultProvider();

    // Create payment link
    const result = await provider.createPaymentLink({
      amount,
      currency: 'USD',
      description,
      metadata: {
        teamId,
        createdByUserId,
      },
    });

    return result;
  }

  /**
   * Get user's subscription history
   */
  static async getSubscriptionHistory(userId: string) {
    const history = await db
      .select()
      .from(paymentTransactions)
      .where(
        and(
          eq(paymentTransactions.userId, userId),
          eq(paymentTransactions.type, 'subscription')
        )
      )
      .orderBy(desc(paymentTransactions.createdAt));

    return history;
  }

  /**
   * Get transaction by ID
   */
  static async getTransaction(transactionId: string, userId?: string) {
    const query = db
      .select()
      .from(paymentTransactions)
      .where(eq(paymentTransactions.id, transactionId));

    // If userId provided, ensure they own the transaction
    if (userId) {
      query.where(eq(paymentTransactions.userId, userId));
    }

    const [transaction] = await query.limit(1);
    return transaction;
  }

  /**
   * Validate webhook from payment provider
   */
  static async validateWebhook(
    providerName: string,
    rawBody: string,
    headers: Record<string, string>
  ) {
    // Get payment provider
    const provider = await PaymentProviderFactory.getProvider(providerName);

    // Verify provider is enabled in database
    const [providerConfig] = await db
      .select()
      .from(paymentProviders)
      .where(eq(paymentProviders.name, providerName))
      .limit(1);

    if (!providerConfig) {
      return {
        isValid: false,
        error: 'Payment provider not found',
      };
    }

    if (!providerConfig.isEnabled) {
      return {
        isValid: false,
        error: 'Payment provider is not enabled',
      };
    }

    // Delegate to provider-specific validation
    return await provider.validateWebhook(rawBody, headers);
  }

  /**
   * Update transaction status (called by webhooks)
   */
  static async updateTransactionStatus(params: {
    providerTransactionId: string;
    status: 'pending' | 'completed' | 'failed' | 'refunded';
    metadata?: any;
  }) {
    const { providerTransactionId, status, metadata } = params;

    // Find transaction
    const [transaction] = await db
      .select()
      .from(paymentTransactions)
      .where(eq(paymentTransactions.providerTransactionId, providerTransactionId))
      .limit(1);

    if (!transaction) {
      throw new Error('Transaction not found');
    }

    // Update transaction
    await db
      .update(paymentTransactions)
      .set({
        status,
        metadata: metadata ? JSON.stringify(metadata) : transaction.metadata,
        updatedAt: new Date(),
      })
      .where(eq(paymentTransactions.id, transaction.id));

    // If team payment, update team payment status
    if (transaction.type === 'team_payment') {
      await db
        .update(teamPayments)
        .set({
          status,
          paidAt: status === 'completed' ? new Date() : null,
        })
        .where(eq(teamPayments.transactionId, transaction.id));
    }

    return transaction;
  }
}

/**
 * Base Payment Provider Interface
 * 
 * This abstract interface defines the contract that all payment providers must implement.
 * It allows the application to support multiple payment providers (Helcim, PayPal, Venmo, etc.)
 * with a unified API.
 */

export interface PaymentProviderConfig {
  apiKey?: string;
  apiSecret?: string;
  merchantId?: string;
  webhookSecret?: string;
  testMode?: boolean;
  [key: string]: any; // Allow provider-specific config
}

export interface CreateSubscriptionParams {
  userId: string;
  tierId: string;
  amount: number; // Amount in cents
  currency?: string;
  billingInterval: 'monthly' | 'yearly';
  metadata?: Record<string, any>;
}

export interface CreateSubscriptionResult {
  subscriptionId: string; // Provider's subscription ID
  checkoutUrl?: string; // URL to redirect user for payment
  status: 'pending' | 'active' | 'failed';
}

export interface CancelSubscriptionParams {
  subscriptionId: string;
  userId: string;
}

export interface ProcessPaymentParams {
  userId: string;
  amount: number; // Amount in cents
  currency?: string;
  description: string;
  teamId?: string;
  metadata?: Record<string, any>;
}

export interface ProcessPaymentResult {
  transactionId: string; // Provider's transaction ID
  checkoutUrl?: string; // URL for hosted checkout
  status: 'pending' | 'completed' | 'failed';
}

export interface CreatePaymentLinkParams {
  amount: number; // Amount in cents
  currency?: string;
  description: string;
  successUrl?: string;
  cancelUrl?: string;
  metadata?: Record<string, any>;
}

export interface CreatePaymentLinkResult {
  paymentLinkUrl: string;
  paymentLinkId: string;
  expiresAt?: Date;
}

export interface WebhookEvent {
  providerId: string;
  eventType: string;
  eventData: any;
  signature?: string;
  timestamp?: number;
}

export interface WebhookValidationResult {
  isValid: boolean;
  event?: WebhookEvent;
  error?: string;
}

/**
 * Abstract base class for payment providers
 */
export abstract class PaymentProvider {
  protected config: PaymentProviderConfig;
  protected providerName: string;
  
  constructor(providerName: string, config: PaymentProviderConfig) {
    this.providerName = providerName;
    this.config = config;
  }

  /**
   * Get the provider name (e.g., "helcim", "paypal", "venmo")
   */
  getProviderName(): string {
    return this.providerName;
  }

  /**
   * Create a new subscription for a user
   */
  abstract createSubscription(params: CreateSubscriptionParams): Promise<CreateSubscriptionResult>;

  /**
   * Cancel an existing subscription
   */
  abstract cancelSubscription(params: CancelSubscriptionParams): Promise<void>;

  /**
   * Process a one-time payment
   */
  abstract processPayment(params: ProcessPaymentParams): Promise<ProcessPaymentResult>;

  /**
   * Create a payment link for customers to pay
   */
  abstract createPaymentLink(params: CreatePaymentLinkParams): Promise<CreatePaymentLinkResult>;

  /**
   * Validate and parse a webhook event from the provider
   */
  abstract validateWebhook(rawBody: string, headers: Record<string, string>): Promise<WebhookValidationResult>;

  /**
   * Get the checkout configuration for embedded forms (if supported)
   */
  abstract getCheckoutConfig?(): Promise<any>;
}

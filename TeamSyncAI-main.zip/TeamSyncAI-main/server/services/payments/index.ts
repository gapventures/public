import { PaymentProvider, PaymentProviderConfig } from './base';
import { HelcimPaymentProvider } from './helcim';
import { PayPalPaymentProvider } from './paypal';
import { VenmoPaymentProvider } from './venmo';
import { db } from '../../db';
import { paymentProviders } from '../../../shared/schema';
import { eq } from 'drizzle-orm';

/**
 * Payment Provider Factory
 * 
 * Creates and manages payment provider instances based on configuration
 * stored in the database.
 */
export class PaymentProviderFactory {
  private static providerInstances: Map<string, PaymentProvider> = new Map();

  /**
   * Get a payment provider instance by name
   */
  static async getProvider(providerName: string): Promise<PaymentProvider> {
    // Normalize provider name to lowercase for consistent caching and lookup
    const normalizedName = providerName.toLowerCase();
    
    // Check cache first
    if (this.providerInstances.has(normalizedName)) {
      return this.providerInstances.get(normalizedName)!;
    }

    // Load provider config from database (case-insensitive search)
    const allProviders = await db
      .select()
      .from(paymentProviders);
    
    const providerConfig = allProviders.find(
      (p: typeof paymentProviders.$inferSelect) => p.name.toLowerCase() === normalizedName
    );

    if (!providerConfig || !providerConfig.isEnabled) {
      throw new Error(`Payment provider '${providerName}' is not configured or enabled`);
    }

    // Parse config JSON and merge with API keys from database
    const config: PaymentProviderConfig = providerConfig.config 
      ? JSON.parse(providerConfig.config)
      : {};
    
    // Add API keys from database columns to config
    config.apiKey = providerConfig.apiKey || undefined;
    config.webhookSecret = providerConfig.webhookSecret || undefined;

    // Create provider instance
    const provider = this.createProviderInstance(normalizedName, config);
    
    // Cache instance using normalized name
    this.providerInstances.set(normalizedName, provider);
    
    return provider;
  }

  /**
   * Get the default payment provider
   */
  static async getDefaultProvider(): Promise<PaymentProvider> {
    // Find default provider in database
    const [defaultProvider] = await db
      .select()
      .from(paymentProviders)
      .where(eq(paymentProviders.isDefault, true))
      .limit(1);

    if (!defaultProvider) {
      throw new Error('No default payment provider configured');
    }

    return this.getProvider(defaultProvider.name);
  }

  /**
   * Create provider instance based on name
   */
  private static createProviderInstance(
    providerName: string,
    config: PaymentProviderConfig
  ): PaymentProvider {
    switch (providerName.toLowerCase()) {
      case 'helcim':
        return new HelcimPaymentProvider(config);
      case 'paypal':
        return new PayPalPaymentProvider(config);
      case 'venmo':
        return new VenmoPaymentProvider(config);
      default:
        throw new Error(`Unknown payment provider: ${providerName}`);
    }
  }

  /**
   * Clear provider cache (useful for config updates)
   */
  static clearCache(providerName?: string) {
    if (providerName) {
      this.providerInstances.delete(providerName);
    } else {
      this.providerInstances.clear();
    }
  }

  /**
   * Get all enabled providers
   */
  static async getEnabledProviders(): Promise<PaymentProvider[]> {
    const enabledProviders = await db
      .select()
      .from(paymentProviders)
      .where(eq(paymentProviders.isEnabled, true));

    return Promise.all(
      enabledProviders.map((provider: typeof paymentProviders.$inferSelect) => this.getProvider(provider.name))
    );
  }
}

// Export provider classes for direct use if needed
export { PaymentProvider, HelcimPaymentProvider, PayPalPaymentProvider, VenmoPaymentProvider };
export * from './base';

import {
  PaymentProvider,
  PaymentProviderConfig,
  CreateSubscriptionParams,
  CreateSubscriptionResult,
  CancelSubscriptionParams,
  ProcessPaymentParams,
  ProcessPaymentResult,
  CreatePaymentLinkParams,
  CreatePaymentLinkResult,
  WebhookValidationResult,
} from './base';

/**
 * Helcim Payment Provider Implementation
 * 
 * Helcim offers:
 * - Interchange + 0.5% + $0.25 online
 * - ACH: 0.5% + $0.25 (capped at $6)
 * - No monthly fees
 * - Automatic volume discounts
 * - Apple Pay, Google Pay, ACH support
 * 
 * Docs: https://devdocs.helcim.com/
 */
export class HelcimPaymentProvider extends PaymentProvider {
  private apiUrl: string;
  
  constructor(config: PaymentProviderConfig) {
    super('helcim', config);
    this.apiUrl = config.testMode 
      ? 'https://api.helcim-test.com' 
      : 'https://api.helcim.com';
  }

  /**
   * Create or get a Helcim customer
   * https://devdocs.helcim.com/docs/customers
   */
  async createOrGetCustomer(params: {
    userId: string;
    email: string;
    firstName?: string;
    lastName?: string;
    phone?: string;
    cardToken?: string;
  }): Promise<{ customerId: string; customerCode: string }> {
    try {
      const response = await fetch(`${this.apiUrl}/v2/customers`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'api-token': this.config.apiKey || '',
        },
        body: JSON.stringify({
          customerCode: `user_${params.userId}`,
          contactName: params.firstName && params.lastName ? `${params.firstName} ${params.lastName}` : undefined,
          businessName: params.email,
          email: params.email,
          phone: params.phone,
          cellPhone: params.phone,
          ...(params.cardToken && {
            cardToken: params.cardToken,
          }),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        if (data.error?.includes('already exists') || data.error?.includes('duplicate')) {
          const customersResponse = await fetch(`${this.apiUrl}/v2/customers?customerCode=user_${params.userId}`, {
            headers: {
              'api-token': this.config.apiKey || '',
            },
          });
          const customersData = await customersResponse.json();
          if (customersData && customersData.length > 0) {
            return {
              customerId: customersData[0].id.toString(),
              customerCode: customersData[0].customerCode,
            };
          }
        }
        throw new Error(`Helcim customer creation error: ${data.error || response.statusText}`);
      }

      return {
        customerId: data.id.toString(),
        customerCode: data.customerCode,
      };
    } catch (error) {
      console.error('Helcim create customer error:', error);
      throw error;
    }
  }

  /**
   * Create a subscription using Helcim's recurring billing
   * https://devdocs.helcim.com/docs/recurring-subscriptions
   */
  async createSubscription(params: CreateSubscriptionParams): Promise<CreateSubscriptionResult> {
    try {
      const paymentPlanId = params.metadata?.helcimPaymentPlanId;
      if (!paymentPlanId) {
        throw new Error('Helcim payment plan ID required in metadata');
      }

      const response = await fetch(`${this.apiUrl}/v2/subscriptions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'api-token': this.config.apiKey || '',
        },
        body: JSON.stringify({
          paymentPlanId,
          customerCode: `user_${params.userId}`,
          activationDate: new Date().toISOString().split('T')[0],
          recurringAmount: params.amount / 100,
          paymentMethod: 'cc',
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Helcim subscription error: ${errorData.error || response.statusText}`);
      }

      const data = await response.json();

      return {
        subscriptionId: data.id.toString(),
        status: 'active',
      };
    } catch (error) {
      console.error('Helcim subscription creation error:', error);
      throw error;
    }
  }

  /**
   * Cancel a subscription
   * https://devdocs.helcim.com/docs/recurring-subscriptions
   */
  async cancelSubscription(params: CancelSubscriptionParams): Promise<void> {
    try {
      const response = await fetch(`${this.apiUrl}/v2/subscriptions/${params.subscriptionId}`, {
        method: 'DELETE',
        headers: {
          'api-token': this.config.apiKey || '',
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Helcim cancellation error: ${errorData.error || response.statusText}`);
      }
    } catch (error) {
      console.error('Helcim subscription cancellation error:', error);
      throw error;
    }
  }

  /**
   * Process a one-time payment using Helcim Checkout
   * https://devdocs.helcim.com/docs/helcim-checkout
   */
  async processPayment(params: ProcessPaymentParams): Promise<ProcessPaymentResult> {
    // TODO: Implement Helcim one-time payment
    // Options:
    // 1. Use HelcimPay.js for embedded checkout (preferred for UX)
    // 2. Use Hosted Payment Pages for redirect flow
    // 3. Use API for server-to-server (requires PCI compliance)
    
    // For now, we'll use Hosted Payment Pages approach
    try {
      const response = await fetch(`${this.apiUrl}/v2/payment-page`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.apiKey}`,
        },
        body: JSON.stringify({
          amount: params.amount / 100, // Convert cents to dollars
          currency: params.currency || 'USD',
          description: params.description,
          customerCode: params.userId,
          paymentType: 'purchase',
          metadata: params.metadata,
        }),
      });

      if (!response.ok) {
        throw new Error(`Helcim API error: ${response.statusText}`);
      }

      const data = await response.json();
      
      return {
        transactionId: data.checkoutToken || data.id,
        checkoutUrl: data.checkoutUrl || `https://checkout.helcim.com/${data.checkoutToken}`,
        status: 'pending',
      };
    } catch (error) {
      console.error('Helcim payment processing error:', error);
      throw error;
    }
  }

  /**
   * Create a payment link
   */
  async createPaymentLink(params: CreatePaymentLinkParams): Promise<CreatePaymentLinkResult> {
    // TODO: Implement Helcim payment link creation
    // Similar to processPayment but returns shareable link
    
    throw new Error('Helcim payment link creation not yet implemented');
  }

  /**
   * Validate Helcim webhook signature
   * https://devdocs.helcim.com/docs/webhooks
   */
  async validateWebhook(rawBody: string, headers: Record<string, string>): Promise<WebhookValidationResult> {
    try {
      const crypto = await import('crypto');
      
      // Get signature and timestamp from headers
      const signature = headers['x-helcim-signature'] || headers['X-Helcim-Signature'];
      const timestamp = headers['x-helcim-timestamp'] || headers['X-Helcim-Timestamp'];

      if (!signature) {
        return {
          isValid: false,
          error: 'Missing webhook signature',
        };
      }

      if (!this.config.webhookSecret) {
        return {
          isValid: false,
          error: 'Webhook secret not configured',
        };
      }

      // Verify timestamp is recent (within 5 minutes)
      if (timestamp) {
        const webhookTime = parseInt(timestamp, 10);
        const now = Math.floor(Date.now() / 1000);
        const maxAge = 5 * 60; // 5 minutes

        if (Math.abs(now - webhookTime) > maxAge) {
          return {
            isValid: false,
            error: 'Webhook timestamp too old',
          };
        }
      }

      // Compute HMAC SHA-256: timestamp + rawBody
      const message = timestamp ? `${timestamp}${rawBody}` : rawBody;
      const hmac = crypto.createHmac('sha256', this.config.webhookSecret);
      hmac.update(message);
      const expectedSignature = hmac.digest('hex');

      // Constant-time comparison to prevent timing attacks
      const signatureBuffer = Buffer.from(signature);
      const expectedBuffer = Buffer.from(expectedSignature);

      if (signatureBuffer.length !== expectedBuffer.length) {
        return {
          isValid: false,
          error: 'Invalid webhook signature',
        };
      }

      const isValid = crypto.timingSafeEqual(signatureBuffer, expectedBuffer);

      if (!isValid) {
        return {
          isValid: false,
          error: 'Invalid webhook signature',
        };
      }

      // Parse and validate payload
      const payload = JSON.parse(rawBody);
      
      if (!payload || !payload.type) {
        return {
          isValid: false,
          error: 'Invalid webhook payload',
        };
      }

      // Map Helcim event types to normalized event types
      let eventType = payload.type;
      if (payload.type === 'payment_capture.succeeded') {
        eventType = 'payment.success';
      } else if (payload.type === 'payment_capture.failed') {
        eventType = 'payment.failed';
      }

      return {
        isValid: true,
        event: {
          providerId: 'helcim',
          eventType,
          eventData: payload.data || payload,
          timestamp: timestamp || payload.created || new Date().toISOString(),
        },
      };
    } catch (error) {
      console.error('Helcim webhook validation error:', error);
      return {
        isValid: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Initialize a HelcimPay.js checkout session for card tokenization
   * https://devdocs.helcim.com/docs/initialize-helcimpayjs
   */
  async initializeHelcimPayCheckout(params: {
    paymentRequestId: string;
    amount: number;
    currency?: string;
  }): Promise<{ checkoutToken: string; secretToken: string }> {
    if (!this.config.apiKey) {
      throw new Error('Helcim API key not configured');
    }

    try {
      // Omit invoiceNumber - Helcim will auto-generate it
      // We'll track the payment using checkoutToken and store paymentRequestId separately
      const requestBody = {
        paymentType: 'purchase',
        amount: params.amount / 100, // Convert cents to dollars
        currency: params.currency || 'USD',
      };
      
      console.log('[HELCIM] Initializing checkout with:', {
        paymentRequestId: params.paymentRequestId,
        amount: requestBody.amount,
        currency: requestBody.currency,
      });
      
      const response = await fetch(`${this.apiUrl}/v2/helcim-pay/initialize`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'api-token': this.config.apiKey,
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('[HELCIM] Checkout initialization failed:', {
          status: response.status,
          statusText: response.statusText,
          paymentRequestId: params.paymentRequestId,
          amount: params.amount,
          responseBody: errorText,
          headers: Object.fromEntries(response.headers.entries()),
        });
        throw new Error(`Helcim API error (${response.status}): ${errorText}`);
      }

      const data = await response.json();
      
      console.log('[HELCIM] Checkout session initialized:', {
        paymentRequestId: params.paymentRequestId,
        hasCheckoutToken: !!data.checkoutToken,
        hasSecretToken: !!data.secretToken,
      });
      
      return {
        checkoutToken: data.checkoutToken,
        secretToken: data.secretToken,
      };
    } catch (error) {
      console.error('[HELCIM] Initialize checkout error:', {
        error: error instanceof Error ? error.message : String(error),
        paymentRequestId: params.paymentRequestId,
        amount: params.amount,
        hasApiKey: !!this.config.apiKey,
        apiKeyLength: this.config.apiKey?.length,
      });
      throw error;
    }
  }

  /**
   * Get HelcimPay.js configuration for embedded checkout
   * https://devdocs.helcim.com/docs/helcimpayjs
   */
  async getCheckoutConfig(): Promise<any> {
    return {
      apiKey: this.config.apiKey,
      testMode: this.config.testMode || false,
      // HelcimPay.js supports: credit cards, ACH, digital wallets
      paymentMethods: ['credit_card', 'ach', 'apple_pay', 'google_pay'],
    };
  }
}

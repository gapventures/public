import {
  PaymentProvider,
  PaymentProviderConfig,
  CreateSubscriptionParams,
  CreateSubscriptionResult,
  CancelSubscriptionParams,
  ProcessPaymentParams,
  ProcessPaymentResult,
  CreatePaymentLinkParams,
  CreatePaymentLinkResult,
  WebhookValidationResult,
} from './base';

/**
 * Venmo Payment Provider Implementation (STUB)
 * 
 * Venmo (via Braintree) offers:
 * - 3.49% + $0.49 per transaction
 * - Popular with younger demographics
 * - Integrated via Braintree SDK
 * 
 * TODO: Implement Venmo integration when needed
 * - Use Braintree SDK with Venmo enabled
 * - Docs: https://developer.paypal.com/braintree/docs/guides/venmo
 */
export class VenmoPaymentProvider extends PaymentProvider {
  constructor(config: PaymentProviderConfig) {
    super('venmo', config);
  }

  async createSubscription(params: CreateSubscriptionParams): Promise<CreateSubscriptionResult> {
    // TODO: Implement Venmo subscription creation
    // Note: Venmo may not support subscriptions directly
    // May need to route through Braintree/PayPal
    throw new Error('Venmo integration not yet implemented. Please configure Helcim or another payment provider.');
  }

  async cancelSubscription(params: CancelSubscriptionParams): Promise<void> {
    // TODO: Implement Venmo subscription cancellation
    throw new Error('Venmo integration not yet implemented. Please configure Helcim or another payment provider.');
  }

  async processPayment(params: ProcessPaymentParams): Promise<ProcessPaymentResult> {
    // TODO: Implement Venmo one-time payment
    // Use Braintree SDK with Venmo payment method
    throw new Error('Venmo integration not yet implemented. Please configure Helcim or another payment provider.');
  }

  async createPaymentLink(params: CreatePaymentLinkParams): Promise<CreatePaymentLinkResult> {
    // TODO: Implement Venmo payment link creation
    throw new Error('Venmo integration not yet implemented. Please configure Helcim or another payment provider.');
  }

  async validateWebhook(rawBody: string, headers: Record<string, string>): Promise<WebhookValidationResult> {
    // TODO: Implement Venmo webhook validation
    return {
      isValid: false,
      error: 'Venmo integration not yet implemented.',
    };
  }

  async getCheckoutConfig(): Promise<any> {
    // TODO: Return Venmo/Braintree SDK configuration
    throw new Error('Venmo integration not yet implemented. Please configure Helcim or another payment provider.');
  }
}

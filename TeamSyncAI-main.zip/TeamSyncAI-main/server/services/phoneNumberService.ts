import { getSMSProvider } from "../sms/factory";
import { storage } from "../storage";

export interface PhoneNumberOptions {
  areaCode?: string;
  contains?: string;
  smsEnabled: boolean;
  voiceEnabled?: boolean;
}

export interface ProvisionedPhoneNumber {
  phoneNumber: string;
  sid: string;
  friendlyName: string;
}

export class PhoneNumberService {
  async searchAvailableNumbers(options: PhoneNumberOptions): Promise<any[]> {
    const provider = getSMSProvider();
    
    const numbers = await provider.searchAvailablePhoneNumbers({
      areaCode: options.areaCode,
      contains: options.contains,
      country: 'US',
    });

    return numbers;
  }

  async provisionPhoneNumber(
    teamId: string,
    options: PhoneNumberOptions = { smsEnabled: true }
  ): Promise<ProvisionedPhoneNumber> {
    try {
      const provider = getSMSProvider();
      
      await storage.updateTeam(teamId, {
        phoneNumberStatus: 'provisioning',
      });

      let availableNumbers = await this.searchAvailableNumbers(options);
      
      if (availableNumbers.length === 0 && options.areaCode) {
        console.log(`No numbers found in area code ${options.areaCode}, searching without area code...`);
        const fallbackOptions = { ...options, areaCode: undefined };
        availableNumbers = await this.searchAvailableNumbers(fallbackOptions);
      }
      
      if (availableNumbers.length === 0) {
        throw new Error(
          `No available phone numbers found via ${provider.name}. This could be due to account restrictions, temporary unavailability, or insufficient balance. Please verify your ${provider.name} account and try again.`
        );
      }

      const selectedNumber = availableNumbers[0];
      
      console.log(`Purchasing phone number via ${provider.name}: ${selectedNumber.phoneNumber}`);
      
      const purchasedNumber = await provider.purchasePhoneNumber({
        phoneNumber: selectedNumber.phoneNumber,
        friendlyName: `Team ${teamId} - SMS`,
      });

      await storage.updateTeam(teamId, {
        twilioPhoneNumber: purchasedNumber.phoneNumber,
        twilioPhoneNumberSid: purchasedNumber.sid,
        phoneNumberStatus: 'active',
      });

      console.log(`Phone number provisioned successfully: ${purchasedNumber.phoneNumber}`);

      return {
        phoneNumber: purchasedNumber.phoneNumber,
        sid: purchasedNumber.sid,
        friendlyName: purchasedNumber.friendlyName,
      };
    } catch (error) {
      console.error('Error provisioning phone number:', error);
      
      await storage.updateTeam(teamId, {
        phoneNumberStatus: 'failed',
      });
      throw error;
    }
  }

  async releasePhoneNumber(teamId: string): Promise<void> {
    const team = await storage.getTeam(teamId);
    
    if (!team || !team.twilioPhoneNumberSid) {
      throw new Error('Team has no phone number to release');
    }

    const provider = getSMSProvider();
    
    try {
      await provider.releasePhoneNumber(team.twilioPhoneNumberSid);

      await storage.updateTeam(teamId, {
        twilioPhoneNumber: null,
        twilioPhoneNumberSid: null,
        phoneNumberStatus: 'released',
      });
    } catch (error) {
      console.error(`Failed to release phone number for team ${teamId}:`, error);
      throw error;
    }
  }

  async listOwnedNumbers(): Promise<any[]> {
    const provider = getSMSProvider();
    const numbers = await provider.listPhoneNumbers();
    return numbers;
  }
}

export const phoneNumberService = new PhoneNumberService();

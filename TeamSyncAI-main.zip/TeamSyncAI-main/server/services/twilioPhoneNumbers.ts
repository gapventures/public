import { getTwilioClient } from "../twilio";
import { storage } from "../storage";

export interface PhoneNumberOptions {
  areaCode?: string;
  contains?: string;
  smsEnabled: boolean;
  voiceEnabled?: boolean;
}

export interface ProvisionedPhoneNumber {
  phoneNumber: string;
  sid: string;
  friendlyName: string;
}

/**
 * Twilio Phone Number Management Service
 * Handles provisioning and releasing phone numbers for teams (TCPA compliance)
 */
export class TwilioPhoneNumberService {
  /**
   * Search for available phone numbers
   */
  async searchAvailableNumbers(options: PhoneNumberOptions): Promise<any[]> {
    const client = await getTwilioClient();
    
    const searchOptions: any = {
      smsEnabled: options.smsEnabled,
      voiceEnabled: options.voiceEnabled ?? false,
    };
    
    if (options.areaCode) {
      searchOptions.areaCode = options.areaCode;
    }
    
    if (options.contains) {
      searchOptions.contains = options.contains;
    }

    // Search for local numbers in the US
    const numbers = await client.availablePhoneNumbers('US')
      .local
      .list(searchOptions);

    return numbers;
  }

  /**
   * Purchase a phone number and configure it for a team
   */
  async provisionPhoneNumber(
    teamId: string,
    options: PhoneNumberOptions = { smsEnabled: true }
  ): Promise<ProvisionedPhoneNumber> {
    try {
      const client = await getTwilioClient();
      
      // Update team status to provisioning
      await storage.updateTeam(teamId, {
        phoneNumberStatus: 'provisioning',
      });

      // Search for available numbers with specified options
      let availableNumbers = await this.searchAvailableNumbers(options);
      
      // If no numbers found and area code was specified, try without area code
      if (availableNumbers.length === 0 && options.areaCode) {
        console.log(`No numbers found in area code ${options.areaCode}, searching without area code...`);
        const fallbackOptions = { ...options, areaCode: undefined };
        availableNumbers = await this.searchAvailableNumbers(fallbackOptions);
      }
      
      if (availableNumbers.length === 0) {
        throw new Error(
          'No available phone numbers found. This could be due to Twilio account restrictions (trial accounts require verification) or temporary unavailability. Please verify your Twilio account is upgraded and has sufficient balance, then try again.'
        );
      }

      // Purchase the first available number
      const selectedNumber = availableNumbers[0];
      
      console.log(`Purchasing phone number: ${selectedNumber.phoneNumber}`);
      
      const purchasedNumber = await client.incomingPhoneNumbers.create({
        phoneNumber: selectedNumber.phoneNumber,
        smsUrl: this.getWebhookUrl(),
        smsMethod: 'POST',
        friendlyName: `Team ${teamId} - SMS`,
      });

      // Update team with the new phone number
      await storage.updateTeam(teamId, {
        twilioPhoneNumber: purchasedNumber.phoneNumber,
        twilioPhoneNumberSid: purchasedNumber.sid,
        phoneNumberStatus: 'active',
      });

      console.log(`Phone number provisioned successfully: ${purchasedNumber.phoneNumber}`);

      return {
        phoneNumber: purchasedNumber.phoneNumber,
        sid: purchasedNumber.sid,
        friendlyName: purchasedNumber.friendlyName || '',
      };
    } catch (error) {
      console.error('Error provisioning phone number:', error);
      
      // Update team status to failed
      await storage.updateTeam(teamId, {
        phoneNumberStatus: 'failed',
      });
      throw error;
    }
  }

  /**
   * Release a phone number and remove it from a team
   */
  async releasePhoneNumber(teamId: string): Promise<void> {
    const team = await storage.getTeam(teamId);
    
    if (!team || !team.twilioPhoneNumberSid) {
      throw new Error('Team has no phone number to release');
    }

    const client = await getTwilioClient();
    
    try {
      // Release the number from Twilio
      await client.incomingPhoneNumbers(team.twilioPhoneNumberSid).remove();

      // Update team record
      await storage.updateTeam(teamId, {
        twilioPhoneNumber: null,
        twilioPhoneNumberSid: null,
        phoneNumberStatus: 'released',
      });
    } catch (error) {
      console.error(`Failed to release phone number for team ${teamId}:`, error);
      throw error;
    }
  }

  /**
   * Update webhook URL for a phone number
   */
  async updateWebhookUrl(phoneSid: string, customUrl?: string): Promise<void> {
    const client = await getTwilioClient();
    
    await client.incomingPhoneNumbers(phoneSid).update({
      smsUrl: customUrl || this.getWebhookUrl(),
      smsMethod: 'POST',
    });
  }

  /**
   * Get the webhook URL for SMS messages
   */
  private getWebhookUrl(): string {
    // Use Replit deployment URL or configured base URL
    const baseUrl = process.env.REPLIT_DEPLOYMENT_URL 
      || process.env.REPL_SLUG 
      ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`
      : 'http://localhost:5000';
    
    return `${baseUrl}/api/sms/webhook`;
  }

  /**
   * List all phone numbers owned by the account
   */
  async listOwnedNumbers(): Promise<any[]> {
    const client = await getTwilioClient();
    const numbers = await client.incomingPhoneNumbers.list();
    return numbers;
  }
}

export const twilioPhoneNumberService = new TwilioPhoneNumberService();

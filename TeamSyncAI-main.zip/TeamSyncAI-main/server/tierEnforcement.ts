import type { Request, Response, NextFunction } from "express";
import { storage } from "./storage";

export interface TierEnforcedRequest extends Request {
  user: {
    id: string;
    claims: any;
  };
  tier?: {
    id: string;
    name: string;
    limits: Map<string, number>;
    features: Set<string>;
    isOnTrial: boolean;
  };
}

export async function enrichWithTierData(req: TierEnforcedRequest, res: Response, next: NextFunction) {
  try {
    const userId = req.user?.id;
    if (!userId) {
      return next();
    }

    const user = await storage.getUser(userId);
    if (!user || !user.membershipTierId) {
      return next();
    }

    const tierData = await storage.getUserMembershipTier(userId);
    if (!tierData) {
      return next();
    }

    const isOnTrial = user.trialStartDate && user.trialEndDate
      ? new Date(user.trialStartDate) <= new Date() && new Date(user.trialEndDate) >= new Date()
      : false;

    const limits = new Map(tierData.limits.map(l => [l.limitKey, l.limitValue]));
    const features = new Set(tierData.features.filter(f => f.enabled).map(f => f.featureKey));

    req.tier = {
      id: tierData.id,
      name: tierData.name,
      limits,
      features,
      isOnTrial,
    };

    next();
  } catch (error) {
    console.error("Error enriching request with tier data:", error);
    next();
  }
}

export function requireFeature(featureKey: string) {
  return (req: TierEnforcedRequest, res: Response, next: NextFunction) => {
    if (!req.tier) {
      return res.status(403).json({ message: "No membership tier assigned" });
    }

    if (req.tier.isOnTrial) {
      return next();
    }

    if (!req.tier.features.has(featureKey)) {
      return res.status(403).json({ 
        message: `This feature requires the ${featureKey} feature`,
        upgradeRequired: true,
        currentTier: req.tier.name,
      });
    }

    next();
  };
}

export function checkLimit(limitKey: string, getCount: (req: TierEnforcedRequest) => Promise<number>) {
  return async (req: TierEnforcedRequest, res: Response, next: NextFunction) => {
    if (!req.tier) {
      return next();
    }

    if (req.tier.isOnTrial) {
      return next();
    }

    const limit = req.tier.limits.get(limitKey);
    if (limit === undefined) {
      return next();
    }

    try {
      const currentCount = await getCount(req);
      
      if (currentCount >= limit) {
        return res.status(403).json({
          message: `You've reached the limit for ${limitKey}`,
          limit,
          current: currentCount,
          upgradeRequired: true,
          currentTier: req.tier.name,
        });
      }

      next();
    } catch (error) {
      console.error(`Error checking limit ${limitKey}:`, error);
      next(error);
    }
  };
}

export async function canUserPerformAction(
  userId: string,
  featureKey?: string,
  limitKey?: string,
  currentCount?: number
): Promise<{ allowed: boolean; reason?: string; upgradeRequired?: boolean }> {
  const user = await storage.getUser(userId);
  if (!user || !user.membershipTierId) {
    return { allowed: true };
  }

  const tierData = await storage.getUserMembershipTier(userId);
  if (!tierData) {
    return { allowed: true };
  }

  const isOnTrial = user.trialStartDate && user.trialEndDate
    ? new Date(user.trialStartDate) <= new Date() && new Date(user.trialEndDate) >= new Date()
    : false;

  if (isOnTrial) {
    return { allowed: true };
  }

  if (featureKey) {
    const feature = tierData.features.find(f => f.featureKey === featureKey);
    if (!feature || !feature.enabled) {
      return {
        allowed: false,
        reason: `This feature requires the ${featureKey} feature`,
        upgradeRequired: true,
      };
    }
  }

  if (limitKey !== undefined && currentCount !== undefined) {
    const limit = tierData.limits.find(l => l.limitKey === limitKey);
    if (limit && currentCount >= limit.limitValue) {
      return {
        allowed: false,
        reason: `You've reached the limit for ${limitKey}`,
        upgradeRequired: true,
      };
    }
  }

  return { allowed: true };
}

import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { db } from "./db";
import { insertTeamSchema, insertPlayerSchema, insertEventSchema, insertResponseSchema, insertRoleSchema, insertMembershipTierSchema, insertEventTemplateSchema, insertCustomFieldSchema, insertMessageSchema, insertUsagePricingSchema, users, teams, documentSignatures, type InsertTeam, players, type Player, teamPaymentRequests, teamPayments, paymentRequestTokens, paymentProviders, roles, pendingParentJoins, insertPendingParentJoinSchema } from "@shared/schema";
import { eq, inArray, desc, and, sql } from "drizzle-orm";
import { z } from "zod";
import { sendSMS, replaceTemplateVariables } from "./twilio";
import { parsePlayerResponse } from "./gemini";
import { ObjectStorageService, ObjectNotFoundError } from "./objectStorage";
import { setupAuth } from "./localAuth";
import { generateOptimalLineup } from "./lineupGenerator";
import { PaymentTokenService } from "./services/PaymentTokenService";
import { PaymentService } from "./services/PaymentService";
import { PaymentProviderFactory } from "./services/payments";
import { HelcimPaymentProvider } from "./services/payments/helcim";

// Middleware to check if user is authenticated
export function isAuthenticated(req: any, res: any, next: any) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}
import { requirePermission, requirePermissionForEvent, requirePermissionForPaymentRequest, requireGlobalAdmin, getUserPermissions } from "./permissions";
import ical from "ical-generator";
import { seedDefaultTiers } from "./seedTiers";
import { seedPaymentProviders } from "./seedPaymentProviders";
import { createRouteHandler } from "uploadthing/express";
import { uploadRouter } from "./uploadthing";
import { log } from "./vite";

// Shared Twilio phone number used by all teams by default
// Teams can provision dedicated numbers through the Phone Number Management UI
const SHARED_TWILIO_NUMBER = '+18556773180';

export async function registerRoutes(app: Express): Promise<Server> {
  // Trust proxy in production (required for Render, Heroku, AWS, etc. behind reverse proxy)
  if (process.env.NODE_ENV === 'production') {
    app.set('trust proxy', 1);
  }
  
  // Setup authentication middleware
  await setupAuth(app);

  // Add UploadThing route handler (must be AFTER session setup to access req.user)
  app.use(
    "/api/uploadthing",
    createRouteHandler({
      router: uploadRouter,
    })
  );
  log("UploadThing route handler registered at /api/uploadthing");

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.patch('/api/user/sports', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const { sports } = req.body;

      if (!Array.isArray(sports)) {
        return res.status(400).json({ message: "Sports must be an array" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const updatedUser = await storage.upsertUser({
        ...user,
        sports,
      });

      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user sports:", error);
      res.status(500).json({ message: "Failed to update user sports" });
    }
  });

  // Profile routes
  app.get('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  app.put('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      
      // Validate profile data with Zod
      const profileSchema = z.object({
        email: z.string().trim().email().min(1),
        phone: z.string().trim().optional().or(z.literal('')),
        firstName: z.string().trim().optional().or(z.literal('')),
        lastName: z.string().trim().optional().or(z.literal('')),
        address: z.string().trim().optional().or(z.literal('')),
        preferredPosition: z.string().trim().optional().or(z.literal('')),
        profileImageUrl: z.string().url().optional().or(z.literal('')),
      });

      const validatedData = profileSchema.parse(req.body);
      
      // Filter out empty strings to prevent clearing existing values
      const filteredData = Object.fromEntries(
        Object.entries(validatedData).filter(([_, value]) => value !== '')
      );

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const updatedUser = await storage.upsertUser({
        ...user,
        ...filteredData,
      });

      res.json(updatedUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid profile data", errors: error.errors });
      }
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Get player record for parent accounts (returns first child for single-child parents)
  app.get('/api/profile/player', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user || user.accountType !== 'parent') {
        return res.status(404).json({ message: "Player record not found" });
      }

      // Find all player records linked to this parent user
      const childPlayers = await db.select().from(players).where(eq(players.userId, userId));
      
      if (childPlayers.length === 0) {
        return res.status(404).json({ message: "Player record not found" });
      }

      // For now, return the first player record (future enhancement: support multiple children)
      // This is sufficient for MVP where parents typically register with one child
      res.json(childPlayers[0]);
    } catch (error) {
      console.error("Error fetching player record:", error);
      res.status(500).json({ message: "Failed to fetch player record" });
    }
  });

  // Global Admin Management
  app.post('/api/admin/set-global-admin', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const { userId, isGlobalAdmin } = req.body;
      
      if (!userId || typeof isGlobalAdmin !== 'boolean') {
        return res.status(400).json({ message: "userId and isGlobalAdmin (boolean) are required" });
      }

      const targetUser = await storage.getUser(userId);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const updatedUser = await storage.upsertUser({
        ...targetUser,
        isGlobalAdmin,
      });

      console.log(`Global admin status updated: ${targetUser.email} -> ${isGlobalAdmin}`);
      res.json(updatedUser);
    } catch (error) {
      console.error("Error setting global admin:", error);
      res.status(500).json({ message: "Failed to set global admin status" });
    }
  });

  app.get('/api/admin/users', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const allUsers = await db.select().from(users);
      
      // Get team ownership info for each user
      const usersWithTeamInfo = await Promise.all(
        allUsers.map(async (user: any) => {
          const userTeams = await db.select().from(teams).where(eq(teams.userId, user.id));
          return {
            ...user,
            teamCount: userTeams.length,
            isTeamOwner: userTeams.length > 0
          };
        })
      );
      
      res.json(usersWithTeamInfo);
    } catch (error) {
      console.error("Error fetching all users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.patch('/api/admin/users/:userId', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const { userId } = req.params;
      const { firstName, lastName, email, sports } = req.body;

      const targetUser = await storage.getUser(userId);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const updateData: Partial<typeof targetUser> = {};
      if (firstName !== undefined) updateData.firstName = firstName;
      if (lastName !== undefined) updateData.lastName = lastName;
      if (email !== undefined) updateData.email = email;
      if (sports !== undefined) updateData.sports = sports;

      const updatedUser = await storage.upsertUser({
        ...targetUser,
        ...updateData,
      });

      console.log(`User updated by admin: ${updatedUser.email} (${userId})`);
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.delete('/api/admin/users/:userId', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const { userId } = req.params;
      const currentUserId = req.user.id;
      
      // Prevent self-deletion
      if (userId === currentUserId) {
        return res.status(400).json({ message: "You cannot delete your own account" });
      }

      // Check if user exists
      const targetUser = await storage.getUser(userId);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }

      // Check if user owns any teams
      const userTeams = await db.select().from(teams).where(eq(teams.userId, userId));
      if (userTeams.length > 0) {
        return res.status(400).json({ 
          message: `Cannot delete user who owns ${userTeams.length} team(s). Please transfer or delete their teams first.` 
        });
      }

      // Delete user (this will cascade delete related records based on schema)
      await storage.deleteUser(userId);
      
      console.log(`User deleted: ${targetUser.email} (${userId})`);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // App Settings
  app.get('/api/app-settings', async (req, res) => {
    try {
      const settings = await storage.getAppSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error fetching app settings:", error);
      res.status(500).json({ message: "Failed to fetch app settings" });
    }
  });

  app.patch('/api/app-settings', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const { applicationName, availableSports } = req.body;
      
      // Build update object based on what was provided
      const updates: Partial<{ applicationName: string; availableSports: string[] }> = {};
      
      if (applicationName !== undefined) {
        if (typeof applicationName !== 'string' || applicationName.trim().length === 0) {
          return res.status(400).json({ message: "Application name must be a non-empty string" });
        }
        updates.applicationName = applicationName.trim();
      }
      
      if (availableSports !== undefined) {
        if (!Array.isArray(availableSports)) {
          return res.status(400).json({ message: "Available sports must be an array" });
        }
        updates.availableSports = availableSports;
      }
      
      // Ensure at least one field is being updated
      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ message: "No valid fields to update" });
      }

      const settings = await storage.updateAppSettings(updates);
      res.json(settings);
    } catch (error) {
      console.error("Error updating app settings:", error);
      res.status(500).json({ message: "Failed to update app settings" });
    }
  });

  // Landing Page Content
  app.get('/api/landing-page', async (req, res) => {
    try {
      const content = await storage.getLandingPageContent();
      res.json(content);
    } catch (error) {
      console.error("Error fetching landing page content:", error);
      res.status(500).json({ message: "Failed to fetch landing page content" });
    }
  });

  app.patch('/api/admin/landing-page', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const { insertLandingPageContentSchema } = await import("@shared/schema");
      const result = insertLandingPageContentSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid landing page content", 
          errors: result.error.errors 
        });
      }

      const content = await storage.updateLandingPageContent(result.data);
      res.json(content);
    } catch (error) {
      console.error("Error updating landing page content:", error);
      res.status(500).json({ message: "Failed to update landing page content" });
    }
  });

  // Marketing Page Content
  app.get('/api/marketing-pages/:page', async (req, res) => {
    try {
      const page = req.params.page;
      
      if (!["about", "features", "pricing", "contact"].includes(page)) {
        return res.status(400).json({ message: "Invalid page. Must be one of: about, features, pricing, contact" });
      }
      
      const content = await storage.getMarketingPageContent(page as "about" | "features" | "pricing" | "contact");
      res.json(content);
    } catch (error) {
      console.error("Error fetching marketing page content:", error);
      res.status(500).json({ message: "Failed to fetch marketing page content" });
    }
  });

  app.put('/api/admin/marketing-pages/:page', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const page = req.params.page;
      
      if (!["about", "features", "pricing", "contact"].includes(page)) {
        return res.status(400).json({ message: "Invalid page. Must be one of: about, features, pricing, contact" });
      }
      
      const content = await storage.updateMarketingPageContent(page as "about" | "features" | "pricing" | "contact", req.body);
      res.json(content);
    } catch (error: any) {
      console.error("Error updating marketing page content:", error);
      
      // Handle Zod validation errors
      if (error.name === "ZodError") {
        return res.status(400).json({ 
          message: "Invalid content for this page", 
          errors: error.errors 
        });
      }
      
      res.status(500).json({ message: "Failed to update marketing page content" });
    }
  });

  // Public Membership Tiers (for marketing/pricing page - no auth required)
  app.get('/api/public/membership-tiers', async (req: any, res) => {
    try {
      const tiers = await storage.getMembershipTiers();
      const activeTiers = tiers
        .filter(t => t.isActive)
        .sort((a, b) => a.displayOrder - b.displayOrder);
      res.json(activeTiers);
    } catch (error) {
      console.error("Error fetching public membership tiers:", error);
      res.status(500).json({ message: "Failed to fetch membership tiers" });
    }
  });

  // Public Membership Tiers (Active tiers for all users)
  app.get('/api/membership-tiers', isAuthenticated, async (req: any, res) => {
    try {
      const tiers = await storage.getMembershipTiers();
      const activeTiers = tiers.filter(t => t.isActive);
      res.json(activeTiers);
    } catch (error) {
      console.error("Error fetching membership tiers:", error);
      res.status(500).json({ message: "Failed to fetch membership tiers" });
    }
  });

  // Membership Tiers (Admin only - includes inactive tiers)
  app.get('/api/admin/membership-tiers', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const tiers = await storage.getMembershipTiers();
      res.json(tiers);
    } catch (error) {
      console.error("Error fetching membership tiers:", error);
      res.status(500).json({ message: "Failed to fetch membership tiers" });
    }
  });

  app.get('/api/admin/membership-tiers/:id', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const tier = await storage.getMembershipTier(req.params.id);
      if (!tier) {
        return res.status(404).json({ message: "Membership tier not found" });
      }
      res.json(tier);
    } catch (error) {
      console.error("Error fetching membership tier:", error);
      res.status(500).json({ message: "Failed to fetch membership tier" });
    }
  });

  app.post('/api/admin/membership-tiers', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const tierData = insertMembershipTierSchema.parse(req.body);
      const newTier = await storage.createMembershipTier(tierData);
      res.status(201).json(newTier);
    } catch (error) {
      console.error("Error creating membership tier:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid tier data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create membership tier" });
    }
  });

  app.patch('/api/admin/membership-tiers/:id', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const updated = await storage.updateMembershipTier(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Membership tier not found" });
      }
      res.json(updated);
    } catch (error) {
      console.error("Error updating membership tier:", error);
      res.status(500).json({ message: "Failed to update membership tier" });
    }
  });

  app.delete('/api/admin/membership-tiers/:id', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      await storage.deleteMembershipTier(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting membership tier:", error);
      res.status(500).json({ message: "Failed to delete membership tier" });
    }
  });

  // Tier Limits Management
  app.post('/api/admin/membership-tiers/:tierId/limits', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const { limitKey, limitValue } = req.body;
      if (!limitKey || typeof limitValue !== 'number') {
        return res.status(400).json({ message: "limitKey and limitValue are required" });
      }
      
      const limit = await storage.setTierLimit({
        tierId: req.params.tierId,
        limitKey,
        limitValue,
      });
      res.json(limit);
    } catch (error) {
      console.error("Error setting tier limit:", error);
      res.status(500).json({ message: "Failed to set tier limit" });
    }
  });

  app.delete('/api/admin/membership-tiers/:tierId/limits/:limitKey', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      await storage.deleteTierLimit(req.params.tierId, req.params.limitKey);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting tier limit:", error);
      res.status(500).json({ message: "Failed to delete tier limit" });
    }
  });

  // Tier Features Management
  app.post('/api/admin/membership-tiers/:tierId/features', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const { featureKey, enabled } = req.body;
      if (!featureKey || typeof enabled !== 'boolean') {
        return res.status(400).json({ message: "featureKey and enabled (boolean) are required" });
      }
      
      const feature = await storage.setTierFeature({
        tierId: req.params.tierId,
        featureKey,
        enabled,
      });
      res.json(feature);
    } catch (error) {
      console.error("Error setting tier feature:", error);
      res.status(500).json({ message: "Failed to set tier feature" });
    }
  });

  app.delete('/api/admin/membership-tiers/:tierId/features/:featureKey', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      await storage.deleteTierFeature(req.params.tierId, req.params.featureKey);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting tier feature:", error);
      res.status(500).json({ message: "Failed to delete tier feature" });
    }
  });

  // User Tier Assignment
  app.post('/api/admin/users/:userId/assign-tier', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const { tierId, startTrial } = req.body;
      if (!tierId) {
        return res.status(400).json({ message: "tierId is required" });
      }
      
      const updated = await storage.assignTierToUser(req.params.userId, tierId, startTrial || false);
      if (!updated) {
        return res.status(404).json({ message: "User or tier not found" });
      }
      res.json(updated);
    } catch (error) {
      console.error("Error assigning tier to user:", error);
      res.status(500).json({ message: "Failed to assign tier to user" });
    }
  });

  // Subscription Management
  app.post('/api/subscriptions/cancel', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Get user's current subscription
      const [user] = await db.select().from(users).where(eq(users.id, userId));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (!user.helcimSubscriptionId) {
        return res.status(400).json({ message: "No active subscription found" });
      }

      if (user.subscriptionStatus === 'canceled') {
        return res.status(400).json({ message: "Subscription already canceled" });
      }

      // Get the default (free) tier to downgrade to
      const tiers = await storage.getMembershipTiers();
      const defaultTier = tiers.find(t => t.isDefault);
      if (!defaultTier) {
        throw new Error('No default tier configured');
      }

      // Get Helcim provider
      const provider = await PaymentProviderFactory.getProvider('helcim');

      // Cancel subscription with Helcim (DELETE request per Helcim API docs)
      // This immediately terminates the subscription and stops future billing
      await provider.cancelSubscription({
        subscriptionId: user.helcimSubscriptionId,
        userId,
      });

      // Update user: downgrade to free tier and clear Helcim subscription fields
      // This allows the user to re-subscribe in the future
      await db.update(users)
        .set({
          membershipTierId: defaultTier.id,
          subscriptionStatus: 'canceled',
          subscriptionCancelledAt: new Date(),
          helcimSubscriptionId: null,
          helcimPaymentPlanId: null,
          billingProvider: null,
        })
        .where(eq(users.id, userId));

      res.json({ success: true, message: 'Subscription canceled successfully' });
    } catch (error: any) {
      console.error('Subscription cancellation error:', error);
      
      // Propagate Helcim API errors with proper status codes
      if (error.message && error.message.includes('Helcim')) {
        return res.status(400).json({ message: error.message });
      }
      
      res.status(500).json({ message: error.message || 'Failed to cancel subscription' });
    }
  });

  // Event Templates Management
  app.get('/api/admin/event-templates', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const templates = await storage.getEventTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching event templates:", error);
      res.status(500).json({ message: "Failed to fetch event templates" });
    }
  });

  app.get('/api/admin/event-templates/sport/:sport', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const templates = await storage.getEventTemplatesBySport(req.params.sport);
      res.json(templates);
    } catch (error) {
      console.error("Error fetching event templates by sport:", error);
      res.status(500).json({ message: "Failed to fetch event templates" });
    }
  });

  app.post('/api/admin/event-templates', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const templateData = insertEventTemplateSchema.parse(req.body);
      const newTemplate = await storage.createEventTemplate(templateData);
      res.status(201).json(newTemplate);
    } catch (error) {
      console.error("Error creating event template:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid template data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create event template" });
    }
  });

  app.patch('/api/admin/event-templates/:id', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const updated = await storage.updateEventTemplate(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Event template not found" });
      }
      res.json(updated);
    } catch (error) {
      console.error("Error updating event template:", error);
      res.status(500).json({ message: "Failed to update event template" });
    }
  });

  app.delete('/api/admin/event-templates/:id', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      await storage.deleteEventTemplate(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting event template:", error);
      res.status(500).json({ message: "Failed to delete event template" });
    }
  });

  // Public read access to global campaign templates (for all coaches)
  app.get('/api/campaign-templates', isAuthenticated, async (req: any, res) => {
    try {
      const templates = await storage.getGlobalCampaignTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching campaign templates:", error);
      res.status(500).json({ message: "Failed to fetch campaign templates" });
    }
  });

  // Global Campaign Templates Management (for admins)
  app.get('/api/admin/campaign-templates', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const templates = await storage.getGlobalCampaignTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching global campaign templates:", error);
      res.status(500).json({ message: "Failed to fetch campaign templates" });
    }
  });

  app.post('/api/admin/campaign-templates', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const data = { ...req.body, teamId: null };
      const template = await storage.createCampaignTemplate(data);
      res.status(201).json(template);
    } catch (error) {
      console.error("Error creating global campaign template:", error);
      res.status(500).json({ message: "Failed to create campaign template" });
    }
  });

  app.patch('/api/admin/campaign-templates/:id', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const template = await storage.updateCampaignTemplate(req.params.id, req.body);
      res.json(template);
    } catch (error) {
      console.error("Error updating global campaign template:", error);
      res.status(500).json({ message: "Failed to update campaign template" });
    }
  });

  app.delete('/api/admin/campaign-templates/:id', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      await storage.deleteCampaignTemplate(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting global campaign template:", error);
      res.status(500).json({ message: "Failed to delete campaign template" });
    }
  });

  // Template Reminders for global templates
  app.get('/api/admin/campaign-templates/:id/reminders', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const reminders = await storage.getTemplateReminders(req.params.id);
      res.json(reminders);
    } catch (error) {
      console.error("Error fetching template reminders:", error);
      res.status(500).json({ message: "Failed to fetch template reminders" });
    }
  });

  app.post('/api/admin/campaign-templates/:id/reminders', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const data = { ...req.body, templateId: req.params.id };
      const reminder = await storage.createTemplateReminder(data);
      res.status(201).json(reminder);
    } catch (error) {
      console.error("Error creating template reminder:", error);
      res.status(500).json({ message: "Failed to create template reminder" });
    }
  });

  app.patch('/api/admin/campaign-templates/:templateId/reminders/:reminderId', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const reminder = await storage.updateTemplateReminder(req.params.reminderId, req.body);
      res.json(reminder);
    } catch (error) {
      console.error("Error updating template reminder:", error);
      res.status(500).json({ message: "Failed to update template reminder" });
    }
  });

  app.delete('/api/admin/campaign-templates/:templateId/reminders/:reminderId', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      await storage.deleteTemplateReminder(req.params.reminderId);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting template reminder:", error);
      res.status(500).json({ message: "Failed to delete template reminder" });
    }
  });

  // Custom Fields Management
  app.get('/api/admin/custom-fields', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const fields = await storage.getCustomFields();
      res.json(fields);
    } catch (error) {
      console.error("Error fetching custom fields:", error);
      res.status(500).json({ message: "Failed to fetch custom fields" });
    }
  });

  app.post('/api/admin/custom-fields', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const userId = req.user.id;
      const fieldData = insertCustomFieldSchema.parse({ ...req.body, createdBy: userId });
      const newField = await storage.createCustomField(fieldData);
      res.status(201).json(newField);
    } catch (error) {
      console.error("Error creating custom field:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid field data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create custom field" });
    }
  });

  app.patch('/api/admin/custom-fields/:id', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const fieldData = insertCustomFieldSchema.partial().parse(req.body);
      const updatedField = await storage.updateCustomField(req.params.id, fieldData);
      if (!updatedField) {
        return res.status(404).json({ message: "Custom field not found" });
      }
      res.json(updatedField);
    } catch (error) {
      console.error("Error updating custom field:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid field data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update custom field" });
    }
  });

  app.delete('/api/admin/custom-fields/:id', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      await storage.deleteCustomField(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting custom field:", error);
      res.status(500).json({ message: "Failed to delete custom field" });
    }
  });

  // Admin Notifications
  app.get('/api/admin/notifications', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const notifications = await storage.getAdminNotifications();
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching admin notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.get('/api/admin/notifications/unread-count', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const count = await storage.getUnreadAdminNotificationsCount();
      res.json({ count });
    } catch (error) {
      console.error("Error fetching unread notifications count:", error);
      res.status(500).json({ message: "Failed to fetch unread count" });
    }
  });

  app.patch('/api/admin/notifications/:id/mark-read', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const notification = await storage.markAdminNotificationAsRead(req.params.id);
      if (!notification) {
        return res.status(404).json({ message: "Notification not found" });
      }
      res.json(notification);
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.patch('/api/admin/notifications/mark-all-read', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      await storage.markAllAdminNotificationsAsRead();
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ message: "Failed to mark all notifications as read" });
    }
  });

  // Team Notifications (Coach notifications for RSVP responses, etc.)
  app.get('/api/team-notifications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const teamId = req.query.teamId;
      
      // If teamId is specified, verify user has access to that team
      if (teamId) {
        const player = await storage.getPlayerByUser(teamId, userId);
        if (!player) {
          return res.status(403).json({ message: "You do not have access to this team" });
        }
      }
      
      const notifications = await storage.getTeamNotifications(userId, teamId);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching team notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.get('/api/team-notifications/unread-count', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const count = await storage.getUnreadTeamNotificationsCount(userId);
      res.json({ count });
    } catch (error) {
      console.error("Error fetching unread team notifications count:", error);
      res.status(500).json({ message: "Failed to fetch unread count" });
    }
  });

  app.patch('/api/team-notifications/:id/mark-read', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const notificationId = req.params.id;
      
      // Fetch the notification first to verify ownership
      const notifications = await storage.getTeamNotifications(userId);
      const notification = notifications.find(n => n.id === notificationId);
      
      if (!notification) {
        return res.status(404).json({ message: "Notification not found" });
      }
      
      if (notification.userId !== userId) {
        return res.status(403).json({ message: "You do not have permission to modify this notification" });
      }
      
      const updated = await storage.markTeamNotificationAsRead(notificationId);
      res.json(updated);
    } catch (error) {
      console.error("Error marking team notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.patch('/api/team-notifications/mark-all-read', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      await storage.markAllTeamNotificationsAsRead(userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking all team notifications as read:", error);
      res.status(500).json({ message: "Failed to mark all notifications as read" });
    }
  });

  // Admin User Management
  app.get('/api/admin/users', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const allUsers = await db.select({
        id: users.id,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        isGlobalAdmin: users.isGlobalAdmin,
        createdAt: users.createdAt,
      }).from(users).orderBy(users.createdAt);
      
      res.json(allUsers);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.patch('/api/admin/users/:id/toggle-admin', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const userId = req.params.id;
      
      // Don't allow users to demote themselves
      if (userId === req.user.id) {
        return res.status(400).json({ message: "You cannot change your own admin status" });
      }
      
      const [existingUser] = await db.select().from(users).where(eq(users.id, userId));
      
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // If demoting an admin, ensure at least one other global admin will remain
      if (existingUser.isGlobalAdmin) {
        const adminCount = await db.select({ count: sql<number>`count(*)` })
          .from(users)
          .where(eq(users.isGlobalAdmin, true));
        
        if (adminCount[0].count <= 1) {
          return res.status(400).json({ 
            message: "Cannot remove the last global administrator. Promote another user to admin first." 
          });
        }
      }
      
      const updatedUser = await storage.upsertUser({
        ...existingUser,
        isGlobalAdmin: !existingUser.isGlobalAdmin,
      });
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error toggling admin status:", error);
      res.status(500).json({ message: "Failed to toggle admin status" });
    }
  });

  // Delete user (admin only)
  app.delete('/api/admin/users/:id', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const userId = req.params.id;
      
      // Don't allow users to delete themselves
      if (userId === req.user.id) {
        return res.status(400).json({ message: "You cannot delete your own account" });
      }
      
      const [existingUser] = await db.select().from(users).where(eq(users.id, userId));
      
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if user owns any teams
      const userTeams = await db.select().from(teams).where(eq(teams.userId, userId));
      if (userTeams.length > 0) {
        return res.status(400).json({ 
          message: `Cannot delete user who owns ${userTeams.length} team(s). Transfer or delete their teams first.` 
        });
      }
      
      // If deleting an admin, ensure at least one other global admin will remain
      if (existingUser.isGlobalAdmin) {
        const adminCount = await db.select({ count: sql<number>`count(*)` })
          .from(users)
          .where(eq(users.isGlobalAdmin, true));
        
        if (adminCount[0].count <= 1) {
          return res.status(400).json({ 
            message: "Cannot delete the last global administrator." 
          });
        }
      }
      
      // Delete user's player records first (foreign key constraint)
      await db.delete(players).where(eq(players.userId, userId));
      
      // Delete user sessions
      await db.execute(sql`DELETE FROM session WHERE sess::jsonb->>'passport'->>'user' = ${userId}`);
      
      // Delete the user
      await db.delete(users).where(eq(users.id, userId));
      
      console.log(`User deleted by admin: ${existingUser.email} (${userId})`);
      res.json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // Usage Pricing Management
  app.get('/api/admin/usage-pricing', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const pricing = await storage.getUsagePricing();
      res.json(pricing || null);
    } catch (error) {
      console.error("Error fetching usage pricing:", error);
      res.status(500).json({ message: "Failed to fetch usage pricing" });
    }
  });

  app.patch('/api/admin/usage-pricing', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const pricingData = insertUsagePricingSchema.partial().parse(req.body);
      const updatedPricing = await storage.updateUsagePricing(pricingData);
      res.json(updatedPricing);
    } catch (error) {
      console.error("Error updating usage pricing:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid pricing data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update usage pricing" });
    }
  });

  // Get Current User's Membership Tier
  app.get('/api/user/membership-tier', isAuthenticated, async (req: any, res) => {
    try {
      const tier = await storage.getUserMembershipTier(req.user.id);
      if (!tier) {
        return res.status(404).json({ message: "No membership tier assigned" });
      }
      res.json(tier);
    } catch (error) {
      console.error("Error fetching user membership tier:", error);
      res.status(500).json({ message: "Failed to fetch membership tier" });
    }
  });

  // Seed Default Tiers
  app.post('/api/admin/seed-tiers', isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      await seedDefaultTiers();
      res.json({ message: "Default tiers seeded successfully" });
    } catch (error) {
      console.error("Error seeding default tiers:", error);
      res.status(500).json({ message: "Failed to seed default tiers" });
    }
  });

  // Teams
  app.get("/api/teams", isAuthenticated, async (req: any, res) => {
    try {
      const testViewMode = req.query.testViewMode as string | undefined;
      let teams = await storage.getTeamsForUser(req.user.id);
      
      // Filter teams for test view mode (player/viewer should only see teams they're a player on)
      if (testViewMode === "player" || testViewMode === "viewer") {
        const userEmail = req.user.email;
        if (userEmail) {
          // Use SQL to find teams where user has a player record
          const userPlayers = await db
            .select()
            .from(players)
            .where(sql`LOWER(${players.email}) = LOWER(${userEmail})`);
          
          const teamIdsWithPlayer = new Set(userPlayers.map((p: Player) => p.teamId));
          teams = teams.filter((team) => teamIdsWithPlayer.has(team.id));
        } else {
          // If no email, can't match player records, so return empty array
          teams = [];
        }
      }
      
      res.json(teams);
    } catch (error) {
      console.error("Error fetching teams:", error);
      res.status(500).json({ message: "Failed to fetch teams" });
    }
  });

  app.get("/api/teams/:id", async (req, res) => {
    try {
      const team = await storage.getTeam(req.params.id);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      res.json(team);
    } catch (error) {
      console.error("Error fetching team:", error);
      res.status(500).json({ message: "Failed to fetch team" });
    }
  });

  app.post("/api/teams", isAuthenticated, async (req: any, res) => {
    try {
      const data = insertTeamSchema.parse({
        ...req.body,
        userId: req.user.id,
        twilioPhoneNumber: SHARED_TWILIO_NUMBER,
        phoneNumberStatus: 'shared',
      });
      const team = await storage.createTeam(data);
      res.json(team);
    } catch (error) {
      console.error("Error creating team:", error);
      res.status(400).json({ message: "Failed to create team" });
    }
  });

  app.patch("/api/teams/:id", isAuthenticated, async (req: any, res) => {
    try {
      const team = await storage.getTeam(req.params.id);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      // Only team owners and global admins can update team info
      if (team.userId !== userId && !user?.isGlobalAdmin) {
        return res.status(403).json({ message: "Forbidden: Only team owners or global admins can update teams" });
      }
      
      // Allow updating name, sport, and other basic fields
      const { name, sport } = req.body;
      const updates: Partial<InsertTeam> = {};
      
      if (name !== undefined) updates.name = name;
      if (sport !== undefined) updates.sport = sport;
      
      const updatedTeam = await storage.updateTeam(req.params.id, updates);
      res.json(updatedTeam);
    } catch (error) {
      console.error("Error updating team:", error);
      res.status(500).json({ message: "Failed to update team" });
    }
  });

  app.delete("/api/teams/:id", isAuthenticated, async (req: any, res) => {
    try {
      const team = await storage.getTeam(req.params.id);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (team.userId !== userId && !user?.isGlobalAdmin) {
        return res.status(403).json({ message: "Forbidden: Only team owners or global admins can delete teams" });
      }
      
      await storage.deleteTeam(req.params.id);
      res.json({ message: "Team deleted successfully" });
    } catch (error) {
      console.error("Error deleting team:", error);
      res.status(500).json({ message: "Failed to delete team" });
    }
  });

  app.patch("/api/teams/:id/message-board", isAuthenticated, requirePermission("canManageSettings"), async (req, res) => {
    try {
      const { enabled } = req.body;
      const team = await storage.updateTeam(req.params.id, { messageBoardEnabled: enabled });
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      res.json(team);
    } catch (error) {
      console.error("Error updating message board setting:", error);
      res.status(500).json({ message: "Failed to update message board setting" });
    }
  });

  app.patch("/api/teams/:id/instance-name", isAuthenticated, requirePermission("canManageSettings"), async (req, res) => {
    try {
      const { instanceName } = req.body;
      const team = await storage.updateTeam(req.params.id, { instanceName: instanceName || null });
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      res.json(team);
    } catch (error) {
      console.error("Error updating instance name:", error);
      res.status(500).json({ message: "Failed to update instance name" });
    }
  });

  // Update team invitation message template
  app.patch("/api/teams/:id/invitation-template", isAuthenticated, requirePermission("canManageSettings"), async (req, res) => {
    try {
      const { invitationMessageTemplate } = req.body;
      
      // Type validation: only accept string or null/undefined
      if (invitationMessageTemplate !== null && 
          invitationMessageTemplate !== undefined && 
          typeof invitationMessageTemplate !== 'string') {
        return res.status(400).json({ message: "Invitation template must be a string" });
      }
      
      // Normalize empty string to null (reset to default)
      const normalizedTemplate = typeof invitationMessageTemplate === 'string' && invitationMessageTemplate.trim() 
        ? invitationMessageTemplate.trim() 
        : null;
      
      // Validate template if provided (non-null after normalization)
      if (normalizedTemplate !== null) {
        // Must contain {inviteUrl} for the invitation link
        if (!normalizedTemplate.includes('{inviteUrl}')) {
          return res.status(400).json({ message: "Invitation template must include {inviteUrl} for the invitation link" });
        }
      }
      
      const team = await storage.updateTeam(req.params.id, { 
        invitationMessageTemplate: normalizedTemplate 
      });
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      res.json(team);
    } catch (error) {
      console.error("Error updating invitation template:", error);
      res.status(500).json({ message: "Failed to update invitation template" });
    }
  });

  // Team Join Code Management
  app.post("/api/teams/:id/join-code/generate", isAuthenticated, requirePermission("canManageSettings"), async (req: any, res) => {
    try {
      const team = await storage.getTeam(req.params.id);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }

      const crypto = await import("crypto");
      const joinCode = crypto.randomBytes(4).toString("hex").toUpperCase();
      
      const { expiryDays } = req.body;
      let joinCodeExpiry = null;
      if (expiryDays && typeof expiryDays === 'number' && expiryDays > 0) {
        joinCodeExpiry = new Date();
        joinCodeExpiry.setDate(joinCodeExpiry.getDate() + expiryDays);
      }

      const updatedTeam = await storage.updateTeam(req.params.id, {
        joinCode,
        joinCodeEnabled: true,
        joinCodeExpiry,
      });

      res.json({
        success: true,
        joinCode: updatedTeam?.joinCode,
        expiresAt: updatedTeam?.joinCodeExpiry,
      });
    } catch (error: any) {
      console.error("Error generating join code:", error);
      res.status(500).json({ message: error.message || "Failed to generate join code" });
    }
  });

  app.patch("/api/teams/:id/join-code/toggle", isAuthenticated, requirePermission("canManageSettings"), async (req, res) => {
    try {
      const { enabled } = req.body;
      if (typeof enabled !== 'boolean') {
        return res.status(400).json({ message: "enabled must be a boolean" });
      }

      const team = await storage.getTeam(req.params.id);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }

      if (!team.joinCode && enabled) {
        return res.status(400).json({ message: "No join code exists. Generate one first." });
      }

      const updatedTeam = await storage.updateTeam(req.params.id, {
        joinCodeEnabled: enabled,
      });

      res.json({
        success: true,
        joinCodeEnabled: updatedTeam?.joinCodeEnabled,
      });
    } catch (error: any) {
      console.error("Error toggling join code:", error);
      res.status(500).json({ message: error.message || "Failed to toggle join code" });
    }
  });

  app.delete("/api/teams/:id/join-code", isAuthenticated, requirePermission("canManageSettings"), async (req, res) => {
    try {
      const team = await storage.getTeam(req.params.id);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }

      const updatedTeam = await storage.updateTeam(req.params.id, {
        joinCode: null,
        joinCodeEnabled: false,
        joinCodeExpiry: null,
      });

      res.json({
        success: true,
        message: "Join code deleted successfully",
      });
    } catch (error: any) {
      console.error("Error deleting join code:", error);
      res.status(500).json({ message: error.message || "Failed to delete join code" });
    }
  });

  // Validate join code (public endpoint)
  app.get("/api/teams/join-code/:code", async (req, res) => {
    try {
      const { code } = req.params;
      
      const team = await db
        .select()
        .from(teams)
        .where(
          and(
            eq(teams.joinCode, code.toUpperCase()),
            eq(teams.joinCodeEnabled, true)
          )
        )
        .limit(1);

      if (!team || team.length === 0) {
        return res.status(404).json({ message: "Invalid or disabled join code" });
      }

      const teamData = team[0];

      if (teamData.joinCodeExpiry && new Date(teamData.joinCodeExpiry) < new Date()) {
        return res.status(410).json({ message: "This join code has expired" });
      }

      res.json({
        valid: true,
        teamId: teamData.id,
        teamName: teamData.name,
        sport: teamData.sport,
      });
    } catch (error: any) {
      console.error("Error validating join code:", error);
      res.status(500).json({ message: "Failed to validate join code" });
    }
  });

  // Pending Parent Join Requests Management
  app.get("/api/teams/:id/pending-joins", isAuthenticated, requirePermission("canManagePlayers"), async (req, res) => {
    try {
      const pendingJoins = await db
        .select()
        .from(pendingParentJoins)
        .where(
          and(
            eq(pendingParentJoins.teamId, req.params.id),
            eq(pendingParentJoins.status, "pending")
          )
        )
        .orderBy(pendingParentJoins.createdAt);

      res.json(pendingJoins);
    } catch (error: any) {
      console.error("Error fetching pending joins:", error);
      res.status(500).json({ message: "Failed to fetch pending joins" });
    }
  });

  app.post("/api/teams/:id/pending-joins", async (req, res) => {
    try {
      const data = insertPendingParentJoinSchema.parse({
        ...req.body,
        teamId: req.params.id,
      });

      const pendingJoin = await db
        .insert(pendingParentJoins)
        .values(data)
        .returning();

      res.status(201).json(pendingJoin[0]);
    } catch (error: any) {
      console.error("Error creating pending join:", error);
      res.status(400).json({ message: error.message || "Failed to create pending join" });
    }
  });

  app.post("/api/teams/:teamId/pending-joins/:joinId/approve", isAuthenticated, requirePermission("canManagePlayers"), async (req: any, res) => {
    try {
      const { teamId, joinId } = req.params;

      const [join] = await db
        .select()
        .from(pendingParentJoins)
        .where(
          and(
            eq(pendingParentJoins.id, joinId),
            eq(pendingParentJoins.teamId, teamId),
            eq(pendingParentJoins.status, "pending")
          )
        );

      if (!join) {
        return res.status(404).json({ message: "Pending join request not found" });
      }

      const { normalizePhoneForTwilio } = await import("../shared/phoneUtils");

      await db.transaction(async (tx: any) => {
        const normalizedPlayerPhone = normalizePhoneForTwilio(join.playerPhone);
        
        const player = await tx
          .insert(players)
          .values({
            teamId,
            firstName: join.playerFirstName,
            lastName: join.playerLastName,
            phone: normalizedPlayerPhone,
            email: join.playerEmail || "",
            parentId: join.parentUserId,
            dateOfBirth: join.playerDateOfBirth,
          })
          .returning();

        await tx
          .update(pendingParentJoins)
          .set({
            status: "approved",
            approvedByUserId: req.user.id,
            approvedAt: new Date(),
          })
          .where(eq(pendingParentJoins.id, joinId));

        res.json({
          success: true,
          player: player[0],
          message: "Join request approved successfully",
        });
      });
    } catch (error: any) {
      console.error("Error approving join request:", error);
      res.status(500).json({ message: error.message || "Failed to approve join request" });
    }
  });

  app.post("/api/teams/:teamId/pending-joins/:joinId/reject", isAuthenticated, requirePermission("canManagePlayers"), async (req: any, res) => {
    try {
      const { teamId, joinId } = req.params;
      const { reason } = req.body;

      const [join] = await db
        .select()
        .from(pendingParentJoins)
        .where(
          and(
            eq(pendingParentJoins.id, joinId),
            eq(pendingParentJoins.teamId, teamId),
            eq(pendingParentJoins.status, "pending")
          )
        );

      if (!join) {
        return res.status(404).json({ message: "Pending join request not found" });
      }

      await db
        .update(pendingParentJoins)
        .set({
          status: "rejected",
          rejectionReason: reason || "No reason provided",
          approvedByUserId: req.user.id,
          approvedAt: new Date(),
        })
        .where(eq(pendingParentJoins.id, joinId));

      res.json({
        success: true,
        message: "Join request rejected successfully",
      });
    } catch (error: any) {
      console.error("Error rejecting join request:", error);
      res.status(500).json({ message: error.message || "Failed to reject join request" });
    }
  });

  // Team Phone Number Management
  app.post("/api/teams/:id/provision-phone", isAuthenticated, requirePermission("canManageSettings"), async (req: any, res) => {
    try {
      const team = await storage.getTeam(req.params.id);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }

      if (team.phoneNumberStatus === 'active' && team.twilioPhoneNumber) {
        return res.status(400).json({ message: "Team already has an active phone number" });
      }

      const { phoneNumberService } = await import("./services/phoneNumberService");
      const { areaCode } = req.body;

      const result = await phoneNumberService.provisionPhoneNumber(req.params.id, {
        smsEnabled: true,
        areaCode: areaCode || undefined,
      });

      res.json({
        success: true,
        phoneNumber: result.phoneNumber,
        sid: result.sid,
        message: "Phone number provisioned successfully",
      });
    } catch (error: any) {
      console.error("Error provisioning phone number:", error);
      res.status(500).json({ message: error.message || "Failed to provision phone number" });
    }
  });

  app.delete("/api/teams/:id/phone-number", isAuthenticated, requirePermission("canManageSettings"), async (req: any, res) => {
    try {
      const team = await storage.getTeam(req.params.id);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }

      if (!team.twilioPhoneNumber) {
        return res.status(400).json({ message: "Team has no phone number to release" });
      }

      const { phoneNumberService } = await import("./services/phoneNumberService");
      await phoneNumberService.releasePhoneNumber(req.params.id);

      res.json({
        success: true,
        message: "Phone number released successfully",
      });
    } catch (error: any) {
      console.error("Error releasing phone number:", error);
      res.status(500).json({ message: error.message || "Failed to release phone number" });
    }
  });

  app.get("/api/teams/:id/message-stats", isAuthenticated, requirePermission("canManageSettings"), async (req: any, res) => {
    try {
      const { messageLogs: messageLogsTable, smsOptOuts: smsOptOutsTable } = await import("@shared/schema");
      
      // Get message counts
      const messageLogs = await db
        .select()
        .from(messageLogsTable)
        .where(eq(messageLogsTable.teamId, req.params.id));
      
      const outboundCount = messageLogs.filter((log: any) => log.direction === 'outbound').length;
      const inboundCount = messageLogs.filter((log: any) => log.direction === 'inbound').length;
      
      // Get opt-out count
      const optOuts = await db
        .select()
        .from(smsOptOutsTable)
        .where(and(
          eq(smsOptOutsTable.teamId, req.params.id),
          eq(smsOptOutsTable.isOptedOut, true)
        ));
      
      res.json({
        outboundCount,
        inboundCount,
        optOutCount: optOuts.length,
        totalMessages: messageLogs.length,
      });
    } catch (error: any) {
      console.error("Error fetching message stats:", error);
      res.status(500).json({ message: "Failed to fetch message stats" });
    }
  });

  app.get("/api/teams/:id/message-logs", isAuthenticated, requirePermission("canManageSettings"), async (req: any, res) => {
    try {
      const { messageLogs: messageLogsTable } = await import("@shared/schema");
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      
      // Get recent message logs with pagination
      const logs = await db
        .select()
        .from(messageLogsTable)
        .where(eq(messageLogsTable.teamId, req.params.id))
        .orderBy(desc(messageLogsTable.createdAt))
        .limit(limit)
        .offset(offset);
      
      res.json(logs);
    } catch (error: any) {
      console.error("Error fetching message logs:", error);
      res.status(500).json({ message: "Failed to fetch message logs" });
    }
  });

  app.get("/api/teams/:id/usage", isAuthenticated, requirePermission("canManageSettings"), async (req: any, res) => {
    try {
      const teamId = req.params.id;
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      
      const usage = await storage.getTeamUsage(teamId, startDate, endDate);
      res.json(usage);
    } catch (error: any) {
      console.error("Error fetching team usage:", error);
      res.status(500).json({ message: "Failed to fetch team usage" });
    }
  });

  app.get("/api/teams/:id/usage-summary", isAuthenticated, requirePermission("canManageSettings"), async (req: any, res) => {
    try {
      const teamId = req.params.id;
      
      // Default to current month if no dates provided
      const now = new Date();
      const startDate = req.query.startDate 
        ? new Date(req.query.startDate as string) 
        : new Date(now.getFullYear(), now.getMonth(), 1);
      const endDate = req.query.endDate 
        ? new Date(req.query.endDate as string) 
        : new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
      
      const summary = await storage.getTeamUsageSummary(teamId, startDate, endDate);
      res.json(summary);
    } catch (error: any) {
      console.error("Error fetching team usage summary:", error);
      res.status(500).json({ message: "Failed to fetch team usage summary" });
    }
  });

  // Roles
  app.get("/api/teams/:id/roles", async (req, res) => {
    try {
      const roles = await storage.getRoles(req.params.id);
      res.json(roles);
    } catch (error) {
      console.error("Error fetching roles:", error);
      res.status(500).json({ message: "Failed to fetch roles" });
    }
  });

  app.post("/api/teams/:id/roles", isAuthenticated, requirePermission("canManageRoles"), async (req, res) => {
    try {
      const data = insertRoleSchema.parse({
        ...req.body,
        teamId: req.params.id,
      });
      const role = await storage.createRole(data);
      res.json(role);
    } catch (error) {
      console.error("Error creating role:", error);
      res.status(400).json({ message: "Failed to create role" });
    }
  });

  app.put("/api/roles/:id", isAuthenticated, async (req: any, res) => {
    try {
      const existingRole = await storage.getRole(req.params.id);
      if (!existingRole) {
        return res.status(404).json({ message: "Role not found" });
      }
      
      const checker = requirePermission("canManageRoles");
      await new Promise((resolve, reject) => {
        checker({ ...req, params: { id: existingRole.teamId } }, res, (err?: any) => {
          if (err) reject(err);
          else resolve(undefined);
        });
      });

      // Only allow updating specific fields - exclude teamId and isDefault to prevent tampering
      const allowedUpdates = insertRoleSchema
        .pick({
          name: true,
          description: true,
          canViewEvents: true,
          canManageEvents: true,
          canViewPlayers: true,
          canManagePlayers: true,
          canSendReminders: true,
          canManageCampaigns: true,
          canViewResponses: true,
          canManageAttendance: true,
          canManageSettings: true,
          canManageRoles: true,
        })
        .partial();

      const data = allowedUpdates.parse(req.body);
      const role = await storage.updateRole(req.params.id, data);
      
      if (!role) {
        return res.status(404).json({ message: "Role not found" });
      }
      
      res.json(role);
    } catch (error) {
      console.error("Error updating role:", error);
      res.status(400).json({ message: "Failed to update role" });
    }
  });

  app.delete("/api/roles/:id", isAuthenticated, async (req: any, res) => {
    try {
      const role = await storage.getRole(req.params.id);
      if (!role) {
        return res.status(404).json({ message: "Role not found" });
      }

      const checker = requirePermission("canManageRoles");
      await new Promise((resolve, reject) => {
        checker({ ...req, params: { id: role.teamId } }, res, (err?: any) => {
          if (err) reject(err);
          else resolve(undefined);
        });
      });

      if (role.isDefault) {
        return res.status(400).json({ message: "Cannot delete default roles" });
      }
      await storage.deleteRole(req.params.id);
      res.json({ message: "Role deleted successfully" });
    } catch (error) {
      if (res.headersSent) return;
      console.error("Error deleting role:", error);
      res.status(500).json({ message: "Failed to delete role" });
    }
  });

  // Notification Settings
  app.get("/api/teams/:id/notification-settings", async (req, res) => {
    try {
      const settings = await storage.getNotificationSettings(req.params.id);
      res.json(settings);
    } catch (error) {
      console.error("Error fetching notification settings:", error);
      res.status(500).json({ message: "Failed to fetch notification settings" });
    }
  });

  app.post("/api/teams/:id/notification-settings", isAuthenticated, requirePermission("canManageSettings"), async (req, res) => {
    try {
      const { insertNotificationSettingsSchema } = await import("@shared/schema");
      const data = insertNotificationSettingsSchema.parse({
        ...req.body,
        teamId: req.params.id,
      });
      const settings = await storage.createNotificationSettings(data);
      res.json(settings);
    } catch (error) {
      console.error("Error creating notification settings:", error);
      res.status(400).json({ message: "Failed to create notification settings" });
    }
  });

  app.put("/api/teams/:id/notification-settings", isAuthenticated, requirePermission("canManageSettings"), async (req, res) => {
    try {
      const { insertNotificationSettingsSchema } = await import("@shared/schema");
      const allowedUpdates = insertNotificationSettingsSchema
        .omit({ teamId: true })
        .partial();
      
      const data = allowedUpdates.parse(req.body);
      const settings = await storage.updateNotificationSettings(req.params.id, data);
      
      if (!settings) {
        return res.status(404).json({ message: "Notification settings not found" });
      }
      
      res.json(settings);
    } catch (error) {
      console.error("Error updating notification settings:", error);
      res.status(400).json({ message: "Failed to update notification settings" });
    }
  });

  // Players
  app.get("/api/teams/:id/players", async (req, res) => {
    try {
      const players = await storage.getPlayers(req.params.id);
      res.json(players);
    } catch (error) {
      console.error("Error fetching players:", error);
      res.status(500).json({ message: "Failed to fetch players" });
    }
  });

  app.post("/api/teams/:id/players", isAuthenticated, requirePermission("canManagePlayers"), async (req, res) => {
    try {
      const data = insertPlayerSchema.parse({
        ...req.body,
        teamId: req.params.id,
      });
      const player = await storage.createPlayer(data);
      res.json(player);
    } catch (error) {
      console.error("Error creating player:", error);
      res.status(400).json({ message: "Failed to create player" });
    }
  });

  // Bulk upload players via CSV
  app.post("/api/teams/:id/players/bulk", isAuthenticated, requirePermission("canManagePlayers"), async (req, res) => {
    try {
      const { players } = req.body;
      
      if (!Array.isArray(players)) {
        return res.status(400).json({ message: "Players must be an array" });
      }

      const createdPlayers = [];
      const errors = [];

      for (let i = 0; i < players.length; i++) {
        try {
          const playerData = insertPlayerSchema.parse({
            ...players[i],
            teamId: req.params.id,
          });
          const player = await storage.createPlayer(playerData);
          createdPlayers.push(player);
        } catch (error) {
          errors.push({
            row: i + 2, // +2 because row 1 is header, and arrays are 0-indexed
            data: players[i],
            error: error instanceof Error ? error.message : "Validation failed",
          });
        }
      }

      res.json({
        success: errors.length === 0,
        created: createdPlayers.length,
        errors: errors,
        players: createdPlayers,
      });
    } catch (error) {
      console.error("Error bulk creating players:", error);
      res.status(500).json({ message: "Failed to bulk create players" });
    }
  });

  // Download CSV template for bulk player upload
  app.get("/api/teams/csv-template", async (req, res) => {
    const csvTemplate = `First,Last,Address,City,State,Zip,Birthdate,Jersey Number,Position,Email,Phone Number,Gender,Contact 1 Name,Contact 1 Phone,Contact 1 Email,Contact 1 Address,Contact 2 Name,Contact 2 Phone,Contact 2 Email,Contact 2 Address
John,Doe,123 Main St,Springfield,IL,62701,1990-05-15,10,Forward,john.doe@example.com,+15551234567,Male,Jane Doe,+15551234568,jane.doe@example.com,123 Main St,Bob Doe,+15551234569,bob.doe@example.com,123 Main St`;
    
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", "attachment; filename=roster_template.csv");
    res.send(csvTemplate);
  });

  // Export team roster as CSV
  app.get("/api/teams/:id/players/export", isAuthenticated, requirePermission("canManagePlayers"), async (req, res) => {
    try {
      const players = await storage.getPlayers(req.params.id);
      
      const csvHeader = "First,Last,Address,City,State,Zip,Birthdate,Jersey Number,Position,Email,Phone Number,Gender,Contact 1 Name,Contact 1 Phone,Contact 1 Email,Contact 1 Address,Contact 2 Name,Contact 2 Phone,Contact 2 Email,Contact 2 Address";
      
      const csvRows = players.map(p => {
        const escapeCsv = (val: any) => {
          if (val === null || val === undefined) return '';
          const str = String(val);
          if (str.includes(',') || str.includes('"') || str.includes('\n')) {
            return `"${str.replace(/"/g, '""')}"`;
          }
          return str;
        };
        
        return [
          escapeCsv(p.firstName),
          escapeCsv(p.lastName),
          escapeCsv(p.address),
          escapeCsv(p.city),
          escapeCsv(p.state),
          escapeCsv(p.zip),
          escapeCsv(p.dateOfBirth),
          escapeCsv(p.jerseyNumber),
          escapeCsv(p.position),
          escapeCsv(p.email),
          escapeCsv(p.phone),
          escapeCsv(p.gender),
          escapeCsv(p.contact1Name),
          escapeCsv(p.contact1Phone),
          escapeCsv(p.contact1Email),
          escapeCsv(p.contact1Address),
          escapeCsv(p.contact2Name),
          escapeCsv(p.contact2Phone),
          escapeCsv(p.contact2Email),
          escapeCsv(p.contact2Address),
        ].join(',');
      });
      
      const csv = [csvHeader, ...csvRows].join('\n');
      
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=roster_export.csv");
      res.send(csv);
    } catch (error) {
      console.error("Error exporting players:", error);
      res.status(500).json({ message: "Failed to export players" });
    }
  });

  // Send invitations to all players on a team
  app.post("/api/teams/:id/send-invitations", isAuthenticated, requirePermission("canManagePlayers"), async (req, res) => {
    try {
      const team = await storage.getTeam(req.params.id);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }

      const players = await storage.getPlayers(req.params.id);
      const user = await storage.getUser((req as any).user.id);
      
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }

      const appSettings = await storage.getAppSettings();
      const appName = appSettings?.applicationName || "TeamSyncAI";
      
      const sent = [];
      const failed = [];

      // Use custom template if available, otherwise use default announcement message
      const { replaceInvitationVariables, DEFAULT_INVITATION_TEMPLATE } = await import("./twilio");

      for (const player of players) {
        try {
          let message: string;
          
          if (team.invitationMessageTemplate) {
            // Use custom template with merge variables
            message = replaceInvitationVariables(team.invitationMessageTemplate, {
              teamName: team.name,
              roleName: "Player",
              coachName: user.firstName || user.email || "your coach",
              playerName: player.firstName || "Player",
              inviteUrl: "", // No invite URL for bulk announcements
            });
          } else {
            // Default message for bulk announcements (no invite link)
            message = `Hi ${player.firstName}! You've been added to ${team.name} on ${appName}. Your coach, ${user.firstName || user.email}, has invited you to join the team. Please contact them if you have any questions.`;
          }
          
          // Send SMS if player has phone number
          if (player.phone) {
            const twilioClient = await import("./twilio");
            await twilioClient.sendSMS(player.phone, message, { teamId: team.id, playerId: player.id });
            sent.push({ playerId: player.id, type: 'sms', to: player.phone });
          }
          
          // Future: could also send email if email exists
        } catch (error) {
          console.error(`Failed to send invitation to player ${player.id}:`, error);
          failed.push({ playerId: player.id, error: error instanceof Error ? error.message : 'Unknown error' });
        }
      }

      res.json({
        success: failed.length === 0,
        sent: sent.length,
        failed: failed.length,
        details: { sent, failed }
      });
    } catch (error) {
      console.error("Error sending invitations:", error);
      res.status(500).json({ message: "Failed to send invitations" });
    }
  });

  app.patch("/api/players/:id", isAuthenticated, async (req: any, res) => {
    try {
      const player = await storage.getPlayer(req.params.id);
      if (!player) {
        return res.status(404).json({ message: "Player not found" });
      }
      
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      // Parents can update their own child's player record, or users with canManagePlayers permission can update any player
      const isParentOfPlayer = user?.accountType === 'parent' && player.userId === userId;
      
      if (!isParentOfPlayer) {
        const checker = requirePermission("canManagePlayers");
        await new Promise((resolve, reject) => {
          checker({ ...req, params: { id: player.teamId } }, res, (err?: any) => {
            if (err) reject(err);
            else resolve(undefined);
          });
        });
      }

      // Filter out empty/whitespace strings to prevent clearing existing values
      const filteredData = Object.fromEntries(
        Object.entries(req.body).filter(([_, value]) => {
          if (value === null || value === undefined) return false;
          if (typeof value === 'string' && value.trim() === '') return false;
          return true;
        })
      );

      const updatedPlayer = await storage.updatePlayer(req.params.id, filteredData);
      res.json(updatedPlayer);
    } catch (error) {
      if (res.headersSent) return;
      console.error("Error updating player:", error);
      res.status(400).json({ message: "Failed to update player" });
    }
  });

  app.delete("/api/players/:id", isAuthenticated, async (req: any, res) => {
    try {
      const player = await storage.getPlayer(req.params.id);
      if (!player) {
        return res.status(404).json({ message: "Player not found" });
      }
      
      const checker = requirePermission("canManagePlayers");
      await new Promise((resolve, reject) => {
        checker({ ...req, params: { id: player.teamId } }, res, (err?: any) => {
          if (err) reject(err);
          else resolve(undefined);
        });
      });

      await storage.deletePlayer(req.params.id);
      res.json({ success: true });
    } catch (error) {
      if (res.headersSent) return;
      console.error("Error deleting player:", error);
      res.status(500).json({ message: "Failed to delete player" });
    }
  });

  // Events - only return events for teams the user has access to
  app.get("/api/events", isAuthenticated, async (req: any, res) => {
    try {
      const teamId = req.query.teamId as string | undefined;
      
      // Get teams the user has access to
      const userTeams = await storage.getTeamsForUser(req.user.id);
      const userTeamIds = new Set(userTeams.map(t => t.id));
      
      // Fetch events (optionally filtered by specific teamId)
      const eventsWithStats = await storage.getEventsWithStats(teamId);
      
      // Filter to only events from teams the user has access to
      const filteredEvents = eventsWithStats.filter(event => userTeamIds.has(event.teamId));
      
      res.json(filteredEvents);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  app.get("/api/events/upcoming", isAuthenticated, async (req: any, res) => {
    try {
      const events = await storage.getUpcomingEvents();
      
      // Filter to only events from teams the user has access to
      const userTeams = await storage.getTeamsForUser(req.user.id);
      const userTeamIds = new Set(userTeams.map(t => t.id));
      const filteredEvents = events.filter(event => userTeamIds.has(event.teamId));
      
      res.json(filteredEvents);
    } catch (error) {
      console.error("Error fetching upcoming events:", error);
      res.status(500).json({ message: "Failed to fetch upcoming events" });
    }
  });

  // Get unique locations from events
  app.get("/api/events/locations", async (req, res) => {
    try {
      const events = await storage.getEvents();
      const uniqueLocations = new Set(events.map(e => e.location).filter(Boolean));
      const locations = Array.from(uniqueLocations);
      res.json(locations.sort());
    } catch (error) {
      console.error("Error fetching locations:", error);
      res.status(500).json({ message: "Failed to fetch locations" });
    }
  });

  app.get("/api/teams/:teamId/events-without-campaigns", async (req, res) => {
    try {
      const events = await storage.getEventsWithoutCampaigns(req.params.teamId);
      res.json(events);
    } catch (error) {
      console.error("Error fetching events without campaigns:", error);
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  // Calendar feed for team events (iCalendar format)
  app.get("/api/teams/:teamId/calendar.ics", async (req, res) => {
    try {
      const team = await storage.getTeam(req.params.teamId);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }

      const teamEvents = await storage.getEvents(req.params.teamId);
      
      // Create calendar
      const calendar = ical({
        name: `${team.name} - TeamSyncAI`,
        prodId: {
          company: 'TeamSyncAI',
          product: 'TeamSync',
          language: 'EN'
        }
      });

      // Add events to calendar
      for (const event of teamEvents) {
        const eventStart = new Date(event.datetime);
        // Default to 2-hour duration for games, 1.5 hours for practices
        const durationHours = event.type === 'game' ? 2 : 1.5;
        const eventEnd = new Date(eventStart.getTime() + durationHours * 60 * 60 * 1000);

        let eventDescription = `Type: ${event.type}`;
        if (event.opponent) eventDescription += `\nOpponent: ${event.opponent}`;
        if (event.homeAway) eventDescription += `\nHome/Away: ${event.homeAway}`;
        if (event.jersey) eventDescription += `\nJersey: ${event.jersey}`;
        if (event.arrivalTime) eventDescription += `\nArrival Time: ${event.arrivalTime}`;
        if (event.notes && event.notes.trim()) eventDescription += `\n\nNotes: ${event.notes}`;

        calendar.createEvent({
          id: `${event.id}@teamsyncai.app`,
          sequence: event.sequence,
          start: eventStart,
          end: eventEnd,
          summary: event.title,
          description: eventDescription,
          location: event.location || undefined,
          stamp: event.updatedAt,
          lastModified: event.updatedAt,
          created: event.createdAt,
        });
      }

      // Set headers for calendar subscription
      res.set({
        'Content-Type': 'text/calendar; charset=utf-8',
        'Content-Disposition': `attachment; filename="${team.name.replace(/[^a-z0-9]/gi, '_')}_calendar.ics"`,
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      });

      res.send(calendar.toString());
    } catch (error) {
      console.error("Error generating calendar feed:", error);
      res.status(500).json({ message: "Failed to generate calendar feed" });
    }
  });

  app.get("/api/events/:id", async (req, res) => {
    try {
      const event = await storage.getEvent(req.params.id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      res.json(event);
    } catch (error) {
      console.error("Error fetching event:", error);
      res.status(500).json({ message: "Failed to fetch event" });
    }
  });

  app.post("/api/events", isAuthenticated, async (req: any, res) => {
    try {
      const data = insertEventSchema.parse(req.body);
      
      // Check permission before creating
      req.body.teamId = data.teamId; // Ensure teamId is in body for middleware
      const checker = requirePermission("canManageEvents");
      let permissionGranted = false;
      
      await new Promise<void>((resolve, reject) => {
        checker({ ...req, params: { id: data.teamId } }, res, (err?: any) => {
          if (err) {
            reject(err);
          } else {
            permissionGranted = true;
            resolve();
          }
        });
      });

      if (!permissionGranted || res.headersSent) {
        return;
      }

      const event = await storage.createEvent(data);
      
      // Automatically create default pending responses for all team players
      const players = await storage.getPlayers(event.teamId);
      for (const player of players) {
        await storage.createResponse({
          eventId: event.id,
          playerId: player.id,
          status: "pending",
          note: null,
          responseText: null,
        });
      }
      
      res.json(event);
    } catch (error) {
      if (res.headersSent) return;
      console.error("Error creating event:", error);
      res.status(400).json({ message: "Failed to create event" });
    }
  });

  app.delete("/api/events/:id", isAuthenticated, requirePermissionForEvent("canManageEvents"), async (req, res) => {
    try {
      await storage.deleteEvent(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting event:", error);
      res.status(500).json({ message: "Failed to delete event" });
    }
  });

  app.patch("/api/events/:id", isAuthenticated, requirePermissionForEvent("canManageEvents"), async (req, res) => {
    try {
      const eventId = req.params.id;
      const existingEvent = await storage.getEvent(eventId);
      
      if (!existingEvent) {
        return res.status(404).json({ message: "Event not found" });
      }

      // Define an update schema that allows partial updates
      // Note: teamId, id, sequence, createdAt, updatedAt are stripped before saving
      // Type accepts any string to match database schema (no enum constraint at DB level)
      const updateEventSchema = z.object({
        type: z.string().optional(),
        title: z.string().min(1).optional(),
        sport: z.string().optional(),
        datetime: z.union([
          z.date(),
          z.string().refine((val) => !isNaN(Date.parse(val)), {
            message: "Invalid datetime format"
          }).transform((val) => new Date(val)),
        ]).optional(),
        location: z.string().min(1).optional(),
        opponent: z.string().nullable().optional(),
        homeAway: z.string().nullable().optional(),
        fieldType: z.string().nullable().optional(),
        cleatsAllowed: z.string().nullable().optional(),
        jersey: z.string().nullable().optional(),
        arrivalTime: z.string().nullable().optional(),
        notes: z.string().nullable().optional(),
        customFieldValues: z.record(z.string(), z.any()).nullable().optional(),
        // Accept but ignore immutable fields (frontend may send them)
        teamId: z.string().optional(),
        id: z.string().optional(),
        sequence: z.number().optional(),
        createdAt: z.any().optional(),
        updatedAt: z.any().optional(),
      });

      // Parse and validate the request body
      const parseResult = updateEventSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid update data", 
          errors: parseResult.error.errors 
        });
      }

      // Strip immutable fields from validated data
      const { teamId: _, id: __, sequence: ___, createdAt: ____, updatedAt: _____, ...validatedUpdates } = parseResult.data;
      
      // Merge validated updates with existing event, preserving immutable/required fields
      const mergedEvent = {
        type: validatedUpdates.type ?? existingEvent.type,
        title: validatedUpdates.title ?? existingEvent.title,
        sport: validatedUpdates.sport ?? existingEvent.sport,
        datetime: validatedUpdates.datetime ?? existingEvent.datetime,
        location: validatedUpdates.location ?? existingEvent.location,
        opponent: validatedUpdates.opponent !== undefined ? validatedUpdates.opponent : existingEvent.opponent,
        homeAway: validatedUpdates.homeAway !== undefined ? validatedUpdates.homeAway : existingEvent.homeAway,
        fieldType: validatedUpdates.fieldType !== undefined ? validatedUpdates.fieldType : existingEvent.fieldType,
        cleatsAllowed: validatedUpdates.cleatsAllowed !== undefined ? validatedUpdates.cleatsAllowed : existingEvent.cleatsAllowed,
        jersey: validatedUpdates.jersey !== undefined ? validatedUpdates.jersey : existingEvent.jersey,
        arrivalTime: validatedUpdates.arrivalTime !== undefined ? validatedUpdates.arrivalTime : existingEvent.arrivalTime,
        notes: validatedUpdates.notes !== undefined ? validatedUpdates.notes : existingEvent.notes,
        customFieldValues: validatedUpdates.customFieldValues !== undefined ? validatedUpdates.customFieldValues : existingEvent.customFieldValues,
      };
      
      const updatedEvent = await storage.updateEvent(eventId, mergedEvent);
      
      if (!updatedEvent) {
        return res.status(500).json({ message: "Failed to update event" });
      }

      res.json(updatedEvent);
    } catch (error) {
      console.error("Error updating event:", error);
      res.status(500).json({ message: "Failed to update event" });
    }
  });

  // Event Responses (Attendance Dashboard)
  app.get("/api/events/:id/responses", async (req, res) => {
    try {
      const event = await storage.getEvent(req.params.id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      const players = await storage.getPlayers(event.teamId);
      const responses = await storage.getResponses(req.params.id);

      // Merge players with their responses
      const playersWithResponses = players.map((player) => {
        const response = responses.find((r) => r.playerId === player.id);
        return {
          ...player,
          response: response || null,
        };
      });

      res.json(playersWithResponses);
    } catch (error) {
      console.error("Error fetching event responses:", error);
      res.status(500).json({ message: "Failed to fetch event responses" });
    }
  });

  app.post("/api/events/:eventId/responses/:playerId", isAuthenticated, async (req: any, res) => {
    try {
      const { eventId, playerId } = req.params;
      const { status, note } = req.body;

      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      const checker = requirePermission("canManageAttendance");
      await new Promise((resolve, reject) => {
        checker({ ...req, params: { id: event.teamId } }, res, (err?: any) => {
          if (err) reject(err);
          else resolve(undefined);
        });
      });

      // Check if response exists
      const existing = await storage.getResponse(eventId, playerId);
      
      let response;
      if (existing) {
        response = await storage.updateResponse(existing.id, { status, note });
      } else {
        response = await storage.createResponse({
          eventId,
          playerId,
          status,
          note,
          responseText: null,
        });
      }

      res.json(response);
    } catch (error) {
      console.error("Error updating response:", error);
      res.status(500).json({ message: "Failed to update response" });
    }
  });

  // Get current user's player record for a team
  app.get("/api/teams/:teamId/my-player", isAuthenticated, async (req: any, res) => {
    try {
      const { teamId } = req.params;
      const userId = req.user.id;

      const player = await storage.getPlayerByUser(teamId, userId);
      
      if (!player) {
        return res.status(404).json({ message: "Player record not found for this team" });
      }

      res.json(player);
    } catch (error) {
      console.error("Error fetching player by user:", error);
      res.status(500).json({ message: "Failed to fetch player record" });
    }
  });

  // Self-RSVP endpoint for players
  app.post("/api/events/:eventId/my-response", isAuthenticated, async (req: any, res) => {
    try {
      const { eventId } = req.params;
      const { status, note } = req.body;
      const userId = req.user.id;

      // Validate status
      if (!["yes", "no", "maybe"].includes(status)) {
        return res.status(400).json({ message: "Invalid status. Must be 'yes', 'no', or 'maybe'" });
      }

      // Get event to determine teamId
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      // Find user's player record for this team
      const player = await storage.getPlayerByUser(event.teamId, userId);
      if (!player) {
        return res.status(404).json({ message: "You are not a player on this team" });
      }

      // Check if response exists
      const existing = await storage.getResponse(eventId, player.id);
      
      let response;
      if (existing) {
        response = await storage.updateResponse(existing.id, { status, note });
      } else {
        response = await storage.createResponse({
          eventId,
          playerId: player.id,
          status,
          note: note || null,
          responseText: null,
        });
      }

      // Notify coaches about the RSVP
      try {
        const roles = await storage.getRoles(event.teamId);
        const coachRoles = roles.filter(r => r.name === "Coach" || r.name === "Assistant Coach");
        const players = await storage.getPlayers(event.teamId);
        
        for (const coachRole of coachRoles) {
          const coachPlayers = players.filter(p => p.roleId === coachRole.id && p.userId);
          
          for (const coachPlayer of coachPlayers) {
            if (!coachPlayer.userId) continue;
            
            const statusText = status === "yes" ? "confirmed" : status === "no" ? "declined" : "marked as maybe";
            const playerFullName = `${player.firstName} ${player.lastName}`;
            const message = `${playerFullName} ${statusText} for ${event.title}`;
            
            await storage.createTeamNotification({
              teamId: event.teamId,
              userId: coachPlayer.userId,
              type: "rsvp_response",
              title: "New RSVP Response",
              message,
              metadata: {
                eventId: event.id,
                playerId: player.id,
                playerName: playerFullName,
                eventTitle: event.title,
                status,
              },
            });
          }
        }
      } catch (notificationError) {
        console.error("Error creating coach notifications:", notificationError);
      }

      res.json(response);
    } catch (error) {
      console.error("Error updating self-response:", error);
      res.status(500).json({ message: "Failed to update response" });
    }
  });

  // Player RSVP to Event (for Tasks page) - DEPRECATED, use my-response instead
  app.post("/api/events/:id/attendance", isAuthenticated, async (req: any, res) => {
    try {
      const { response: rsvpResponse } = req.body;
      const eventId = req.params.id;

      // Validate response
      if (!["yes", "no", "maybe"].includes(rsvpResponse)) {
        return res.status(400).json({ message: "Invalid response. Must be 'yes', 'no', or 'maybe'" });
      }

      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      // Get current user
      const user = await storage.getUser(req.user.id);
      if (!user || !user.email) {
        return res.status(401).json({ message: "User not found" });
      }

      // Find player record by matching email
      const players = await storage.getPlayers(event.teamId);
      const player = players.find(
        (p) => p.email?.toLowerCase() === user.email?.toLowerCase()
      );

      if (!player) {
        return res.status(403).json({ message: "You are not a member of this team" });
      }

      // Update or create response
      const existing = await storage.getResponse(eventId, player.id);
      
      const statusMap: Record<string, "yes" | "no" | "maybe"> = {
        yes: "yes",
        no: "no",
        maybe: "maybe",
      };

      const status = statusMap[rsvpResponse];
      const noteMap: Record<string, string> = {
        yes: "Confirmed",
        no: "Declined",
        maybe: "Maybe",
      };

      if (existing) {
        await storage.updateResponse(existing.id, {
          status,
          note: noteMap[rsvpResponse],
          responseText: rsvpResponse,
        });
      } else {
        await storage.createResponse({
          eventId,
          playerId: player.id,
          status,
          note: noteMap[rsvpResponse],
          responseText: rsvpResponse,
        });
      }

      res.json({ success: true, status });
    } catch (error) {
      console.error("Error recording RSVP:", error);
      res.status(500).json({ message: "Failed to record RSVP" });
    }
  });

  // Send Reminder via Twilio SMS
  app.post("/api/events/:id/send-reminder", isAuthenticated, requirePermissionForEvent("canSendReminders"), async (req: any, res) => {
    try {
      const { messageTemplate } = req.body;
      const event = await storage.getEvent(req.params.id);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      const players = await storage.getPlayers(event.teamId);
      const team = await storage.getTeam(event.teamId);
      const sendingUser = await storage.getUser(req.user.id);
      const coachName = sendingUser?.firstName || sendingUser?.email || 'Coach';
      
      // Send SMS to all players
      const eventDate = new Date(event.datetime);
      for (const player of players) {
        const personalizedMessage = replaceTemplateVariables(messageTemplate, {
          playerName: `${player.firstName || ''} ${player.lastName || ''}`.trim() || 'Player',
          firstName: player.firstName || 'Player',
          teamName: team?.name || 'Team',
          coachName: coachName,
          eventType: event.type,
          eventTitle: event.title,
          date: eventDate.toLocaleDateString(),
          eventDate: eventDate.toLocaleDateString(),
          time: eventDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          eventTime: eventDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          location: event.location,
          opponent: event.opponent || undefined,
          homeAway: event.homeAway || undefined,
          fieldType: event.fieldType || undefined,
          cleats: event.cleatsAllowed || undefined,
          jersey: event.jersey || undefined,
          arrivalTime: event.arrivalTime || undefined,
        });

        // Pass teamId, eventId, and playerId so message log is created
        // This enables the webhook to route SMS replies correctly
        await sendSMS(player.phone, personalizedMessage, {
          teamId: event.teamId,
          eventId: event.id,
          playerId: player.id,
        });
      }
      
      res.json({ success: true, count: players.length });
    } catch (error) {
      console.error("Error sending reminder:", error);
      res.status(500).json({ message: "Failed to send reminder" });
    }
  });

  // Twilio Webhook - Receive SMS responses from players
  app.post("/api/sms/webhook", async (req, res) => {
    try {
      const { From: from, Body: body, To: to, MessageSid: messageSid } = req.body;
      
      console.log(`Received SMS from ${from} to ${to}: ${body}`);

      // Find team by 'To' phone number
      // First check if this is the shared number by seeing if multiple teams use it
      const teamsWithNumber = await db.select().from(teams).where(eq(teams.twilioPhoneNumber, to));
      console.log(`[SMS Webhook] Teams with phone number ${to}: ${teamsWithNumber.length}`);
      
      let team;
      if (teamsWithNumber.length === 1) {
        // Only one team uses this number - it's a dedicated number
        team = teamsWithNumber[0];
        console.log(`[SMS Webhook] Found dedicated number for team: ${team.name} (${team.id})`);
      } else {
        // Multiple teams share this number (or no teams) - find team from recent message logs
        // Import message logs table
        const { messageLogs: messageLogsTable } = await import("@shared/schema");
        
        console.log(`[SMS Webhook] Searching message logs for outbound SMS to: ${from}`);
        
        // Find most recent outbound message to this sender to determine team context
        const recentLogs = await db
          .select()
          .from(messageLogsTable)
          .where(and(
            eq(messageLogsTable.toPhone, from),
            eq(messageLogsTable.direction, 'outbound')
          ))
          .orderBy(desc(messageLogsTable.createdAt))
          .limit(1);
        
        console.log(`[SMS Webhook] Found ${recentLogs.length} matching message logs`);
        
        if (recentLogs.length > 0) {
          console.log(`[SMS Webhook] Most recent log: teamId=${recentLogs[0].teamId}, toPhone=${recentLogs[0].toPhone}, createdAt=${recentLogs[0].createdAt}`);
          team = await storage.getTeam(recentLogs[0].teamId);
        }
      }

      if (!team) {
        console.log(`No team context found for ${from} -> ${to}`);
        res.status(200).send();
        return;
      }

      // Handle opt-out keywords (STOP, UNSTOP/START) - MUST work for both dedicated and shared numbers
      const normalizedBody = body.trim().toUpperCase();
      if (['STOP', 'STOPALL', 'UNSUBSCRIBE', 'CANCEL', 'END', 'QUIT'].includes(normalizedBody)) {
        // Create opt-out record
        await storage.createOptOut({
          teamId: team.id,
          phoneNumber: from,
          isOptedOut: true,
        });

        // Log the opt-out message
        await storage.createMessageLog({
          messageSid: messageSid,
          teamId: team.id,
          playerId: null,
          eventId: null,
          campaignId: null,
          direction: 'inbound',
          fromPhone: from,
          toPhone: to,
          body: body,
          status: 'received',
          errorCode: null,
          errorMessage: null,
        });

        // Send TCPA-compliant confirmation
        await sendSMS(from, 
          `You have been unsubscribed from ${team.name} SMS messages. Reply START to resubscribe.`,
          { teamId: team.id }
        );

        console.log(`${from} opted out from team ${team.id} (${team.name})`);
        res.status(200).send();
        return;
      }

      if (['START', 'UNSTOP', 'YES', 'SUBSCRIBE'].includes(normalizedBody)) {
        // Opt back in
        await storage.optBackIn(team.id, from);

        // Log the opt-in message
        await storage.createMessageLog({
          messageSid: messageSid,
          teamId: team.id,
          playerId: null,
          eventId: null,
          campaignId: null,
          direction: 'inbound',
          fromPhone: from,
          toPhone: to,
          body: body,
          status: 'received',
          errorCode: null,
          errorMessage: null,
        });

        // Send TCPA-compliant confirmation
        await sendSMS(from, 
          `You have been resubscribed to ${team.name} SMS messages. Reply STOP to opt out.`,
          { teamId: team.id }
        );

        console.log(`${from} opted back in for team ${team.id} (${team.name})`);
        res.status(200).send();
        return;
      }

      // Find player in this specific team by phone number
      // Normalize both incoming and stored phone numbers for comparison (remove spaces, hyphens, etc.)
      const normalizePhone = (phone: string) => phone.replace(/[\s\-()]/g, '');
      const normalizedFrom = normalizePhone(from);
      
      const players = await storage.getPlayers(team.id);
      const player = players.find((p) => normalizePhone(p.phone) === normalizedFrom);

      if (!player) {
        console.log(`No player found with phone ${from} (normalized: ${normalizedFrom}) in team ${team.id}`);
        res.status(200).send();
        return;
      }

      // Log the inbound message
      const messageLog = await storage.createMessageLog({
        messageSid: messageSid,
        teamId: team.id,
        playerId: player.id,
        eventId: null, // Will be updated after we determine which event
        campaignId: null,
        direction: 'inbound',
        fromPhone: from,
        toPhone: to,
        body: body,
        status: 'received',
        errorCode: null,
        errorMessage: null,
      });

      // Find most recent upcoming event for this player's team
      const events = await storage.getEvents(team.id);
      const upcomingEvents = events.filter((e) => new Date(e.datetime) > new Date());
      
      if (upcomingEvents.length === 0) {
        console.log(`No upcoming events found for player ${player.firstName} ${player.lastName}`);
        res.status(200).send();
        return;
      }

      const event = upcomingEvents[0];

      // Update message log with event ID
      await storage.updateMessageLog(messageLog.id, {
        eventId: event.id,
      });

      // Parse response using Gemini AI
      const parsed = await parsePlayerResponse(body);
      
      // Update or create response
      const existing = await storage.getResponse(event.id, player.id);
      
      if (existing) {
        await storage.updateResponse(existing.id, {
          status: parsed.status,
          note: parsed.note,
          responseText: body,
        });
      } else {
        await storage.createResponse({
          eventId: event.id,
          playerId: player.id,
          status: parsed.status,
          note: parsed.note,
          responseText: body,
        });
      }

      console.log(`Updated response for ${player.firstName} ${player.lastName} (Team: ${team.name}): ${parsed.status} - ${parsed.note}`);
      res.status(200).send();
    } catch (error) {
      console.error("Error processing SMS webhook:", error);
      res.status(200).send(); // Return 200 to avoid Twilio retries
    }
  });

  // Post-Game Confirmation
  app.post("/api/events/:id/confirm-attendance", isAuthenticated, requirePermissionForEvent("canManageAttendance"), async (req, res) => {
    try {
      const { attendance: attendanceData } = req.body;
      const event = await storage.getEvent(req.params.id);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      const players = await storage.getPlayers(event.teamId);
      const responses = await storage.getResponses(req.params.id);

      // Process each player's attendance and update reliability scores
      for (const player of players) {
        const attended = attendanceData[player.id] || false;
        const response = responses.find((r) => r.playerId === player.id);
        
        // Record attendance
        await storage.createAttendance({
          eventId: req.params.id,
          playerId: player.id,
          actuallyAttended: attended,
        });

        // Calculate reliability score adjustment
        let scoreChange = 0;
        let reason = "";

        const committed = response?.status === "yes";
        const declined = response?.status === "no";
        const maybe = response?.status === "maybe";

        if (committed && attended) {
          scoreChange = 1;
          reason = "Showed up as committed";
        } else if (committed && !attended) {
          scoreChange = -1;
          reason = "No-show after committing";
        } else if ((declined || maybe) && attended) {
          scoreChange = 0.5;
          reason = "Showed up despite declining/maybe";
        } else if (maybe && !attended) {
          scoreChange = -0.5;
          reason = "Didn't show after saying maybe";
        }

        // Update reliability score
        if (scoreChange !== 0) {
          const oldScore = player.reliabilityScore;
          const newScore = Math.max(1, Math.min(5, oldScore + scoreChange));
          
          await storage.updatePlayer(player.id, { reliabilityScore: newScore });
          await storage.createReliabilityHistory({
            playerId: player.id,
            eventId: req.params.id,
            oldScore,
            newScore,
            reason,
          });
        }
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Error confirming attendance:", error);
      res.status(500).json({ message: "Failed to confirm attendance" });
    }
  });

  // Lineup Management (Baseball/Softball Only)
  app.get("/api/lineups/:eventId", isAuthenticated, async (req: any, res) => {
    try {
      const event = await storage.getEvent(req.params.eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      // Validate sport
      if (!['Baseball', 'Softball'].includes(event.sport)) {
        return res.status(400).json({ message: "Lineups are only available for Baseball and Softball" });
      }

      // Check tier access
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      // Allow global admins to bypass tier checks
      if (!user?.isGlobalAdmin) {
        if (!user?.membershipTierId) {
          return res.status(403).json({ message: "Lineup management requires a Coach or Pro membership" });
        }
        
        // Check if user is in active trial period
        const now = new Date();
        const isInTrial = user.trialEndDate && new Date(user.trialEndDate) > now;
        
        if (!isInTrial) {
          // Only enforce feature check if not in trial
          const tier = await storage.getUserMembershipTier(userId);
          const hasLineupFeature = tier?.features.some(f => f.featureKey === 'lineup_management' && f.enabled);
          if (!hasLineupFeature) {
            return res.status(403).json({ message: "Lineup management requires a Coach or Pro membership" });
          }
        }
      }

      // Check permission
      const checker = requirePermission("canManagePlayers");
      await new Promise((resolve, reject) => {
        checker({ ...req, params: { id: event.teamId } }, res, (err?: any) => {
          if (err) reject(err);
          else resolve(undefined);
        });
      });

      const lineup = await storage.getLineup(req.params.eventId);
      res.json(lineup || null);
    } catch (error) {
      console.error("Error fetching lineup:", error);
      res.status(500).json({ message: "Failed to fetch lineup" });
    }
  });

  app.post("/api/lineups/:eventId/generate", isAuthenticated, async (req: any, res) => {
    try {
      const event = await storage.getEvent(req.params.eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      // Validate sport
      if (!['Baseball', 'Softball'].includes(event.sport)) {
        return res.status(400).json({ message: "Lineups are only available for Baseball and Softball" });
      }

      // Check tier access
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      // Allow global admins to bypass tier checks
      if (!user?.isGlobalAdmin) {
        if (!user?.membershipTierId) {
          return res.status(403).json({ message: "Lineup management requires a Coach or Pro membership" });
        }
        
        // Check if user is in active trial period
        const now = new Date();
        const isInTrial = user.trialEndDate && new Date(user.trialEndDate) > now;
        
        if (!isInTrial) {
          // Only enforce feature check if not in trial
          const tier = await storage.getUserMembershipTier(userId);
          const hasLineupFeature = tier?.features.some(f => f.featureKey === 'lineup_management' && f.enabled);
          if (!hasLineupFeature) {
            return res.status(403).json({ message: "Lineup management requires a Coach or Pro membership" });
          }
        }
      }

      // Check permission - lineup management requires event management permission
      const checker = requirePermissionForEvent("canManageEvents");
      await new Promise((resolve, reject) => {
        checker(req, res, (err?: any) => {
          if (err) reject(err);
          else resolve(undefined);
        });
      });

      // Get lineup size from request body (default to 9 if not provided)
      const lineupSize = req.body.lineupSize || 9;
      
      // Validate lineup size
      if (lineupSize < 1) {
        return res.status(400).json({ message: "Lineup size must be at least 1" });
      }

      // Get players and attendance data
      const players = await storage.getPlayers(event.teamId);
      const responses = await storage.getResponses(req.params.eventId);
      const attendance = await storage.getAttendance(req.params.eventId);

      // Combine responses and attendance for AI generation
      const attendanceData = [...responses, ...attendance];
      
      // Calculate attending players
      const attendingPlayerIds = attendanceData
        .filter(a => ('status' in a && a.status === 'yes') || ('attended' in a && a.attended))
        .map(a => a.playerId);
      const attendingPlayers = players.filter(p => attendingPlayerIds.includes(p.id));
      
      // Validate lineup size doesn't exceed attending players
      if (lineupSize > attendingPlayers.length) {
        return res.status(400).json({ 
          message: `Cannot create lineup with ${lineupSize} players. Only ${attendingPlayers.length} players are attending.` 
        });
      }

      // Generate lineup using AI
      const lineupData = await generateOptimalLineup({
        event,
        players,
        attendance: attendanceData,
        lineupSize,
      });

      // Save lineup
      const lineup = await storage.createLineup({
        eventId: req.params.eventId,
        teamId: event.teamId,
        battingOrder: lineupData.battingOrder as any,
        pitchingRotation: lineupData.pitchingRotation as any,
        reserves: lineupData.reserves as any,
        generatedBy: 'ai',
        generatedAt: new Date(),
      });

      res.json(lineup);
    } catch (error) {
      console.error("Error generating lineup:", error);
      res.status(500).json({ message: "Failed to generate lineup" });
    }
  });

  app.post("/api/lineups/:eventId", isAuthenticated, async (req: any, res) => {
    try {
      const event = await storage.getEvent(req.params.eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      // Validate sport
      if (!['Baseball', 'Softball'].includes(event.sport)) {
        return res.status(400).json({ message: "Lineups are only available for Baseball and Softball" });
      }

      // Check tier access
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      // Allow global admins to bypass tier checks
      if (!user?.isGlobalAdmin) {
        if (!user?.membershipTierId) {
          return res.status(403).json({ message: "Lineup management requires a Coach or Pro membership" });
        }
        
        // Check if user is in active trial period
        const now = new Date();
        const isInTrial = user.trialEndDate && new Date(user.trialEndDate) > now;
        
        if (!isInTrial) {
          // Only enforce feature check if not in trial
          const tier = await storage.getUserMembershipTier(userId);
          const hasLineupFeature = tier?.features.some(f => f.featureKey === 'lineup_management' && f.enabled);
          if (!hasLineupFeature) {
            return res.status(403).json({ message: "Lineup management requires a Coach or Pro membership" });
          }
        }
      }

      // Check permission - lineup management requires event management permission
      const checker = requirePermissionForEvent("canManageEvents");
      await new Promise((resolve, reject) => {
        checker(req, res, (err?: any) => {
          if (err) reject(err);
          else resolve(undefined);
        });
      });

      const { battingOrder, pitchingRotation, reserves } = req.body;

      // Save lineup
      const lineup = await storage.createLineup({
        eventId: req.params.eventId,
        teamId: event.teamId,
        battingOrder: battingOrder as any,
        pitchingRotation: pitchingRotation as any,
        reserves: reserves as any,
        generatedBy: userId,
        generatedAt: new Date(),
      });

      res.json(lineup);
    } catch (error) {
      console.error("Error saving lineup:", error);
      res.status(500).json({ message: "Failed to save lineup" });
    }
  });

  app.delete("/api/lineups/:eventId", isAuthenticated, async (req: any, res) => {
    try {
      const event = await storage.getEvent(req.params.eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      // Validate sport
      if (!['Baseball', 'Softball'].includes(event.sport)) {
        return res.status(400).json({ message: "Lineups are only available for Baseball and Softball" });
      }

      // Check tier access
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      // Allow global admins to bypass tier checks
      if (!user?.isGlobalAdmin) {
        if (!user?.membershipTierId) {
          return res.status(403).json({ message: "Lineup management requires a Coach or Pro membership" });
        }
        
        // Check if user is in active trial period
        const now = new Date();
        const isInTrial = user.trialEndDate && new Date(user.trialEndDate) > now;
        
        if (!isInTrial) {
          // Only enforce feature check if not in trial
          const tier = await storage.getUserMembershipTier(userId);
          const hasLineupFeature = tier?.features.some(f => f.featureKey === 'lineup_management' && f.enabled);
          if (!hasLineupFeature) {
            return res.status(403).json({ message: "Lineup management requires a Coach or Pro membership" });
          }
        }
      }

      // Check permission - lineup management requires event management permission
      const checker = requirePermissionForEvent("canManageEvents");
      await new Promise((resolve, reject) => {
        checker(req, res, (err?: any) => {
          if (err) reject(err);
          else resolve(undefined);
        });
      });

      await storage.deleteLineup(req.params.eventId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting lineup:", error);
      res.status(500).json({ message: "Failed to delete lineup" });
    }
  });

  // Campaigns
  app.get("/api/events/:id/campaign", async (req, res) => {
    try {
      const campaign = await storage.getCampaign(req.params.id);
      res.json(campaign || null);
    } catch (error) {
      console.error("Error fetching campaign:", error);
      res.status(500).json({ message: "Failed to fetch campaign" });
    }
  });

  app.post("/api/events/:id/campaign", isAuthenticated, requirePermissionForEvent("canManageCampaigns"), async (req, res) => {
    try {
      // Get event to get teamId
      const event = await storage.getEvent(req.params.id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      const campaign = await storage.createCampaign({
        teamId: event.teamId,
        eventId: req.params.id,
        isActive: true,
      });
      res.json(campaign);
    } catch (error) {
      console.error("Error creating campaign:", error);
      res.status(400).json({ message: "Failed to create campaign" });
    }
  });

  // Create standalone campaign (not tied to an event)
  app.post("/api/teams/:teamId/campaigns", isAuthenticated, requirePermission("canManageCampaigns"), async (req: any, res) => {
    try {
      const campaign = await storage.createCampaign({
        teamId: req.params.teamId,
        eventId: null,
        isActive: true,
      });
      res.json(campaign);
    } catch (error) {
      console.error("Error creating standalone campaign:", error);
      res.status(400).json({ message: "Failed to create campaign" });
    }
  });

  app.post("/api/events/:id/apply-template", async (req, res) => {
    try {
      const { templateId } = req.body;
      if (!templateId) {
        return res.status(400).json({ message: "Template ID is required" });
      }

      // Get event to verify it exists and get its team
      const event = await storage.getEvent(req.params.id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      // Get template to verify ownership
      const template = await storage.getCampaignTemplate(templateId);
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }

      // Verify template belongs to the same team as the event
      if (template.teamId !== event.teamId) {
        return res.status(403).json({ message: "Cannot apply template from a different team" });
      }

      // Get or create campaign for this event
      let campaign = await storage.getCampaign(req.params.id);
      if (!campaign) {
        campaign = await storage.createCampaign({
          teamId: event.teamId,
          eventId: req.params.id,
          isActive: true,
        });
      }

      // Get template reminders
      const templateReminders = await storage.getTemplateReminders(templateId);

      // Create campaign reminders from template
      // Note: This appends reminders; duplicates are possible if template is applied multiple times
      const createdReminders = [];
      for (const templateReminder of templateReminders) {
        const reminder = await storage.createReminder({
          campaignId: campaign.id,
          intervalHours: templateReminder.intervalHours,
          messageTemplate: templateReminder.messageTemplate,
          targetReliabilityThreshold: templateReminder.targetReliabilityThreshold,
          minReliability: templateReminder.minReliability,
          maxReliability: templateReminder.maxReliability,
          targetStatusFilter: templateReminder.targetStatusFilter,
        });
        createdReminders.push(reminder);
      }

      res.json({
        campaign,
        reminders: createdReminders,
        count: createdReminders.length,
      });
    } catch (error) {
      console.error("Error applying template:", error);
      res.status(500).json({ message: "Failed to apply template" });
    }
  });

  // Reminders
  app.get("/api/campaigns/:id/reminders", async (req, res) => {
    try {
      const reminders = await storage.getReminders(req.params.id);
      res.json(reminders);
    } catch (error) {
      console.error("Error fetching reminders:", error);
      res.status(500).json({ message: "Failed to fetch reminders" });
    }
  });

  app.post("/api/campaigns/:id/reminders", async (req, res) => {
    try {
      const { intervalHours, targetReliabilityThreshold, minReliability, maxReliability, targetStatusFilter, messageTemplate } = req.body;
      
      // Validate required fields
      if (!intervalHours || typeof intervalHours !== 'number' || intervalHours <= 0) {
        return res.status(400).json({ message: "Invalid interval hours" });
      }
      if (!messageTemplate || typeof messageTemplate !== 'string' || messageTemplate.trim() === '') {
        return res.status(400).json({ message: "Message template is required" });
      }

      // Validate reliability ranges
      if (minReliability !== undefined && minReliability !== null && (typeof minReliability !== 'number' || minReliability < 0 || minReliability > 5)) {
        return res.status(400).json({ message: "minReliability must be between 0 and 5" });
      }
      if (maxReliability !== undefined && maxReliability !== null && (typeof maxReliability !== 'number' || maxReliability < 0 || maxReliability > 5)) {
        return res.status(400).json({ message: "maxReliability must be between 0 and 5" });
      }
      if (minReliability !== undefined && minReliability !== null && maxReliability !== undefined && maxReliability !== null && minReliability > maxReliability) {
        return res.status(400).json({ message: "minReliability cannot be greater than maxReliability" });
      }
      
      const reminder = await storage.createReminder({
        campaignId: req.params.id,
        intervalHours,
        targetReliabilityThreshold,
        minReliability: minReliability !== undefined ? minReliability : null,
        maxReliability: maxReliability !== undefined ? maxReliability : null,
        targetStatusFilter,
        messageTemplate: messageTemplate.trim(),
      });
      res.json(reminder);
    } catch (error) {
      console.error("Error creating reminder:", error);
      res.status(400).json({ message: "Failed to create reminder" });
    }
  });

  app.put("/api/reminders/:id", async (req, res) => {
    try {
      const { intervalHours, targetReliabilityThreshold, targetStatusFilter, messageTemplate } = req.body;
      
      // Validate required fields
      if (intervalHours !== undefined && (typeof intervalHours !== 'number' || intervalHours <= 0)) {
        return res.status(400).json({ message: "Invalid interval hours" });
      }
      if (messageTemplate !== undefined && (typeof messageTemplate !== 'string' || messageTemplate.trim() === '')) {
        return res.status(400).json({ message: "Message template cannot be empty" });
      }
      if (targetReliabilityThreshold !== undefined && targetReliabilityThreshold !== null) {
        if (typeof targetReliabilityThreshold !== 'number' || targetReliabilityThreshold < 1 || targetReliabilityThreshold > 5) {
          return res.status(400).json({ message: "Target reliability threshold must be between 1 and 5" });
        }
      }
      
      const updateData: any = {};
      if (intervalHours !== undefined) updateData.intervalHours = intervalHours;
      if (messageTemplate !== undefined) updateData.messageTemplate = messageTemplate.trim();
      if (targetReliabilityThreshold !== undefined) updateData.targetReliabilityThreshold = targetReliabilityThreshold;
      if (targetStatusFilter !== undefined) updateData.targetStatusFilter = targetStatusFilter;
      
      const reminder = await storage.updateReminder(req.params.id, updateData);
      if (!reminder) {
        return res.status(404).json({ message: "Reminder not found" });
      }
      res.json(reminder);
    } catch (error) {
      console.error("Error updating reminder:", error);
      res.status(400).json({ message: "Failed to update reminder" });
    }
  });

  app.delete("/api/reminders/:id", async (req, res) => {
    try {
      await storage.deleteReminder(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting reminder:", error);
      res.status(500).json({ message: "Failed to delete reminder" });
    }
  });

  // Manual reminder sending
  app.post("/api/events/:id/send-reminder-now", isAuthenticated, requirePermissionForEvent("canSendReminders"), async (req: any, res) => {
    try {
      const { messageTemplate } = req.body;
      const event = await storage.getEvent(req.params.id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      const players = await storage.getPlayers(event.teamId);
      const team = await storage.getTeam(event.teamId);
      const sendingUser = await storage.getUser(req.user.id);
      const coachName = sendingUser?.firstName || sendingUser?.email || 'Coach';
      const eventDate = new Date(event.datetime);
      
      let sentCount = 0;
      for (const player of players) {
        const personalizedMessage = replaceTemplateVariables(messageTemplate, {
          playerName: `${player.firstName || ''} ${player.lastName || ''}`.trim() || 'Player',
          firstName: player.firstName || 'Player',
          teamName: team?.name || 'Team',
          coachName: coachName,
          eventType: event.type,
          eventTitle: event.title,
          date: eventDate.toLocaleDateString(),
          eventDate: eventDate.toLocaleDateString(),
          time: eventDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          eventTime: eventDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          location: event.location,
          opponent: event.opponent || undefined,
          homeAway: event.homeAway || undefined,
          fieldType: event.fieldType || undefined,
          cleats: event.cleatsAllowed || undefined,
          jersey: event.jersey || undefined,
          arrivalTime: event.arrivalTime || undefined,
        });

        // Pass teamId, eventId, and playerId so message log is created
        // This enables the webhook to route SMS replies correctly
        await sendSMS(player.phone, personalizedMessage, {
          teamId: event.teamId,
          eventId: event.id,
          playerId: player.id,
        });
        sentCount++;
      }

      res.json({ success: true, sentCount });
    } catch (error) {
      console.error("Error sending manual reminder:", error);
      res.status(500).json({ message: "Failed to send reminder" });
    }
  });

  // Get all campaigns with their events and reminders
  app.get("/api/campaigns", async (req, res) => {
    try {
      const allCampaigns = await storage.getAllCampaigns();
      // Flatten the event data for easier consumption on the frontend
      const flattened = allCampaigns.map(campaign => ({
        id: campaign.id,
        eventId: campaign.eventId,
        eventTitle: campaign.event.title,
        eventDate: campaign.event.datetime,
        eventType: campaign.event.type,
        reminders: campaign.reminders,
      }));
      res.json(flattened);
    } catch (error) {
      console.error("Error fetching all campaigns:", error);
      res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  // Delete a campaign
  app.delete("/api/campaigns/:id", async (req, res) => {
    try {
      const campaign = await storage.getCampaignById(req.params.id);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      await storage.deleteCampaign(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting campaign:", error);
      res.status(500).json({ message: "Failed to delete campaign" });
    }
  });

  // Campaign Templates
  app.get("/api/teams/:teamId/campaign-templates", async (req, res) => {
    try {
      // Get both team-specific templates and global admin templates
      const [teamTemplates, globalTemplates] = await Promise.all([
        storage.getCampaignTemplates(req.params.teamId),
        storage.getGlobalCampaignTemplates()
      ]);
      
      // Combine them, with team templates first
      const allTemplates = [...teamTemplates, ...globalTemplates];
      res.json(allTemplates);
    } catch (error) {
      console.error("Error fetching campaign templates:", error);
      res.status(500).json({ message: "Failed to fetch campaign templates" });
    }
  });

  app.get("/api/campaign-templates/:id", async (req, res) => {
    try {
      const template = await storage.getCampaignTemplate(req.params.id);
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      res.json(template);
    } catch (error) {
      console.error("Error fetching campaign template:", error);
      res.status(500).json({ message: "Failed to fetch campaign template" });
    }
  });

  app.post("/api/teams/:teamId/campaign-templates", async (req, res) => {
    try {
      const { name, description } = req.body;
      
      if (!name || typeof name !== 'string' || name.trim() === '') {
        return res.status(400).json({ message: "Template name is required" });
      }

      const template = await storage.createCampaignTemplate({
        teamId: req.params.teamId,
        name: name.trim(),
        description: description?.trim() || null,
      });

      res.json(template);
    } catch (error) {
      console.error("Error creating campaign template:", error);
      res.status(400).json({ message: "Failed to create campaign template" });
    }
  });

  app.patch("/api/campaign-templates/:id", async (req, res) => {
    try {
      const { name, description } = req.body;
      const updateData: any = {};
      
      if (name !== undefined) {
        if (typeof name !== 'string' || name.trim() === '') {
          return res.status(400).json({ message: "Invalid template name" });
        }
        updateData.name = name.trim();
      }
      
      if (description !== undefined) {
        updateData.description = description?.trim() || null;
      }

      const updated = await storage.updateCampaignTemplate(req.params.id, updateData);
      if (!updated) {
        return res.status(404).json({ message: "Template not found" });
      }

      res.json(updated);
    } catch (error) {
      console.error("Error updating campaign template:", error);
      res.status(500).json({ message: "Failed to update campaign template" });
    }
  });

  app.delete("/api/campaign-templates/:id", async (req, res) => {
    try {
      await storage.deleteCampaignTemplate(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting campaign template:", error);
      res.status(500).json({ message: "Failed to delete campaign template" });
    }
  });

  // Template Reminders
  app.get("/api/campaign-templates/:id/reminders", async (req, res) => {
    try {
      const reminders = await storage.getTemplateReminders(req.params.id);
      res.json(reminders);
    } catch (error) {
      console.error("Error fetching template reminders:", error);
      res.status(500).json({ message: "Failed to fetch template reminders" });
    }
  });

  app.post("/api/campaign-templates/:id/reminders", async (req, res) => {
    try {
      const { intervalHours, targetReliabilityThreshold, minReliability, maxReliability, targetStatusFilter, messageTemplate } = req.body;
      
      if (!intervalHours || typeof intervalHours !== 'number' || intervalHours <= 0) {
        return res.status(400).json({ message: "Invalid interval hours" });
      }
      if (!messageTemplate || typeof messageTemplate !== 'string' || messageTemplate.trim() === '') {
        return res.status(400).json({ message: "Message template is required" });
      }

      if (minReliability !== undefined && minReliability !== null && (typeof minReliability !== 'number' || minReliability < 0 || minReliability > 5)) {
        return res.status(400).json({ message: "minReliability must be between 0 and 5" });
      }
      if (maxReliability !== undefined && maxReliability !== null && (typeof maxReliability !== 'number' || maxReliability < 0 || maxReliability > 5)) {
        return res.status(400).json({ message: "maxReliability must be between 0 and 5" });
      }
      if (minReliability !== undefined && minReliability !== null && maxReliability !== undefined && maxReliability !== null && minReliability > maxReliability) {
        return res.status(400).json({ message: "minReliability cannot be greater than maxReliability" });
      }

      const reminder = await storage.createTemplateReminder({
        templateId: req.params.id,
        intervalHours,
        targetReliabilityThreshold: targetReliabilityThreshold || null,
        minReliability: minReliability !== undefined ? minReliability : null,
        maxReliability: maxReliability !== undefined ? maxReliability : null,
        targetStatusFilter: targetStatusFilter || null,
        messageTemplate: messageTemplate.trim(),
      });

      res.json(reminder);
    } catch (error) {
      console.error("Error creating template reminder:", error);
      res.status(400).json({ message: "Failed to create template reminder" });
    }
  });

  app.patch("/api/template-reminders/:id", async (req, res) => {
    try {
      const { intervalHours, targetReliabilityThreshold, minReliability, maxReliability, targetStatusFilter, messageTemplate } = req.body;
      const updateData: any = {};

      if (intervalHours !== undefined) {
        if (typeof intervalHours !== 'number' || intervalHours <= 0) {
          return res.status(400).json({ message: "Invalid interval hours" });
        }
        updateData.intervalHours = intervalHours;
      }

      if (targetReliabilityThreshold !== undefined) {
        updateData.targetReliabilityThreshold = targetReliabilityThreshold || null;
      }

      if (minReliability !== undefined) {
        if (minReliability !== null && (typeof minReliability !== 'number' || minReliability < 0 || minReliability > 5)) {
          return res.status(400).json({ message: "minReliability must be between 0 and 5" });
        }
        updateData.minReliability = minReliability;
      }

      if (maxReliability !== undefined) {
        if (maxReliability !== null && (typeof maxReliability !== 'number' || maxReliability < 0 || maxReliability > 5)) {
          return res.status(400).json({ message: "maxReliability must be between 0 and 5" });
        }
        updateData.maxReliability = maxReliability;
      }

      if (targetStatusFilter !== undefined) {
        updateData.targetStatusFilter = targetStatusFilter || null;
      }

      if (messageTemplate !== undefined) {
        if (typeof messageTemplate !== 'string' || messageTemplate.trim() === '') {
          return res.status(400).json({ message: "Invalid message template" });
        }
        updateData.messageTemplate = messageTemplate.trim();
      }

      const updated = await storage.updateTemplateReminder(req.params.id, updateData);
      if (!updated) {
        return res.status(404).json({ message: "Template reminder not found" });
      }

      res.json(updated);
    } catch (error) {
      console.error("Error updating template reminder:", error);
      res.status(500).json({ message: "Failed to update template reminder" });
    }
  });

  app.delete("/api/template-reminders/:id", async (req, res) => {
    try {
      await storage.deleteTemplateReminder(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting template reminder:", error);
      res.status(500).json({ message: "Failed to delete template reminder" });
    }
  });

  // Apply campaign template to event
  app.post("/api/events/:eventId/apply-template/:templateId", async (req, res) => {
    try {
      const { eventId, templateId } = req.params;

      // Get the template and its reminders
      const template = await storage.getCampaignTemplate(templateId);
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }

      const templateReminders = await storage.getTemplateReminders(templateId);

      // Get event to get teamId
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      // Create campaign for event if it doesn't exist
      let campaign = await storage.getCampaign(eventId);
      if (!campaign) {
        campaign = await storage.createCampaign({
          teamId: event.teamId,
          eventId,
          isActive: true,
        });
      }

      // Create reminders based on template
      const createdReminders = [];
      for (const templateReminder of templateReminders) {
        const reminder = await storage.createReminder({
          campaignId: campaign.id,
          intervalHours: templateReminder.intervalHours,
          targetReliabilityThreshold: templateReminder.targetReliabilityThreshold,
          targetStatusFilter: templateReminder.targetStatusFilter,
          messageTemplate: templateReminder.messageTemplate,
        });
        createdReminders.push(reminder);
      }

      res.json({ campaign, reminders: createdReminders });
    } catch (error) {
      console.error("Error applying template:", error);
      res.status(500).json({ message: "Failed to apply template" });
    }
  });

  // Get next scheduled reminder for an event
  app.get("/api/events/:id/next-reminder", async (req, res) => {
    try {
      const event = await storage.getEvent(req.params.id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }

      const campaign = await storage.getCampaign(req.params.id);
      if (!campaign) {
        return res.json({ nextReminder: null });
      }

      const reminders = await storage.getReminders(campaign.id);
      if (reminders.length === 0) {
        return res.json({ nextReminder: null });
      }

      const eventDate = new Date(event.datetime);
      const now = new Date();
      
      const nextReminders = reminders
        .map(reminder => ({
          ...reminder,
          scheduledTime: new Date(eventDate.getTime() - reminder.intervalHours * 60 * 60 * 1000)
        }))
        .filter(r => r.scheduledTime > now)
        .sort((a, b) => a.scheduledTime.getTime() - b.scheduledTime.getTime());

      res.json({ 
        nextReminder: nextReminders[0] || null,
        allUpcoming: nextReminders
      });
    } catch (error) {
      console.error("Error fetching next reminder:", error);
      res.status(500).json({ message: "Failed to fetch next reminder" });
    }
  });

  // Message Board - Messages
  app.get("/api/teams/:teamId/messages", isAuthenticated, async (req, res) => {
    try {
      const messages = await storage.getMessages(req.params.teamId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/teams/:teamId/messages", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      
      // Validate request body with schema (ensures at least content or imageUrl)
      const validationResult = insertMessageSchema.safeParse({
        teamId: req.params.teamId,
        userId,
        content: req.body.content || null,
        imageUrl: req.body.imageUrl || null,
        isPinned: false,
      });
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Invalid message data", 
          errors: validationResult.error.errors 
        });
      }
      
      const message = await storage.createMessage(validationResult.data);
      res.status(201).json(message);
    } catch (error) {
      console.error("Error creating message:", error);
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  app.patch("/api/messages/:id", isAuthenticated, async (req, res) => {
    try {
      const message = await storage.updateMessage(req.params.id, req.body);
      if (!message) {
        return res.status(404).json({ message: "Message not found" });
      }
      res.json(message);
    } catch (error) {
      console.error("Error updating message:", error);
      res.status(500).json({ message: "Failed to update message" });
    }
  });

  app.delete("/api/messages/:id", isAuthenticated, async (req, res) => {
    try {
      await storage.deleteMessage(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting message:", error);
      res.status(500).json({ message: "Failed to delete message" });
    }
  });

  app.patch("/api/messages/:id/pin", isAuthenticated, async (req: any, res) => {
    try {
      const message = await storage.getMessage(req.params.id);
      if (!message) {
        return res.status(404).json({ message: "Message not found" });
      }
      
      const team = await storage.getTeam(message.teamId);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      
      if (team.userId && team.userId !== req.user.id) {
        return res.status(403).json({ message: "Only team owners can pin messages" });
      }
      
      const updatedMessage = await storage.pinMessage(req.params.id, req.body.isPinned);
      res.json(updatedMessage);
    } catch (error) {
      console.error("Error pinning message:", error);
      res.status(500).json({ message: "Failed to pin message" });
    }
  });

  // Message Board - Reactions
  app.post("/api/messages/:messageId/reactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const { emoji } = req.body;
      
      const existingReaction = await storage.getUserReaction(req.params.messageId, userId, emoji);
      if (existingReaction) {
        await storage.deleteMessageReaction(req.params.messageId, userId, emoji);
        return res.status(204).send();
      }
      
      const reaction = await storage.createMessageReaction({
        messageId: req.params.messageId,
        userId,
        emoji,
      });
      res.status(201).json(reaction);
    } catch (error) {
      console.error("Error toggling reaction:", error);
      res.status(500).json({ message: "Failed to toggle reaction" });
    }
  });

  app.delete("/api/messages/:messageId/reactions/:emoji", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      await storage.deleteMessageReaction(req.params.messageId, userId, req.params.emoji);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting reaction:", error);
      res.status(500).json({ message: "Failed to delete reaction" });
    }
  });

  // Object Storage - Legacy route (only works in Replit)
  // Endpoint for serving uploaded objects (public logos)
  app.get("/objects/:objectPath(*)", async (req, res) => {
    try {
      // This route only works when using Replit's object storage
      const objectStorageService = new ObjectStorageService();
      const objectFile = await objectStorageService.getObjectEntityFile(
        req.path,
      );
      objectStorageService.downloadObject(objectFile, res);
    } catch (error) {
      console.error("Error accessing object:", error);
      if (error instanceof ObjectNotFoundError) {
        return res.sendStatus(404);
      }
      if ((error as Error).message?.includes("not configured")) {
        // Object storage not available (e.g., on Render) - this is expected
        return res.status(404).json({ error: "File not found" });
      }
      return res.sendStatus(500);
    }
  });

  // Endpoint for getting upload URL for logo (legacy - use UploadThing instead)
  app.post("/api/objects/upload", async (req, res) => {
    try {
      // This route only works when using Replit's object storage
      const objectStorageService = new ObjectStorageService();
      const uploadURL = await objectStorageService.getObjectEntityUploadURL();
      res.json({ uploadURL });
    } catch (error) {
      console.error("Error generating upload URL:", error);
      if ((error as Error).message?.includes("not configured")) {
        // Object storage not available - suggest using UploadThing instead
        return res.status(503).json({ error: "Please use the file upload button instead" });
      }
      res.status(500).json({ error: "Failed to generate upload URL" });
    }
  });

  // Endpoint for updating team logo (supports both UploadThing and legacy object storage URLs)
  app.put("/api/teams/:id/logo", async (req, res) => {
    if (!req.body.logoUrl) {
      return res.status(400).json({ error: "logoUrl is required" });
    }

    try {
      let normalizedPath = req.body.logoUrl;

      // UploadThing URLs: Store as-is (they're already publicly accessible CDN URLs)
      // Legacy Replit Object Storage URLs: Normalize to local path
      if (normalizedPath.startsWith("https://storage.googleapis.com/")) {
        try {
          const objectStorageService = new ObjectStorageService();
          normalizedPath = objectStorageService.normalizeObjectEntityPath(normalizedPath);
        } catch (error) {
          console.warn("[Logo Update] Object storage normalization failed, storing URL as-is:", error);
        }
      }

      const team = await storage.updateTeam(req.params.id, { logoUrl: normalizedPath });
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }

      res.status(200).json({
        objectPath: normalizedPath,
        team,
      });
    } catch (error) {
      console.error("Error setting team logo:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Endpoint for updating organization logo (supports both UploadThing and legacy object storage URLs)
  app.put("/api/user/organization-logo", isAuthenticated, async (req: any, res) => {
    if (!req.body.logoUrl) {
      return res.status(400).json({ error: "logoUrl is required" });
    }

    if (!req.user) {
      return res.status(401).json({ error: "User not authenticated" });
    }

    try {
      let normalizedPath = req.body.logoUrl;

      // UploadThing URLs: Store as-is (they're already publicly accessible CDN URLs)
      // Legacy Replit Object Storage URLs: Normalize to local path
      if (normalizedPath.startsWith("https://storage.googleapis.com/")) {
        try {
          const objectStorageService = new ObjectStorageService();
          normalizedPath = objectStorageService.normalizeObjectEntityPath(normalizedPath);
        } catch (error) {
          console.warn("[Logo Update] Object storage normalization failed, storing URL as-is:", error);
        }
      }

      // Fetch the existing user to preserve all fields
      const existingUser = await storage.getUser(req.user.id);
      if (!existingUser) {
        return res.status(404).json({ error: "User not found" });
      }

      // Merge the organization logo update with existing user data
      const user = await storage.upsertUser({
        ...existingUser,
        organizationLogoUrl: normalizedPath,
      });

      res.status(200).json({
        objectPath: normalizedPath,
        user,
      });
    } catch (error) {
      console.error("Error setting organization logo:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // ========== INVITATIONS API ==========
  
  // Create a team invitation
  app.post("/api/teams/:teamId/invitations", isAuthenticated, requirePermission("canManagePlayers"), async (req: any, res) => {
    try {
      const { teamId } = req.params;
      const { contactType, contactValue, roleId, sendNotification } = req.body;

      // Validate required fields
      if (!contactType || !contactValue || !roleId) {
        return res.status(400).json({ error: "contactType, contactValue, and roleId are required" });
      }

      // Check for existing pending invitation
      const existingInvitation = await storage.getPendingInvitation(teamId, contactValue);
      if (existingInvitation) {
        return res.status(409).json({ 
          error: "An active invitation already exists for this contact",
          invitation: existingInvitation
        });
      }

      // Generate secure token (using crypto)
      const crypto = await import("crypto");
      const token = crypto.randomBytes(32).toString("hex");

      // Set expiration to 7 days from now
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7);

      const invitation = await storage.createInvitation({
        teamId,
        invitedByUserId: req.user.id,
        contactType,
        contactValue,
        roleId,
        status: "pending",
        token,
        expiresAt,
      });

      // Send invitation notification if requested
      if (sendNotification !== false && contactType === "phone") {
        try {
          const team = await storage.getTeam(teamId);
          const role = await storage.getRole(roleId);
          const invitingUser = await storage.getUser(req.user.id);
          
          if (team && role) {
            const { sendInvitationSMS } = await import("./twilio");
            await sendInvitationSMS(contactValue, team.name, role.name, token, {
              customTemplate: team.invitationMessageTemplate || undefined,
              coachName: invitingUser?.firstName || invitingUser?.email || undefined,
              teamId: team.id,
            });
          }
        } catch (smsError) {
          console.error("Failed to send invitation SMS:", smsError);
          // Don't fail the whole request if SMS fails
        }
      }

      res.status(201).json(invitation);
    } catch (error) {
      console.error("Error creating invitation:", error);
      res.status(500).json({ error: "Failed to create invitation" });
    }
  });

  // Get all invitations for a team
  app.get("/api/teams/:teamId/invitations", isAuthenticated, requirePermission("canManagePlayers"), async (req, res) => {
    try {
      const invitations = await storage.getInvitations(req.params.teamId);
      res.json(invitations);
    } catch (error) {
      console.error("Error fetching invitations:", error);
      res.status(500).json({ error: "Failed to fetch invitations" });
    }
  });

  // Get invitation by token (public - for accepting invitations)
  app.get("/api/invitations/token/:token", async (req, res) => {
    try {
      const invitation = await storage.getInvitationByToken(req.params.token);
      
      if (!invitation) {
        return res.status(404).json({ error: "Invitation not found" });
      }

      // Check if expired
      if (new Date() > new Date(invitation.expiresAt)) {
        await storage.updateInvitation(invitation.id, { status: "expired" });
        return res.status(410).json({ error: "Invitation has expired" });
      }

      // Check if already accepted
      if (invitation.status !== "pending") {
        return res.status(410).json({ error: `Invitation ${invitation.status}` });
      }

      // Get team and role details
      const team = await storage.getTeam(invitation.teamId);
      const role = await storage.getRole(invitation.roleId);

      res.json({
        invitation,
        team,
        role,
      });
    } catch (error) {
      console.error("Error fetching invitation:", error);
      res.status(500).json({ error: "Failed to fetch invitation" });
    }
  });

  // Cancel an invitation
  app.patch("/api/invitations/:id/cancel", isAuthenticated, async (req: any, res) => {
    try {
      // Fetch invitation to get team ID for permission check
      const invitation = await storage.getInvitation(req.params.id);
      if (!invitation) {
        return res.status(404).json({ error: "Invitation not found" });
      }

      // Check permissions for this team
      req.params.teamId = invitation.teamId;
      const checker = requirePermission("canManagePlayers");
      let hasPermission = true;
      await checker(req, res, () => { hasPermission = true; });
      if (!hasPermission) return;

      // Cancel the invitation
      const cancelled = await storage.cancelInvitation(req.params.id);
      res.json(cancelled);
    } catch (error) {
      console.error("Error cancelling invitation:", error);
      res.status(500).json({ error: "Failed to cancel invitation" });
    }
  });

  // Resend an invitation (updates expiration and generates new token)
  app.post("/api/invitations/:id/resend", isAuthenticated, async (req: any, res) => {
    try {
      const invitation = await storage.getInvitation(req.params.id);
      
      if (!invitation) {
        return res.status(404).json({ error: "Invitation not found" });
      }

      // Check permissions for this team
      req.params.teamId = invitation.teamId;
      const checker = requirePermission("canManagePlayers");
      let hasPermission = true;
      await checker(req, res, () => { hasPermission = true; });
      if (!hasPermission) return;

      // Generate new token
      const crypto = await import("crypto");
      const token = crypto.randomBytes(32).toString("hex");

      // Set new expiration
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7);

      const updated = await storage.updateInvitation(invitation.id, {
        token,
        expiresAt,
        status: "pending",
      });

      // Send invitation notification if phone type
      if (invitation.contactType === "phone") {
        try {
          const team = await storage.getTeam(invitation.teamId);
          const role = await storage.getRole(invitation.roleId);
          const resendingUser = await storage.getUser(req.user.id);
          
          if (team && role) {
            const { sendInvitationSMS } = await import("./twilio");
            await sendInvitationSMS(invitation.contactValue, team.name, role.name, token, {
              customTemplate: team.invitationMessageTemplate || undefined,
              coachName: resendingUser?.firstName || resendingUser?.email || undefined,
              teamId: team.id,
            });
          }
        } catch (smsError) {
          console.error("Failed to send invitation SMS:", smsError);
          // Don't fail the whole request if SMS fails
        }
      }

      res.json(updated);
    } catch (error) {
      console.error("Error resending invitation:", error);
      res.status(500).json({ error: "Failed to resend invitation" });
    }
  });

  // Accept an invitation (link to existing player or create new player record)
  app.post("/api/invitations/:token/accept", isAuthenticated, async (req: any, res) => {
    try {
      const invitation = await storage.getInvitationByToken(req.params.token);
      
      if (!invitation) {
        return res.status(404).json({ error: "Invitation not found" });
      }

      // Check if expired
      if (new Date() > new Date(invitation.expiresAt)) {
        await storage.updateInvitation(invitation.id, { status: "expired" });
        return res.status(410).json({ error: "Invitation has expired" });
      }

      // Check if already accepted
      if (invitation.status !== "pending") {
        return res.status(410).json({ error: `Invitation already ${invitation.status}` });
      }

      // Get user details from auth
      const user = req.user;

      // Check if player already exists on this team with matching contact
      const existingPlayer = await storage.findPlayerByContact(invitation.teamId, invitation.contactValue, invitation.contactType as "email" | "phone");
      
      let player;
      
      if (existingPlayer) {
        // Found existing player record - update it to link to this user
        
        // Check if player is already linked to a different user
        if (existingPlayer.userId && existingPlayer.userId !== user.id) {
          return res.status(409).json({ 
            error: "This player is already linked to a different account. Please contact your team administrator." 
          });
        }
        
        // Update existing player with user link and latest profile info
        player = await storage.updatePlayer(existingPlayer.id, {
          userId: user.id,
          firstName: user.firstName || existingPlayer.firstName,
          lastName: user.lastName || existingPlayer.lastName,
          email: invitation.contactType === "email" 
            ? invitation.contactValue 
            : (user.email || existingPlayer.email),
          phone: invitation.contactType === "phone" 
            ? invitation.contactValue 
            : existingPlayer.phone,
          roleId: invitation.roleId, // Update role from invitation
        });
      } else {
        // No existing player - create new player record with user link
        player = await storage.createPlayer({
          teamId: invitation.teamId,
          roleId: invitation.roleId,
          userId: user.id, // Link to user account
          firstName: user.firstName || "",
          lastName: user.lastName || "",
          phone: invitation.contactType === "phone" ? invitation.contactValue : "",
          email: invitation.contactType === "email" ? invitation.contactValue : user.email || "",
        });
      }

      // Mark invitation as accepted
      await storage.updateInvitation(invitation.id, {
        status: "accepted",
        acceptedAt: new Date(),
        acceptedByUserId: user.id,
      });

      res.json({ player });
    } catch (error) {
      console.error("Error accepting invitation:", error);
      res.status(500).json({ error: "Failed to accept invitation" });
    }
  });

  // ========== TEAM DOCUMENTS API ==========

  // Create a team document
  app.post("/api/teams/:teamId/documents", isAuthenticated, requirePermission("canManageSettings"), async (req: any, res) => {
    try {
      const { teamId } = req.params;
      const { title, description, fileUrl, requiresSignature } = req.body;

      if (!title || !fileUrl) {
        return res.status(400).json({ error: "title and fileUrl are required" });
      }

      // Use UploadThing URL directly (no object storage needed)
      const document = await storage.createTeamDocument({
        teamId,
        title,
        description,
        fileUrl, // Store the UploadThing URL as-is
        requiresSignature: requiresSignature !== undefined ? requiresSignature : true,
        version: 1,
        createdByUserId: req.user.id,
      });

      res.status(201).json(document);
    } catch (error) {
      console.error("Error creating document:", error);
      res.status(500).json({ error: "Failed to create document" });
    }
  });

  // Get all documents for a team (active only)
  app.get("/api/teams/:teamId/documents", async (req, res) => {
    try {
      const documents = await storage.getActiveTeamDocuments(req.params.teamId);
      res.json(documents);
    } catch (error) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ error: "Failed to fetch documents" });
    }
  });

  // Get all signatures for a team's documents with user info
  app.get("/api/teams/:teamId/signatures", isAuthenticated, requirePermission("canManageSettings"), async (req: any, res) => {
    try {
      const { teamId } = req.params;
      
      // Get all documents for this team
      const documents = await storage.getActiveTeamDocuments(teamId);
      const docIds = documents.map(d => d.id);
      
      if (docIds.length === 0) {
        return res.json([]);
      }

      // Get all signatures for these documents with user info
      const signaturesWithUsers = await db
        .select({
          id: documentSignatures.id,
          documentId: documentSignatures.documentId,
          userId: documentSignatures.userId,
          signedAt: documentSignatures.signedAt,
          acknowledgmentText: documentSignatures.acknowledgmentText,
          documentVersion: documentSignatures.documentVersion,
          userFirstName: users.firstName,
          userLastName: users.lastName,
          userEmail: users.email,
        })
        .from(documentSignatures)
        .leftJoin(users, eq(documentSignatures.userId, users.id))
        .where(inArray(documentSignatures.documentId, docIds))
        .orderBy(desc(documentSignatures.signedAt));

      res.json(signaturesWithUsers);
    } catch (error) {
      console.error("Error fetching signatures:", error);
      res.status(500).json({ error: "Failed to fetch signatures" });
    }
  });

  // Get a specific document
  app.get("/api/documents/:id", async (req, res) => {
    try {
      const document = await storage.getTeamDocument(req.params.id);
      
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }

      res.json(document);
    } catch (error) {
      console.error("Error fetching document:", error);
      res.status(500).json({ error: "Failed to fetch document" });
    }
  });

  // Archive a document
  app.patch("/api/documents/:id/archive", isAuthenticated, async (req: any, res) => {
    try {
      // Fetch document to get team ID for permission check
      const document = await storage.getTeamDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }

      // Check permissions for this team
      req.params.teamId = document.teamId;
      const checker = requirePermission("canManageSettings");
      let hasPermission = true;
      await checker(req, res, () => { hasPermission = true; });
      if (!hasPermission) return;

      // Archive the document
      const archived = await storage.archiveTeamDocument(req.params.id);
      res.json(archived);
    } catch (error) {
      console.error("Error archiving document:", error);
      res.status(500).json({ error: "Failed to archive document" });
    }
  });

  // ========== DOCUMENT SIGNATURES API ==========

  // Get signatures for a document
  app.get("/api/documents/:id/signatures", isAuthenticated, async (req, res) => {
    try {
      const signatures = await storage.getDocumentSignatures(req.params.id);
      res.json(signatures);
    } catch (error) {
      console.error("Error fetching signatures:", error);
      res.status(500).json({ error: "Failed to fetch signatures" });
    }
  });

  // Create a document signature
  app.post("/api/documents/:documentId/signatures", isAuthenticated, async (req: any, res) => {
    try {
      const { documentId } = req.params;
      const { acknowledgmentText, invitationId } = req.body;

      // Get document to retrieve version
      const document = await storage.getTeamDocument(documentId);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }

      // Check if already signed
      const alreadySigned = await storage.hasUserSignedDocument(req.user.id, documentId);
      if (alreadySigned) {
        return res.status(409).json({ error: "Document already signed by this user" });
      }

      // Extract IP and user agent
      const ipAddress = req.ip || req.connection.remoteAddress;
      const userAgent = req.get("user-agent");

      const signature = await storage.createDocumentSignature({
        documentId,
        userId: req.user.id,
        invitationId: invitationId || null,
        documentVersion: document.version,
        acknowledgmentText: acknowledgmentText || null,
        ipAddress,
        userAgent,
      });

      res.status(201).json(signature);
    } catch (error) {
      console.error("Error creating signature:", error);
      res.status(500).json({ error: "Failed to create signature" });
    }
  });

  // Get user's signatures for a team
  app.get("/api/teams/:teamId/my-signatures", isAuthenticated, async (req: any, res) => {
    try {
      const signatures = await storage.getUserSignatures(req.user.id, req.params.teamId);
      res.json(signatures);
    } catch (error) {
      console.error("Error fetching user signatures:", error);
      res.status(500).json({ error: "Failed to fetch signatures" });
    }
  });

  // Payment Request Routes
  // GET /api/payment-requests - Fetch payment requests for a team
  app.get("/api/payment-requests", isAuthenticated, async (req: any, res) => {
    try {
      const { team: teamId } = req.query;
      
      if (!teamId) {
        return res.status(400).json({ error: "Team ID is required" });
      }

      // Verify user has access to this team
      const team = await db
        .select()
        .from(teams)
        .where(eq(teams.id, teamId as string))
        .limit(1);

      if (team.length === 0) {
        return res.status(404).json({ error: "Team not found" });
      }

      // Check if user owns the team or is a player on the team
      const isOwner = team[0].userId === req.user.id;
      
      if (!isOwner && !req.user.isGlobalAdmin) {
        // Check if user is a player on the team
        const player = await db
          .select()
          .from(players)
          .where(
            and(
              eq(players.teamId, teamId as string),
              eq(players.email, req.user.email)
            )
          )
          .limit(1);

        if (player.length === 0) {
          return res.status(403).json({ error: "You don't have access to this team" });
        }
      }

      // Fetch payment requests for the team
      const paymentRequests = await db
        .select()
        .from(teamPaymentRequests)
        .where(eq(teamPaymentRequests.teamId, teamId as string))
        .orderBy(desc(teamPaymentRequests.createdAt));

      res.json(paymentRequests);
    } catch (error) {
      console.error("Error fetching payment requests:", error);
      res.status(500).json({ error: "Failed to fetch payment requests" });
    }
  });

  // GET /api/payment-requests/:id/status - Get payment status for a payment request
  app.get("/api/payment-requests/:id/status", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;

      // Fetch the payment request
      const paymentRequest = await db
        .select()
        .from(teamPaymentRequests)
        .where(eq(teamPaymentRequests.id, id))
        .limit(1);

      if (paymentRequest.length === 0) {
        return res.status(404).json({ error: "Payment request not found" });
      }

      // Verify user has access to this team
      const team = await db
        .select()
        .from(teams)
        .where(eq(teams.id, paymentRequest[0].teamId))
        .limit(1);

      if (team.length === 0) {
        return res.status(404).json({ error: "Team not found" });
      }

      const isOwner = team[0].userId === req.user.id;
      
      if (!isOwner && !req.user.isGlobalAdmin) {
        // Check if user is a player on the team
        const player = await db
          .select()
          .from(players)
          .where(
            and(
              eq(players.teamId, paymentRequest[0].teamId),
              eq(players.email, req.user.email)
            )
          )
          .limit(1);

        if (player.length === 0) {
          return res.status(403).json({ error: "You don't have access to this team" });
        }
      }

      // Fetch all payment links for this request
      const paymentLinks = await db
        .select({
          playerId: paymentRequestTokens.playerId,
          playerFirstName: players.firstName,
          playerLastName: players.lastName,
          playerEmail: players.email,
          channel: paymentRequestTokens.channel,
          createdAt: paymentRequestTokens.createdAt,
          usedAt: paymentRequestTokens.usedAt,
        })
        .from(paymentRequestTokens)
        .innerJoin(players, eq(paymentRequestTokens.playerId, players.id))
        .where(eq(paymentRequestTokens.paymentRequestId, id))
        .orderBy(players.lastName, players.firstName);

      // Fetch all completed payments for this request
      const payments = await db
        .select({
          playerId: teamPayments.playerId,
          playerFirstName: players.firstName,
          playerLastName: players.lastName,
          status: teamPayments.status,
          paidAt: teamPayments.paidAt,
          payerEmail: teamPayments.payerEmail,
        })
        .from(teamPayments)
        .innerJoin(players, eq(teamPayments.playerId, players.id))
        .where(eq(teamPayments.paymentRequestId, id));

      // Group payment data by player
      const playerPaymentMap = new Map();

      // Add payment link data
      for (const link of paymentLinks) {
        if (!playerPaymentMap.has(link.playerId)) {
          playerPaymentMap.set(link.playerId, {
            playerId: link.playerId,
            playerName: `${link.playerFirstName} ${link.playerLastName}`,
            playerEmail: link.playerEmail,
            linkSent: true,
            linkChannel: link.channel,
            linkSentAt: link.createdAt,
            status: 'pending',
            paidAt: null,
          });
        }
      }

      // Add payment status data
      for (const payment of payments) {
        const key = payment.playerId;
        if (playerPaymentMap.has(key)) {
          const existing = playerPaymentMap.get(key);
          playerPaymentMap.set(key, {
            ...existing,
            status: payment.status,
            paidAt: payment.paidAt,
          });
        } else {
          // Payment without a link sent (shouldn't normally happen, but handle it)
          playerPaymentMap.set(key, {
            playerId: payment.playerId,
            playerName: `${payment.playerFirstName} ${payment.playerLastName}`,
            playerEmail: payment.payerEmail,
            linkSent: false,
            linkChannel: null,
            linkSentAt: null,
            status: payment.status,
            paidAt: payment.paidAt,
          });
        }
      }

      const playerPayments = Array.from(playerPaymentMap.values());
      const totalPlayers = playerPayments.length;
      const completedCount = playerPayments.filter(p => p.status === 'completed').length;

      res.json({
        totalPlayers,
        completedCount,
        pendingCount: totalPlayers - completedCount,
        playerPayments,
      });
    } catch (error) {
      console.error("Error fetching payment status:", error);
      res.status(500).json({ error: "Failed to fetch payment status" });
    }
  });

  // POST /api/payment-requests - Create a new payment request
  app.post("/api/payment-requests", isAuthenticated, requirePermission("canManagePlayers"), async (req: any, res) => {
    try {
      const createPaymentRequestSchema = z.object({
        teamId: z.string().uuid(),
        title: z.string().min(1).max(200),
        description: z.string().max(1000).nullable().optional(),
        amount: z.number().positive(),
        dueDate: z.string().nullable().optional(),
      });

      const validation = createPaymentRequestSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid request data',
            details: validation.error.errors,
          },
        });
      }

      const { teamId, title, description, amount, dueDate } = validation.data;

      // Convert amount from dollars to cents
      const amountInCents = Math.round(amount * 100);

      // Convert dueDate string to Date object if provided
      let dueDateObj: Date | null = null;
      if (dueDate) {
        dueDateObj = new Date(dueDate);
        // Validate the date
        if (isNaN(dueDateObj.getTime())) {
          return res.status(400).json({
            error: {
              code: 'INVALID_DATE',
              message: 'Invalid due date format',
            },
          });
        }
      }

      // Create payment request
      const [paymentRequest] = await db
        .insert(teamPaymentRequests)
        .values({
          id: sql`gen_random_uuid()`,
          teamId,
          createdByUserId: req.user.id,
          title,
          description: description || null,
          amount: amountInCents,
          dueDate: dueDateObj,
          status: 'active',
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();

      res.status(201).json(paymentRequest);
    } catch (error) {
      console.error("Error creating payment request:", error);
      res.status(500).json({ error: "Failed to create payment request" });
    }
  });

  // DELETE /api/payment-requests/:id - Delete a payment request
  app.delete("/api/payment-requests/:id", isAuthenticated, requirePermissionForPaymentRequest("canManagePlayers"), async (req: any, res) => {
    try {
      const { id } = req.params;

      // Delete the payment request (authorization already handled by middleware)
      await db
        .delete(teamPaymentRequests)
        .where(eq(teamPaymentRequests.id, id));

      res.json({ message: "Payment request deleted successfully" });
    } catch (error) {
      console.error("Error deleting payment request:", error);
      res.status(500).json({ error: "Failed to delete payment request" });
    }
  });

  // POST /api/payment-requests/:id/send-links - Generate and send payment links via SMS
  app.post("/api/payment-requests/:id/send-links", isAuthenticated, async (req: any, res) => {
    try {
      const sendPaymentLinkSchema = z.object({
        playerIds: z.array(z.string().uuid()).min(1).max(50),
        channel: z.enum(['sms', 'email', 'manual']),
        customMessage: z.string().max(500).optional(),
      });

      const validation = sendPaymentLinkSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid request data',
            details: validation.error.errors,
          },
        });
      }

      const { id: paymentRequestId } = req.params;
      const { playerIds, channel, customMessage } = validation.data;
      const userId = req.user.id;

      // Verify payment request exists
      const [paymentRequest] = await db
        .select()
        .from(teamPaymentRequests)
        .where(eq(teamPaymentRequests.id, paymentRequestId))
        .limit(1);

      if (!paymentRequest) {
        return res.status(404).json({
          error: {
            code: 'PAYMENT_REQUEST_NOT_FOUND',
            message: 'Payment request not found',
          },
        });
      }

      // Check permissions - user must be team owner or have canManagePlayers permission
      const userPermissions = await getUserPermissions(userId, paymentRequest.teamId);
      if (!userPermissions) {
        return res.status(403).json({
          error: {
            code: 'FORBIDDEN',
            message: 'You do not have permission to send payment links for this team',
          },
        });
      }

      if (!userPermissions.isTeamOwner && !userPermissions.canManagePlayers) {
        return res.status(403).json({
          error: {
            code: 'FORBIDDEN',
            message: 'You do not have permission to send payment links',
          },
        });
      }

      // Fetch all players
      const allPlayers = await db
        .select()
        .from(players)
        .where(eq(players.teamId, paymentRequest.teamId));

      type Player = typeof players.$inferSelect;
      const playerMap = new Map<string, Player>(allPlayers.map((p: Player) => [p.id, p]));
      const results: Array<{ playerId: string; success: boolean; error?: string; paymentLink?: string }> = [];

      // Check SMS prerequisites ONCE if using SMS channel (fail early for entire batch)
      if (channel === 'sms') {
        if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_PHONE_NUMBER) {
          return res.status(400).json({
            error: {
              code: 'SMS_NOT_CONFIGURED',
              message: 'SMS messaging is not configured. Twilio credentials are missing.',
            },
          });
        }
      }

      // Generate tokens and send for each player
      for (const playerId of playerIds) {
        const player = playerMap.get(playerId);
        
        if (!player) {
          results.push({
            playerId,
            success: false,
            error: 'Player not found',
          });
          continue;
        }

        // Generate token
        const rawToken = await PaymentTokenService.generateToken({
          paymentRequestId,
          playerId,
          channel,
          createdByUserId: userId,
          expiresInHours: 48,
        });

        // Build payment link URL (frontend route for guest payment page)
        // Construct base URL - works on Replit, Render, and localhost
        const baseUrl = process.env.REPLIT_DOMAINS 
          ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}`
          : process.env.RENDER_EXTERNAL_URL
          ? process.env.RENDER_EXTERNAL_URL
          : `http://localhost:5000`;
        const paymentLink = `${baseUrl}/pay/${rawToken}`;

        // Send based on channel
        if (channel === 'sms') {
          // Check if player has phone number
          if (!player.phone) {
            results.push({
              playerId,
              success: false,
              error: 'Player has no phone number',
            });
            continue;
          }

          try {
            const amountDollars = (paymentRequest.amount / 100).toFixed(2);
            const message = customMessage || 
              `Payment request from your team: ${paymentRequest.title}. ` +
              `Amount: $${amountDollars}. ` +
              `Click here to pay: ${paymentLink}`;

            await sendSMS(player.phone, message);
            results.push({ playerId, success: true });
          } catch (smsError) {
            console.error('Error sending SMS:', smsError);
            results.push({
              playerId,
              success: false,
              error: 'Failed to send SMS',
            });
          }
        } else {
          // Email/manual channels - validate player has email for verification
          if (!player.email) {
            results.push({
              playerId,
              success: false,
              error: 'Player has no email address',
            });
            continue;
          }

          // Token generated, return link for manual distribution
          results.push({
            playerId,
            success: true,
            paymentLink, // Include link for coach to copy/paste or send via email
          });
        }
      }

      res.json({
        sent: results.filter(r => r.success).length,
        failed: results.filter(r => !r.success).length,
        results,
      });
    } catch (error) {
      console.error('Error sending payment links:', error);
      res.status(500).json({
        error: {
          code: 'SEND_LINKS_FAILED',
          message: 'Failed to send payment links',
        },
      });
    }
  });

  // GET /api/payment-links/:token - Validate token and get payment info
  app.get("/api/payment-links/:token", async (req, res) => {
    try {
      const { token } = req.params;
      const validation = await PaymentTokenService.validateToken(token);

      if (!validation.isValid) {
        return res.status(400).json({
          error: {
            code: 'INVALID_TOKEN',
            message: validation.error || 'Invalid payment link',
          },
        });
      }

      // Return payment context for UI display (without playerEmail for privacy)
      res.json({
        paymentRequestId: validation.token!.paymentRequestId,
        playerId: validation.token!.playerId,
        playerName: validation.token!.playerName,
        title: validation.token!.title,
        amount: validation.token!.amount,
      });
    } catch (error) {
      console.error('Error validating payment link:', error);
      res.status(500).json({
        error: {
          code: 'VALIDATION_FAILED',
          message: 'Failed to validate payment link',
        },
      });
    }
  });

  // POST /api/payment-links/:token/initialize - Initialize HelcimPay checkout session
  app.post("/api/payment-links/:token/initialize", async (req, res) => {
    try {
      const { token } = req.params;
      
      // Validate token
      const validation = await PaymentTokenService.validateToken(token);
      if (!validation.isValid) {
        return res.status(400).json({
          error: {
            code: 'INVALID_TOKEN',
            message: validation.error || 'Invalid or expired payment link',
          },
        });
      }

      const validatedToken = validation.token!;

      // Initialize HelcimPay checkout session
      const helcimProvider = await PaymentProviderFactory.getProvider('helcim') as HelcimPaymentProvider;
      if (!helcimProvider) {
        return res.status(500).json({
          error: {
            code: 'PROVIDER_NOT_CONFIGURED',
            message: 'Payment provider not configured',
          },
        });
      }

      const checkoutSession = await helcimProvider.initializeHelcimPayCheckout({
        paymentRequestId: validatedToken.paymentRequestId,
        amount: validatedToken.amount,
        currency: 'USD',
      });

      res.json(checkoutSession);
    } catch (error) {
      console.error('Error initializing HelcimPay checkout:', error);
      res.status(500).json({
        error: {
          code: 'INITIALIZATION_FAILED',
          message: 'Failed to initialize payment checkout',
        },
      });
    }
  });

  // POST /api/payment-links/:token/pay - Process guest payment with email verification
  app.post("/api/payment-links/:token/pay", async (req, res) => {
    try {
      const guestPaymentSchema = z.object({
        email: z.string().email(),
        providerName: z.string().optional(),
      });

      const validation = guestPaymentSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid request data',
            details: validation.error.errors,
          },
        });
      }

      const { token } = req.params;
      const { email, providerName } = validation.data;

      // Validate token
      const tokenValidation = await PaymentTokenService.validateToken(token);
      if (!tokenValidation.isValid) {
        return res.status(400).json({
          error: {
            code: 'INVALID_TOKEN',
            message: tokenValidation.error || 'Invalid or expired payment link',
          },
        });
      }

      const paymentContext = tokenValidation.token!;

      // Verify email matches player email (CRITICAL SECURITY CHECK)
      const emailMatches = await PaymentTokenService.verifyPlayerEmail(
        paymentContext.playerId,
        email
      );

      if (!emailMatches) {
        return res.status(403).json({
          error: {
            code: 'EMAIL_VERIFICATION_FAILED',
            message: 'The email address does not match our records. Please use the email address associated with this player.',
          },
        });
      }

      // Check if already paid
      const [existingPayment] = await db
        .select()
        .from(teamPayments)
        .where(
          and(
            eq(teamPayments.paymentRequestId, paymentContext.paymentRequestId),
            eq(teamPayments.playerId, paymentContext.playerId),
            eq(teamPayments.status, 'completed')
          )
        )
        .limit(1);

      if (existingPayment) {
        return res.status(409).json({
          error: {
            code: 'ALREADY_PAID',
            message: 'This payment has already been completed',
          },
        });
      }

      // Process guest payment
      const result = await PaymentService.processGuestPayment({
        amount: paymentContext.amount,
        description: paymentContext.title,
        paymentRequestId: paymentContext.paymentRequestId,
        playerId: paymentContext.playerId,
        payerEmail: email,
        providerName,
      });

      // Mark token as used
      await PaymentTokenService.markTokenUsed(paymentContext.id);

      // Return 202 Accepted with checkout URL
      res.status(202).json({
        transactionId: result.transactionId,
        checkoutUrl: result.checkoutUrl,
        status: result.status,
      });
    } catch (error) {
      console.error('Error processing guest payment:', error);
      
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      
      if (errorMessage.includes('not configured') || errorMessage.includes('not enabled')) {
        return res.status(402).json({
          error: {
            code: 'PAYMENT_REQUIRED',
            message: errorMessage,
          },
        });
      }

      if (errorMessage.includes('Payment already exists')) {
        return res.status(409).json({
          error: {
            code: 'DUPLICATE_PAYMENT',
            message: errorMessage,
          },
        });
      }

      res.status(500).json({
        error: {
          code: 'PAYMENT_FAILED',
          message: 'Failed to process payment',
        },
      });
    }
  });

  // Helcim Webhook Endpoint
  app.post("/api/webhooks/payment-notifications", async (req, res) => {
    try {
      // Get raw body for signature validation
      const rawBody = JSON.stringify(req.body);
      
      // Validate webhook using PaymentService
      const validation = await PaymentService.validateWebhook(
        'helcim',
        rawBody,
        req.headers as Record<string, string>
      );

      if (!validation.isValid) {
        console.error('Invalid webhook signature:', validation.error);
        return res.status(401).json({ error: 'Invalid webhook signature' });
      }

      const event = validation.event!;
      console.log('Received Helcim webhook event:', event.eventType);

      // Handle different event types
      if (event.eventType === 'transaction.success' || event.eventType === 'payment.success') {
        const { transactionId, status } = event.eventData;

        // Atomic update with RETURNING clause - only the first webhook to succeed gets the data
        // This prevents race conditions when Helcim sends concurrent/retry webhooks
        const updatedPayments = await db
          .update(teamPayments)
          .set({ 
            status: 'completed',
            paidAt: new Date(),
            updatedAt: new Date(),
          })
          .where(and(
            eq(teamPayments.transactionId, transactionId),
            sql`${teamPayments.status} != 'completed'` // Only update if not already completed
          ))
          .returning();

        // If no rows were updated, another webhook already processed this payment
        if (updatedPayments.length === 0) {
          console.log(`Payment for transaction ${transactionId} already completed by another webhook, skipping`);
        } else {
          const payment = updatedPayments[0];
          console.log(`Payment ${payment.id} marked as completed`);

          // Send SMS confirmation to the player (only runs if update succeeded)
          try {
            const [player] = await db
              .select()
              .from(players)
              .where(eq(players.id, payment.playerId))
              .limit(1);

            const [paymentRequest] = await db
              .select()
              .from(teamPaymentRequests)
              .where(eq(teamPaymentRequests.id, payment.paymentRequestId))
              .limit(1);

            if (player?.phoneNumber && paymentRequest) {
              const amount = (paymentRequest.amount / 100).toFixed(2);
              const message = `Payment confirmed! Thank you for your ${paymentRequest.title} payment of $${amount}. Your transaction has been processed successfully.`;

              await sendSMS(player.phoneNumber, message);
              console.log(`Payment confirmation SMS sent to ${player.phoneNumber}`);
            } else {
              console.warn(`Cannot send SMS: ${!player?.phoneNumber ? 'No phone number' : 'Payment request not found'}`);
            }
          } catch (smsError) {
            console.error('Error sending payment confirmation SMS:', smsError);
            // Don't fail the webhook if SMS fails
          }
        }
      } else if (event.eventType === 'transaction.failed' || event.eventType === 'payment.failed') {
        const { transactionId } = event.eventData;

        // Update payment status to failed
        const [payment] = await db
          .select()
          .from(teamPayments)
          .where(eq(teamPayments.transactionId, transactionId))
          .limit(1);

        if (payment) {
          await db
            .update(teamPayments)
            .set({ 
              status: 'failed',
              updatedAt: new Date(),
            })
            .where(eq(teamPayments.id, payment.id));

          console.log(`Payment ${payment.id} marked as failed`);
        }
      }

      // Always return 200 OK to acknowledge receipt
      res.status(200).json({ received: true });
    } catch (error) {
      console.error('Error processing webhook:', error);
      // Still return 200 to prevent Helcim from retrying
      res.status(200).json({ received: true, error: 'Internal processing error' });
    }
  });

  // Payment Providers API
  app.get("/api/payment-providers", isAuthenticated, requireGlobalAdmin(), async (req: any, res) => {
    try {
      const providers = await db.select().from(paymentProviders);
      
      // Never send actual API keys/secrets to frontend - only indicate if they're configured
      const sanitizedProviders = providers.map((provider: any) => ({
        id: provider.id,
        name: provider.name,
        displayName: provider.displayName,
        isEnabled: provider.isEnabled,
        isDefault: provider.isDefault,
        // Security: Don't expose actual credentials, just indicate if they exist
        apiKey: provider.apiKey ? '***configured***' : null,
        webhookSecret: provider.webhookSecret ? '***configured***' : null,
        config: provider.config,
        createdAt: provider.createdAt,
        updatedAt: provider.updatedAt,
      }));
      
      res.json(sanitizedProviders);
    } catch (error) {
      console.error("Error fetching payment providers:", error);
      res.status(500).json({ error: "Failed to fetch payment providers" });
    }
  });

  // Tasks API
  app.get("/api/tasks/summary", isAuthenticated, async (req: any, res) => {
    try {
      const summary = await storage.getTasksSummary(req.user.id);
      res.json(summary);
    } catch (error) {
      console.error("Error fetching tasks summary:", error);
      res.status(500).json({ error: "Failed to fetch tasks summary" });
    }
  });

  app.get("/api/tasks/list", isAuthenticated, async (req: any, res) => {
    try {
      // Fetch user's teams to check if they're a coach
      const userTeams = await storage.getTeamsForUser(req.user.id);
      
      const [pendingDocs, pendingRsvps] = await Promise.all([
        storage.getPendingDocuments(req.user.id),
        storage.getPendingRsvps(req.user.id),
      ]);

      // Fetch pending join requests for teams the user owns
      const pendingJoins: any[] = [];
      for (const team of userTeams) {
        if (team.userId === req.user.id) {
          const joins = await db
            .select()
            .from(pendingParentJoins)
            .where(
              and(
                eq(pendingParentJoins.teamId, team.id),
                eq(pendingParentJoins.status, "pending")
              )
            );
          pendingJoins.push(...joins.map((j: any) => ({ ...j, teamName: team.name })));
        }
      }

      const tasks = {
        documents: pendingDocs.map((doc) => ({
          id: doc.id,
          type: "document" as const,
          teamId: doc.teamId,
          teamName: doc.team.name,
          title: doc.title,
          description: doc.description,
          fileUrl: doc.fileUrl,
          createdAt: doc.createdAt,
        })),
        events: pendingRsvps.map((event) => ({
          id: event.id,
          type: "event" as const,
          teamId: event.teamId,
          teamName: event.team.name,
          title: event.title,
          datetime: event.datetime,
          location: event.location,
          eventType: event.type,
        })),
        pendingJoins: pendingJoins.map((join) => ({
          id: join.id,
          type: "pending_join" as const,
          teamId: join.teamId,
          teamName: join.teamName,
          parentFirstName: join.parentFirstName,
          parentLastName: join.parentLastName,
          parentPhone: join.parentPhone,
          parentEmail: join.parentEmail,
          playerFirstName: join.playerFirstName,
          playerLastName: join.playerLastName,
          playerPhone: join.playerPhone,
          joinCode: join.joinCode,
          createdAt: join.createdAt,
        })),
      };

      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks list:", error);
      res.status(500).json({ error: "Failed to fetch tasks list" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

import type { ISMSProvider } from './provider';
import { TwilioProvider } from './twilioProvider';
import { PlivoProvider } from './plivoProvider';

let providerInstance: ISMSProvider | null = null;

export function getSMSProvider(): ISMSProvider {
  if (providerInstance) {
    return providerInstance;
  }

  const providerName = process.env.SMS_PROVIDER || 'twilio';

  switch (providerName.toLowerCase()) {
    case 'plivo':
      providerInstance = new PlivoProvider();
      break;
    case 'twilio':
    default:
      providerInstance = new TwilioProvider();
      break;
  }

  console.log(`[SMS] Using ${providerInstance.name} provider`);
  return providerInstance;
}

export function resetSMSProvider() {
  providerInstance = null;
}

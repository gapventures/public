import twilio from 'twilio';
import type { 
  ISMSProvider, 
  SMSMessage, 
  PhoneNumber, 
  AvailablePhoneNumber,
  SendSMSParams,
  SearchPhoneNumbersParams,
  PurchasePhoneNumberParams
} from './provider';

export class TwilioProvider implements ISMSProvider {
  name = 'twilio';
  private client: ReturnType<typeof twilio> | null = null;
  private defaultPhoneNumber: string | null = null;
  private connectionSettings: any;

  private async getCredentials() {
    const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
    const xReplitToken = process.env.REPL_IDENTITY 
      ? 'repl ' + process.env.REPL_IDENTITY 
      : process.env.WEB_REPL_RENEWAL 
      ? 'depl ' + process.env.WEB_REPL_RENEWAL 
      : null;

    if (xReplitToken && hostname) {
      try {
        this.connectionSettings = await fetch(
          'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=twilio',
          {
            headers: {
              'Accept': 'application/json',
              'X_REPLIT_TOKEN': xReplitToken
            }
          }
        ).then(res => res.json()).then(data => data.items?.[0]);

        if (this.connectionSettings?.settings?.account_sid && 
            this.connectionSettings?.settings?.api_key && 
            this.connectionSettings?.settings?.api_key_secret) {
          return {
            accountSid: this.connectionSettings.settings.account_sid,
            apiKey: this.connectionSettings.settings.api_key,
            apiKeySecret: this.connectionSettings.settings.api_key_secret,
            phoneNumber: this.connectionSettings.settings.phone_number
          };
        }
      } catch (error) {
        console.warn('Failed to fetch Twilio credentials from Replit connector, falling back to environment variables:', error);
      }
    }

    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const phoneNumber = process.env.TWILIO_PHONE_NUMBER;

    if (!accountSid || !authToken || !phoneNumber) {
      throw new Error('Twilio not configured. Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER environment variables.');
    }

    return {
      accountSid,
      authToken,
      phoneNumber
    };
  }

  private async getClient() {
    if (this.client) {
      return this.client;
    }

    const credentials = await this.getCredentials();
    
    if ('apiKey' in credentials && credentials.apiKey) {
      this.client = twilio(credentials.apiKey, (credentials as any).apiKeySecret, {
        accountSid: credentials.accountSid
      });
    } else {
      this.client = twilio(credentials.accountSid, (credentials as any).authToken);
    }

    this.defaultPhoneNumber = credentials.phoneNumber;
    return this.client;
  }

  async getDefaultPhoneNumber(): Promise<string> {
    if (this.defaultPhoneNumber) {
      return this.defaultPhoneNumber;
    }
    const credentials = await this.getCredentials();
    this.defaultPhoneNumber = credentials.phoneNumber;
    if (!this.defaultPhoneNumber) {
      throw new Error('No default phone number configured');
    }
    return this.defaultPhoneNumber;
  }

  async sendSMS(params: SendSMSParams): Promise<SMSMessage> {
    const client = await this.getClient();
    
    const twilioMessage = await client.messages.create({
      body: params.body,
      from: params.from,
      to: params.to,
    });

    return {
      sid: twilioMessage.sid,
      status: twilioMessage.status,
      errorCode: twilioMessage.errorCode ? String(twilioMessage.errorCode) : null,
      errorMessage: twilioMessage.errorMessage || null,
    };
  }

  async searchAvailablePhoneNumbers(params: SearchPhoneNumbersParams): Promise<AvailablePhoneNumber[]> {
    const client = await this.getClient();
    const country = params.country || 'US';
    
    const searchParams: any = {
      limit: 20,
    };
    
    if (params.areaCode) {
      searchParams.areaCode = parseInt(params.areaCode, 10);
    }
    if (params.contains) {
      searchParams.contains = params.contains;
    }
    
    const numbers = await client.availablePhoneNumbers(country).local.list(searchParams);

    return numbers.map(num => ({
      phoneNumber: num.phoneNumber,
      friendlyName: num.friendlyName,
      locality: num.locality,
      region: num.region,
    }));
  }

  async purchasePhoneNumber(params: PurchasePhoneNumberParams): Promise<PhoneNumber> {
    const client = await this.getClient();
    
    const purchasedNumber = await client.incomingPhoneNumbers.create({
      phoneNumber: params.phoneNumber,
      friendlyName: params.friendlyName,
    });

    return {
      phoneNumber: purchasedNumber.phoneNumber,
      friendlyName: purchasedNumber.friendlyName,
      sid: purchasedNumber.sid,
    };
  }

  async releasePhoneNumber(sid: string): Promise<void> {
    const client = await this.getClient();
    await client.incomingPhoneNumbers(sid).remove();
  }

  async listPhoneNumbers(): Promise<PhoneNumber[]> {
    const client = await this.getClient();
    const numbers = await client.incomingPhoneNumbers.list();
    
    return numbers.map(num => ({
      phoneNumber: num.phoneNumber,
      friendlyName: num.friendlyName,
      sid: num.sid,
    }));
  }

  async getSMSCost(): Promise<number> {
    return 0.0079;
  }
}

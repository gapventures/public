import type { 
  ISMSProvider, 
  SMSMessage, 
  PhoneNumber, 
  AvailablePhoneNumber,
  SendSMSParams,
  SearchPhoneNumbersParams,
  PurchasePhoneNumberParams
} from './provider';

export class PlivoProvider implements ISMSProvider {
  name = 'plivo';
  private authId: string | null = null;
  private authToken: string | null = null;
  private defaultPhoneNumber: string | null = null;
  private client: any = null;

  private async getCredentials() {
    const authId = process.env.PLIVO_AUTH_ID;
    const authToken = process.env.PLIVO_AUTH_TOKEN;
    const phoneNumber = process.env.PLIVO_PHONE_NUMBER;

    if (!authId || !authToken || !phoneNumber) {
      throw new Error('Plivo not configured. Set PLIVO_AUTH_ID, PLIVO_AUTH_TOKEN, and PLIVO_PHONE_NUMBER environment variables.');
    }

    return {
      authId,
      authToken,
      phoneNumber
    };
  }

  private async getClient() {
    if (this.client) {
      return this.client;
    }

    let plivo;
    try {
      plivo = await import('plivo');
    } catch (error) {
      throw new Error(
        'Plivo package not installed. Please run: npm install plivo\n' +
        'Or use the packager tool to install the plivo package.'
      );
    }

    const credentials = await this.getCredentials();
    
    this.authId = credentials.authId;
    this.authToken = credentials.authToken;
    this.defaultPhoneNumber = credentials.phoneNumber;
    
    this.client = new plivo.Client(credentials.authId, credentials.authToken);
    return this.client;
  }

  async getDefaultPhoneNumber(): Promise<string> {
    if (this.defaultPhoneNumber) {
      return this.defaultPhoneNumber;
    }
    const credentials = await this.getCredentials();
    this.defaultPhoneNumber = credentials.phoneNumber;
    if (!this.defaultPhoneNumber) {
      throw new Error('No default phone number configured');
    }
    return this.defaultPhoneNumber;
  }

  async sendSMS(params: SendSMSParams): Promise<SMSMessage> {
    const client = await this.getClient();
    
    const response = await client.messages.create(
      params.from,
      params.to,
      params.body
    );

    let messageUuid = response.messageUuid || response.message_uuid;
    
    if (Array.isArray(messageUuid)) {
      messageUuid = messageUuid[0];
    }

    return {
      sid: String(messageUuid),
      status: 'queued',
      errorCode: null,
      errorMessage: null,
    };
  }

  async searchAvailablePhoneNumbers(params: SearchPhoneNumbersParams): Promise<AvailablePhoneNumber[]> {
    const client = await this.getClient();
    const countryIso = params.country || 'US';
    
    const searchParams: any = {
      limit: 20,
    };
    
    if (params.areaCode) {
      searchParams.pattern = params.areaCode;
    }
    if (params.contains) {
      searchParams.pattern = params.contains;
    }

    const response = await client.phoneNumbers.search(countryIso, searchParams);
    
    const numbers = response.objects || [];
    
    return numbers.map((num: any) => ({
      phoneNumber: num.number,
      friendlyName: num.number,
      locality: num.region,
      region: num.region,
    }));
  }

  async purchasePhoneNumber(params: PurchasePhoneNumberParams): Promise<PhoneNumber> {
    const client = await this.getClient();
    
    const response = await client.phoneNumbers.buy(params.phoneNumber, {
      alias: params.friendlyName,
    });

    return {
      phoneNumber: params.phoneNumber,
      friendlyName: params.friendlyName || params.phoneNumber,
      sid: response.number || params.phoneNumber,
    };
  }

  async releasePhoneNumber(sid: string): Promise<void> {
    const client = await this.getClient();
    await client.phoneNumbers.delete(sid);
  }

  async listPhoneNumbers(): Promise<PhoneNumber[]> {
    const client = await this.getClient();
    const response = await client.phoneNumbers.list();
    
    const numbers = response.objects || [];
    
    return numbers.map((num: any) => ({
      phoneNumber: num.number,
      friendlyName: num.alias || num.number,
      sid: num.number,
    }));
  }

  async getSMSCost(): Promise<number> {
    return 0.0055;
  }
}

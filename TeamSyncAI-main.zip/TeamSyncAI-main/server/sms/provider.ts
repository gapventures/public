export interface SMSMessage {
  sid: string;
  status: string;
  errorCode?: string | null;
  errorMessage?: string | null;
}

export interface PhoneNumber {
  phoneNumber: string;
  friendlyName: string;
  sid: string;
}

export interface AvailablePhoneNumber {
  phoneNumber: string;
  friendlyName: string;
  locality?: string;
  region?: string;
}

export interface SendSMSParams {
  to: string;
  from: string;
  body: string;
}

export interface SearchPhoneNumbersParams {
  areaCode?: string;
  contains?: string;
  country?: string;
}

export interface PurchasePhoneNumberParams {
  phoneNumber: string;
  friendlyName?: string;
}

export interface ISMSProvider {
  name: string;
  
  sendSMS(params: SendSMSParams): Promise<SMSMessage>;
  
  searchAvailablePhoneNumbers(params: SearchPhoneNumbersParams): Promise<AvailablePhoneNumber[]>;
  
  purchasePhoneNumber(params: PurchasePhoneNumberParams): Promise<PhoneNumber>;
  
  releasePhoneNumber(sid: string): Promise<void>;
  
  listPhoneNumbers(): Promise<PhoneNumber[]>;
  
  getDefaultPhoneNumber(): Promise<string>;
  
  getSMSCost(): Promise<number>;
}

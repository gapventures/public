/**
 * Phone number formatting and normalization utilities
 * Handles display formatting and E.164 normalization for Twilio
 */

/**
 * Formats a phone number for display in a readable format
 * Supports: 10-digit US, 11-digit with country code
 * Examples:
 *   5551234567 -> (555) 123-4567
 *   15551234567 -> +1 (555) 123-4567
 *   555-123-4567 -> (555) 123-4567
 */
export function formatPhoneForDisplay(phone: string | null | undefined): string {
  if (!phone) return '';
  
  // Remove all non-digit characters
  const cleaned = phone.replace(/\D/g, '');
  
  // Handle 10-digit US number
  if (cleaned.length === 10) {
    return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
  }
  
  // Handle 11-digit number with country code (1)
  if (cleaned.length === 11 && cleaned[0] === '1') {
    return `+1 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
  }
  
  // Return original if it doesn't match expected formats
  return phone;
}

/**
 * Normalizes a phone number to E.164 format for Twilio
 * E.164 format: +[country code][number] with no spaces or punctuation
 * Examples:
 *   (555) 123-4567 -> +15551234567
 *   555-123-4567 -> +15551234567
 *   5551234567 -> +15551234567
 *   +1 555 123 4567 -> +15551234567
 *   +44 20 1234 5678 -> +442012345678
 */
export function normalizePhoneForTwilio(phone: string | null | undefined): string {
  if (!phone) return '';
  
  // If it already starts with +, just clean and return
  if (phone.trim().startsWith('+')) {
    // Remove all non-digits except the leading +
    return '+' + phone.replace(/\D/g, '');
  }
  
  // Remove all non-digit characters
  const cleaned = phone.replace(/\D/g, '');
  
  // Handle 10-digit US number - add country code
  if (cleaned.length === 10) {
    return `+1${cleaned}`;
  }
  
  // Handle 11-digit number with country code (1)
  if (cleaned.length === 11 && cleaned[0] === '1') {
    return `+${cleaned}`;
  }
  
  // International dialing prefixes: 011 (US), 00 (most countries)
  if (cleaned.startsWith('011')) {
    // Remove 011 prefix and add +
    return `+${cleaned.substring(3)}`;
  }
  
  if (cleaned.startsWith('00')) {
    // Remove 00 prefix and add +
    return `+${cleaned.substring(2)}`;
  }
  
  // If it's 11+ digits and doesn't start with 1, likely international (not US)
  // Common patterns: UK (44), Australia (61), Germany (49), France (33), etc.
  if (cleaned.length >= 11 && cleaned[0] !== '1') {
    return `+${cleaned}`;
  }
  
  // If it's longer than 11 digits, it's definitely international
  if (cleaned.length > 11) {
    return `+${cleaned}`;
  }
  
  // Default: assume US number and add +1
  return `+1${cleaned}`;
}

/**
 * Auto-formats phone number as user types
 * Formats to US format: (555) 123-4567
 */
export function autoFormatPhoneInput(value: string): string {
  if (!value) return '';
  
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Limit to 10 digits for US numbers
  const limited = cleaned.slice(0, 10);
  
  // Format as user types
  if (limited.length === 0) return '';
  if (limited.length <= 3) return limited;
  if (limited.length <= 6) return `(${limited.slice(0, 3)}) ${limited.slice(3)}`;
  return `(${limited.slice(0, 3)}) ${limited.slice(3, 6)}-${limited.slice(6)}`;
}

/**
 * Validates if a phone number is in a valid format
 * Accepts various formats but ensures it can be normalized to E.164
 */
export function isValidPhoneNumber(phone: string | null | undefined): boolean {
  if (!phone) return false;
  
  const cleaned = phone.replace(/\D/g, '');
  
  // Valid US phone number: 10 digits or 11 digits starting with 1
  if (cleaned.length === 10) return true;
  if (cleaned.length === 11 && cleaned[0] === '1') return true;
  
  return false;
}

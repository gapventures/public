import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, real, numeric, jsonb, index, uniqueIndex, pgEnum, check } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Available sports for teams and events
export const AVAILABLE_SPORTS = [
  "Baseball",
  "Softball",
  "Soccer",
  "Basketball",
  "Football",
  "Hockey",
  "Volleyball",
  "Lacrosse",
  "Track & Field",
  "Tennis",
  "Swimming",
  "Wrestling",
  "Golf",
  "Cross Country",
  "Cheerleading",
  "Rugby",
  "Ultimate Frisbee",
  "Water Polo",
  "Other",
] as const;

export type Sport = typeof AVAILABLE_SPORTS[number];

// Account types for users
export const accountTypeEnum = pgEnum("account_type", ["coach", "parent", "player"]);

// Message direction for SMS logs
export const messageDirectionEnum = pgEnum("message_direction", ["outbound", "inbound"]);

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Application Settings (singleton table)
export const appSettings = pgTable("app_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  applicationName: text("application_name").notNull().default("TeamSyncAI"),
  availableSports: jsonb("available_sports").$type<string[]>().default(sql`'["Baseball","Softball","Soccer","Basketball","Football","Hockey","Volleyball","Lacrosse","Track & Field","Tennis","Swimming","Wrestling","Golf","Cross Country","Cheerleading","Rugby","Ultimate Frisbee","Water Polo","Other"]'::jsonb`),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertAppSettingsSchema = createInsertSchema(appSettings).omit({
  id: true,
  updatedAt: true,
});

export type InsertAppSettings = z.infer<typeof insertAppSettingsSchema>;
export type AppSettings = typeof appSettings.$inferSelect;

// Landing Page Content (singleton table)
export const landingPageContent = pgTable("landing_page_content", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  // Hero section
  heroTitle: text("hero_title").notNull().default("Your AI-Powered Assistant Manager"),
  heroSubtitle: text("hero_subtitle").notNull().default("Automate team management for amateur sports teams. Save hours every week with intelligent SMS reminders, attendance tracking, and player reliability monitoring."),
  heroCta: text("hero_cta").notNull().default("Get Started"),
  logoUrl: text("logo_url"), // Optional landing page logo
  // Feature cards (stored as JSON array)
  features: jsonb("features").notNull().default(sql`'[]'::jsonb`),
  // Bottom CTA section
  ctaHeading: text("cta_heading").notNull().default("Ready to simplify your team management?"),
  ctaDescription: text("cta_description").notNull().default("Join coaches who are already saving time and staying organized with {appName}."),
  ctaButton: text("cta_button").notNull().default("Start Now"),
  // Footer
  footerText: text("footer_text").notNull().default("&copy; 2025 {appName}. Built for coaches, by coaches."),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Landing Page Feature schema for validation
export const landingPageFeatureSchema = z.object({
  icon: z.enum([
    "MessageSquare", 
    "Calendar", 
    "TrendingUp", 
    "Bell", 
    "Zap", 
    "Users",
    "Shield",
    "Database",
    "Settings",
    "CheckCircle",
    "Star",
    "Target",
  ]),
  title: z.string().min(1).max(100),
  description: z.string().min(1).max(500),
});

export const insertLandingPageContentSchema = createInsertSchema(landingPageContent).omit({
  id: true,
  updatedAt: true,
}).extend({
  features: z.array(landingPageFeatureSchema).min(0).max(12), // 0-12 features supported
});

export type LandingPageFeature = z.infer<typeof landingPageFeatureSchema>;
export type InsertLandingPageContent = z.infer<typeof insertLandingPageContentSchema>;
export type LandingPageContent = typeof landingPageContent.$inferSelect;

// Marketing Page enum
export const marketingPageEnum = pgEnum("marketing_page", ["about", "features", "pricing", "contact"]);

// Marketing Page Content (one row per page)
export const marketingPageContent = pgTable("marketing_page_content", {
  page: marketingPageEnum("page").primaryKey(),
  content: jsonb("content").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// About Page Content Schema
export const aboutPageContentSchema = z.object({
  heroTitle: z.string().min(1).max(200),
  heroSubtitle: z.string().min(1).max(500),
  missionTitle: z.string().min(1).max(200),
  missionText: z.string().min(1).max(1000),
  valuesTitle: z.string().min(1).max(200),
  values: z.array(z.object({
    icon: z.enum(["Target", "Users", "Heart", "Zap", "Shield", "Star", "TrendingUp", "Award"]),
    title: z.string().min(1).max(100),
    description: z.string().min(1).max(300),
  })).min(1).max(8),
  ctaTitle: z.string().min(1).max(200),
  ctaButton: z.string().min(1).max(50),
});

// Features Page Content Schema
export const featuresPageContentSchema = z.object({
  heroTitle: z.string().min(1).max(200),
  heroSubtitle: z.string().min(1).max(500),
  features: z.array(z.object({
    icon: z.enum(["MessageSquare", "Calendar", "Bell", "Users", "TrendingUp", "Shield", "Database", "Zap", "CheckCircle", "Settings", "Star", "Award"]),
    title: z.string().min(1).max(100),
    description: z.string().min(1).max(500),
  })).min(1).max(12),
  ctaTitle: z.string().min(1).max(200),
  ctaSubtitle: z.string().min(1).max(500),
  ctaPrimaryButton: z.string().min(1).max(50),
  ctaSecondaryButton: z.string().min(1).max(50),
});

// Pricing Page Content Schema
// Note: plans are now optional as pricing data comes from membership tiers
export const pricingPageContentSchema = z.object({
  heroTitle: z.string().min(1).max(200),
  heroSubtitle: z.string().min(1).max(500),
  plans: z.array(z.object({
    name: z.string().min(1).max(50),
    price: z.string().min(1).max(50),
    description: z.string().min(1).max(200),
    features: z.array(z.string().min(1).max(200)).min(1).max(15),
    highlighted: z.boolean(),
    buttonText: z.string().min(1).max(50),
  })).optional().default([]),
});

// Contact Page Content Schema
export const contactPageContentSchema = z.object({
  heroTitle: z.string().min(1).max(200),
  heroSubtitle: z.string().min(1).max(500),
  supportEmail: z.string().email(),
  supportEmailLabel: z.string().min(1).max(100),
  supportEmailDescription: z.string().min(1).max(200),
  salesEmail: z.string().email(),
  salesEmailLabel: z.string().min(1).max(100),
  salesEmailDescription: z.string().min(1).max(200),
  phone: z.string().min(1).max(50),
  phoneLabel: z.string().min(1).max(100),
  phoneDescription: z.string().min(1).max(200),
  formTitle: z.string().min(1).max(100),
  formDescription: z.string().min(1).max(200),
  formSuccessTitle: z.string().min(1).max(100),
  formSuccessMessage: z.string().min(1).max(300),
});

// Marketing Page Content Types
export type AboutPageContent = z.infer<typeof aboutPageContentSchema>;
export type FeaturesPageContent = z.infer<typeof featuresPageContentSchema>;
export type PricingPageContent = z.infer<typeof pricingPageContentSchema>;
export type ContactPageContent = z.infer<typeof contactPageContentSchema>;
export type MarketingPageContent = typeof marketingPageContent.$inferSelect;

// Union type for all marketing page content
export type MarketingPageContentData = AboutPageContent | FeaturesPageContent | PricingPageContent | ContactPageContent;

// Default content for marketing pages
export const DEFAULT_ABOUT_CONTENT: AboutPageContent = {
  heroTitle: "About TeamSyncAI",
  heroSubtitle: "We're on a mission to make amateur sports team management effortless, so coaches can focus on what matters most—developing their players and enjoying the game.",
  missionTitle: "Our Mission",
  missionText: "Amateur sports coaches wear many hats—organizer, motivator, strategist, and sometimes even conflict mediator. We built TeamSyncAI because we believe coaches shouldn't have to spend hours every week chasing down attendance confirmations and sending reminders. Our AI-powered assistant manager automates the tedious parts of team management, giving coaches their time back to focus on what they love: coaching.",
  valuesTitle: "Our Values",
  values: [
    {
      icon: "Target",
      title: "Coach-First Design",
      description: "Every feature is built with coaches in mind, designed to solve real problems they face every day.",
    },
    {
      icon: "Users",
      title: "Built by Coaches",
      description: "Our team includes active coaches who understand the challenges firsthand.",
    },
    {
      icon: "Heart",
      title: "Community Focused",
      description: "We're committed to supporting grassroots sports and strengthening local communities.",
    },
  ],
  ctaTitle: "Ready to get started?",
  ctaButton: "Get Started Today",
};

export const DEFAULT_FEATURES_CONTENT: FeaturesPageContent = {
  heroTitle: "Everything You Need to Manage Your Team",
  heroSubtitle: "From automated reminders to player reliability tracking, TeamSyncAI provides all the tools you need to run your team efficiently.",
  features: [
    {
      icon: "MessageSquare",
      title: "Smart SMS Reminders",
      description: "Automated reminders sent via SMS based on player reliability scores. The system learns who needs more nudges.",
    },
    {
      icon: "Calendar",
      title: "Event Management",
      description: "Create and manage practices, games, and team events with ease. Players get automatic reminders.",
    },
    {
      icon: "TrendingUp",
      title: "Reliability Tracking",
      description: "Track player attendance patterns and reliability scores to know who to count on.",
    },
    {
      icon: "Users",
      title: "Team Roster Management",
      description: "Manage your team roster, contact information, and player details all in one place.",
    },
    {
      icon: "Bell",
      title: "Customizable Campaigns",
      description: "Create custom reminder campaigns with multiple reminders leading up to events.",
    },
    {
      icon: "CheckCircle",
      title: "RSVP Tracking",
      description: "Track who's coming, who's not, and who hasn't responded yet with real-time updates.",
    },
  ],
  ctaTitle: "Ready to simplify your team management?",
  ctaSubtitle: "Join coaches who are already saving time and staying organized.",
  ctaPrimaryButton: "Get Started Free",
  ctaSecondaryButton: "View Pricing",
};

export const DEFAULT_PRICING_CONTENT: PricingPageContent = {
  heroTitle: "Simple, Transparent Pricing",
  heroSubtitle: "Choose the plan that works for your team. All plans include our core features.",
  plans: [
    {
      name: "Free",
      price: "$0",
      description: "Perfect for trying out TeamSyncAI",
      features: [
        "Up to 10 players",
        "Basic event management",
        "Manual reminders",
        "Email support",
      ],
      highlighted: false,
      buttonText: "Get Started",
    },
    {
      name: "Team",
      price: "$19/mo",
      description: "Best for most amateur teams",
      features: [
        "Up to 30 players",
        "Automated SMS reminders",
        "Reliability tracking",
        "Custom campaigns",
        "Priority support",
      ],
      highlighted: true,
      buttonText: "Start Free Trial",
    },
    {
      name: "Pro",
      price: "$49/mo",
      description: "For larger organizations",
      features: [
        "Unlimited players",
        "All Team features",
        "Multiple teams",
        "Advanced analytics",
        "API access",
        "Dedicated support",
      ],
      highlighted: false,
      buttonText: "Contact Sales",
    },
  ],
};

export const DEFAULT_CONTACT_CONTENT: ContactPageContent = {
  heroTitle: "Get in Touch",
  heroSubtitle: "Have questions? We're here to help. Send us a message and we'll respond as soon as possible.",
  supportEmail: "support@team-sync-ai.com",
  supportEmailLabel: "Email Us",
  supportEmailDescription: "For general inquiries and support",
  salesEmail: "sales@team-sync-ai.com",
  salesEmailLabel: "Sales",
  salesEmailDescription: "Questions about pricing or enterprise plans",
  phone: "(855) 677-3180",
  phoneLabel: "Phone Support",
  phoneDescription: "Available Monday-Friday, 9am-5pm EST",
  formTitle: "Send us a message",
  formDescription: "Fill out the form below and we'll get back to you within 24 hours.",
  formSuccessTitle: "Message Sent!",
  formSuccessMessage: "Thanks for reaching out. We'll get back to you as soon as possible.",
};

// User storage table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").notNull().unique(),
  password: varchar("password"), // Hashed password for local auth (bcrypt)
  accountType: accountTypeEnum("account_type").notNull().default("coach"), // Type of account: coach, parent, or player
  phone: text("phone"), // Phone number for SMS notifications and password reset
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  address: text("address"), // Physical address
  preferredPosition: varchar("preferred_position"), // Preferred playing position
  profileImageUrl: varchar("profile_image_url"),
  organizationLogoUrl: varchar("organization_logo_url"),
  sports: text("sports").array().notNull().default(sql`ARRAY[]::text[]`), // Sports the user manages
  isGlobalAdmin: boolean("is_global_admin").notNull().default(false),
  smsConsentGranted: boolean("sms_consent_granted").notNull().default(false), // User consent for receiving SMS messages (TCPA compliance)
  // Password reset fields
  resetToken: varchar("reset_token"),
  resetTokenExpires: timestamp("reset_token_expires"),
  // Membership fields
  membershipTierId: varchar("membership_tier_id"),
  trialStartDate: timestamp("trial_start_date"),
  trialEndDate: timestamp("trial_end_date"),
  // Payment integration fields (legacy Stripe - kept for future fallback)
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  // Helcim payment integration fields
  helcimCustomerId: varchar("helcim_customer_id"),
  helcimSubscriptionId: varchar("helcim_subscription_id"),
  helcimPaymentPlanId: varchar("helcim_payment_plan_id"),
  billingProvider: varchar("billing_provider"), // 'helcim' or 'stripe'
  subscriptionStatus: varchar("subscription_status"), // active, past_due, canceled, trialing, etc.
  subscriptionCancelledAt: timestamp("subscription_cancelled_at"), // Soft delete timestamp for cancellation audit
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Membership Tiers
export const membershipTiers = pgTable("membership_tiers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(), // e.g., "Free", "Pro", "Enterprise"
  description: text("description"),
  displayOrder: integer("display_order").notNull().default(0), // For ordering tiers in UI
  trialPeriodDays: integer("trial_period_days").notNull().default(0), // Number of days of trial
  monthlyPrice: integer("monthly_price").notNull().default(0), // Price in cents (0 for free tier)
  annualPrice: integer("annual_price").notNull().default(0), // Annual price in cents (0 for free tier)
  helcimPaymentPlanId: text("helcim_payment_plan_id"), // Helcim recurring payment plan ID (legacy, kept for compatibility)
  helcimMonthlyCheckoutId: text("helcim_monthly_checkout_id"), // Helcim checkout link ID for monthly billing
  helcimAnnualCheckoutId: text("helcim_annual_checkout_id"), // Helcim checkout link ID for annual billing
  isContactForPricing: boolean("is_contact_for_pricing").notNull().default(false), // True if tier shows "Contact Us for Pricing"
  contactInfo: text("contact_info"), // Contact information (email, phone, or custom message) for contact-for-pricing tiers
  isDefault: boolean("is_default").notNull().default(false), // Default tier for new users
  isActive: boolean("is_active").notNull().default(true), // Can be deactivated without deleting
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertMembershipTierSchema = createInsertSchema(membershipTiers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertMembershipTier = z.infer<typeof insertMembershipTierSchema>;
export type MembershipTier = typeof membershipTiers.$inferSelect;

// Tier Limits - Numeric limits per tier (e.g., maxTeams: 5)
export const tierLimits = pgTable("tier_limits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tierId: varchar("tier_id").notNull().references(() => membershipTiers.id, { onDelete: "cascade" }),
  limitKey: text("limit_key").notNull(), // e.g., "maxTeams", "maxPlayers", "maxEvents", "maxSmsPerMonth"
  limitValue: integer("limit_value").notNull(), // The numeric limit (-1 for unlimited)
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTierLimitSchema = createInsertSchema(tierLimits).omit({
  id: true,
  createdAt: true,
});

export type InsertTierLimit = z.infer<typeof insertTierLimitSchema>;
export type TierLimit = typeof tierLimits.$inferSelect;

// Tier Features - Boolean feature toggles per tier
export const tierFeatures = pgTable("tier_features", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tierId: varchar("tier_id").notNull().references(() => membershipTiers.id, { onDelete: "cascade" }),
  featureKey: text("feature_key").notNull(), // e.g., "messageBoard", "campaignTemplates", "calendarSubscription"
  enabled: boolean("enabled").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTierFeatureSchema = createInsertSchema(tierFeatures).omit({
  id: true,
  createdAt: true,
});

export type InsertTierFeature = z.infer<typeof insertTierFeatureSchema>;
export type TierFeature = typeof tierFeatures.$inferSelect;

// Payment-ready tables for future Stripe integration

// Subscriptions - Track Stripe subscriptions
export const subscriptions = pgTable("subscriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  stripeSubscriptionId: varchar("stripe_subscription_id").unique(),
  stripeCustomerId: varchar("stripe_customer_id"),
  stripePriceId: varchar("stripe_price_id"),
  status: varchar("status").notNull(), // active, canceled, past_due, trialing, etc.
  currentPeriodStart: timestamp("current_period_start"),
  currentPeriodEnd: timestamp("current_period_end"),
  cancelAtPeriodEnd: boolean("cancel_at_period_end").notNull().default(false),
  canceledAt: timestamp("canceled_at"),
  trialEnd: timestamp("trial_end"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;

// Payment Methods - Store payment method details
export const paymentMethods = pgTable("payment_methods", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  stripePaymentMethodId: varchar("stripe_payment_method_id").unique(),
  type: varchar("type").notNull(), // card, bank_account, etc.
  cardBrand: varchar("card_brand"), // visa, mastercard, etc.
  cardLast4: varchar("card_last4", { length: 4 }),
  cardExpMonth: integer("card_exp_month"),
  cardExpYear: integer("card_exp_year"),
  isDefault: boolean("is_default").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertPaymentMethodSchema = createInsertSchema(paymentMethods).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPaymentMethod = z.infer<typeof insertPaymentMethodSchema>;
export type PaymentMethod = typeof paymentMethods.$inferSelect;

// Webhook Events - Log Stripe webhook events for debugging and idempotency
export const webhookEvents = pgTable("webhook_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  stripeEventId: varchar("stripe_event_id").unique().notNull(),
  eventType: varchar("event_type").notNull(), // e.g., "customer.subscription.updated"
  payload: jsonb("payload").notNull(), // Full Stripe event object
  processed: boolean("processed").notNull().default(false),
  processedAt: timestamp("processed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertWebhookEventSchema = createInsertSchema(webhookEvents).omit({
  id: true,
  createdAt: true,
});

export type InsertWebhookEvent = z.infer<typeof insertWebhookEventSchema>;
export type WebhookEvent = typeof webhookEvents.$inferSelect;

// Teams
export const teams = pgTable("teams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  name: text("name").notNull(),
  instanceName: text("instance_name"), // Custom instance/app name for this team (e.g., "Hawks Manager")
  sport: text("sport").notNull().default("Baseball"), // Sport this team plays
  logoUrl: text("logo_url"),
  messageBoardEnabled: boolean("message_board_enabled").notNull().default(false),
  // Twilio phone number for team-specific SMS (TCPA compliance)
  twilioPhoneNumber: text("twilio_phone_number"), // E.164 format phone number
  twilioPhoneNumberSid: text("twilio_phone_number_sid"), // Twilio resource SID for phone number
  phoneNumberStatus: text("phone_number_status").default("none"), // none, provisioning, active, failed, released
  phoneNumberProvisionedAt: timestamp("phone_number_provisioned_at"),
  // Team join codes for parent self-signup
  joinCode: varchar("join_code", { length: 8 }), // 6-8 character code (e.g., "HAWKS24")
  joinCodeEnabled: boolean("join_code_enabled").notNull().default(false),
  joinCodeExpiry: timestamp("join_code_expiry"), // Optional expiration date
  // Custom invitation message template - supports {teamName}, {roleName}, {coachName}, {inviteUrl}, {playerName}
  invitationMessageTemplate: text("invitation_message_template"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTeamSchema = createInsertSchema(teams).omit({
  id: true,
  createdAt: true,
  phoneNumberProvisionedAt: true,
});

export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Team = typeof teams.$inferSelect;

// Roles
export const roles = pgTable("roles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description"),
  // Permissions
  canViewEvents: boolean("can_view_events").notNull().default(true),
  canManageEvents: boolean("can_manage_events").notNull().default(false),
  canViewPlayers: boolean("can_view_players").notNull().default(true),
  canManagePlayers: boolean("can_manage_players").notNull().default(false),
  canSendReminders: boolean("can_send_reminders").notNull().default(false),
  canManageCampaigns: boolean("can_manage_campaigns").notNull().default(false),
  canViewResponses: boolean("can_view_responses").notNull().default(true),
  canManageAttendance: boolean("can_manage_attendance").notNull().default(false),
  canManageSettings: boolean("can_manage_settings").notNull().default(false),
  canManageRoles: boolean("can_manage_roles").notNull().default(false),
  canViewMembership: boolean("can_view_membership").notNull().default(false),
  isDefault: boolean("is_default").notNull().default(false), // System-created default roles
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertRoleSchema = createInsertSchema(roles).omit({
  id: true,
  createdAt: true,
});

export type InsertRole = z.infer<typeof insertRoleSchema>;
export type Role = typeof roles.$inferSelect;

// Team Membership Enums
export const membershipTypeEnum = pgEnum("membership_type", ["player", "coach", "manager", "volunteer"]);
export const membershipStatusEnum = pgEnum("membership_status", ["active", "inactive", "pending"]);

// Team Members - First-class membership system for staff and players
export const teamMembers = pgTable("team_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  userId: varchar("user_id").references(() => users.id, { onDelete: "set null" }), // Nullable for invited members
  email: text("email").notNull(), // ALWAYS stored lowercase - enforced by CHECK constraint and validation
  roleId: varchar("role_id").references(() => roles.id, { onDelete: "set null" }), // Nullable for basic members
  membershipType: membershipTypeEnum("membership_type").notNull().default("player"),
  status: membershipStatusEnum("status").notNull().default("active"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  // CHECK constraint: email must be lowercase
  emailLowercaseCheck: check("email_lowercase_check", sql`${table.email} = lower(${table.email})`),
  // Unique constraint: one active membership per user per team (by userId)
  uniqueUserTeam: uniqueIndex("team_members_user_team_unique")
    .on(table.teamId, table.userId)
    .where(sql`${table.userId} IS NOT NULL AND ${table.status} = 'active'`),
  // Unique constraint: one active membership per email per team (uses lower() for SQL-level safety)
  uniqueEmailTeam: uniqueIndex("team_members_email_team_unique")
    .on(table.teamId, sql`lower(${table.email})`)
    .where(sql`${table.status} = 'active'`),
  // Performance indexes
  teamUserIndex: index("team_members_team_user_idx").on(table.teamId, table.userId),
  teamEmailIndex: index("team_members_team_email_idx").on(table.teamId, table.email),
}));

export const insertTeamMemberSchema = createInsertSchema(teamMembers).omit({
  id: true,
  createdAt: true,
}).extend({
  // Enforce lowercase email normalization at validation layer
  email: z.string().email().transform(v => v.trim().toLowerCase()),
});

export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type TeamMember = typeof teamMembers.$inferSelect;

// Pending Parent Join Requests - Track parent self-signups via join codes
export const pendingParentJoins = pgTable("pending_parent_joins", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  parentUserId: varchar("parent_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  parentEmail: text("parent_email").notNull(),
  parentPhone: text("parent_phone").notNull(),
  parentFirstName: text("parent_first_name").notNull(),
  parentLastName: text("parent_last_name").notNull(),
  // Child/Player Details
  playerFirstName: text("player_first_name").notNull(),
  playerLastName: text("player_last_name").notNull(),
  playerPhone: text("player_phone").notNull(),
  playerEmail: text("player_email"),
  playerDateOfBirth: text("player_date_of_birth"),
  // Request metadata
  joinCode: varchar("join_code", { length: 8 }).notNull(), // Join code used during signup
  status: varchar("status").notNull().default("pending"), // pending, approved, rejected
  rejectionReason: text("rejection_reason"),
  approvedByUserId: varchar("approved_by_user_id").references(() => users.id, { onDelete: "set null" }),
  approvedAt: timestamp("approved_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  teamIdIndex: index("pending_parent_joins_team_idx").on(table.teamId),
  statusIndex: index("pending_parent_joins_status_idx").on(table.status),
  parentUserIndex: index("pending_parent_joins_parent_user_idx").on(table.parentUserId),
}));

export const insertPendingParentJoinSchema = createInsertSchema(pendingParentJoins).omit({
  id: true,
  createdAt: true,
});

export type InsertPendingParentJoin = z.infer<typeof insertPendingParentJoinSchema>;
export type PendingParentJoin = typeof pendingParentJoins.$inferSelect;

// Payment Request Tokens - Secure tokenized links for guest payments
export const paymentRequestTokens = pgTable("payment_request_tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tokenHash: text("token_hash").notNull().unique(), // SHA-256 hash of the actual token
  paymentRequestId: varchar("payment_request_id").notNull().references(() => teamPaymentRequests.id, { onDelete: "cascade" }),
  playerId: varchar("player_id").notNull().references(() => players.id, { onDelete: "cascade" }),
  channel: text("channel").notNull(), // 'sms', 'email', 'manual'
  createdByUserId: varchar("created_by_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(), // Typically 48 hours from creation
  usedAt: timestamp("used_at"), // NULL until consumed
}, (table) => ({
  tokenHashIndex: index("payment_tokens_hash_idx").on(table.tokenHash),
  paymentRequestIndex: index("payment_tokens_request_idx").on(table.paymentRequestId),
  playerIndex: index("payment_tokens_player_idx").on(table.playerId),
}));

export const insertPaymentRequestTokenSchema = createInsertSchema(paymentRequestTokens).omit({
  id: true,
  createdAt: true,
});

export type InsertPaymentRequestToken = z.infer<typeof insertPaymentRequestTokenSchema>;
export type PaymentRequestToken = typeof paymentRequestTokens.$inferSelect;

// Notification Settings
export const notificationSettings = pgTable("notification_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }).unique(),
  enabled: boolean("enabled").notNull().default(false),
  roleIds: text("role_ids").array().notNull().default(sql`ARRAY[]::text[]`), // Array of role IDs that should receive updates
  cadence: text("cadence").notNull().default("daily"), // "daily", "weekly", "before_event"
  timeOfDay: text("time_of_day").default("09:00"), // HH:MM format for daily/weekly
  dayOfWeek: integer("day_of_week").default(1), // 0-6, Sunday=0, for weekly cadence
  eventTimingHours: integer("event_timing_hours").default(24), // hours before event for "before_event" cadence
  includeUpcomingEvents: boolean("include_upcoming_events").notNull().default(true),
  includeRecentResponses: boolean("include_recent_responses").notNull().default(true),
  includeAttendanceStats: boolean("include_attendance_stats").notNull().default(true),
  includePendingResponses: boolean("include_pending_responses").notNull().default(true),
  lastSentAt: timestamp("last_sent_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertNotificationSettingsSchema = createInsertSchema(notificationSettings).omit({
  id: true,
  createdAt: true,
});

export type InsertNotificationSettings = z.infer<typeof insertNotificationSettingsSchema>;
export type NotificationSettings = typeof notificationSettings.$inferSelect;

// Notification Sends (tracking which events have had notifications sent)
export const notificationSends = pgTable("notification_sends", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  notificationSettingsId: varchar("notification_settings_id").notNull().references(() => notificationSettings.id, { onDelete: "cascade" }),
  eventId: varchar("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  sentAt: timestamp("sent_at").notNull().defaultNow(),
});

export const insertNotificationSendSchema = createInsertSchema(notificationSends).omit({
  id: true,
  sentAt: true,
});

export type InsertNotificationSend = z.infer<typeof insertNotificationSendSchema>;
export type NotificationSend = typeof notificationSends.$inferSelect;

// Players
export const players = pgTable("players", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  userId: varchar("user_id").references(() => users.id, { onDelete: "set null" }), // Links player record to user account
  roleId: varchar("role_id").references(() => roles.id, { onDelete: "set null" }),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  dateOfBirth: text("date_of_birth"),
  gender: text("gender"),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  zip: text("zip"),
  position: text("position"),
  jerseyNumber: integer("jersey_number"),
  reliabilityScore: real("reliability_score").notNull().default(3),
  preferredBattingOrder: integer("preferred_batting_order"),
  preferredPitchingOrder: integer("preferred_pitching_order"),
  contact1Name: text("contact1_name"),
  contact1Phone: text("contact1_phone"),
  contact1Email: text("contact1_email"),
  contact1Address: text("contact1_address"),
  contact2Name: text("contact2_name"),
  contact2Phone: text("contact2_phone"),
  contact2Email: text("contact2_email"),
  contact2Address: text("contact2_address"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPlayerSchema = createInsertSchema(players).omit({
  id: true,
  createdAt: true,
});

export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type Player = typeof players.$inferSelect;

// Events
export const events = pgTable("events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  title: text("title").notNull().default("Untitled Event"),
  type: text("type").notNull(), // "game", "practice", "team_party"
  sport: text("sport").notNull().default("Baseball"), // Sport for this event
  datetime: timestamp("datetime").notNull(),
  location: text("location").notNull(),
  opponent: text("opponent"),
  homeAway: text("home_away"), // "home", "away"
  fieldType: text("field_type"), // "grass", "turf"
  cleatsAllowed: text("cleats_allowed"), // "any", "non-metal"
  jersey: text("jersey"),
  arrivalTime: text("arrival_time"),
  notes: text("notes"),
  customFieldValues: jsonb("custom_field_values"), // Stores custom field values as {fieldId: value}
  sequence: integer("sequence").notNull().default(0), // iCalendar sequence for tracking updates
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  sequence: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  datetime: z.union([
    z.date(),
    z.string().transform((val) => new Date(val)),
  ]),
});

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

// Lineups - Baseball/Softball lineup management
export const lineups = pgTable("lineups", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  eventId: varchar("event_id").notNull().unique().references(() => events.id, { onDelete: "cascade" }),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  battingOrder: jsonb("batting_order").notNull(), // Array of {playerId, position, battingSlot}
  pitchingRotation: jsonb("pitching_rotation").notNull(), // Array of {playerId, pitchingSlot}
  reserves: jsonb("reserves").notNull(), // Array of {playerId}
  generatedBy: varchar("generated_by"), // "ai" or user ID who manually created
  generatedAt: timestamp("generated_at").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => [
  index("lineups_team_id_idx").on(table.teamId),
]);

export const insertLineupSchema = createInsertSchema(lineups).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertLineup = z.infer<typeof insertLineupSchema>;
export type Lineup = typeof lineups.$inferSelect;

// Zod schemas for lineup JSONB structures
export const lineupBattingSlotSchema = z.object({
  playerId: z.string(),
  position: z.string(), // 2B, CF, SS, etc.
  battingSlot: z.number().int().min(1).max(9),
  playerName: z.string().optional(), // For display purposes
});

export const lineupPitchingSlotSchema = z.object({
  playerId: z.string(),
  pitchingSlot: z.number().int().min(1), // SP, RP, RP, RP...
  playerName: z.string().optional(), // For display purposes
});

export const lineupReserveSchema = z.object({
  playerId: z.string(),
  playerName: z.string().optional(), // For display purposes
});

export const lineupDataSchema = z.object({
  battingOrder: z.array(lineupBattingSlotSchema).refine(
    (slots) => {
      const slotNumbers = slots.map(s => s.battingSlot);
      const uniqueSlots = new Set(slotNumbers);
      return uniqueSlots.size === slotNumbers.length && slotNumbers.every(s => s >= 1 && s <= 9);
    },
    { message: "Batting slots must be unique and between 1-9" }
  ),
  pitchingRotation: z.array(lineupPitchingSlotSchema).refine(
    (slots) => {
      const playerIds = slots.map(s => s.playerId);
      const uniquePlayers = new Set(playerIds);
      return uniquePlayers.size === playerIds.length;
    },
    { message: "Pitching rotation must have unique players" }
  ),
  reserves: z.array(lineupReserveSchema),
});

export type LineupBattingSlot = z.infer<typeof lineupBattingSlotSchema>;
export type LineupPitchingSlot = z.infer<typeof lineupPitchingSlotSchema>;
export type LineupReserve = z.infer<typeof lineupReserveSchema>;
export type LineupData = z.infer<typeof lineupDataSchema>;

// Event Templates
// Custom Fields - Admin-created custom fields for templates
export const customFields = pgTable("custom_fields", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(), // Field label (e.g., "Uniform Color", "Equipment Needed")
  fieldType: text("field_type").notNull(), // "text", "textarea", "number", "select"
  options: text("options").array(), // For select fields - array of options
  placeholder: text("placeholder"), // Optional placeholder text
  createdBy: varchar("created_by").notNull(), // User ID who created this field
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertCustomFieldSchema = createInsertSchema(customFields).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCustomField = z.infer<typeof insertCustomFieldSchema>;
export type CustomField = typeof customFields.$inferSelect;

export const eventTemplates = pgTable("event_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sport: text("sport").notNull(), // Which sport this template is for
  name: text("name").notNull(), // Template name (e.g., "Home Game", "Away Practice")
  type: text("type").notNull(), // "game", "practice", "team_party"
  defaultTitle: text("default_title"), // Default title for events created from this template
  durationMinutes: integer("duration_minutes"), // Typical duration
  defaultLocation: text("default_location"),
  opponent: text("opponent"),
  homeAway: text("home_away"), // "home", "away"
  fieldType: text("field_type"), // "grass", "turf"
  cleatsAllowed: text("cleats_allowed"), // "any", "non-metal"
  jersey: text("jersey"),
  arrivalTime: text("arrival_time"),
  notes: text("notes"),
  customFieldIds: text("custom_field_ids").array().notNull().default(sql`ARRAY[]::text[]`), // IDs of custom fields to include
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertEventTemplateSchema = createInsertSchema(eventTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertEventTemplate = z.infer<typeof insertEventTemplateSchema>;
export type EventTemplate = typeof eventTemplates.$inferSelect;

// Campaigns
export const campaigns = pgTable("campaigns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  eventId: varchar("event_id").references(() => events.id, { onDelete: "cascade" }),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCampaignSchema = createInsertSchema(campaigns).omit({
  id: true,
  createdAt: true,
});

export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Campaign = typeof campaigns.$inferSelect;

// Reminders
export const reminders = pgTable("reminders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: varchar("campaign_id").notNull().references(() => campaigns.id, { onDelete: "cascade" }),
  intervalHours: integer("interval_hours").notNull(), // hours before event (e.g., 72 for 3 days)
  targetReliabilityThreshold: real("target_reliability_threshold"), // DEPRECATED: use minReliability/maxReliability instead
  minReliability: real("min_reliability"), // null = no minimum (0), range 0-5
  maxReliability: real("max_reliability"), // null = no maximum (5), range 0-5
  targetStatusFilter: text("target_status_filter"), // null = all, "pending", "maybe"
  messageTemplate: text("message_template").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertReminderSchema = createInsertSchema(reminders).omit({
  id: true,
  createdAt: true,
});

export type InsertReminder = z.infer<typeof insertReminderSchema>;
export type Reminder = typeof reminders.$inferSelect;

// Reminder Sends (tracking which reminders have been sent to which players)
export const reminderSends = pgTable("reminder_sends", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  reminderId: varchar("reminder_id").notNull().references(() => reminders.id, { onDelete: "cascade" }),
  playerId: varchar("player_id").notNull().references(() => players.id, { onDelete: "cascade" }),
  sentAt: timestamp("sent_at").notNull().defaultNow(),
});

export const insertReminderSendSchema = createInsertSchema(reminderSends).omit({
  id: true,
  sentAt: true,
});

export type InsertReminderSend = z.infer<typeof insertReminderSendSchema>;
export type ReminderSend = typeof reminderSends.$inferSelect;

// Responses
export const responses = pgTable("responses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  eventId: varchar("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  playerId: varchar("player_id").notNull().references(() => players.id, { onDelete: "cascade" }),
  status: text("status").notNull(), // "yes", "no", "maybe", "pending"
  note: text("note"),
  responseText: text("response_text"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertResponseSchema = createInsertSchema(responses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertResponse = z.infer<typeof insertResponseSchema>;
export type Response = typeof responses.$inferSelect;

// Post-game attendance
export const attendance = pgTable("attendance", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  eventId: varchar("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  playerId: varchar("player_id").notNull().references(() => players.id, { onDelete: "cascade" }),
  actuallyAttended: boolean("actually_attended").notNull(),
  confirmedAt: timestamp("confirmed_at").notNull().defaultNow(),
});

export const insertAttendanceSchema = createInsertSchema(attendance).omit({
  id: true,
  confirmedAt: true,
});

export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendance.$inferSelect;

// Reliability History
export const reliabilityHistory = pgTable("reliability_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  playerId: varchar("player_id").notNull().references(() => players.id, { onDelete: "cascade" }),
  eventId: varchar("event_id").references(() => events.id, { onDelete: "set null" }),
  oldScore: real("old_score").notNull(),
  newScore: real("new_score").notNull(),
  reason: text("reason").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertReliabilityHistorySchema = createInsertSchema(reliabilityHistory).omit({
  id: true,
  createdAt: true,
});

export type InsertReliabilityHistory = z.infer<typeof insertReliabilityHistorySchema>;
export type ReliabilityHistory = typeof reliabilityHistory.$inferSelect;

// Campaign Templates
export const campaignTemplates = pgTable("campaign_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").references(() => teams.id, { onDelete: "cascade" }), // Nullable for global admin templates
  name: text("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCampaignTemplateSchema = createInsertSchema(campaignTemplates).omit({
  id: true,
  createdAt: true,
});

export type InsertCampaignTemplate = z.infer<typeof insertCampaignTemplateSchema>;
export type CampaignTemplate = typeof campaignTemplates.$inferSelect;

// Template Reminders
export const templateReminders = pgTable("template_reminders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  templateId: varchar("template_id").notNull().references(() => campaignTemplates.id, { onDelete: "cascade" }),
  intervalHours: integer("interval_hours").notNull(),
  targetReliabilityThreshold: real("target_reliability_threshold"), // DEPRECATED: use minReliability/maxReliability instead
  minReliability: real("min_reliability"), // null = no minimum (0), range 0-5
  maxReliability: real("max_reliability"), // null = no maximum (5), range 0-5
  targetStatusFilter: text("target_status_filter"),
  messageTemplate: text("message_template").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTemplateReminderSchema = createInsertSchema(templateReminders).omit({
  id: true,
  createdAt: true,
});

export type InsertTemplateReminder = z.infer<typeof insertTemplateReminderSchema>;
export type TemplateReminder = typeof templateReminders.$inferSelect;

// Messages
export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  content: text("content"),
  imageUrl: text("image_url"),
  isPinned: boolean("is_pinned").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
}).superRefine((data, ctx) => {
  // Ensure at least one of content or imageUrl is provided
  if (!data.content && !data.imageUrl) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Message must include either text content or an image",
      path: ["content"],
    });
  }
});

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// Message Reactions
export const messageReactions = pgTable("message_reactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  messageId: varchar("message_id").notNull().references(() => messages.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  emoji: text("emoji").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertMessageReactionSchema = createInsertSchema(messageReactions).omit({
  id: true,
  createdAt: true,
});

export type InsertMessageReaction = z.infer<typeof insertMessageReactionSchema>;
export type MessageReaction = typeof messageReactions.$inferSelect;

// Relations
export const teamsRelations = relations(teams, ({ many }) => ({
  players: many(players),
  events: many(events),
  campaignTemplates: many(campaignTemplates),
  messages: many(messages),
}));

export const playersRelations = relations(players, ({ one, many }) => ({
  team: one(teams, {
    fields: [players.teamId],
    references: [teams.id],
  }),
  responses: many(responses),
  attendance: many(attendance),
  reliabilityHistory: many(reliabilityHistory),
  reminderSends: many(reminderSends),
}));

export const eventsRelations = relations(events, ({ one, many }) => ({
  team: one(teams, {
    fields: [events.teamId],
    references: [teams.id],
  }),
  campaigns: many(campaigns),
  responses: many(responses),
  attendance: many(attendance),
}));

export const campaignsRelations = relations(campaigns, ({ one, many }) => ({
  event: one(events, {
    fields: [campaigns.eventId],
    references: [events.id],
  }),
  reminders: many(reminders),
}));

export const remindersRelations = relations(reminders, ({ one, many }) => ({
  campaign: one(campaigns, {
    fields: [reminders.campaignId],
    references: [campaigns.id],
  }),
  sends: many(reminderSends),
}));

export const reminderSendsRelations = relations(reminderSends, ({ one }) => ({
  reminder: one(reminders, {
    fields: [reminderSends.reminderId],
    references: [reminders.id],
  }),
  player: one(players, {
    fields: [reminderSends.playerId],
    references: [players.id],
  }),
}));

export const responsesRelations = relations(responses, ({ one }) => ({
  event: one(events, {
    fields: [responses.eventId],
    references: [events.id],
  }),
  player: one(players, {
    fields: [responses.playerId],
    references: [players.id],
  }),
}));

export const attendanceRelations = relations(attendance, ({ one }) => ({
  event: one(events, {
    fields: [attendance.eventId],
    references: [events.id],
  }),
  player: one(players, {
    fields: [attendance.playerId],
    references: [players.id],
  }),
}));

export const reliabilityHistoryRelations = relations(reliabilityHistory, ({ one }) => ({
  player: one(players, {
    fields: [reliabilityHistory.playerId],
    references: [players.id],
  }),
  event: one(events, {
    fields: [reliabilityHistory.eventId],
    references: [events.id],
  }),
}));

export const campaignTemplatesRelations = relations(campaignTemplates, ({ one, many }) => ({
  team: one(teams, {
    fields: [campaignTemplates.teamId],
    references: [teams.id],
  }),
  templateReminders: many(templateReminders),
}));

export const templateRemindersRelations = relations(templateReminders, ({ one }) => ({
  template: one(campaignTemplates, {
    fields: [templateReminders.templateId],
    references: [campaignTemplates.id],
  }),
}));

export const messagesRelations = relations(messages, ({ one, many }) => ({
  team: one(teams, {
    fields: [messages.teamId],
    references: [teams.id],
  }),
  user: one(users, {
    fields: [messages.userId],
    references: [users.id],
  }),
  reactions: many(messageReactions),
}));

export const messageReactionsRelations = relations(messageReactions, ({ one }) => ({
  message: one(messages, {
    fields: [messageReactions.messageId],
    references: [messages.id],
  }),
  user: one(users, {
    fields: [messageReactions.userId],
    references: [users.id],
  }),
}));

export const membershipTiersRelations = relations(membershipTiers, ({ many }) => ({
  tierLimits: many(tierLimits),
  tierFeatures: many(tierFeatures),
}));

export const tierLimitsRelations = relations(tierLimits, ({ one }) => ({
  tier: one(membershipTiers, {
    fields: [tierLimits.tierId],
    references: [membershipTiers.id],
  }),
}));

export const tierFeaturesRelations = relations(tierFeatures, ({ one }) => ({
  tier: one(membershipTiers, {
    fields: [tierFeatures.tierId],
    references: [membershipTiers.id],
  }),
}));

export const subscriptionsRelations = relations(subscriptions, ({ one }) => ({
  user: one(users, {
    fields: [subscriptions.userId],
    references: [users.id],
  }),
}));

export const paymentMethodsRelations = relations(paymentMethods, ({ one }) => ({
  user: one(users, {
    fields: [paymentMethods.userId],
    references: [users.id],
  }),
}));

// Team Invitations
export const invitations = pgTable("invitations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  invitedByUserId: varchar("invited_by_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  contactType: varchar("contact_type").notNull(), // "email" or "phone"
  contactValue: text("contact_value").notNull(), // email address or phone number
  roleId: varchar("role_id").notNull().references(() => roles.id, { onDelete: "cascade" }),
  status: varchar("status").notNull().default("pending"), // "pending", "accepted", "expired", "cancelled"
  token: varchar("token").notNull().unique(), // Secure token for invitation URL
  expiresAt: timestamp("expires_at").notNull(),
  acceptedAt: timestamp("accepted_at"),
  acceptedByUserId: varchar("accepted_by_user_id").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => [
  index("idx_invitations_team_contact").on(table.teamId, table.contactValue),
  index("idx_invitations_token").on(table.token),
]);

export const insertInvitationSchema = createInsertSchema(invitations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertInvitation = z.infer<typeof insertInvitationSchema>;
export type Invitation = typeof invitations.$inferSelect;

// Team Documents (waivers, forms, etc.)
export const teamDocuments = pgTable("team_documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  fileUrl: text("file_url").notNull(), // Object storage path
  requiresSignature: boolean("requires_signature").notNull().default(true),
  version: integer("version").notNull().default(1),
  activeFrom: timestamp("active_from").notNull().defaultNow(),
  archivedAt: timestamp("archived_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  createdByUserId: varchar("created_by_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
}, (table) => [
  index("idx_team_documents_team_active").on(table.teamId, table.archivedAt),
]);

export const insertTeamDocumentSchema = createInsertSchema(teamDocuments).omit({
  id: true,
  createdAt: true,
});

export type InsertTeamDocument = z.infer<typeof insertTeamDocumentSchema>;
export type TeamDocument = typeof teamDocuments.$inferSelect;

// Document Signatures (tracking acknowledgments)
export const documentSignatures = pgTable("document_signatures", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  documentId: varchar("document_id").notNull().references(() => teamDocuments.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  invitationId: varchar("invitation_id").references(() => invitations.id, { onDelete: "set null" }),
  signedAt: timestamp("signed_at").notNull().defaultNow(),
  ipAddress: varchar("ip_address"),
  userAgent: text("user_agent"),
  documentVersion: integer("document_version").notNull(),
  acknowledgmentText: text("acknowledgment_text"), // Text typed for signature (e.g., "I agree")
}, (table) => [
  index("idx_document_signatures_document").on(table.documentId),
  index("idx_document_signatures_user").on(table.userId),
]);

export const insertDocumentSignatureSchema = createInsertSchema(documentSignatures).omit({
  id: true,
  signedAt: true,
});

export type InsertDocumentSignature = z.infer<typeof insertDocumentSignatureSchema>;
export type DocumentSignature = typeof documentSignatures.$inferSelect;

// Relations for new tables
export const invitationsRelations = relations(invitations, ({ one }) => ({
  team: one(teams, {
    fields: [invitations.teamId],
    references: [teams.id],
  }),
  invitedBy: one(users, {
    fields: [invitations.invitedByUserId],
    references: [users.id],
  }),
  acceptedBy: one(users, {
    fields: [invitations.acceptedByUserId],
    references: [users.id],
  }),
  role: one(roles, {
    fields: [invitations.roleId],
    references: [roles.id],
  }),
}));

export const teamDocumentsRelations = relations(teamDocuments, ({ one, many }) => ({
  team: one(teams, {
    fields: [teamDocuments.teamId],
    references: [teams.id],
  }),
  createdBy: one(users, {
    fields: [teamDocuments.createdByUserId],
    references: [users.id],
  }),
  signatures: many(documentSignatures),
}));

export const documentSignaturesRelations = relations(documentSignatures, ({ one }) => ({
  document: one(teamDocuments, {
    fields: [documentSignatures.documentId],
    references: [teamDocuments.id],
  }),
  user: one(users, {
    fields: [documentSignatures.userId],
    references: [users.id],
  }),
  invitation: one(invitations, {
    fields: [documentSignatures.invitationId],
    references: [invitations.id],
  }),
}));

// Payment Providers
export const paymentProviders = pgTable("payment_providers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull().unique(), // "helcim", "paypal", "venmo"
  displayName: text("display_name").notNull(), // "Helcim", "PayPal", "Venmo"
  isEnabled: boolean("is_enabled").notNull().default(false),
  isDefault: boolean("is_default").notNull().default(false),
  apiKey: text("api_key"), // Provider API key/token
  webhookSecret: text("webhook_secret"), // Webhook verification secret
  config: text("config"), // Additional JSON config (endpoints, merchant IDs, etc.)
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertPaymentProviderSchema = createInsertSchema(paymentProviders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPaymentProvider = z.infer<typeof insertPaymentProviderSchema>;
export type PaymentProvider = typeof paymentProviders.$inferSelect;

// Payment Transactions (unified log for all payment types)
export const paymentTransactions = pgTable("payment_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  providerId: varchar("provider_id").notNull().references(() => paymentProviders.id),
  providerTransactionId: text("provider_transaction_id"), // External provider's transaction ID
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  teamId: varchar("team_id").references(() => teams.id, { onDelete: "set null" }), // Null for subscription payments
  amount: integer("amount").notNull(), // Amount in cents
  currency: varchar("currency", { length: 3 }).notNull().default("USD"),
  status: varchar("status").notNull().default("pending"), // "pending", "completed", "failed", "refunded"
  type: varchar("type").notNull(), // "subscription", "team_payment", "one_time"
  description: text("description"),
  metadata: text("metadata"), // JSON: invoice links, receipt URLs, etc.
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => [
  index("idx_payment_transactions_user").on(table.userId),
  index("idx_payment_transactions_team").on(table.teamId),
  index("idx_payment_transactions_provider").on(table.providerId),
]);

export const insertPaymentTransactionSchema = createInsertSchema(paymentTransactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPaymentTransaction = z.infer<typeof insertPaymentTransactionSchema>;
export type PaymentTransaction = typeof paymentTransactions.$inferSelect;

// Subscription Payments (links transactions to user subscriptions)
export const subscriptionPayments = pgTable("subscription_payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  transactionId: varchar("transaction_id").notNull().references(() => paymentTransactions.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  tierId: varchar("tier_id").notNull().references(() => membershipTiers.id),
  billingPeriodStart: timestamp("billing_period_start").notNull(),
  billingPeriodEnd: timestamp("billing_period_end").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_subscription_payments_user").on(table.userId),
]);

export const insertSubscriptionPaymentSchema = createInsertSchema(subscriptionPayments).omit({
  id: true,
  createdAt: true,
});

export type InsertSubscriptionPayment = z.infer<typeof insertSubscriptionPaymentSchema>;
export type SubscriptionPayment = typeof subscriptionPayments.$inferSelect;

// Team Payment Requests (fees created by coaches)
export const teamPaymentRequests = pgTable("team_payment_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  createdByUserId: varchar("created_by_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(), // "Uniform Fee", "Tournament Fee", etc.
  description: text("description"),
  amount: integer("amount").notNull(), // Amount in cents
  currency: varchar("currency", { length: 3 }).notNull().default("USD"),
  dueDate: timestamp("due_date"),
  isRecurring: boolean("is_recurring").notNull().default(false),
  recurringInterval: varchar("recurring_interval"), // "monthly", "yearly", null if not recurring
  status: varchar("status").notNull().default("active"), // "active", "archived"
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => [
  index("idx_team_payment_requests_team").on(table.teamId),
]);

export const insertTeamPaymentRequestSchema = createInsertSchema(teamPaymentRequests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertTeamPaymentRequest = z.infer<typeof insertTeamPaymentRequestSchema>;
export type TeamPaymentRequest = typeof teamPaymentRequests.$inferSelect;

// Team Payments (individual player payments)
export const teamPayments = pgTable("team_payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  paymentRequestId: varchar("payment_request_id").notNull().references(() => teamPaymentRequests.id, { onDelete: "cascade" }),
  transactionId: varchar("transaction_id").notNull().references(() => paymentTransactions.id, { onDelete: "cascade" }),
  playerId: varchar("player_id").notNull().references(() => players.id, { onDelete: "cascade" }),
  userId: varchar("user_id").references(() => users.id, { onDelete: "set null" }), // Null if paid by non-user (guest)
  payerEmail: text("payer_email"), // Email used for guest payments (for receipts/audit trail)
  status: varchar("status").notNull().default("pending"), // "pending", "completed", "failed", "refunded"
  paidAt: timestamp("paid_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_team_payments_request").on(table.paymentRequestId),
  index("idx_team_payments_player").on(table.playerId),
]);

export const insertTeamPaymentSchema = createInsertSchema(teamPayments).omit({
  id: true,
  createdAt: true,
});

export type InsertTeamPayment = z.infer<typeof insertTeamPaymentSchema>;
export type TeamPayment = typeof teamPayments.$inferSelect;

// Message Logs - Track all SMS messages for attribution and compliance
export const messageLogs = pgTable("message_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  messageSid: text("message_sid").unique(), // Twilio message SID
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  eventId: varchar("event_id").references(() => events.id, { onDelete: "set null" }),
  playerId: varchar("player_id").references(() => players.id, { onDelete: "set null" }),
  campaignId: varchar("campaign_id").references(() => campaigns.id, { onDelete: "set null" }),
  direction: messageDirectionEnum("direction").notNull(), // "outbound" or "inbound"
  fromPhone: text("from_phone").notNull(), // Phone number that sent the message
  toPhone: text("to_phone").notNull(), // Phone number that received the message
  body: text("body"), // Message content
  status: text("status").notNull().default("pending"), // pending, sent, delivered, failed, received
  errorCode: text("error_code"), // Twilio error code if failed
  errorMessage: text("error_message"), // Twilio error message if failed
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => [
  index("idx_message_logs_team").on(table.teamId),
  index("idx_message_logs_event").on(table.eventId),
  index("idx_message_logs_player").on(table.playerId),
  index("idx_message_logs_sid").on(table.messageSid),
]);

export const insertMessageLogSchema = createInsertSchema(messageLogs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertMessageLog = z.infer<typeof insertMessageLogSchema>;
export type MessageLog = typeof messageLogs.$inferSelect;

// SMS Opt-Outs - Track per-team opt-out preferences for TCPA compliance
export const smsOptOuts = pgTable("sms_opt_outs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  phoneNumber: text("phone_number").notNull(), // E.164 format
  playerId: varchar("player_id").references(() => players.id, { onDelete: "set null" }), // Can be null for unknown numbers
  optedOutAt: timestamp("opted_out_at").notNull().defaultNow(),
  optedBackInAt: timestamp("opted_back_in_at"), // Track if they re-opt-in
  isOptedOut: boolean("is_opted_out").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("idx_sms_opt_outs_team_phone").on(table.teamId, table.phoneNumber),
  uniqueIndex("idx_sms_opt_outs_unique").on(table.teamId, table.phoneNumber),
]);

export const insertSmsOptOutSchema = createInsertSchema(smsOptOuts).omit({
  id: true,
  createdAt: true,
  optedOutAt: true,
});

export type InsertSmsOptOut = z.infer<typeof insertSmsOptOutSchema>;
export type SmsOptOut = typeof smsOptOuts.$inferSelect;

// Payment Provider Relations
export const paymentProvidersRelations = relations(paymentProviders, ({ many }) => ({
  transactions: many(paymentTransactions),
}));

export const paymentTransactionsRelations = relations(paymentTransactions, ({ one }) => ({
  provider: one(paymentProviders, {
    fields: [paymentTransactions.providerId],
    references: [paymentProviders.id],
  }),
  user: one(users, {
    fields: [paymentTransactions.userId],
    references: [users.id],
  }),
  team: one(teams, {
    fields: [paymentTransactions.teamId],
    references: [teams.id],
  }),
}));

// Usage Pricing Configuration (Admin-controlled)
export const usagePricing = pgTable("usage_pricing", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  smsBaseCost: numeric("sms_base_cost", { precision: 12, scale: 4 }).notNull().default("0.0079"), // Twilio's base cost
  smsMarkupType: text("sms_markup_type").notNull().default("percentage"), // 'percentage' or 'fixed'
  smsMarkupValue: numeric("sms_markup_value", { precision: 12, scale: 4 }).notNull().default("50"), // 50% markup or $0.005 fixed
  phoneNumberBaseCost: numeric("phone_number_base_cost", { precision: 12, scale: 4 }).notNull().default("2.00"), // Monthly cost per number
  phoneNumberMarkupType: text("phone_number_markup_type").notNull().default("percentage"),
  phoneNumberMarkupValue: numeric("phone_number_markup_value", { precision: 12, scale: 4 }).notNull().default("25"), // 25% markup
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertUsagePricingSchema = createInsertSchema(usagePricing).omit({
  id: true,
  updatedAt: true,
});

export type InsertUsagePricing = z.infer<typeof insertUsagePricingSchema>;
export type UsagePricing = typeof usagePricing.$inferSelect;

// Usage Tracking (Log every SMS and resource usage)
export const usageTracking = pgTable("usage_tracking", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  usageType: text("usage_type").notNull(), // 'sms', 'phone_number'
  quantity: integer("quantity").notNull().default(1), // Number of SMS or 1 for phone number
  baseCost: numeric("base_cost", { precision: 12, scale: 4 }).notNull(), // Cost before markup
  markupCost: numeric("markup_cost", { precision: 12, scale: 4 }).notNull(), // Markup amount
  totalCost: numeric("total_cost", { precision: 12, scale: 4 }).notNull(), // Total charged to customer
  metadata: jsonb("metadata"), // { campaignId, eventId, playerId, messageId, phoneNumber, etc. }
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUsageTrackingSchema = createInsertSchema(usageTracking).omit({
  id: true,
  createdAt: true,
});

export type InsertUsageTracking = z.infer<typeof insertUsageTrackingSchema>;
export type UsageTracking = typeof usageTracking.$inferSelect;

// Admin Notifications (for new user signups and other admin alerts)
export const adminNotifications = pgTable("admin_notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // 'user_signup', 'team_created', etc.
  title: text("title").notNull(),
  message: text("message").notNull(),
  metadata: jsonb("metadata"), // { userId, userEmail, userName, etc. }
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  readAt: timestamp("read_at"),
});

export const insertAdminNotificationSchema = createInsertSchema(adminNotifications).omit({
  id: true,
  createdAt: true,
});

export type InsertAdminNotification = z.infer<typeof insertAdminNotificationSchema>;
export type AdminNotification = typeof adminNotifications.$inferSelect;

// Team Notifications (for coach notifications about RSVP responses, etc.)
export const teamNotifications = pgTable("team_notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }), // Coach receiving the notification
  type: text("type").notNull(), // 'rsvp_yes', 'rsvp_no', 'rsvp_maybe', etc.
  title: text("title").notNull(),
  message: text("message").notNull(),
  metadata: jsonb("metadata"), // { eventId, playerId, playerName, eventTitle, response, etc. }
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  readAt: timestamp("read_at"),
}, (table) => [
  index("team_notifications_team_id_idx").on(table.teamId),
  index("team_notifications_user_id_idx").on(table.userId),
]);

export const insertTeamNotificationSchema = createInsertSchema(teamNotifications).omit({
  id: true,
  createdAt: true,
});

export type InsertTeamNotification = z.infer<typeof insertTeamNotificationSchema>;
export type TeamNotification = typeof teamNotifications.$inferSelect;

export const subscriptionPaymentsRelations = relations(subscriptionPayments, ({ one }) => ({
  transaction: one(paymentTransactions, {
    fields: [subscriptionPayments.transactionId],
    references: [paymentTransactions.id],
  }),
  user: one(users, {
    fields: [subscriptionPayments.userId],
    references: [users.id],
  }),
  tier: one(membershipTiers, {
    fields: [subscriptionPayments.tierId],
    references: [membershipTiers.id],
  }),
}));

export const teamPaymentRequestsRelations = relations(teamPaymentRequests, ({ one, many }) => ({
  team: one(teams, {
    fields: [teamPaymentRequests.teamId],
    references: [teams.id],
  }),
  createdBy: one(users, {
    fields: [teamPaymentRequests.createdByUserId],
    references: [users.id],
  }),
  payments: many(teamPayments),
}));

export const teamPaymentsRelations = relations(teamPayments, ({ one }) => ({
  paymentRequest: one(teamPaymentRequests, {
    fields: [teamPayments.paymentRequestId],
    references: [teamPaymentRequests.id],
  }),
  transaction: one(paymentTransactions, {
    fields: [teamPayments.transactionId],
    references: [paymentTransactions.id],
  }),
  player: one(players, {
    fields: [teamPayments.playerId],
    references: [players.id],
  }),
  user: one(users, {
    fields: [teamPayments.userId],
    references: [users.id],
  }),
}));

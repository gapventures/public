# TeamSyncAI User Guide

**Welcome to TeamSyncAI!** This guide explains how to use all the features to manage your sports team more easily.

---

## Table of Contents

1. [Getting Started](#getting-started)
2. [Understanding User Roles](#understanding-user-roles)
3. [Managing Your Team](#managing-your-team)
4. [Managing Players & Roster](#managing-players--roster)
5. [Creating & Managing Events](#creating--managing-events)
6. [SMS Campaigns & Reminders](#sms-campaigns--reminders)
7. [Attendance Tracking & Reliability Scores](#attendance-tracking--reliability-scores)
8. [Payment Requests](#payment-requests)
9. [Calendar Subscriptions](#calendar-subscriptions)
10. [Message Board](#message-board)
11. [Tasks & Documents](#tasks--documents)
12. [Settings & Customization](#settings--customization)
13. [AI Lineup Generation](#ai-lineup-generation-baseball--softball)
14. [Admin Features](#admin-features-global-admins-only)
15. [Mobile App Features](#mobile-app-features)
16. [SMS Opt-Out & Privacy](#sms-opt-out--privacy)

---

## Getting Started

### Creating Your Account

1. **Visit the landing page** and click "Log In" or "Get Started"
2. **Choose your account type:**
   - **Coach Account:** For team managers, coaches, and assistant coaches
   - **Parent Account:** For parents managing their child's player profile

3. **Fill in your information:**
   - Your email address (used for login)
   - Password (at least 6 characters)
   - First and last name
   - Phone number (for SMS notifications and password recovery)
   - SMS consent checkbox (required to receive text reminders)

4. **If you're a parent:**
   - You'll also enter your child's information:
     - Child's first and last name
     - Child's phone number
     - Child's date of birth (optional)

5. **Click "Create Account"** and you're ready to go!

### Logging In

1. Go to the **Login** page
2. Enter your email and password
3. Click "Log In"

### Forgot Your Password?

1. Click **"Forgot Password?"** on the login page
2. Enter your email address
3. You'll receive a **reset code via SMS** to your registered phone number
4. Enter the code and create a new password

---

## Understanding User Roles

TeamSyncAI uses different permission levels to control what each person can do:

### **Team Owner** (Coach who created the team)
- Full access to everything
- Can manage all team settings
- Can create/edit/delete events, players, and campaigns
- Can send payment requests
- Can assign roles to other team members

### **Coach**
- Can manage events and players
- Can send SMS reminders
- Can track attendance
- Can view responses and reliability scores
- Limited access to team settings

### **Assistant Coach**
- Similar to Coach but with fewer permissions
- Cannot manage certain settings
- Cannot create campaigns (depending on configuration)

### **Player**
- Can view events and their own attendance
- Can respond to event invitations (Yes/No/Maybe)
- Can view team roster
- Cannot edit or manage team information

### **Parent**
- Can manage their child's player profile
- Can respond to events on behalf of their child
- Can view team information
- Limited editing capabilities

### **Viewer**
- Read-only access to team information
- Can see events and roster
- Cannot make changes or send messages

### **Global Admin**
- Full system access across all teams
- Can manage global settings
- Can create campaign templates for everyone
- Can manage membership tiers and pricing

---

## Managing Your Team

### Creating a New Team

1. After logging in, go to **Teams** page
2. Click **"Create Team"**
3. Fill in team details:
   - Team name (e.g., "Hawks U12 Baseball")
   - Sport (Baseball, Softball, Soccer, Basketball, etc.)
   - Team logo (optional - upload an image)
4. Click **"Create Team"**

### Team Settings

Go to your team page and click **Settings** to customize:

#### Basic Information
- **Team Name:** Update your team's name
- **Sport:** Change the sport type
- **Team Logo:** Upload or change your team logo

#### Team Branding (Instance Name)
- Customize how your instance appears (e.g., "Hawks Manager", "Tigers Team Central")
- This name appears throughout the app for your team members
- Go to **Settings > Team Branding** to change it

#### Phone Number Management (TCPA Compliance)
Each team can have its own dedicated phone number for SMS messages:

1. **Provision a Phone Number:**
   - Go to **Settings > Phone Numbers**
   - Click **"Get New Number"**
   - Choose from available area codes
   - System will assign a Twilio number to your team

2. **Why Use Team-Specific Numbers?**
   - Legal compliance (TCPA requirements)
   - Professional appearance (consistent sender)
   - Better message delivery
   - Proper opt-out tracking per team

3. **View Message Statistics:**
   - See total messages sent
   - Track delivery success rates
   - View opt-out counts
   - Monitor message logs

4. **Release Phone Number:**
   - If no longer needed, you can release the number
   - WARNING: This cannot be undone
   - All message history is preserved

---

## Managing Players & Roster

### Adding Players to Your Team

TeamSyncAI offers several ways to add players:

#### Method 1: Add Individual Player

1. Go to your team's **Roster** page
2. Click **"Add Player"**
3. Fill in player information:
   - **Required:** First name, last name, phone number
   - **Optional:** Email, date of birth, address, position, jersey number
   - **Parent/Guardian Info:** Contact names, phones, emails
   - **Player Preferences:** Batting order, pitching order (for baseball/softball)
4. Click **"Save"**

#### Method 2: Import from CSV

1. Go to **Roster > Import Players**
2. Download the **CSV template** to see the correct format
3. Fill in your player data using Excel or Google Sheets
4. Upload the completed CSV file
5. Review the preview and click **"Import"**

**CSV Format:**
```
firstName,lastName,phone,email,dateOfBirth,position,jerseyNumber,contact1Name,contact1Phone
John,Smith,555-1234,john@example.com,2010-05-15,Pitcher,12,Jane Smith,555-5678
```

#### Method 3: Send Invitations

1. Go to **Roster > Invite Players**
2. Choose invitation method:
   - **Individual:** Enter one player's email
   - **Bulk:** Paste multiple email addresses
   - **Import from Contacts:** Select from your device contacts
3. Include optional message
4. Click **"Send Invitations"**

**What happens when you send an invitation:**
- Player receives an email with invitation link
- They create an account or log in
- They complete their profile
- They're automatically added to your team

#### Method 4: Copy from Phone Contacts

1. On mobile, go to **Roster > Add from Contacts**
2. Grant permission to access contacts
3. Select players from your phone's contact list
4. System automatically fills in names and phone numbers
5. Review and save

### Managing Player Information

#### Editing Player Profiles

1. Go to **Roster**
2. Click on a player's name
3. Click **"Edit Player"**
4. Update any information
5. Click **"Save Changes"**

#### Player Reliability Scores

Each player has a reliability score from 1-5 (explained in detail below). You can view this in the roster to identify your most dependable players.

#### Removing Players

1. Go to **Roster**
2. Click on player's name
3. Click **"Remove from Team"**
4. Confirm the action

**Note:** This removes them from the team but preserves historical data like attendance records.

### Exporting Roster

1. Go to **Roster**
2. Click **"Export to CSV"**
3. Opens in Excel/Sheets for printing or sharing

---

## Creating & Managing Events

### Creating a New Event

1. Click **"Create Event"** from Dashboard or Events page
2. Fill in event details:

#### Basic Information
- **Event Type:** Game or Practice
- **Title:** (e.g., "Hawks vs. Tigers Game 3")
- **Date & Time:** When the event occurs
- **Location:** Where to meet (supports autocomplete for addresses)

#### Game-Specific Details (if type is "game")
- **Opponent:** Team you're playing against
- **Home/Away:** Where the game is played
- **Field Type:** (e.g., Grass, Turf, Indoor)
- **Jersey Color:** Which uniforms to wear
- **Arrival Time:** When players should arrive (before game time)

#### Practice-Specific Details
- **Cleats Required:** Yes/No
- **Equipment Needed:** What to bring

#### Additional Information
- **Notes:** Any special instructions or reminders
- **Custom Fields:** Add sport-specific details

3. Click **"Create Event"**

### Viewing Events

- **Dashboard:** Shows upcoming events (next 30 days)
- **Events Page:** Full calendar view of all events
- **Click any event** to see:
  - Full event details
  - Player responses (Yes/No/Maybe/Pending)
  - Response statistics
  - Associated campaign information

### Editing Events

1. Open the event
2. Click **"Edit Event"**
3. Make your changes
4. Click **"Save Changes"**

**Note:** Changes automatically sync to calendar subscriptions within a few hours.

### Deleting Events

1. Open the event
2. Click **"Delete Event"**
3. Confirm the deletion

**Warning:** This also deletes all associated responses and campaigns.

### Event Templates

Global Admins can create reusable event templates with pre-filled fields for common event types (e.g., "Home Game Template", "Away Practice Template").

---

## SMS Campaigns & Reminders

SMS campaigns automate reminder messages to your players, reducing manual effort.

### Types of Campaigns

#### Event-Based Campaigns
- Linked to a specific event (game or practice)
- Reminders sent at scheduled times relative to the event
- Example: "3 days before game", "1 day before practice"

#### Standalone Campaigns
- Not tied to any specific event
- Used for general team announcements
- Example: "Season starting next week!", "Practice uniforms available"

### Creating a Campaign

#### For an Event:

1. **Go to the event** details page
2. Click **"Create Campaign"** or **"Manage Reminders"**
3. Choose **"Create from Template"** or **"Create Custom"**

#### Campaign Settings:
- **Campaign Name:** Internal reference (e.g., "Game Reminders - Hawks vs Tigers")
- **Target Players:** All players, or filter by reliability score
- **Reminders:** Schedule one or more reminder messages

#### Custom Template (if not using a template):

4. Click **"Add Reminder"**
5. Configure each reminder:
   - **When to Send:** Hours before the event (e.g., 72 hours = 3 days)
   - **Target by Reliability:** Optional filter (e.g., only send to players with score 3 or below)
   - **Target by Response Status:** Optional filter (e.g., only "Maybe" or "No Response")
   - **Message Template:** Write your message with variables

6. Click **"Save Campaign"**

#### For Standalone Announcements:

1. Go to **Campaigns** page
2. Click **"Create Standalone Campaign"**
3. Fill in:
   - Campaign name
   - Target players (all or filtered by reliability)
   - Message template
   - Send immediately or schedule for later
4. Click **"Create"**

### Message Variables (Personalization)

You can use these variables in your messages to automatically insert player/event details:

#### Player Variables:
- `{playerName}` - Full name (e.g., "John Smith")
- `{firstName}` - First name only (e.g., "John")

#### Team Variables:
- `{teamName}` - Your team's name (e.g., "Hawks U12")
- `{coachName}` - Team owner's name (e.g., "Coach Johnson")

#### Event Variables (event-based campaigns only):
- `{eventType}` - Game or Practice
- `{eventTitle}` - Event title
- `{date}` or `{eventDate}` - Event date
- `{time}` or `{eventTime}` - Event time
- `{location}` - Event location
- `{opponent}` - Opponent team name
- `{homeAway}` - Home or Away
- `{fieldType}` - Field type
- `{cleats}` - Cleats required (Yes/No)
- `{jersey}` - Jersey color
- `{arrivalTime}` - When to arrive

**Example Message Template:**
```
Hi {firstName}! Reminder: {teamName} has a {eventType} on {date} at {time}. 
Location: {location}. Please confirm if you can attend. Reply STOP to opt out.
```

**What player receives:**
```
Hi John! Reminder: Hawks U12 has a game on March 15 at 6:00 PM. 
Location: Lincoln Park Field 3. Please confirm if you can attend. Reply STOP to opt out.
```

### Using Campaign Templates

**Global Admins** can create reusable templates that all teams can use:

1. **Admin creates template** with pre-written reminders
2. **Coaches select template** when creating a campaign
3. **System applies template** with all reminder schedules and messages
4. **Coach can customize** messages if needed

**Benefits:**
- Consistent messaging across teams
- Saves time (no need to write from scratch)
- Best practices built-in

### Reliability-Based Targeting

You can target reminders to specific players based on their reliability score (1-5):

- **All Players:** Everyone receives the message
- **Low Reliability (1-2):** Only players who often miss events
- **Medium Reliability (3):** Average attendees
- **High Reliability (4-5):** Most dependable players
- **Custom Range:** Set your own min/max scores

**Example Use Case:**
- Send extra reminder 1 day before game only to players with score ≤ 3
- This reduces unnecessary messages to reliable players while ensuring less-reliable players get extra nudges

### Viewing Campaign Results

1. Go to **Campaigns** page or open an event
2. Click on a campaign to view:
   - **Reminder Schedule:** All planned messages
   - **Sent Messages:** Which messages have been sent
   - **Delivery Status:** Success/failed messages
   - **Responses:** Player replies and RSVPs
   - **Cost Estimate:** Expected SMS charges

### Editing or Canceling Campaigns

1. Open the campaign
2. **Edit:** Change reminder times or messages (only unsent reminders)
3. **Cancel:** Stop all future reminders
4. Click **"Save"** or **"Cancel Campaign"**

**Note:** You cannot edit messages that have already been sent.

---

## Attendance Tracking & Reliability Scores

### How Players Respond to Events

When you create a campaign, players receive an SMS with event details. They can respond:

- **Yes:** "I'm attending"
- **Maybe:** "Not sure yet"
- **No:** "Can't make it"
- **No Response:** Hasn't replied

**Players can also respond directly in the app:**
1. Log in
2. Go to **Events** or **Tasks**
3. Click on the event
4. Select Yes/No/Maybe

### Viewing Responses

1. Go to **Events**
2. Click on an event
3. See response summary:
   - **Yes:** 12 players
   - **No:** 3 players
   - **Maybe:** 2 players
   - **Pending:** 5 players (no response)

4. Click **"View Details"** to see individual player responses

### Post-Game Attendance (Marking Actual Attendance)

After an event occurs, you should mark who actually showed up. This updates reliability scores.

1. Go to the event details
2. Click **"Mark Attendance"** or **"Post-Game Confirmation"**
3. For each player, mark:
   - **Attended:** Player showed up
   - **Did Not Attend:** Player was absent

4. Click **"Save Attendance"**

### Understanding Reliability Scores

Every player has a **Reliability Score** from 1 to 5:

- **5:** Highly reliable (always shows up when they commit)
- **4:** Very reliable
- **3:** Average reliability (default for new players)
- **2:** Below average
- **1:** Unreliable (often misses events)

#### How Scores Change:

Scores automatically update based on actual attendance vs. responses:

| Response | Attended | Did Not Attend |
|----------|----------|----------------|
| **Yes**  | +1 point | -1 point       |
| **Maybe**| +0.5 points | -0.5 points |
| **No**   | +0.5 points (bonus for showing up anyway) | 0 (no penalty) |
| **No Response** | 0 | 0 |

**Scores are capped between 1 and 5.**

#### Why This Matters:

- **Target unreliable players** with extra reminders
- **Recognize dependable players** (less nagging needed)
- **Inform lineup decisions** (for baseball/softball AI lineups)
- **Track trends** over time

#### Viewing Score History:

1. Go to **Roster**
2. Click on a player
3. View **"Reliability History"** tab to see how their score changed over time

---

## Payment Requests

TeamSyncAI integrates with **Helcim** to handle team payments securely (fees, equipment, uniforms, etc.).

### Creating a Payment Request

1. Go to your team page
2. Click **"Payments"** tab
3. Click **"Create Payment Request"**
4. Fill in:
   - **Title:** (e.g., "Season Fees", "Uniform Payment")
   - **Description:** Optional details
   - **Amount:** In dollars (e.g., 150.00)
   - **Due Date:** Optional deadline
   - **Recurring:** One-time or recurring (monthly/yearly)
5. Click **"Create Request"**

### Sending Payment Links to Players

After creating a payment request:

1. Go to **Payments** page
2. Find the payment request
3. For each player who needs to pay:
   - Click **"Send Payment Link"**
   - System generates a secure, unique link
   - Link sent via SMS or email
   - Link expires after 48 hours (for security)

### How Players Pay (Guest Payments)

Players receive a payment link and don't need to log in:

1. **Click the payment link** (from SMS/email)
2. **Enter email address** (must match player record for security)
3. **Confirm email** (re-enter to verify)
4. **Click "Proceed to Payment"**
5. **Helcim checkout opens** (secure payment form)
6. **Enter payment details:**
   - Credit/debit card information
   - Billing address
7. **Complete payment**
8. **Confirmation shown** and email receipt sent

### Tracking Payment Status

1. Go to **Payments** page
2. View payment request details:
   - **Pending:** Not yet paid
   - **Completed:** Payment successful
   - **Failed:** Payment attempt failed

3. See which players have paid and which haven't

### Payment Security Features

- **Token-based links:** Each link is unique and single-use
- **Email verification:** Player's email must match record
- **Expiration:** Links expire after 48 hours (default)
- **SHA-256 hashing:** Tokens never stored in plain text
- **One-time use:** Link cannot be reused after payment
- **Audit trail:** All payment attempts logged

### Viewing Payment History

1. Go to **Payments** tab
2. Click on a payment request
3. View:
   - Total amount collected
   - Individual payment transactions
   - Payment dates and methods
   - Transaction IDs (for Helcim support)

---

## Calendar Subscriptions

Subscribe to your team's calendar in Google Calendar, Apple Calendar, or any calendar app that supports iCalendar (.ics) format.

### How to Subscribe

#### Option 1: Download Calendar File

1. Go to your team page
2. Click **"Calendar"** or **"Export Calendar"**
3. Click **"Download .ics file"**
4. Open the file in your calendar app
5. Events are imported

**Note:** This is a one-time import. Changes won't sync automatically.

#### Option 2: Subscribe to Live Calendar (Recommended)

1. Go to your team page
2. Click **"Calendar Subscription"**
3. Copy the **subscription URL** (starts with `webcal://`)
4. Add to your calendar app:

**Google Calendar:**
- Click **"+ Add Other Calendars"**
- Select **"From URL"**
- Paste the webcal URL
- Click **"Add Calendar"**

**Apple Calendar (iOS/Mac):**
- Open Calendar app
- Go to **File > New Calendar Subscription** (Mac) or **Settings > Accounts > Add Account > Other** (iOS)
- Paste the webcal URL
- Click **"Subscribe"**
- Choose refresh frequency (recommended: every hour)

**Outlook:**
- Go to **Calendar**
- Click **"Add Calendar"**
- Select **"Subscribe from web"**
- Paste the webcal URL
- Click **"Import"**

### What Syncs to Your Calendar?

- Event title
- Date and time
- Location
- Event type (game or practice)
- Opponent (if applicable)
- Home/Away
- Jersey color
- Arrival time
- Notes

### How Often Does It Update?

- Your calendar app checks for changes periodically (usually every 30 minutes to a few hours)
- When you update an event in TeamSyncAI, it will appear in your subscribed calendar within a few hours
- Some apps let you choose refresh frequency

### Managing Subscriptions

- **Unsubscribe:** Remove the calendar subscription from your calendar app
- **Re-subscribe:** Use the same URL to re-add if you accidentally removed it

---

## Message Board

The Message Board is a team-wide communication hub for announcements, updates, and discussions.

### Posting a Message

1. Go to your team's **Message Board** tab
2. Type your message in the text box
3. **Optional:** Upload an image
4. Click **"Post"**

### Viewing Messages

- All team members can see posted messages
- Messages appear in chronological order (newest first)
- Each message shows:
  - Author's name
  - Timestamp
  - Message content
  - Attached image (if any)

### Pinning Important Messages

Coaches/Admins can pin important announcements to the top:

1. Click on a message
2. Click **"Pin Message"**
3. Pinned messages stay at the top of the board

### Deleting Messages

**Team owners** can delete messages:

1. Click on the message
2. Click **"Delete"**
3. Confirm deletion

---

## Tasks & Documents

The **Tasks** page shows pending items that require your attention.

### Types of Tasks

#### 1. **Events Needing RSVP**
- Events you haven't responded to yet
- Click **"Respond"** to mark Yes/No/Maybe

#### 2. **Documents to Sign**
- Team documents requiring your signature (waivers, consent forms, etc.)
- Click **"Sign Document"** to review and sign

### Signing Documents

When invited to a team with required documents:

1. Go to **Tasks** or accept team invitation
2. Review each document
3. Check **"I agree"** or enter acknowledgment text
4. Click **"Sign"**
5. Document marked as signed

**Note:** You cannot join a team until all required documents are signed.

---

## Settings & Customization

### User Profile Settings

1. Go to **Settings** or click your name in the sidebar
2. Click **"Profile"**
3. Update:
   - First and last name
   - Phone number
   - Email address
   - Profile picture
   - Preferred position (for player accounts)
4. Click **"Save Changes"**

### Team Branding

Team owners can customize their instance:

1. Go to **Settings > Team Branding**
2. Set **Instance Name** (e.g., "Hawks Manager", "Tigers Central")
3. This name appears in:
   - App header
   - Email notifications
   - Landing page (for your team)
4. Click **"Save"**

### Organization Logo

Coaches can upload an organization/league logo:

1. Go to **Settings**
2. Click **"Upload Organization Logo"**
3. Choose image file
4. Logo appears on landing page and communications

### Notification Preferences

1. Go to **Settings > Notifications**
2. Choose preferences:
   - Email notifications
   - SMS notifications
   - Notification frequency
3. **Note:** SMS opt-out is handled separately (see below)

---

## AI Lineup Generation (Baseball & Softball)

**Available for:** Coach and Pro membership tiers  
**Sports:** Baseball and Softball only

The AI Lineup Generator uses Google Gemini AI to create optimal batting orders, defensive positions, and pitching rotations.

### How It Works

The AI considers:
- **Player Positions:** Preferred defensive positions
- **Batting Preferences:** Preferred batting order slot
- **Pitching Preferences:** Preferred pitching rotation slot
- **Reliability Scores:** More reliable players get priority
- **Attendance:** Only includes players who confirmed attendance
- **Traditional Strategy:** Follows baseball/softball lineup conventions

### Generating a Lineup

1. **Create an event** (must be Baseball or Softball game)
2. **Wait for player responses** (or mark attendance)
3. Go to the event details page
4. Click **"Generate Lineup"** or **"AI Lineup"**
5. System generates:
   - **Batting Order:** Slots 1-9 (or more) with assigned defensive positions
   - **Pitching Rotation:** Starting pitcher (SP) and relief pitchers (RP)
   - **Reserves:** Players not in starting lineup
6. **Review the lineup**
7. **Edit if needed:** Drag and drop to rearrange
8. Click **"Save Lineup"**

### Setting Player Preferences

To help the AI make better decisions:

1. Go to **Roster**
2. Click on a player
3. Edit player profile:
   - **Preferred Batting Order:** 1-9 (or 0 for no preference)
   - **Preferred Pitching Order:** 1 = starter, 2+ = reliever, 0 = doesn't pitch
   - **Position:** Primary defensive position
4. Click **"Save"**

### Viewing Saved Lineups

1. Go to **Events**
2. Click on a game
3. Click **"View Lineup"** tab
4. See:
   - Batting order with positions
   - Pitching rotation
   - Reserves
   - Who generated it (AI or manual)

### Manual Lineup Editing

You can also create lineups manually (without AI):

1. Go to event details
2. Click **"Create Lineup"**
3. Manually assign:
   - Each player to a batting slot
   - Each player to a defensive position
   - Pitching rotation
4. Save

---

## Admin Features (Global Admins Only)

Global Admins have system-wide privileges for platform management.

### Accessing Admin Settings

1. Go to **Admin** page (visible only to Global Admins)
2. Choose from admin sections:
   - Landing Page Management
   - Campaign Templates
   - Event Templates
   - Membership Tiers
   - Usage Pricing

### Managing Landing Page Content

Global Admins can customize the public landing page:

1. Go to **Admin > Landing Page**
2. Edit:
   - **Hero Title:** Main headline
   - **Hero Subtitle:** Supporting text
   - **Call-to-Action Button:** Button text
   - **Features:** List of feature highlights
   - **Logo:** Upload organization logo
3. Click **"Save Changes"**

### Creating Campaign Templates

Create reusable SMS campaign templates for all teams:

1. Go to **Admin > Campaign Templates**
2. Click **"Create Template"**
3. Fill in:
   - **Template Name:** (e.g., "Standard Game Reminders")
   - **Description:** What this template is for
4. Click **"Add Reminder"** for each reminder in the template:
   - **Interval (hours before event):** e.g., 72, 24, 2
   - **Target Reliability Range:** Optional (e.g., 1-3 for less reliable players)
   - **Target Response Status:** Optional (e.g., "maybe" or "pending")
   - **Message Template:** Write message with variables
5. Click **"Save Template"**

**Example Template: "3-Reminder Game Campaign"**
- Reminder 1: 72 hours before (all players)
- Reminder 2: 24 hours before (only "maybe" and "pending")
- Reminder 3: 2 hours before (only "pending" and reliability ≤ 3)

### Creating Event Templates

Create reusable event configurations:

1. Go to **Admin > Event Templates**
2. Click **"Create Template"**
3. Fill in:
   - **Template Name:** (e.g., "Home Game Template")
   - **Sport:** Baseball, Soccer, etc.
   - **Event Type:** Game or Practice
   - **Pre-filled Fields:** Location, arrival time, notes, etc.
4. Click **"Save"**

Teams can then select templates when creating events, auto-filling common details.

### Managing Membership Tiers

1. Go to **Admin > Membership Tiers**
2. **Create/Edit Tiers:**
   - Tier name (e.g., "Free", "Coach", "Pro")
   - Features included
   - Monthly/yearly pricing
   - Maximum teams allowed
   - SMS credits included
3. Click **"Save"**

### Setting Usage Pricing

Configure pay-per-usage pricing for SMS:

1. Go to **Admin > Usage Pricing**
2. Set:
   - **Base Cost per SMS:** Your Twilio/Plivo cost
   - **Markup Percentage:** Your profit margin
   - **Total Price:** What teams pay per SMS
3. Click **"Save"**

**How it works:**
- Teams are charged per SMS sent
- Cost appears in team's usage dashboard
- Helps track and bill SMS expenses

---

## Mobile App Features

TeamSyncAI is a **Progressive Web App (PWA)**, which means it works like a native mobile app but runs in your web browser.

### Installing on Mobile

#### iPhone/iPad:

1. Open TeamSyncAI in **Safari**
2. Tap the **Share** button
3. Scroll down and tap **"Add to Home Screen"**
4. Tap **"Add"**
5. App icon appears on your home screen

#### Android:

1. Open TeamSyncAI in **Chrome**
2. Tap the **menu** (three dots)
3. Tap **"Add to Home Screen"** or **"Install App"**
4. Tap **"Install"**
5. App icon appears on your home screen

### Mobile-Specific Features

- **Offline Mode:** View previously loaded data without internet
- **Push Notifications:** (if enabled) Receive event reminders
- **Add from Contacts:** Import players from your phone's contact list
- **Responsive Design:** Optimized layouts for small screens
- **Bottom Navigation:** Easy thumb-friendly navigation on phones

### Mobile Navigation

- **Bottom Navigation Bar:** Quick access to Dashboard, Events, Teams, Tasks
- **Sidebar Menu:** Access all features from the hamburger menu
- **Swipe Gestures:** Navigate between pages (depending on browser)

---

## SMS Opt-Out & Privacy

TeamSyncAI is fully **TCPA compliant**, meaning we respect privacy laws and opt-out requests.

### How Opt-Out Works

Players can opt out of SMS messages at any time by replying **"STOP"** to any message.

**What happens when someone opts out:**
1. They reply "STOP" to any SMS from your team
2. System automatically records the opt-out
3. Future messages to that number are blocked for your team
4. Player can still use the app normally
5. Player's opt-out applies only to SMS, not email

### Checking Opt-Out Status

1. Go to **Settings > Phone Numbers** (team owners only)
2. View **"Opt-Outs"** tab
3. See list of opted-out phone numbers
4. **Note:** Players can opt back in by contacting you directly

### Team-Specific Opt-Outs

- Each team's opt-outs are separate
- If a player opts out from Team A, they can still receive messages from Team B
- This is enforced by team-specific phone numbers

### Privacy & Security

- **Phone numbers normalized** to prevent bypass (e.g., `(555) 123-4567` and `+15551234567` are treated the same)
- **Canonical matching** ensures all format variations are blocked
- **Message logs** track all sent/received messages for compliance
- **Opt-out enforcement** happens before every SMS send

### Re-Opting In

If a player wants to receive messages again:

1. They must contact the team owner directly
2. Team owner manually removes them from opt-out list
3. **Note:** This feature may require admin assistance

---

## Frequently Asked Questions

### Can I manage multiple teams?

Yes! You can create and manage multiple teams. Switch between them using the Teams page or sidebar menu.

### Can players see other players' phone numbers?

No. Players can only see names and general roster information. Contact details are private unless you share them separately.

### What happens if I delete an event?

All responses, campaigns, and lineup data for that event are also deleted. This cannot be undone.

### How accurate is the AI lineup generator?

The AI uses best practices for baseball/softball strategy and player preferences. However, you should always review and adjust based on your coaching knowledge.

### Can I export my team data?

Yes, you can export roster data to CSV at any time from the Roster page.

### How do I cancel my membership?

Go to **Settings > Membership** and click **"Cancel Subscription"**. You'll retain access until the end of your billing period.

### Are my payment details secure?

Yes! All payments are processed through Helcim, a PCI-compliant payment processor. TeamSyncAI never stores credit card information.

### Can parents manage multiple children?

Yes, parent accounts can be associated with multiple player records.

### What if a player doesn't have a phone?

You can still add them to the roster. They won't receive SMS reminders but can view events in the app if they have an email/account.

### How do I report a problem?

Contact support through the app or email your administrator.

---

## Getting Help

**Need more assistance?**

- **In-App Support:** Look for the help icon in the sidebar
- **Contact Your Admin:** For team-specific questions
- **Email Support:** Contact platform support (check your welcome email)
- **Community:** Join the TeamSyncAI user community (if available)

---

*Last Updated: November 19, 2025*

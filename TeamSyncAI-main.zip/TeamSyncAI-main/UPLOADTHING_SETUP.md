# UploadThing Setup Guide

## Overview

UploadThing provides portable file upload functionality that works on both Replit and Render (and any other Node.js hosting platform). It handles team logos, organization logos, and document uploads (waivers, forms, etc.).

## Why UploadThing?

- **Portable**: Works on Replit, Render, and any Node.js server
- **Simple**: 10-minute setup with minimal configuration
- **Affordable**: $10/month for 100 GB storage (free tier: 10 GB)
- **Secure**: Built-in authentication and file validation
- **Fast**: Global CDN for quick file delivery

## Setup Steps

### 1. Create UploadThing Account

1. Go to https://uploadthing.com/sign-in
2. Sign up with your email or GitHub account
3. Create a new project (e.g., "TeamSyncAI")

### 2. Get Your API Token

1. Go to your UploadThing dashboard: https://uploadthing.com/dashboard
2. Click on your project
3. Navigate to "API Keys" section
4. Copy your **UPLOADTHING_TOKEN**

### 3. Add Environment Variable

#### On Replit:
1. Go to the "Secrets" tab (lock icon in sidebar)
2. Add a new secret:
   - Key: `UPLOADTHING_TOKEN`
   - Value: (paste your token from step 2)

#### On Render:
1. Go to your Render dashboard
2. Click on your web service
3. Go to "Environment" tab
4. Click "Add Environment Variable"
5. Add:
   - Key: `UPLOADTHING_TOKEN`
   - Value: (paste your token from step 2)
6. Click "Save Changes"
7. Render will automatically redeploy with the new variable

### 4. Test File Uploads

Once the environment variable is set:

1. Log in to your app
2. Go to Settings or Team Detail page
3. Try uploading a logo
4. You should see the upload progress and success message

## File Upload Limits

### Logo Uploader:
- **Max file size**: 4 MB
- **Allowed types**: Images only (JPG, PNG, GIF, WebP)
- **Max files**: 1 per upload

### Document Uploader:
- **Max file size**: 8 MB
- **Allowed types**: PDF, Word documents, Images
- **Max files**: 1 per upload

## How It Works

1. **Frontend**: User clicks upload button
2. **Authentication**: UploadThing verifies user session
3. **Upload**: File uploads directly to UploadThing's CDN (S3-backed)
4. **Storage**: File URL is saved in your database
5. **Access**: Files are publicly accessible via CDN URL

## Pricing

### Free Tier:
- 10 GB storage
- Suitable for testing and small teams

### Paid Plan:
- $10/month for 100 GB storage
- Recommended for production use

## Backwards Compatibility

The app supports both:
- **UploadThing URLs** (new): `https://utfs.io/...`
- **Legacy Replit URLs** (old): `/objects/...` (read-only)

Existing logos and documents on Replit will continue to work. New uploads will use UploadThing.

## Troubleshooting

### Upload fails with "Unauthorized"
- Check that `UPLOADTHING_TOKEN` is set correctly
- Ensure you're logged in to the app
- Restart your server after adding the env variable

### Upload succeeds but file doesn't appear
- Check browser console for errors
- Verify the file URL was saved to the database
- Check that the file type is allowed (images for logos, PDF/docs for documents)

### "Logo upload is temporarily disabled"
- This message appears if UploadThing is not configured
- Add the `UPLOADTHING_TOKEN` environment variable
- Restart your server

## Support

For UploadThing-specific issues, check their documentation: https://docs.uploadthing.com/

For TeamSyncAI integration issues, check the server logs for `[UploadThing]` prefixed messages.

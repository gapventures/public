# TeamSyncAI - Design Guidelines

## Design Approach

**Selected Framework**: Design System Approach combining Linear's typography clarity with Material Design's component structure

**Rationale**: TeamSyncAI is a utility-focused productivity tool requiring efficiency, data clarity, and consistent usability. Coaches need quick access to attendance information, roster management, and campaign controls without visual distraction.

**Core Principles**:
- Information clarity over visual flair
- Fast data scanning and decision-making
- Consistent interaction patterns across features
- Mobile-responsive for on-the-go coaches

---

## Typography System

**Primary Font**: Inter (via Google Fonts CDN)
- Headings: 600 weight
- Body: 400 weight  
- Data/Numbers: 500 weight (tabular numbers variant)

**Responsive Type Scale** (using CSS clamp() for fluid scaling):
- Page Titles (h1): 24px-30px (responsive via --text-3xl)
- Section Headers (h2): 20px-24px (responsive via --text-2xl)
- Card Titles (h3): 18px-20px (responsive via --text-xl)
- Body Text: text-base (16px) / text-sm (14px) on mobile
- Secondary Text: text-sm (14px) / text-xs (12px) on mobile
- Micro Labels: text-xs (12px)

**Mobile Typography Rules**:
- Use semantic HTML tags (h1, h2, h3) which automatically scale via CSS variables
- Body text reduces to text-sm on mobile for better readability
- Always use `text-sm md:text-base` for secondary text that appears below headings
- Enable word-break utilities (.break-words-safe) on long text that might overflow

**Hierarchy Rules**:
- Page titles use 600 weight with tight tracking
- Data tables use tabular-nums for number alignment
- Status badges use 500 weight uppercase at text-xs
- Player names in lists use 500 weight for emphasis

---

## Layout System

**Mobile-First Spacing**: All layouts start mobile and scale up

**Spacing Primitives**:
- Mobile: 4px (1), 8px (2), 16px (4)
- Desktop: 16px (4), 24px (6), 32px (8)

**Grid Structure**:
- Main container: w-full max-w-7xl with responsive padding
  - Mobile: px-4 py-4
  - Tablet: sm:px-6 sm:py-6
  - Desktop: no additional changes (inherits sm)
- Dashboard cards: gap-4 md:gap-6
- Form fields: gap-4 (consistent across all breakpoints)
- List items: py-2 md:py-3
- Section padding: py-6 md:py-8

**Responsive Grid Patterns**:
- Two-column forms: `grid-cols-1 md:grid-cols-2` 
- Three-column cards: `grid-cols-1 md:grid-cols-2 lg:grid-cols-3`
- Always start with single column, add breakpoints for larger screens

**Container Guidelines**:
- Use `min-w-0` on flex children to prevent overflow
- Use `break-words-safe` utility class for long text
- Never use fixed padding (p-6) without responsive variants

**Responsive Breakpoints**:
- **Mobile-first required**: All components must work on 375px screens
- sm (640px): Increase padding from px-4 to px-6
- md (768px): Activate multi-column layouts, show desktop sidebar
- lg (1024px): Optional - only for 3+ column grids

---

## Component Library

### Navigation
**Top Navigation Bar**:
- Fixed position with backdrop blur
- Height h-16
- Logo left, team switcher center, user profile right
- Notification bell icon with badge counter for pending responses

**Side Navigation** (Desktop):
- Width w-64 fixed on left
- Items: Dashboard, Teams, Events, Campaigns, Settings
- Active state with subtle left border accent
- Icon + label layout with py-3 spacing

### Dashboard Components

**Attendance Overview Cards** (Primary Feature):
Three-column grid (single column mobile):
- YES Card: Player count header, scrollable list with avatars
- NO Card: Players with truncated reason notes
- PENDING/MAYBE Card: Unreplied players with reliability score indicators

Card structure:
- p-6 padding
- Rounded corners (rounded-lg)
- Subtle shadow (shadow-sm)
- Header with count badge
- Scrollable list max-h-96

**Player List Items**:
- Avatar circle (8x8 units) with initials fallback
- Name in 500 weight
- Secondary info (reliability score, note) in text-sm
- Manual override button (ghost style) on hover
- Response timestamp in micro text

### Event Cards
**Event List View**:
- Compact card design with p-4
- Left border stripe indicating event type
- Event title (text-lg 600 weight)
- Date/time with calendar icon
- Quick stats: X/Y confirmed, reliability average
- Action buttons: View Dashboard, Edit, Send Reminder

**Event Detail Headers**:
- Full-width banner with key info grid
- Game details in 2-column layout (home/away, field type, cleats, jersey, arrival time)
- Large status indicators showing response counts
- Export CSV button prominent in top-right

### Forms

**Event Creation Form**:
- Two-column layout on desktop (single on mobile)
- Grouped sections with section headers
- Standard fields with consistent h-11 input height
- Custom field section with add/remove buttons
- Date/time pickers with calendar popover
- Location autocomplete with map preview suggestion

**Bulk Upload Interface**:
- Drag-and-drop zone with dashed border
- Template download button
- Preview table of parsed data before import
- Error highlighting for invalid rows

**Reminder Campaign Builder**:
- Timeline visualization showing reminder schedule
- Add reminder button creates new timeline node
- Each reminder node shows: timing, target group, message preview
- Message template editor with variable insertion dropdown
- Live preview panel on right showing sample message

### Data Tables

**Roster Management Table**:
- Sticky header row
- Columns: Avatar, Name, Phone (masked), Reliability Score, Actions
- Inline editing for reliability score (click to edit)
- Bulk actions checkbox column
- Sort indicators in headers
- Row hover state with action buttons reveal

**Post-Game Confirmation View**:
- Expected vs Actual attendance comparison
- Three-section layout: Confirmed & Showed, Confirmed & No-Show, Not Confirmed & Showed
- Checkbox interface to mark attendance
- Reliability score change indicators (+1, -1) shown inline
- Submit confirmation button saves changes

### Status Badges
- YES: Solid badge with checkmark icon
- NO: Outlined badge with X icon  
- MAYBE: Soft badge with question icon
- PENDING: Gray badge with clock icon
- Pill shape (rounded-full) with px-3 py-1

### Buttons
Primary actions: Solid style with px-4 py-2
Secondary actions: Outlined style
Ghost actions: Text-only with hover background
Icon buttons: Square with p-2, rounded

---

## Animations

**Minimal Animation Strategy**:
- Real-time updates: Gentle fade-in for new player responses (200ms)
- List sorting: 150ms ease transition
- Modal/drawer: Slide-in from right (250ms)
- No scroll animations, parallax, or decorative motion
- Loading states: Simple spinner, no skeleton screens

---

## Images

**Usage**: Minimal - this is a data-focused application

**Avatar Placeholders**: 
- Use initials with varied background hues based on name hash
- Upload option for team logo (appears in navigation)
- No hero images or decorative photography
- Icon library: Heroicons (outline style) for UI elements

---

## Layout Patterns by View

**Dashboard Landing**:
- Top metrics bar: Total teams, upcoming events, response rate
- Event list with filters (upcoming, past, by team)
- Quick action floating button for "Create Event"

**Event Dashboard** (Critical View):
- Event header with all game details
- Three-column attendance cards as primary focus
- Timeline showing reminder history sent
- Manual message composer at bottom for ad-hoc texts

**Team Management**:
- Team header with stats
- Roster table as main content
- Add player form in slide-out drawer
- Bulk import option in top toolbar

**Campaign Builder**:
- Two-panel layout: Timeline left (40%), Configuration right (60%)
- Save as template option for reusable campaigns
- Test message feature to send to coach's phone

**Settings**:
- Tabbed interface: Profile, Teams, Integrations, Billing
- Twilio connection status card
- API key management with masked display

---

## Responsive Behavior

**Critical Mobile Rules**:
1. **Test on 375px width minimum** - iPhone SE and small Android devices
2. **Prevent horizontal scroll** - No element should cause page-wide overflow
3. **Touch targets minimum 44px** - All interactive elements (buttons, links, inputs)
4. **Readable line length** - Max 65 characters per line on mobile

**Mobile Layout Patterns**:
- **Sidebar**: Hidden by default on mobile, shown via trigger on desktop
- **Tables**: Hidden on mobile (`hidden md:block`), replaced with card layout (`md:hidden`)
- **Forms**: Multi-column forms collapse to single column with `grid-cols-1 md:grid-cols-2`
- **Cards**: Stack vertically on mobile, multi-column on desktop
- **Navigation**: Bottom nav bar on mobile, sidebar on desktop

**Mobile-Specific Components**:
- Bottom navigation bar (< md breakpoint)
- Card-based player lists (instead of tables)
- Full-screen modals (vs side panels on desktop)
- Collapsible sections with accordion pattern

**Overflow Prevention**:
- Use `overflow-x-auto` wrapper for unavoidable wide content
- Apply `min-w-0` to flex children
- Use `truncate` or `break-words-safe` for long text
- Set `max-w-full` on images and embedded content

**Touch Interaction**:
- Minimum button height: 44px (use default Button sizes)
- Comfortable spacing between touch targets: minimum 8px gap
- Use ghost/outline buttons sparingly on mobile (harder to tap)

**Testing Checklist**:
- [ ] No horizontal scroll at 375px width
- [ ] All text readable without zoom
- [ ] Forms submit successfully on mobile
- [ ] Touch targets are ≥44px
- [ ] Cards/tables adapt to narrow screens